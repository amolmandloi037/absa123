package com.absa.amol.debitcardlimits.sparrow.mapper;

import java.util.ArrayList;
import java.util.List;

import javax.json.bind.Jsonb;
import javax.json.bind.JsonbBuilder;

import com.absa.amol.debitcardlimits.sparrow.model.retrieve.DebitCardLimitsRetReqWrapper;
import com.absa.amol.debitcardlimits.sparrow.model.retrieve.DebitCardLimitsRetRes;
import com.absa.amol.debitcardlimits.sparrow.model.retrieve.SorRetRes;
import com.absa.amol.debitcardlimits.sparrow.model.retrieve.SorRetResLimits;
import com.absa.amol.util.exception.ApiRequestException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.utility.CommonUtil;

public class DebitCardLimitsRetMapper {

	private static final Logger LOGGER = LoggerFactory.getLogger(DebitCardLimitsRetMapper.class);

	public List<DebitCardLimitsRetRes> setRetResponse(String response,
			DebitCardLimitsRetReqWrapper debitCardLimitsRetReqWrapper) throws Exception {
		List<DebitCardLimitsRetRes> list = null;
		LOGGER.info("setRetResponse", debitCardLimitsRetReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(),
				"", "");
			try(Jsonb jsonb = JsonbBuilder.create()){
			SorRetRes sorRetRes = jsonb.fromJson(response, SorRetRes.class);

			DebitCardLimitsRetRes resp = null;
			if (CommonUtil.isNotNull(sorRetRes.getData()) && CommonUtil.isNotNull(sorRetRes.getData().getResult())
					&& sorRetRes.getData().getResult().equalsIgnoreCase("OK")) {
				list = new ArrayList<>();
				for (SorRetResLimits sorRetResLimits : sorRetRes.getData().getLimits()) {
					resp = new DebitCardLimitsRetRes();
					resp.setClassName(sorRetResLimits.getClassName());
					resp.setLimitId(sorRetResLimits.getId());
					resp.setLimitMaximum(sorRetResLimits.getLimitMaximum());
					resp.setLimitMinimum(sorRetResLimits.getLimitMinimum());
					resp.setLimitValue(sorRetResLimits.getLimitValue());
					resp.setName(sorRetResLimits.getName());
					resp.setPeriod(sorRetResLimits.getPeriod());
					resp.setType(sorRetResLimits.getType());
					resp.setLimitUsed(sorRetResLimits.getLimitUsed());
					resp.setLimitRemaining(sorRetResLimits.getLimitRemaining());
					list.add(resp);
				}
			} else {
				LOGGER.error("setRetResponse",
						debitCardLimitsRetReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(), sorRetRes.getData().getError(),
						sorRetRes.getData().getErrorText());
				throw new ApiRequestException("400", sorRetRes.getData().getErrorText());
			}
		return list;

	}

}
}
