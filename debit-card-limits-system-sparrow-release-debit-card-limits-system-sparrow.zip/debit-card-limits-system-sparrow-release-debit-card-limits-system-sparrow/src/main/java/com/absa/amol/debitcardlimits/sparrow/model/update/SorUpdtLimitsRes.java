package com.absa.amol.debitcardlimits.sparrow.model.update;

import javax.json.bind.annotation.JsonbProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class SorUpdtLimitsRes {

	private String id;
	private String name;
	private String type;
	private String period;

	@JsonbProperty(value = "class")
	private String className;

	private String limitValue;
	private String limitMinimum;
	private String limitMaximum;

	private String limitUsed;
	private String limitRemaining;

}
