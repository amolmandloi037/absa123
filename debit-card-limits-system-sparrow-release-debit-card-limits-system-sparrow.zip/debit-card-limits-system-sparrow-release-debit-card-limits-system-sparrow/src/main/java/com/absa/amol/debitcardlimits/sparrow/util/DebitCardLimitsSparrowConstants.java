package com.absa.amol.debitcardlimits.sparrow.util;

public final class DebitCardLimitsSparrowConstants {

	private DebitCardLimitsSparrowConstants() {

	}
	
	public static final String DEBIT_CARD_LIMITS_RETRIEVAL = "debitCardLimitsRetrieval";

	
	public static final String BLANK = "";
	public static final String CONFIG_CLASS_NAME = "DebitCardLimitsSparrowConfig";
	public static final String EXCEPTION_PROCESSOR = "ExceptionProcessor";
	public static final String INTERNAL_ERROR_CODE = "500";
	public static final String SOR_DOWN_MSG = "SOR Service Unavailable";
	public static final String FAILURE_MSG = "Failure";
	public static final String FALLBACK_METHOD_FOR_TIMEOUT = "fallbackForTimeout";
	public static final String LOCATION_CODE = "ebox.accountManagement.enquireAccountConduct.LocationCode";
	public static final String M_DATA_FOUND = "Data Found";
	public static final String M_EXCEPTION_HANDLER = "exceptionHandler";
	public static final String M_FALL_BACK_FOR_TIMEOUT = "10000";
	public static final String M_INTERNAL_SERVER_ERROR = "Internal Server Error";
	public static final String M_PARTIAL_DATA_FOUND = "Partial Data Found";
	public static final String M_PROCESS = "process";
	public static final String M_PROCESS_RESP = "process method in Response processor";
	public static final String M_VALIDATE_REQUEST = "Validating Request ";
	public static final String M_SERVER_ERROR = "Server Error";
	public static final String BAD_REQ_CODE = "400";
	public static final String BAD_REQ_MSG = "Bad Request";
	public static final String SOAP_DEFAULT_RESP_CODE = "9000";
	public static final String SYSTEM_ID_KEY_EBOX = "EBOX.";
	public static final String SOAP_SUCCESS_CODE = "0";
	public static final String SUCCESS_CODE = "200";
	public static final String SUCCESS_MESSAGE = "Success";
	public static final String TIMEOUT_CODE = "504";
	public static final long FALLBACK_TIMEOUT = 10000;
	public static final String SECRETKEY = "Cw}qsrtjtC%75;663<4";
	public static final String SALT = "E}|ignpbyqf$,4944695;::3";
	public static final String EMPTY = "";
	public static final String GET_CHANNEL_ID = "getChannelId";
	public static final String NO_RECORDS_FOUND = "No records found";
	public static final String CHANNEL_ID_NOT_FOUND = "Channel Id not found";
	public static final String CHANNEL_ID_FOUND = "Channel Id found";
	public static final String DOWN_STREAM_SYSTEM_UNAVAILABLE_EXCEPTION = "DownStreamSystemUnavailableException";
	public static final String API_EXCEPTION = "ApiException";
	public static final String EXCEPTION = "Exception";
	public static final String COLON = ":";
	public static final String SEPARATOR = ",";
	public static final String VALIDATE_INPUT_REQUEST = "validation input request";
	public static final String VALIDATING_REQUEST = "validation request";
	public static final String VALIDATION_FAILED = "Validation Failed";
	public static final String M_INVALID_JSON_EXCEPTION = "Invalid Json";
	public static final String M_NO_DATA_FOUND = "Account information not found";
	public static final String PRODUCT_NAME_KEY = "ebox.enquireAccountConduct.productname.";
	public static final String HYPHEN = "-";

	// EnquireAccountDetails
	public static final String API_RESPONSE_EXCEPTION = "ApiResponseException";
	public static final String API_REQUEST_EXCEPTION = "ApiRequestException";
	public static final String SOAPFAULTEXCEPTION = "SOAPFaultException";
	public static final String EBOX_SOAPFAULT_MESSAGE = "EBoxSoapFaultMessage";
	
	
	//Datagrid
	public static final String DATAGRID_CACHE_NAME = "datagrid.cache.name";
	public static final String DATAGRID_SOR_NAME = "datagrid.sor.name";

	public static final String DATA_RETRIEVED = "Data Retrieved";

	public static final String GATEWAY_TIMEOUT = "Gateway Timeout";
	public static final String FALLBACK_METHOD_FOR_RETRIEVE_DEBIT_LIMITS = "fallbackForRetrieveDebitCardLimits";
	public static final String FALLBACK_METHOD_FOR_UPDATE_DEBIT_LIMITS = "fallbackForUpdateDebitCardLimits";


	public static final String SOR_DOWN_CODE = "503";


	public static final String DEBIT_CARD_LIMITS_UPDATE = "debitCardLimitsUpdate";


	public static final String DEBIT_CARD_LIMIT_URL = "sparrow.debitcard.limit.url";
	
	
	
	

	
}
