package com.absa.amol.debitcardlimits.sparrow.model.retrieve;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Schema(name = "DebitCardLimitsRetRes", description = "Response Schema for Debit Card Limits Retrive")
public class DebitCardLimitsRetRes {
	
	private String limitId;
	private String name;
	private String type;
	private String period;
	private String className;
	private String limitValue;
	private String limitMinimum;
	private String limitMaximum;
	private String limitUsed;
	private String limitRemaining;
}
