package com.absa.amol.debitcardlimits.sparrow.controller;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.eclipse.microprofile.faulttolerance.Fallback;
import org.eclipse.microprofile.faulttolerance.Timeout;
import org.eclipse.microprofile.faulttolerance.exceptions.TimeoutException;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponses;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

import com.absa.amol.debitcardlimits.sparrow.model.retrieve.DebitCardLimitsRetReq;
import com.absa.amol.debitcardlimits.sparrow.model.retrieve.DebitCardLimitsRetReqWrapper;
import com.absa.amol.debitcardlimits.sparrow.model.retrieve.DebitCardLimitsRetRes;
import com.absa.amol.debitcardlimits.sparrow.model.update.DebitCardLimitsUpdtReq;
import com.absa.amol.debitcardlimits.sparrow.model.update.DebitCardLimitsUpdtReqWrapper;
import com.absa.amol.debitcardlimits.sparrow.model.update.DebitCardLimitsUpdtRes;
import com.absa.amol.debitcardlimits.sparrow.service.DebitCardLimitsRetService;
import com.absa.amol.debitcardlimits.sparrow.service.DebitCardLimitsUpdtService;
import com.absa.amol.debitcardlimits.sparrow.util.DebitCardLimitsSparrowConstants;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.model.ResponseEntity;

@Path("/debit-card-limits-system-sparrow")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Tag(name = "Debit Card Limits Sparrow- OpenAPI Resources")
@ApplicationScoped
public class DebitCardLimitsSparrowController {
	private static final Logger LOGGER = LoggerFactory.getLogger(DebitCardLimitsSparrowController.class);

	@Inject
	private DebitCardLimitsRetService debitCardLimitsRetService;

	@Inject
	private DebitCardLimitsUpdtService debitCardLimitsUpdtService;

	@GET
	@Path("/retrieveDebitCardLimits")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Timeout
	@Fallback(fallbackMethod = DebitCardLimitsSparrowConstants.FALLBACK_METHOD_FOR_RETRIEVE_DEBIT_LIMITS, applyOn = {
			TimeoutException.class })
	@Tag(name = "Debit Card Limits Sparrow")
	@Operation(summary = "Debit Card Limits Retrieve", description = "Debit Card Limits Retrieve")
	@APIResponses(value = {
			@APIResponse(responseCode = DebitCardLimitsSparrowConstants.SUCCESS_CODE, description = DebitCardLimitsSparrowConstants.DATA_RETRIEVED, content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = DebitCardLimitsRetRes.class))),
			@APIResponse(responseCode = DebitCardLimitsSparrowConstants.BAD_REQ_CODE, description = DebitCardLimitsSparrowConstants.BAD_REQ_MSG, content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = DebitCardLimitsSparrowConstants.INTERNAL_ERROR_CODE, description = DebitCardLimitsSparrowConstants.M_INTERNAL_SERVER_ERROR, content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = DebitCardLimitsSparrowConstants.SOR_DOWN_CODE, description = DebitCardLimitsSparrowConstants.SOR_DOWN_MSG, content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = DebitCardLimitsSparrowConstants.TIMEOUT_CODE, description = DebitCardLimitsSparrowConstants.GATEWAY_TIMEOUT, content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ResponseEntity.class))) })
	public Response retrieveDebitCardLimits(@BeanParam ApiRequestHeader apiRequestHeader,
			@BeanParam DebitCardLimitsRetReq debitCardLimitsRetReq) {
		LOGGER.info("retrieveDebitCardLimits", apiRequestHeader.getConsumerUniqueReferenceId(), "", "request received");
		DebitCardLimitsRetReqWrapper debitCardLimitsRetReqWrapper = new DebitCardLimitsRetReqWrapper();
		debitCardLimitsRetReqWrapper.setDebitCardLimitsRetReq(debitCardLimitsRetReq);
		debitCardLimitsRetReqWrapper.setApiRequestHeader(apiRequestHeader);

		ResponseEntity<List<DebitCardLimitsRetRes>> responseEntity = debitCardLimitsRetService
				.debitCardLimitsRetrieval(debitCardLimitsRetReqWrapper);
		return Response.ok(responseEntity).build();
	}

	public Response fallbackForRetrieveDebitCardLimits(ApiRequestHeader apiRequestHeader,
			DebitCardLimitsRetReq debitCardLimitsRetReq) {
		LOGGER.infoCustom(DebitCardLimitsSparrowConstants.M_FALL_BACK_FOR_TIMEOUT, debitCardLimitsRetReq,
				apiRequestHeader);
		ResponseEntity<Object> responseEntity = new ResponseEntity<>(DebitCardLimitsSparrowConstants.TIMEOUT_CODE,
				"Time out Exception", DebitCardLimitsSparrowConstants.FAILURE_MSG, null);
		return Response.status(Response.Status.GATEWAY_TIMEOUT).entity(responseEntity).build();
	}

	@POST
	@Path("/updateDebitCardLimits")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Timeout
	@Fallback(fallbackMethod = DebitCardLimitsSparrowConstants.FALLBACK_METHOD_FOR_UPDATE_DEBIT_LIMITS, applyOn = {
			TimeoutException.class })
	@Tag(name = "Debit Card Limits Sparrow")
	@Operation(summary = "Debit Card Limits Update", description = "Debit Card Limits Update")
	@APIResponses(value = {
			@APIResponse(responseCode = DebitCardLimitsSparrowConstants.SUCCESS_CODE, description = DebitCardLimitsSparrowConstants.DATA_RETRIEVED, content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = DebitCardLimitsUpdtRes.class))),
			@APIResponse(responseCode = DebitCardLimitsSparrowConstants.BAD_REQ_CODE, description = DebitCardLimitsSparrowConstants.BAD_REQ_MSG, content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = DebitCardLimitsSparrowConstants.INTERNAL_ERROR_CODE, description = DebitCardLimitsSparrowConstants.M_INTERNAL_SERVER_ERROR, content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = DebitCardLimitsSparrowConstants.SOR_DOWN_CODE, description = DebitCardLimitsSparrowConstants.SOR_DOWN_MSG, content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = DebitCardLimitsSparrowConstants.TIMEOUT_CODE, description = DebitCardLimitsSparrowConstants.GATEWAY_TIMEOUT, content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ResponseEntity.class))) })
	public Response updateDebitCardLimits(@BeanParam ApiRequestHeader apiRequestHeader,
			@RequestBody DebitCardLimitsUpdtReq debitCardLimitsUpdtReq) {
		LOGGER.info("updateDebitCardLimits", apiRequestHeader.getConsumerUniqueReferenceId(), "", "request received");
		DebitCardLimitsUpdtReqWrapper debitCardLimitsUpdtReqWrapper = new DebitCardLimitsUpdtReqWrapper();
		debitCardLimitsUpdtReqWrapper.setDebitCardLimitsUpdtReq(debitCardLimitsUpdtReq);
		debitCardLimitsUpdtReqWrapper.setApiRequestHeader(apiRequestHeader);

		ResponseEntity<List<DebitCardLimitsUpdtRes>> responseEntity = debitCardLimitsUpdtService
				.debitCardLimitsUpdate(debitCardLimitsUpdtReqWrapper);
		return Response.ok(responseEntity).build();
	}

	public Response fallbackForUpdateDebitCardLimits(ApiRequestHeader apiRequestHeader,
			DebitCardLimitsUpdtReq debitCardLimitsUpdtReq) {
		LOGGER.infoCustom(DebitCardLimitsSparrowConstants.M_FALL_BACK_FOR_TIMEOUT, debitCardLimitsUpdtReq,
				apiRequestHeader);
		ResponseEntity<Object> responseEntity = new ResponseEntity<>(DebitCardLimitsSparrowConstants.TIMEOUT_CODE,
				"Time out Exception", DebitCardLimitsSparrowConstants.FAILURE_MSG, null);
		return Response.status(Response.Status.GATEWAY_TIMEOUT).entity(responseEntity).build();
	}
}
