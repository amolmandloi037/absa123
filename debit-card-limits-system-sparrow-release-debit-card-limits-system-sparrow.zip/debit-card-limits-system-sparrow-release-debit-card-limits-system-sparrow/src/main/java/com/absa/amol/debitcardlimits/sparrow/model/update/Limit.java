package com.absa.amol.debitcardlimits.sparrow.model.update;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Limit {
	
	@NotNull(message = "limitId.null.empty.message")
	@NotEmpty(message = "limitId.null.empty.message")
	private String limitId;
	
	@NotNull(message = "currentLimit.null.empty.message")
	@NotEmpty(message = "currentLimit.null.empty.message")
	private String currentLimit;

}
