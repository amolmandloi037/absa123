package com.absa.amol.debitcardlimits.sparrow.util;

import java.util.HashSet;
import java.util.Set;

import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.eclipse.microprofile.config.Config;

import com.absa.amol.debitcardlimits.sparrow.model.retrieve.DebitCardLimitsRetReqWrapper;
import com.absa.amol.debitcardlimits.sparrow.model.update.DebitCardLimitsUpdtReqWrapper;
import com.absa.amol.util.exception.ApiRequestException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.utility.CommonUtil;
import com.absa.amol.util.utility.StringUtil;

public class DebitCardLimitsSparrowValidatorUtil {

	@Inject
	Config config;

	@Inject
	DebitCardLimitsSparrowUtil debitCardLimitsSparrowUtil;

	@Inject
	private Validator validator;

	private static final Logger LOGGER = LoggerFactory.getLogger(DebitCardLimitsSparrowValidatorUtil.class);

	public void validateRetRequest(DebitCardLimitsRetReqWrapper debitCardLimitsRetReqWrapper) {
		
		String consumerUniqueRefId = DebitCardLimitsSparrowConstants.EMPTY;
		LOGGER.info(DebitCardLimitsSparrowConstants.VALIDATE_INPUT_REQUEST, consumerUniqueRefId,
				DebitCardLimitsSparrowConstants.VALIDATING_REQUEST,
				DebitCardLimitsSparrowConstants.EMPTY);

		Set<String> errorSet = new HashSet<>();
		Set<String> annoBeansValErrSet = validatedAnnotedBeans(debitCardLimitsRetReqWrapper);
		Set<String> customValErrSet = customvalidatedBeans(debitCardLimitsRetReqWrapper);
		errorSet.addAll(annoBeansValErrSet);
		errorSet.addAll(customValErrSet);
		if (!errorSet.isEmpty()) {
			String errorMessage = String.join(DebitCardLimitsSparrowConstants.SEPARATOR, errorSet);
			LOGGER.error(DebitCardLimitsSparrowConstants.VALIDATE_INPUT_REQUEST, consumerUniqueRefId,
					DebitCardLimitsSparrowConstants.VALIDATION_FAILED, errorMessage);
			throw new ApiRequestException(DebitCardLimitsSparrowConstants.BAD_REQ_CODE, errorMessage);
		}
	}

	private Set<String> validatedAnnotedBeans(DebitCardLimitsRetReqWrapper debitCardLimitsRetReqWrapper) {
		Set<String> annoBeansValErrSet = new HashSet<>();
		Set<ConstraintViolation<Object>> violations = validator.validate(debitCardLimitsRetReqWrapper);
		for (ConstraintViolation<Object> error : violations) {
			String customErroMsg = getPropertyValue(error.getMessageTemplate());
			if (StringUtil.isStringNullOrEmpty(customErroMsg)) {
				customErroMsg = error.getMessage();
			}
			annoBeansValErrSet.add(customErroMsg);
		}
		return annoBeansValErrSet;
	}

	private Set<String> customvalidatedBeans(DebitCardLimitsRetReqWrapper debitCardLimitsRetReqWrapper) {
		LOGGER.info("customvalidatedBeans",
				debitCardLimitsRetReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(),
				DebitCardLimitsSparrowConstants.EMPTY, DebitCardLimitsSparrowConstants.EMPTY);
		Set<String> customValErrSet = new HashSet<>();
		if (CommonUtil.isNotNull(debitCardLimitsRetReqWrapper.getDebitCardLimitsRetReq())
				&& CommonUtil.isNotNull(
						debitCardLimitsRetReqWrapper.getDebitCardLimitsRetReq().getCardId())
				&& (debitCardLimitsRetReqWrapper.getDebitCardLimitsRetReq().getCardId().split("0",
						-1).length - 1 == debitCardLimitsRetReqWrapper.getDebitCardLimitsRetReq().getCardId().length())) {
			customValErrSet
					.add(debitCardLimitsSparrowUtil.getConfigStringValue("cardId.pattren.error.message"));
		}
		return customValErrSet;
	}

	private String getPropertyValue(String confKey) {
		try {
			return config.getValue(confKey, String.class);
		} catch (Exception e) {
			LOGGER.error("getPropertyValue", DebitCardLimitsSparrowConstants.BLANK,
					"Exception while reading property for the key ::" + confKey, e.getMessage());
		}
		return "";
	}

	public void validateUpdtRequest(DebitCardLimitsUpdtReqWrapper debitCardLimitsUpdtReqWrapper) {
		String consumerUniqueRefId = DebitCardLimitsSparrowConstants.EMPTY;
		LOGGER.info(DebitCardLimitsSparrowConstants.VALIDATE_INPUT_REQUEST, consumerUniqueRefId,
				DebitCardLimitsSparrowConstants.VALIDATING_REQUEST,
				DebitCardLimitsSparrowConstants.EMPTY);

		Set<String> errorSet = new HashSet<>();
		Set<String> annoBeansValErrSet = validatedAnnotedBeans(debitCardLimitsUpdtReqWrapper);
		Set<String> customValErrSet = customvalidatedBeans(debitCardLimitsUpdtReqWrapper);
		errorSet.addAll(annoBeansValErrSet);
		errorSet.addAll(customValErrSet);
		if (!errorSet.isEmpty()) {
			String errorMessage = String.join(DebitCardLimitsSparrowConstants.SEPARATOR, errorSet);
			LOGGER.error(DebitCardLimitsSparrowConstants.VALIDATE_INPUT_REQUEST, consumerUniqueRefId,
					DebitCardLimitsSparrowConstants.VALIDATION_FAILED, errorMessage);
			throw new ApiRequestException(DebitCardLimitsSparrowConstants.BAD_REQ_CODE, errorMessage);
		}
		
	}

	private Set<String> validatedAnnotedBeans(DebitCardLimitsUpdtReqWrapper debitCardLimitsUpdtReqWrapper) {
		Set<String> annoBeansValErrSet = new HashSet<>();
		Set<ConstraintViolation<Object>> violations = validator.validate(debitCardLimitsUpdtReqWrapper);
		for (ConstraintViolation<Object> error : violations) {
			String customErroMsg = getPropertyValue(error.getMessageTemplate());
			if (StringUtil.isStringNullOrEmpty(customErroMsg)) {
				customErroMsg = error.getMessage();
			}
			annoBeansValErrSet.add(customErroMsg);
		}
		return annoBeansValErrSet;
	}
	
	private Set<String> customvalidatedBeans(DebitCardLimitsUpdtReqWrapper debitCardLimitsUpdtReqWrapper) {
		LOGGER.info("customvalidatedBeans",
				debitCardLimitsUpdtReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(),
				DebitCardLimitsSparrowConstants.EMPTY, DebitCardLimitsSparrowConstants.EMPTY);
		Set<String> customValErrSet = new HashSet<>();
		if (CommonUtil.isNotNull(debitCardLimitsUpdtReqWrapper.getDebitCardLimitsUpdtReq())
				&& CommonUtil.isNotNull(
						debitCardLimitsUpdtReqWrapper.getDebitCardLimitsUpdtReq().getCardId())
				&& (debitCardLimitsUpdtReqWrapper.getDebitCardLimitsUpdtReq().getCardId().split("0",
						-1).length - 1 == debitCardLimitsUpdtReqWrapper.getDebitCardLimitsUpdtReq().getCardId().length())) {
			customValErrSet
					.add(debitCardLimitsSparrowUtil.getConfigStringValue("cardId.pattren.error.message"));
		}
		return customValErrSet;
	}

}
