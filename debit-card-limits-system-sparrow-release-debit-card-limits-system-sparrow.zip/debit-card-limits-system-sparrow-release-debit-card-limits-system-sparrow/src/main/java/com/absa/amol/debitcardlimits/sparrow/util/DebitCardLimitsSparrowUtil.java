package com.absa.amol.debitcardlimits.sparrow.util;

import javax.inject.Inject;

import org.eclipse.microprofile.config.Config;

import com.absa.amol.util.utility.DataGridServiceUtil;

public class DebitCardLimitsSparrowUtil {
	
	@Inject
	Config config;
	
	@Inject
	DataGridServiceUtil dataGridServiceUtil;


	public String getConfigStringValue(String key){
		return config.getValue(key, String.class);
	}

	public Integer getConfigIntValue(String key){
		return config.getValue(key, Integer.class);
	}

	public Boolean getConfigBooleanValue(String key){
		return config.getValue(key, Boolean.class);
	}
	
	public String getChannelId(String systemId) {
		return dataGridServiceUtil.getChannelId(
				getConfigStringValue(DebitCardLimitsSparrowConstants.DATAGRID_CACHE_NAME),
				getConfigStringValue(DebitCardLimitsSparrowConstants.DATAGRID_SOR_NAME)
						+ DebitCardLimitsSparrowConstants.COLON + systemId);
	}


}