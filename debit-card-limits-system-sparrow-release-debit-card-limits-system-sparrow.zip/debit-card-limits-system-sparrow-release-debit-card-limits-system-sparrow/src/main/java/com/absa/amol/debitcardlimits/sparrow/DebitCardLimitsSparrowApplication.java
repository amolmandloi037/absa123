package com.absa.amol.debitcardlimits.sparrow;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import org.eclipse.microprofile.openapi.annotations.OpenAPIDefinition;
import org.eclipse.microprofile.openapi.annotations.info.Info;

import lombok.NoArgsConstructor;


@OpenAPIDefinition(info = @Info(
		title = "Debit Card Limits Retrieve Sparrow API", 
		version = "1.0.0"))

@NoArgsConstructor
@ApplicationPath("/v1")
public class DebitCardLimitsSparrowApplication extends Application {

}
