package com.absa.amol.debitcardlimits.sparrow.service;

import java.util.List;

import com.absa.amol.debitcardlimits.sparrow.model.retrieve.DebitCardLimitsRetReqWrapper;
import com.absa.amol.debitcardlimits.sparrow.model.retrieve.DebitCardLimitsRetRes;
import com.absa.amol.util.model.ResponseEntity;

public interface DebitCardLimitsRetService {

	public ResponseEntity<List<DebitCardLimitsRetRes>> debitCardLimitsRetrieval(
			DebitCardLimitsRetReqWrapper debitCardLimitsRetReqWrapper);
	
}
