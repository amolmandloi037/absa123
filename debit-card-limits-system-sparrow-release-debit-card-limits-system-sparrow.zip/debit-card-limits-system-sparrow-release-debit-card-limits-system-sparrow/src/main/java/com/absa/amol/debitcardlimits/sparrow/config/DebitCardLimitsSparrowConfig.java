package com.absa.amol.debitcardlimits.sparrow.config;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.eclipse.microprofile.config.spi.ConfigSource;

import com.absa.amol.debitcardlimits.sparrow.util.DebitCardLimitsSparrowConstants;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;

public class DebitCardLimitsSparrowConfig implements ConfigSource {
	private static final Logger LOGGER = LoggerFactory.getLogger(DebitCardLimitsSparrowConfig.class);

	private Map<String, String> custmap = new HashMap<>();

	public DebitCardLimitsSparrowConfig() {

		Properties properties = new Properties();
		String path = System.getProperty("properties.path");
		LOGGER.info(DebitCardLimitsSparrowConstants.CONFIG_CLASS_NAME, "", "Property File Path: ", path);
		LOGGER.debug(DebitCardLimitsSparrowConstants.CONFIG_CLASS_NAME, DebitCardLimitsSparrowConstants.BLANK,
				"properties path", path);
		try (FileInputStream fileInputStream = new FileInputStream(new File(path))) {
			properties.load(fileInputStream);
			properties.forEach((k, v) -> {
                String value = String.valueOf(v);
                custmap.put(String.valueOf(k), value);
	            });
			LOGGER.info(DebitCardLimitsSparrowConstants.CONFIG_CLASS_NAME, "", "Custom Map has been created!", "");
		} catch (Exception e) {
			LOGGER.error(DebitCardLimitsSparrowConstants.CONFIG_CLASS_NAME, DebitCardLimitsSparrowConstants.BLANK,
					"Exception Occured", e.getMessage());
			LOGGER.debug(DebitCardLimitsSparrowConstants.CONFIG_CLASS_NAME, DebitCardLimitsSparrowConstants.BLANK,
					"Detailed Exception : ", e);
		}
	}

	@Override
	public Map<String, String> getProperties() {
		return custmap;
	}

	@Override
	public String getValue(String s) {
		return custmap.get(s);
	}

	@Override
	public String getName() {
		return DebitCardLimitsSparrowConstants.CONFIG_CLASS_NAME;
	}
	
	
}
