package com.absa.amol.debitcardlimits.sparrow.mapper;

import java.util.ArrayList;
import java.util.List;

import javax.json.bind.Jsonb;
import javax.json.bind.JsonbBuilder;

import com.absa.amol.debitcardlimits.sparrow.model.update.DebitCardLimitsUpdtReqWrapper;
import com.absa.amol.debitcardlimits.sparrow.model.update.DebitCardLimitsUpdtRes;
import com.absa.amol.debitcardlimits.sparrow.model.update.Limit;
import com.absa.amol.debitcardlimits.sparrow.model.update.LimitsUpdReq;
import com.absa.amol.debitcardlimits.sparrow.model.update.SorUpdtLimitsReq;
import com.absa.amol.debitcardlimits.sparrow.model.update.SorUpdtLimitsRes;
import com.absa.amol.debitcardlimits.sparrow.model.update.SorUpdtReq;
import com.absa.amol.debitcardlimits.sparrow.model.update.SorUpdtRes;
import com.absa.amol.util.exception.ApiRequestException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ResponseEntity;
import com.absa.amol.util.utility.CommonUtil;

public class DebitCardLimitsUpdtMapper {

	private static final Logger LOGGER = LoggerFactory.getLogger(DebitCardLimitsUpdtMapper.class);

	public ResponseEntity<List<DebitCardLimitsUpdtRes>> getUpdatedResp(
			DebitCardLimitsUpdtReqWrapper debitCardLimitsUpdtReqWrapper, String result) throws Exception {
		LOGGER.info("getUpdatedResp",
				debitCardLimitsUpdtReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(), "", "");
		ResponseEntity<List<DebitCardLimitsUpdtRes>> responseEntity = null;
		List<DebitCardLimitsUpdtRes> list = null;
		DebitCardLimitsUpdtRes resp = null;
		try (Jsonb jsonb = JsonbBuilder.create()) {

			SorUpdtRes sorUpdtRes = jsonb.fromJson(result, SorUpdtRes.class);

			if (CommonUtil.isNotNull(sorUpdtRes.getData()) && CommonUtil.isNotNull(sorUpdtRes.getData().getResult())
					&& sorUpdtRes.getData().getResult().equalsIgnoreCase("Ok")) {
				list = new ArrayList<>();
				for (SorUpdtLimitsRes sorUpdtLimitsRes : sorUpdtRes.getData().getLimits()) {
					resp = new DebitCardLimitsUpdtRes();
					resp.setClassName(sorUpdtLimitsRes.getClassName());
					resp.setLimitId(sorUpdtLimitsRes.getId());
					resp.setLimitMaximum(sorUpdtLimitsRes.getLimitMaximum());
					resp.setLimitMinimum(sorUpdtLimitsRes.getLimitMinimum());
					resp.setLimitValue(sorUpdtLimitsRes.getLimitValue());
					resp.setName(sorUpdtLimitsRes.getName());
					resp.setPeriod(sorUpdtLimitsRes.getPeriod());
					resp.setType(sorUpdtLimitsRes.getType());
					resp.setLimitUsed(sorUpdtLimitsRes.getLimitUsed());
					resp.setLimitRemaining(sorUpdtLimitsRes.getLimitRemaining());
					list.add(resp);
				}

				responseEntity = new ResponseEntity<>();
				responseEntity.setCode("200");
				responseEntity.setData(list);
				responseEntity.setMessage("Data Processed");
				responseEntity.setStatus("Successs");
			} else {
				LOGGER.error("getUpdatedResp",
						debitCardLimitsUpdtReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(), sorUpdtRes.getData().getError(),
						sorUpdtRes.getData().getErrorText());
				throw new ApiRequestException("400", sorUpdtRes.getData().getErrorText());
			}
		}
		return responseEntity;
	}

	public SorUpdtLimitsReq getSorReq(DebitCardLimitsUpdtReqWrapper debitCardLimitsUpdtReqWrapper) {
		SorUpdtLimitsReq sorUpdtLimitsReq = new SorUpdtLimitsReq();
		LimitsUpdReq req = new LimitsUpdReq();
		List<LimitsUpdReq> limits = new ArrayList<>();
		if (CommonUtil.isNotNull(debitCardLimitsUpdtReqWrapper.getDebitCardLimitsUpdtReq())
				&& CommonUtil.isNotNull(debitCardLimitsUpdtReqWrapper.getDebitCardLimitsUpdtReq().getLimits())
				&& !debitCardLimitsUpdtReqWrapper.getDebitCardLimitsUpdtReq().getLimits().isEmpty()) {
			for (Limit limit : debitCardLimitsUpdtReqWrapper.getDebitCardLimitsUpdtReq().getLimits()) {
				req.setId(limit.getLimitId());
				req.setLimitValue(limit.getCurrentLimit());
				limits.add(req);
			}
			SorUpdtReq reqData = new SorUpdtReq();
			reqData.setLimits(limits);

			sorUpdtLimitsReq.setData(reqData);

		}
		return sorUpdtLimitsReq;
	}

}
