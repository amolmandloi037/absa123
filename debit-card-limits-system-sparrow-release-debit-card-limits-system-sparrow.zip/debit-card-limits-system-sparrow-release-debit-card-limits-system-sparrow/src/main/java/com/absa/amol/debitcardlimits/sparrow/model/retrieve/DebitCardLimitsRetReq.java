package com.absa.amol.debitcardlimits.sparrow.model.retrieve;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.ws.rs.BeanParam;
import javax.ws.rs.QueryParam;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import com.absa.amol.util.model.ApiRequestHeader;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Schema(name = "DebitCardLimitsRetReq", description = "Request Schema for Debit Card Limits Retrive")
public class DebitCardLimitsRetReq {
	
	@Valid
	@BeanParam
	@Schema(hidden = true)
	private ApiRequestHeader apiRequestHeader;

	@Valid
	@QueryParam("cardId")
	@NotNull(message = "cardId.null.empty.message")
	@Pattern(regexp = "[0-9A-Za-z]{0,27}", message = "cardId.pattern.message")
	private String cardId;

}
