package com.absa.amol.debitcardlimits.sparrow.model.update;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Schema(name = "DebitCardLimitsUpdtReq", description = "Request Schema for Debit Card Limits Update")
public class DebitCardLimitsUpdtReq {
	
	@Valid
	@NotNull(message = "cardId.null.empty.message")
	@Pattern(regexp = "[0-9A-Za-z]{0,27}", message = "cardId.pattern.message")
	private String cardId;
	
	@Valid
	private List<Limit> limits;

}
