package com.absa.amol.debitcardlimits.sparrow.model.retrieve;

import javax.validation.Valid;

import com.absa.amol.util.model.ApiRequestHeader;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class DebitCardLimitsRetReqWrapper {
	
	
	@Valid
	private	DebitCardLimitsRetReq debitCardLimitsRetReq;
	private String channelId;
	private ApiRequestHeader apiRequestHeader;

}
