package com.absa.amol.debitcardlimits.sparrow.util;

import java.io.IOException;
import java.net.URL;

import javax.inject.Inject;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;

import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

public class HttpConnectionUtil {
	
	
	@Inject
	DebitCardLimitsSparrowUtil util;
	
	public HttpsURLConnection getHttpConnectionForGet()
			throws IOException {
		String httpsUrl = util.getConfigStringValue(DebitCardLimitsSparrowConstants.DEBIT_CARD_LIMIT_URL);
		URL url = new URL(httpsUrl);

		HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
		con.setHostnameVerifier(new HostnameVerifier() {
			@Override
			public boolean verify(String hostname, SSLSession session) {
				return true;
			}
		});
		return con;
	}

	public  CloseableHttpClient getCloseableHttpClient() {
		return HttpClients.custom().setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE)
				.build();
	}

}
