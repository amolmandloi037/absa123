package com.absa.amol.debitcardlimits.sparrow.service.impl;

import java.util.List;

import javax.inject.Inject;
import javax.json.bind.Jsonb;
import javax.json.bind.JsonbBuilder;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPatch;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;

import com.absa.amol.debitcardlimits.sparrow.mapper.DebitCardLimitsUpdtMapper;
import com.absa.amol.debitcardlimits.sparrow.model.update.DebitCardLimitsUpdtReqWrapper;
import com.absa.amol.debitcardlimits.sparrow.model.update.DebitCardLimitsUpdtRes;
import com.absa.amol.debitcardlimits.sparrow.model.update.SorUpdtLimitsReq;
import com.absa.amol.debitcardlimits.sparrow.service.DebitCardLimitsUpdtService;
import com.absa.amol.debitcardlimits.sparrow.util.DebitCardLimitsSparrowConstants;
import com.absa.amol.debitcardlimits.sparrow.util.DebitCardLimitsSparrowUtil;
import com.absa.amol.debitcardlimits.sparrow.util.DebitCardLimitsSparrowValidatorUtil;
import com.absa.amol.debitcardlimits.sparrow.util.HttpConnectionUtil;
import com.absa.amol.util.exception.ApiException;
import com.absa.amol.util.exception.ApiResponseException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ResponseEntity;

public class DebitCardLimitsUpdtServiceImpl implements DebitCardLimitsUpdtService {

	private static final Logger LOGGER = LoggerFactory.getLogger(DebitCardLimitsUpdtServiceImpl.class);

	@Inject
	DebitCardLimitsSparrowUtil util;
	
	@Inject
	HttpConnectionUtil httpConnectionUtil;

	@Inject
	DebitCardLimitsSparrowValidatorUtil validateUtil;

	@Inject
	DebitCardLimitsUpdtMapper updtMapper;

	@Override
	public ResponseEntity<List<DebitCardLimitsUpdtRes>> debitCardLimitsUpdate(
			DebitCardLimitsUpdtReqWrapper debitCardLimitsUpdtReqWrapper) {
		ResponseEntity<List<DebitCardLimitsUpdtRes>> resp = null;
		try {
			validateUtil.validateUpdtRequest(debitCardLimitsUpdtReqWrapper);
			debitCardLimitsUpdtReqWrapper
					.setChannelId(util.getChannelId(debitCardLimitsUpdtReqWrapper.getApiRequestHeader().getSystemId()));
			resp = updateDebitcardLimit(debitCardLimitsUpdtReqWrapper);

		} catch (ApiException ex) {
			LOGGER.error(DebitCardLimitsSparrowConstants.DEBIT_CARD_LIMITS_UPDATE,
					debitCardLimitsUpdtReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(), "",
					ex.getErrorMessage());
			LOGGER.debug(DebitCardLimitsSparrowConstants.DEBIT_CARD_LIMITS_UPDATE,
					debitCardLimitsUpdtReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(), "", ex);
			throw ex;
		} catch (Exception ex) {
			LOGGER.error(DebitCardLimitsSparrowConstants.DEBIT_CARD_LIMITS_UPDATE,
					debitCardLimitsUpdtReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(), "",
					ex.getMessage());
			LOGGER.error(DebitCardLimitsSparrowConstants.DEBIT_CARD_LIMITS_UPDATE,
					debitCardLimitsUpdtReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(), "", ex);
			throw new ApiResponseException(DebitCardLimitsSparrowConstants.INTERNAL_ERROR_CODE,
					DebitCardLimitsSparrowConstants.M_INTERNAL_SERVER_ERROR);
		}
		return resp;
	}

	private ResponseEntity<List<DebitCardLimitsUpdtRes>> updateDebitcardLimit(
			DebitCardLimitsUpdtReqWrapper debitCardLimitsUpdtReqWrapper) throws Exception {
		String result = "";
		CloseableHttpClient client = httpConnectionUtil.getCloseableHttpClient();
		ResponseEntity<List<DebitCardLimitsUpdtRes>> resp = null;
		HttpPatch post = new HttpPatch(util.getConfigStringValue(DebitCardLimitsSparrowConstants.DEBIT_CARD_LIMIT_URL));
		try (Jsonb jsonb = JsonbBuilder.create()) {
			SorUpdtLimitsReq sorUpdtLimitsReq = updtMapper.getSorReq(debitCardLimitsUpdtReqWrapper);

			String json = jsonb.toJson(sorUpdtLimitsReq);
			post.setHeader("x-absa-channel-id", debitCardLimitsUpdtReqWrapper.getChannelId());
			post.setHeader("x-absa-card-id", debitCardLimitsUpdtReqWrapper.getDebitCardLimitsUpdtReq().getCardId());
			post.setHeader("x-absa-trace-id", debitCardLimitsUpdtReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId());
			post.setEntity(new StringEntity(json, ContentType.create("application/json")));
			
			CloseableHttpResponse response = client.execute(post);
			HttpEntity httpEntity = response.getEntity();
			result = EntityUtils.toString(httpEntity);
			LOGGER.info("Response from API",
					debitCardLimitsUpdtReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(), result, "");
			resp = updtMapper.getUpdatedResp(debitCardLimitsUpdtReqWrapper, result);
			client.close();
		} 
		return resp;

	}

	

}
