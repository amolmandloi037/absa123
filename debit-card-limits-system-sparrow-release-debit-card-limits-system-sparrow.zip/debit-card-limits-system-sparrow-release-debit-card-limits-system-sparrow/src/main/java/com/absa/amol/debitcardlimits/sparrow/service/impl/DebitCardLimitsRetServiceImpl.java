package com.absa.amol.debitcardlimits.sparrow.service.impl;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;

import javax.inject.Inject;
import javax.net.ssl.HttpsURLConnection;

import com.absa.amol.debitcardlimits.sparrow.mapper.DebitCardLimitsRetMapper;
import com.absa.amol.debitcardlimits.sparrow.model.retrieve.DebitCardLimitsRetReqWrapper;
import com.absa.amol.debitcardlimits.sparrow.model.retrieve.DebitCardLimitsRetRes;
import com.absa.amol.debitcardlimits.sparrow.service.DebitCardLimitsRetService;
import com.absa.amol.debitcardlimits.sparrow.util.DebitCardLimitsSparrowConstants;
import com.absa.amol.debitcardlimits.sparrow.util.DebitCardLimitsSparrowUtil;
import com.absa.amol.debitcardlimits.sparrow.util.DebitCardLimitsSparrowValidatorUtil;
import com.absa.amol.debitcardlimits.sparrow.util.HttpConnectionUtil;
import com.absa.amol.util.exception.ApiException;
import com.absa.amol.util.exception.ApiResponseException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ResponseEntity;

public class DebitCardLimitsRetServiceImpl implements DebitCardLimitsRetService {

	@Inject
	DebitCardLimitsSparrowUtil util;
	
	@Inject
	HttpConnectionUtil httpConnectionUtil;

	@Inject
	DebitCardLimitsSparrowValidatorUtil validateUtil;

	@Inject
	DebitCardLimitsRetMapper retMapper;

	@Inject
	DebitCardLimitsRetMapper mapper;

	private static final Logger LOGGER = LoggerFactory.getLogger(DebitCardLimitsRetServiceImpl.class);

	@Override
	public ResponseEntity<List<DebitCardLimitsRetRes>> debitCardLimitsRetrieval(
			DebitCardLimitsRetReqWrapper debitCardLimitsRetReqWrapper) {
		List<DebitCardLimitsRetRes> resp = null;
		ResponseEntity<List<DebitCardLimitsRetRes>> responseEntity = null;
		try {

			validateUtil.validateRetRequest(debitCardLimitsRetReqWrapper);
			debitCardLimitsRetReqWrapper
					.setChannelId(util.getChannelId(debitCardLimitsRetReqWrapper.getApiRequestHeader().getSystemId()));
			resp = sparrowCallForRetDebitLimits(debitCardLimitsRetReqWrapper);
			responseEntity = new ResponseEntity<>();
			responseEntity.setCode("200");
			responseEntity.setData(resp);
			responseEntity.setMessage("Data Retrieved");
			responseEntity.setStatus("Successs");

		} catch (ApiException ex) {
			LOGGER.error(DebitCardLimitsSparrowConstants.DEBIT_CARD_LIMITS_RETRIEVAL,
					debitCardLimitsRetReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(), "",
					ex.getErrorMessage());
			LOGGER.debug(DebitCardLimitsSparrowConstants.DEBIT_CARD_LIMITS_RETRIEVAL,
					debitCardLimitsRetReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(), "", ex);
			throw ex;
		} catch (Exception ex) {
			LOGGER.error(DebitCardLimitsSparrowConstants.DEBIT_CARD_LIMITS_RETRIEVAL,
					debitCardLimitsRetReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(), "",
					ex.getMessage());
			LOGGER.error(DebitCardLimitsSparrowConstants.DEBIT_CARD_LIMITS_RETRIEVAL,
					debitCardLimitsRetReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(), "", ex);
			throw new ApiResponseException(DebitCardLimitsSparrowConstants.INTERNAL_ERROR_CODE,
					DebitCardLimitsSparrowConstants.M_INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	private List<DebitCardLimitsRetRes> sparrowCallForRetDebitLimits(
			DebitCardLimitsRetReqWrapper debitCardLimitsRetReqWrapper)
			throws Exception {
		List<DebitCardLimitsRetRes> listResp = null;

		HttpsURLConnection con = httpConnectionUtil.getHttpConnectionForGet();
		con.setRequestMethod("GET");
		con.setRequestProperty("x-absa-channel-id", debitCardLimitsRetReqWrapper.getChannelId());
		con.setRequestProperty("x-absa-card-id", debitCardLimitsRetReqWrapper.getDebitCardLimitsRetReq().getCardId());
		con.setRequestProperty("x-absa-trace-id",
				debitCardLimitsRetReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId());
		BufferedReader in = null;
		if (100 <= con.getResponseCode() && con.getResponseCode() <= 399) {
			in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		}else {
			in = new BufferedReader(new InputStreamReader(con.getErrorStream()));
		}
		String inputLine;
		StringBuilder sb = new StringBuilder();
		while ((inputLine = in.readLine()) != null) {
			sb.append(inputLine);
		}
		in.close();
		LOGGER.info("retrieveLimit response", "", "", sb.toString());
		listResp = retMapper.setRetResponse(sb.toString(), debitCardLimitsRetReqWrapper);
		return listResp;

	}

	

}