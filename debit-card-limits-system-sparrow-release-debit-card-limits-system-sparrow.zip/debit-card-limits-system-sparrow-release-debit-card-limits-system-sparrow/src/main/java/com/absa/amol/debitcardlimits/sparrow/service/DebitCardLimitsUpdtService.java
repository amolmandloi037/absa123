package com.absa.amol.debitcardlimits.sparrow.service;

import java.util.List;

import com.absa.amol.debitcardlimits.sparrow.model.update.DebitCardLimitsUpdtReqWrapper;
import com.absa.amol.debitcardlimits.sparrow.model.update.DebitCardLimitsUpdtRes;
import com.absa.amol.util.model.ResponseEntity;

public interface DebitCardLimitsUpdtService {

	public ResponseEntity<List<DebitCardLimitsUpdtRes>> debitCardLimitsUpdate(
			DebitCardLimitsUpdtReqWrapper debitCardLimitsUpdtReqWrapper);
}
