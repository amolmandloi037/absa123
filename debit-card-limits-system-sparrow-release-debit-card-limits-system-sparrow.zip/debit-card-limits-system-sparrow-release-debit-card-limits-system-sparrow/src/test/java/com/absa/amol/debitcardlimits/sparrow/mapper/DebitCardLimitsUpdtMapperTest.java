package com.absa.amol.debitcardlimits.sparrow.mapper;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import com.absa.amol.debitcardlimits.sparrow.model.update.DebitCardLimitsUpdtReq;
import com.absa.amol.debitcardlimits.sparrow.model.update.DebitCardLimitsUpdtReqWrapper;
import com.absa.amol.debitcardlimits.sparrow.model.update.DebitCardLimitsUpdtRes;
import com.absa.amol.debitcardlimits.sparrow.model.update.Limit;
import com.absa.amol.debitcardlimits.sparrow.model.update.SorUpdtLimitsReq;
import com.absa.amol.util.exception.ApiRequestException;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.model.ResponseEntity;

class DebitCardLimitsUpdtMapperTest {

	@InjectMocks
	DebitCardLimitsUpdtMapper mapper;
	
	@BeforeEach
	public void init() {
		MockitoAnnotations.openMocks(this);
	}
	
	@Test
	void getSorReqTest() {
		SorUpdtLimitsReq req=mapper.getSorReq(getDebitCardLimitsUpdtReqWrapper());
		Assertions.assertEquals("aa", req.getData().getLimits().get(0).getId());
	}
	
	@Test
	void getUpdatedRespTest() {
		String response="{\"data\":{\"result\":\"OK\",\"limits\":[{\"id\":\"2-1\",\"name\":\"Daily Contactless No-PIN Debit Amount\",\"type\":\"contactless\",\"period\":\"1D\",\"class\":\"amount\",\"limitValue\":\"10000\",\"limitUsed\":\"0\",\"limitRemaining\":\"10000\",\"limitMinimum\":\"300\",\"limitMaximum\":\"1000\"}]}}";
		ResponseEntity<List<DebitCardLimitsUpdtRes>> resp = null;
		try {
			resp = mapper.getUpdatedResp(getDebitCardLimitsUpdtReqWrapper(),response);
			Assertions.assertEquals("200", resp.getCode());
		} catch (Exception e) {
			e.printStackTrace();
		}
	
	}
	
	@Test
	void setUpdtExpResponseTest() {
		String response = "{\"data\":{\"result\":\"ERROR\",\"error\":\"ERR_APP_VALIDATION\",\"errorText\":\"Card identifier is invalid\"}}";
		try {
			mapper.getUpdatedResp(getDebitCardLimitsUpdtReqWrapper(),response);

		} catch (Exception e) {
			Assertions.assertEquals(true, e instanceof ApiRequestException);
		}
	}


	private DebitCardLimitsUpdtReqWrapper getDebitCardLimitsUpdtReqWrapper() {
		
		DebitCardLimitsUpdtReqWrapper reqWrapper= new DebitCardLimitsUpdtReqWrapper();
		reqWrapper.setApiRequestHeader(getApiRequestHeader());
		reqWrapper.setChannelId("IB");
		reqWrapper.setDebitCardLimitsUpdtReq(getDebitCardLimitsUpdtReq());
		return reqWrapper;
	}
	
	private DebitCardLimitsUpdtReq getDebitCardLimitsUpdtReq() {
		DebitCardLimitsUpdtReq req = new DebitCardLimitsUpdtReq();
		Limit limit= new Limit();
		limit.setCurrentLimit("4");
		limit.setLimitId("aa");
		List<Limit> limits = new ArrayList<>();
		limits.add(limit);
		req.setCardId("4234234234234234234");
		req.setLimits(limits);
			return req;
	}

	private ApiRequestHeader getApiRequestHeader() {
		ApiRequestHeader apiRequestHeader = new ApiRequestHeader();
		apiRequestHeader.setBusinessId("BWBRB");
		apiRequestHeader.setCorrelationId("d7ebfa84-e5e2-425e-999e-f07f70c3f751");
		apiRequestHeader.setCountryCode("BW");
		apiRequestHeader.setSystemId("IB");
		apiRequestHeader.setStaffId("IFE");
		apiRequestHeader.setConsumerUniqueReferenceId("1212312312312312");
		return apiRequestHeader;
	}


}
