package com.absa.amol.debitcardlimits.sparrow.config;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;


	class DebitCardLimitsSparrowConfigTest {
	
	 @InjectMocks
	 DebitCardLimitsSparrowConfig debitCardLimitsSparrowConfig;
	 


	@BeforeEach
	public void init() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void configTest() {
		String file = getClass().getClassLoader()
				.getResource("properties/dev/debit-card-limits-system-sparrow-dev.properties").getFile();
		System.setProperty("properties.path", file);
		assertEquals("DebitCardLimitsSparrowConfig", debitCardLimitsSparrowConfig.getName());
	}

	@Test
	void getNameTest() {
		assertEquals("DebitCardLimitsSparrowConfig", debitCardLimitsSparrowConfig.getName());
	}

	@Test
	void getPropertiesTest() {
		assertNotNull(debitCardLimitsSparrowConfig.getProperties());
	}

	@Test
	void getValueTest() {
		assertEquals(null, debitCardLimitsSparrowConfig.getValue("test data"));
	}
	
	
	 @Test
	   void configTestUrl() {
	  	String file= getClass().getClassLoader().getResource("properties/dev/debit-card-limits-system-sparrow-dev.properties").getFile();
	  	System.setProperty("properties.path", file);
	      assertEquals("DebitCardLimitsSparrowConfig", debitCardLimitsSparrowConfig.getName());
	  }
}
