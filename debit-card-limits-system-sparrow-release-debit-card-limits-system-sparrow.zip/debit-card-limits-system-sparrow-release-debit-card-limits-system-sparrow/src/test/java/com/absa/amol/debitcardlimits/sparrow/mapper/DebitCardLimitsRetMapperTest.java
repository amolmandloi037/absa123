package com.absa.amol.debitcardlimits.sparrow.mapper;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import com.absa.amol.debitcardlimits.sparrow.model.retrieve.DebitCardLimitsRetReq;
import com.absa.amol.debitcardlimits.sparrow.model.retrieve.DebitCardLimitsRetReqWrapper;
import com.absa.amol.debitcardlimits.sparrow.model.retrieve.DebitCardLimitsRetRes;
import com.absa.amol.util.exception.ApiRequestException;
import com.absa.amol.util.model.ApiRequestHeader;

class DebitCardLimitsRetMapperTest {

	@InjectMocks
	DebitCardLimitsRetMapper mapper;

	@BeforeEach
	public void init() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void setRetResponseTest() {
		String response = "{\"data\":{\"result\":\"OK\",\"limits\":[{\"id\":\"2-1\",\"name\":\"Daily Contactless No-PIN Debit Amount\",\"type\":\"contactless\",\"period\":\"1D\",\"class\":\"amount\",\"limitValue\":\"10000\",\"limitUsed\":\"0\",\"limitRemaining\":\"10000\",\"limitMinimum\":\"300\",\"limitMaximum\":\"1000\"}]}}";
		try {
			List<DebitCardLimitsRetRes> resp = mapper.setRetResponse(response, getDebitCardLimitsRetReqWrapper());
			Assertions.assertEquals("2-1", resp.get(0).getLimitId());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	void setRetExpResponseTest() {
		String response = "{\"data\":{\"result\":\"ERROR\",\"error\":\"ERR_APP_VALIDATION\",\"errorText\":\"Card identifier is invalid\"}}";
		try {
			mapper.setRetResponse(response, getDebitCardLimitsRetReqWrapper());

		} catch (Exception e) {
			Assertions.assertEquals(true, e instanceof ApiRequestException);
		}
	}

	

	private DebitCardLimitsRetReqWrapper getDebitCardLimitsRetReqWrapper() {
		DebitCardLimitsRetReqWrapper reqWrapper = new DebitCardLimitsRetReqWrapper();
		DebitCardLimitsRetReq debitCardLimitsRetReq = new DebitCardLimitsRetReq();
		debitCardLimitsRetReq.setCardId("ddasdasdasdasdasd");
		reqWrapper.setApiRequestHeader(getApiRequestHeader());
		reqWrapper.setDebitCardLimitsRetReq(debitCardLimitsRetReq);
		return reqWrapper;
	}

	private ApiRequestHeader getApiRequestHeader() {
		ApiRequestHeader apiRequestHeader = new ApiRequestHeader();
		apiRequestHeader.setBusinessId("BWBRB");
		apiRequestHeader.setSystemId("IB");
		apiRequestHeader.setCountryCode("BW");
		apiRequestHeader.setCorrelationId("abcbfa84-e5e2-425e-830e-f07f70c3fabc");
		apiRequestHeader.setStaffId("IFE");
		apiRequestHeader.setConsumerUniqueReferenceId("4466456684");
		return apiRequestHeader;
	}

}
