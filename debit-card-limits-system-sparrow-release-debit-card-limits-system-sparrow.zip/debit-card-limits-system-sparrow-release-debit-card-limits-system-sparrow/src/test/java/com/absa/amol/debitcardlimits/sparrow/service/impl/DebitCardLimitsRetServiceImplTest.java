package com.absa.amol.debitcardlimits.sparrow.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.absa.amol.debitcardlimits.sparrow.mapper.DebitCardLimitsRetMapper;
import com.absa.amol.debitcardlimits.sparrow.model.retrieve.DebitCardLimitsRetReq;
import com.absa.amol.debitcardlimits.sparrow.model.retrieve.DebitCardLimitsRetReqWrapper;
import com.absa.amol.debitcardlimits.sparrow.model.retrieve.DebitCardLimitsRetRes;
import com.absa.amol.debitcardlimits.sparrow.util.DebitCardLimitsSparrowUtil;
import com.absa.amol.debitcardlimits.sparrow.util.DebitCardLimitsSparrowValidatorUtil;
import com.absa.amol.debitcardlimits.sparrow.util.HttpConnectionUtil;
import com.absa.amol.util.exception.ApiRequestException;
import com.absa.amol.util.exception.ApiResponseException;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.model.ResponseEntity;
import com.absa.amol.util.utility.DataGridServiceUtil;

class DebitCardLimitsRetServiceImplTest {

	@Mock
	DebitCardLimitsSparrowValidatorUtil debitCardLimitsSparrowValidatorUtil;

	@Mock
	DebitCardLimitsSparrowUtil util;

	@InjectMocks
	DebitCardLimitsRetServiceImpl serviceImpl;

	@Mock
	DataGridServiceUtil dataGridServiceUtil;

	@Mock
	DebitCardLimitsRetMapper retMapper;

	@Mock
	HttpConnectionUtil httpConnectionUtil;

	@BeforeEach
	void init() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void debitCardLimitsRetrievalTest() {

		Mockito.when(util.getChannelId(ArgumentMatchers.any())).thenReturn("IB");
		try {
			Mockito.when(retMapper.setRetResponse(ArgumentMatchers.any(), ArgumentMatchers.any()))
					.thenReturn(getListResp());
		} catch (Exception e) {
			e.printStackTrace();
		}

		Mockito.when(util.getConfigStringValue("sparrow.debitcard.limit.url"))
				.thenReturn("https://155.24.100.137:8008/tanzania/api/v1/cards/limits");

		try {
			Mockito.when(httpConnectionUtil.getHttpConnectionForGet()).thenReturn(httpGetUrlConnection());
		} catch (KeyManagementException | NoSuchAlgorithmException | IOException e) {
			e.printStackTrace();
		}
		ResponseEntity<List<DebitCardLimitsRetRes>> listResp = serviceImpl
				.debitCardLimitsRetrieval(getDebitCardLimitsRetReqWrapper());

		assertEquals("test", listResp.getData().get(0).getClassName());
	}
	
	@Test
	void debitCardLimitsRetrievalErrorTest() {

		Mockito.when(util.getChannelId(ArgumentMatchers.any())).thenReturn("IB");
		try {
			Mockito.when(retMapper.setRetResponse(ArgumentMatchers.any(), ArgumentMatchers.any()))
					.thenReturn(getListResp());
		} catch (Exception e) {
			e.printStackTrace();
		}

		Mockito.when(util.getConfigStringValue("sparrow.debitcard.limit.url"))
				.thenReturn("https://155.24.100.137:8008/tanzania/api/v1/cards/limits");

		try {
			Mockito.when(httpConnectionUtil.getHttpConnectionForGet()).thenReturn(httpGetUrlConnection());
		} catch (KeyManagementException | NoSuchAlgorithmException | IOException e) {
			e.printStackTrace();
		}
		ResponseEntity<List<DebitCardLimitsRetRes>> listResp = serviceImpl
				.debitCardLimitsRetrieval(getDebitCardLimitsRetErrorReqWrapper());

		assertEquals("test", listResp.getData().get(0).getClassName());
	}

	private HttpsURLConnection httpGetUrlConnection()
			throws NoSuchAlgorithmException, KeyManagementException, IOException {
		SSLContext sslCtx = SSLContext.getInstance("TLS");
		TrustManager[] trustMgr = getTrustMngr();
		sslCtx.init(null, trustMgr, new SecureRandom());
		HttpsURLConnection.setDefaultSSLSocketFactory(sslCtx.getSocketFactory());
		String httpsUrl = "https://155.24.100.137:8008/tanzania/api/v1/cards/limits";
		URL url = new URL(httpsUrl);

		HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
		con.setHostnameVerifier(new HostnameVerifier() {
			@Override
			public boolean verify(String hostname, SSLSession session) {
				return true;
			}
		});
		return con;
	}

	private TrustManager[] getTrustMngr() {
		return new TrustManager[] { new X509TrustManager() {
			@Override
			public X509Certificate[] getAcceptedIssuers() {
				return new X509Certificate[0];
			}

			@Override
			public void checkClientTrusted(X509Certificate[] certs, String t) {
			}

			@Override
			public void checkServerTrusted(X509Certificate[] certs, String t) {
			}
		} };
	}

	@Test
	void debitCardLimitsRetrievalExceptionTest() {

		Mockito.when(util.getChannelId(ArgumentMatchers.any())).thenReturn("IB");
		try {

			serviceImpl.debitCardLimitsRetrieval(getDebitCardLimitsRetReqWrapper());

		} catch (Exception e) {
			assertEquals(true, e instanceof ApiResponseException);
		}
	}

	@Test
	void debitCardLimitsRetrievalApiExceptionTest() throws Exception {

		Mockito.when(util.getChannelId(ArgumentMatchers.any())).thenReturn("IB");
		Mockito.when(retMapper.setRetResponse(ArgumentMatchers.any(), ArgumentMatchers.any()))
				.thenThrow(new ApiRequestException("400", "Bad Request"));
		try {
			Mockito.when(httpConnectionUtil.getHttpConnectionForGet()).thenReturn(httpGetUrlConnection());
		} catch (KeyManagementException | NoSuchAlgorithmException | IOException e) {
			e.printStackTrace();
		}
		try {

			serviceImpl.debitCardLimitsRetrieval(getDebitCardLimitsRetReqWrapper());

		} catch (Exception e) {
			assertEquals(true, e instanceof ApiRequestException);
		}
	}

	private List<DebitCardLimitsRetRes> getListResp() {
		DebitCardLimitsRetRes resp = new DebitCardLimitsRetRes();
		List<DebitCardLimitsRetRes> respList = new ArrayList<DebitCardLimitsRetRes>();
		resp.setClassName("test");
		resp.setLimitId("test");
		resp.setLimitMaximum("test");
		resp.setLimitMinimum("test");
		resp.setLimitValue("test");
		resp.setName("test");
		resp.setPeriod("test");
		resp.setType("test");
		resp.setLimitRemaining("test");
		resp.setLimitUsed("test");
		respList.add(resp);
		return respList;
	}

	private DebitCardLimitsRetReqWrapper getDebitCardLimitsRetReqWrapper() {
		DebitCardLimitsRetReqWrapper reqWrapper = new DebitCardLimitsRetReqWrapper();
		DebitCardLimitsRetReq debitCardLimitsRetReq = new DebitCardLimitsRetReq();
		debitCardLimitsRetReq.setCardId("gGQWoROoQ5TZmO04AEgMt0QLRMn");
		reqWrapper.setApiRequestHeader(getApiRequestHeader());
		reqWrapper.setDebitCardLimitsRetReq(debitCardLimitsRetReq);
		return reqWrapper;
	}
	private DebitCardLimitsRetReqWrapper getDebitCardLimitsRetErrorReqWrapper() {
		DebitCardLimitsRetReqWrapper reqWrapper = new DebitCardLimitsRetReqWrapper();
		DebitCardLimitsRetReq debitCardLimitsRetReq = new DebitCardLimitsRetReq();
		debitCardLimitsRetReq.setCardId("gGQWoROoQ5TZmO04AEgMt0QLRMo");
		reqWrapper.setApiRequestHeader(getApiRequestHeader());
		reqWrapper.setDebitCardLimitsRetReq(debitCardLimitsRetReq);
		return reqWrapper;
	}

	private ApiRequestHeader getApiRequestHeader() {
		ApiRequestHeader apiRequestHeader = new ApiRequestHeader();
		apiRequestHeader.setBusinessId("BWBRB");
		apiRequestHeader.setSystemId("IB");
		apiRequestHeader.setCountryCode("BW");
		apiRequestHeader.setCorrelationId("abcbfa84-e5e2-425e-830e-f07f70c3fabc");
		apiRequestHeader.setStaffId("IFE");
		apiRequestHeader.setConsumerUniqueReferenceId("4466456684");
		return apiRequestHeader;
	}

}
