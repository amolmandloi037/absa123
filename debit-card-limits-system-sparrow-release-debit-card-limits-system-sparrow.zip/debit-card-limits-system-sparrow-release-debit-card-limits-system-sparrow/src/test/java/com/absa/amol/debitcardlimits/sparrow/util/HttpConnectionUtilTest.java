package com.absa.amol.debitcardlimits.sparrow.util;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.io.IOException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

class HttpConnectionUtilTest {

	@InjectMocks
	HttpConnectionUtil httpConnectionUtil;
	
	@Mock
	DebitCardLimitsSparrowUtil util;
	
	@BeforeEach
	 void setup() {
		 MockitoAnnotations.openMocks(this);
	}
	@Test
	void test() {
		assertNotNull(httpConnectionUtil.getCloseableHttpClient());
	}
	
	@Test
	void getHttpConnectionForGetTest() throws IOException {
		Mockito.when(util.getConfigStringValue(ArgumentMatchers.anyString())).thenReturn("https://155.24.100.137:8008/tanzania/api/v1/cards/limits");
		
		assertNotNull(httpConnectionUtil.getHttpConnectionForGet());
	}

}
