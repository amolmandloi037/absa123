package com.absa.amol.debitcardlimits.sparrow.util;
import org.eclipse.microprofile.config.Config;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.absa.amol.util.utility.DataGridServiceUtil;

class DebitCardLimitsSparrowUtilTest {

	@InjectMocks
	private DebitCardLimitsSparrowUtil debitCardLimitsSparrowUtil;
	
	@Mock
	Config config;

	@Mock
	DataGridServiceUtil dataGridServiceUtil;
	


	@BeforeEach
	public void setup() {
		MockitoAnnotations.openMocks(this);
	}


	@Test
	void testGetConfigStringValue() {
		Mockito.when(debitCardLimitsSparrowUtil.getConfigStringValue("businessId")).thenReturn("MUBRB");
		Assertions.assertEquals("MUBRB", debitCardLimitsSparrowUtil.getConfigStringValue("businessId"));
		
	}
	@Test
	void testGetConfigIntValue() {

		Mockito.when(config.getValue(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(1);
		debitCardLimitsSparrowUtil.getConfigIntValue("vgvgh");
		Assertions.assertEquals(1, debitCardLimitsSparrowUtil.getConfigIntValue("vgvgh"));
	}
	
	@Test
	void testGetConfigBooleanValue() {

		Mockito.when(config.getValue(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn(false);
		debitCardLimitsSparrowUtil.getConfigBooleanValue("vgvgh");
		Assertions.assertEquals(false, debitCardLimitsSparrowUtil.getConfigBooleanValue("vgvgh"));
	}
	@Test
	void testGetChannelId() {

		Mockito.when(dataGridServiceUtil.getChannelId(ArgumentMatchers.any(), ArgumentMatchers.any()))
				.thenReturn("test");
		Assertions.assertEquals("test",
				debitCardLimitsSparrowUtil.getChannelId("IB"));

	}	
}