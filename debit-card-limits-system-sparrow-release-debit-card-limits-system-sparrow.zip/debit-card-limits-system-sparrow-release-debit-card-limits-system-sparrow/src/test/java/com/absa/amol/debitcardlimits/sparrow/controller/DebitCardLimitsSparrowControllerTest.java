package com.absa.amol.debitcardlimits.sparrow.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;

import javax.ws.rs.core.Response;

import org.eclipse.microprofile.config.Config;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.absa.amol.debitcardlimits.sparrow.model.retrieve.DebitCardLimitsRetReq;
import com.absa.amol.debitcardlimits.sparrow.model.update.DebitCardLimitsUpdtReq;
import com.absa.amol.debitcardlimits.sparrow.service.impl.DebitCardLimitsRetServiceImpl;
import com.absa.amol.debitcardlimits.sparrow.service.impl.DebitCardLimitsUpdtServiceImpl;
import com.absa.amol.util.model.ApiRequestHeader;

class DebitCardLimitsSparrowControllerTest {

	@InjectMocks
	private DebitCardLimitsSparrowController controller;

	@Mock
	Config config;

	@Mock
	DebitCardLimitsRetServiceImpl debitCardLimitsRetServiceImpl;

	@Mock
	DebitCardLimitsUpdtServiceImpl debitCardLimitsUpdtServiceImpl;

	@BeforeEach
	public void init() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void retrieveDebitCardLimitsTest() {
		DebitCardLimitsRetReq debitCardLimitsRetReq = new DebitCardLimitsRetReq();
		ApiRequestHeader apiRequestHeader = new ApiRequestHeader();
		apiRequestHeader.setConsumerUniqueReferenceId("6878978");
		Response response = controller.retrieveDebitCardLimits(apiRequestHeader, debitCardLimitsRetReq);
		assertEquals(200, response.getStatus());
	}

	@Test
	void retrieveDebitCardLimitsFallbackTimeOutTest() {
		DebitCardLimitsRetReq debitCardLimitsRetReq = new DebitCardLimitsRetReq();
		ApiRequestHeader apiRequestHeader = new ApiRequestHeader();
		Response response = controller.fallbackForRetrieveDebitCardLimits(apiRequestHeader, debitCardLimitsRetReq);
		assertEquals(504, response.getStatus());
	}

	@Test
	void updateDebitCardLimitsTest() {
		DebitCardLimitsUpdtReq debitCardLimitsUpdtReq = new DebitCardLimitsUpdtReq();
		ApiRequestHeader apiRequestHeader = new ApiRequestHeader();
		apiRequestHeader.setConsumerUniqueReferenceId("6878978");
		Response response = controller.updateDebitCardLimits(apiRequestHeader, debitCardLimitsUpdtReq);
		assertEquals(200, response.getStatus());
	}

	@Test
	void updateDebitCardLimitsFallbackTimeOutTest() {
		DebitCardLimitsUpdtReq debitCardLimitsUpdtReq = new DebitCardLimitsUpdtReq();
		ApiRequestHeader apiRequestHeader = new ApiRequestHeader();
		Response response = controller.fallbackForUpdateDebitCardLimits(apiRequestHeader, debitCardLimitsUpdtReq);
		assertEquals(504, response.getStatus());
	}

}
