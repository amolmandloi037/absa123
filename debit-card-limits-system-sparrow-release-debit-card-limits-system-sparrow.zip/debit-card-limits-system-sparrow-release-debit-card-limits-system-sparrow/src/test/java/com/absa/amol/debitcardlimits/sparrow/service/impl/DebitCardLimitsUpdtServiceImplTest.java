package com.absa.amol.debitcardlimits.sparrow.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.absa.amol.debitcardlimits.sparrow.mapper.DebitCardLimitsUpdtMapper;
import com.absa.amol.debitcardlimits.sparrow.model.update.DebitCardLimitsUpdtReq;
import com.absa.amol.debitcardlimits.sparrow.model.update.DebitCardLimitsUpdtReqWrapper;
import com.absa.amol.debitcardlimits.sparrow.model.update.DebitCardLimitsUpdtRes;
import com.absa.amol.debitcardlimits.sparrow.model.update.Limit;
import com.absa.amol.debitcardlimits.sparrow.model.update.LimitsUpdReq;
import com.absa.amol.debitcardlimits.sparrow.model.update.SorUpdtLimitsReq;
import com.absa.amol.debitcardlimits.sparrow.model.update.SorUpdtReq;
import com.absa.amol.debitcardlimits.sparrow.util.DebitCardLimitsSparrowConstants;
import com.absa.amol.debitcardlimits.sparrow.util.DebitCardLimitsSparrowUtil;
import com.absa.amol.debitcardlimits.sparrow.util.DebitCardLimitsSparrowValidatorUtil;
import com.absa.amol.debitcardlimits.sparrow.util.HttpConnectionUtil;
import com.absa.amol.util.exception.ApiRequestException;
import com.absa.amol.util.exception.ApiResponseException;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.model.ResponseEntity;
import com.absa.amol.util.utility.DataGridServiceUtil;

class DebitCardLimitsUpdtServiceImplTest {

	@Mock
	DebitCardLimitsSparrowValidatorUtil debitCardLimitsSparrowValidatorUtil;

	@Mock
	DebitCardLimitsSparrowUtil util;

	@InjectMocks
	DebitCardLimitsUpdtServiceImpl serviceImpl;

	@Mock
	DataGridServiceUtil dataGridServiceUtil;

	@Mock
	DebitCardLimitsUpdtMapper updtMapper;

	@Mock
	HttpConnectionUtil httpConnectionUtil;

	@BeforeEach
	void init() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void debitCardLimitsUpdateTest() {
		Mockito.when(util.getChannelId(ArgumentMatchers.any())).thenReturn("IB");
		Mockito.when(util.getConfigStringValue(DebitCardLimitsSparrowConstants.DEBIT_CARD_LIMIT_URL))
				.thenReturn("https://155.24.100.137:8008/tanzania/api/v1/cards/limits");
		Mockito.when(updtMapper.getSorReq(ArgumentMatchers.any())).thenReturn(getSorUpdtLimitsReq());
		Mockito.when(httpConnectionUtil.getCloseableHttpClient()).thenReturn(getHttpClient());
		try {
			Mockito.when(updtMapper.getUpdatedResp(ArgumentMatchers.any(), ArgumentMatchers.any()))
					.thenReturn(getRespentity());
		} catch (Exception e) {
			e.printStackTrace();
		}
		ResponseEntity<List<DebitCardLimitsUpdtRes>> resp = serviceImpl
				.debitCardLimitsUpdate(getDebitCardLimitsUpdtReqWrapper());
		assertEquals("200", resp.getCode());

	}

	private CloseableHttpClient getHttpClient() {
		CloseableHttpClient httpClient = HttpClients.custom().build();
		try {
			httpClient = HttpClients.custom().setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE)
					.setSSLContext(new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy() {
						public boolean isTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
							return true;
						}
					}).build()).build();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return httpClient;
	}

	@Test
	void debitCardLimitsUpdateExceptionTest() {

		try {

			serviceImpl.debitCardLimitsUpdate(getDebitCardLimitsUpdtReqWrapper());

		} catch (Exception e) {
			assertEquals(true, e instanceof ApiResponseException);
		}

	}

	@Test
	void debitCardLimitsUpdateApiRequestTest() {
		Mockito.when(util.getChannelId(ArgumentMatchers.any())).thenReturn("IB");
		Mockito.when(util.getConfigStringValue("sparrow.retrieve.debitcard.limit.url"))
				.thenReturn("https://155.24.100.137:8008/tanzania/api/v1/cards/limits");
		Mockito.when(httpConnectionUtil.getCloseableHttpClient())
				.thenThrow(new ApiRequestException("400", "Bad Request"));

		try {

			serviceImpl.debitCardLimitsUpdate(getDebitCardLimitsUpdtReqWrapper());

		} catch (Exception e) {
			assertEquals(true, e instanceof ApiRequestException);
		}

	}

	private ResponseEntity<List<DebitCardLimitsUpdtRes>> getRespentity() {
		ResponseEntity<List<DebitCardLimitsUpdtRes>> entity = new ResponseEntity<List<DebitCardLimitsUpdtRes>>("200",
				"Success", "Data Updated", getData());
		return entity;
	}

	private List<DebitCardLimitsUpdtRes> getData() {
		List<DebitCardLimitsUpdtRes> respList = new ArrayList<DebitCardLimitsUpdtRes>();
		DebitCardLimitsUpdtRes resp = new DebitCardLimitsUpdtRes();
		resp.setClassName("test");
		resp.setLimitId("test");
		resp.setLimitMaximum("test");
		resp.setLimitMinimum("test");
		resp.setLimitValue("test");
		resp.setName("test");
		resp.setPeriod("test");
		resp.setType("test");
		resp.setLimitRemaining("test");
		resp.setLimitUsed("test");
		respList.add(resp);

		return respList;
	}

	private SorUpdtLimitsReq getSorUpdtLimitsReq() {
		LimitsUpdReq req = new LimitsUpdReq();
		req.setId("test");
		req.setLimitValue("4");
		List<LimitsUpdReq> limits = new ArrayList<>();
		limits.add(req);
		SorUpdtReq data = new SorUpdtReq();
		data.setLimits(limits);
		SorUpdtLimitsReq sorUpdtLimitsReq = new SorUpdtLimitsReq();
		sorUpdtLimitsReq.setData(data);
		return sorUpdtLimitsReq;
	}

	private DebitCardLimitsUpdtReqWrapper getDebitCardLimitsUpdtReqWrapper() {

		DebitCardLimitsUpdtReqWrapper reqWrapper = new DebitCardLimitsUpdtReqWrapper();
		reqWrapper.setApiRequestHeader(getApiRequestHeader());
		reqWrapper.setChannelId("IB");
		reqWrapper.setDebitCardLimitsUpdtReq(getDebitCardLimitsUpdtReq());
		return reqWrapper;
	}

	private DebitCardLimitsUpdtReq getDebitCardLimitsUpdtReq() {
		DebitCardLimitsUpdtReq req = new DebitCardLimitsUpdtReq();
		Limit limit = new Limit();
		limit.setCurrentLimit("4");
		limit.setLimitId("aa");
		List<Limit> limits = new ArrayList<>();
		limits.add(limit);
		req.setCardId("gGQWoROoQ5TZmO04AEgMt0QLRMn");
		req.setLimits(limits);
		return req;
	}

	private ApiRequestHeader getApiRequestHeader() {
		ApiRequestHeader apiRequestHeader = new ApiRequestHeader();
		apiRequestHeader.setBusinessId("BWBRB");
		apiRequestHeader.setCorrelationId("d7ebfa84-e5e2-425e-999e-f07f70c3f751");
		apiRequestHeader.setCountryCode("BW");
		apiRequestHeader.setSystemId("IB");
		apiRequestHeader.setStaffId("IFE");
		apiRequestHeader.setConsumerUniqueReferenceId("1212312312312312");
		return apiRequestHeader;
	}

}
