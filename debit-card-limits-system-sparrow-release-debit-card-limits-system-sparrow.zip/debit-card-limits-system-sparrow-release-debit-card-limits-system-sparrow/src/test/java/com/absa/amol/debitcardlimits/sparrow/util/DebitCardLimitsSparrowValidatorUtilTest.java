package com.absa.amol.debitcardlimits.sparrow.util;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.eclipse.microprofile.config.Config;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.absa.amol.debitcardlimits.sparrow.model.retrieve.DebitCardLimitsRetReq;
import com.absa.amol.debitcardlimits.sparrow.model.retrieve.DebitCardLimitsRetReqWrapper;
import com.absa.amol.debitcardlimits.sparrow.model.update.DebitCardLimitsUpdtReq;
import com.absa.amol.debitcardlimits.sparrow.model.update.DebitCardLimitsUpdtReqWrapper;
import com.absa.amol.debitcardlimits.sparrow.model.update.Limit;
import com.absa.amol.util.exception.ApiException;
import com.absa.amol.util.model.ApiRequestHeader;

class DebitCardLimitsSparrowValidatorUtilTest {
	
	@InjectMocks
	DebitCardLimitsSparrowValidatorUtil validateUtil;
	
	@Mock
	private Validator validator;
	@Mock
	DebitCardLimitsSparrowUtil debitCardLimitsSparrowUtil;
	@InjectMocks
	private HashSet<ConstraintViolation<Object>> violations;

	@Mock
	private ConstraintViolation<Object> object;
	@Mock
	Config config;
	
	
	@BeforeEach
	 void setup() {
		 MockitoAnnotations.openMocks(this);
	}
	
	@Test
	void validatorRetrieveTest() {
		
		Mockito.when(object.getMessageTemplate()).thenReturn("test error message template");
		violations.add(object);
		Mockito.when(config.getValue(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn("test");
		Mockito.when(validator.validate(ArgumentMatchers.any(),ArgumentMatchers.any())).thenReturn(violations);
		Mockito.when(debitCardLimitsSparrowUtil.getConfigStringValue(ArgumentMatchers.any())).thenReturn("error message");
		
		DebitCardLimitsRetReqWrapper debitCardLimitsRetReqWrapper= new DebitCardLimitsRetReqWrapper();
		debitCardLimitsRetReqWrapper.setApiRequestHeader(getApiHeaders());
		debitCardLimitsRetReqWrapper.setDebitCardLimitsRetReq(getDebitCardLimitsRetReq());
		
		try {
			validateUtil.validateRetRequest(debitCardLimitsRetReqWrapper);
		} catch (ApiException e) {
			Assertions.assertEquals(true, e instanceof ApiException);
		}


	}
	
	@Test
	void validatorRetrieveCustomTest() {
		
		DebitCardLimitsRetReq req = new DebitCardLimitsRetReq();
		req.setApiRequestHeader(getApiHeaders());
		req.setCardId("000000");
		
		Mockito.when(object.getMessageTemplate()).thenReturn("test error message template");
		violations.add(object);
		Mockito.when(config.getValue(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn("test");
		Mockito.when(validator.validate(ArgumentMatchers.any(),ArgumentMatchers.any())).thenReturn(violations);
		Mockito.when(debitCardLimitsSparrowUtil.getConfigStringValue(ArgumentMatchers.any())).thenReturn("error message");
		
		DebitCardLimitsRetReqWrapper debitCardLimitsRetReqWrapper= new DebitCardLimitsRetReqWrapper();
		debitCardLimitsRetReqWrapper.setApiRequestHeader(getApiHeaders());
		debitCardLimitsRetReqWrapper.setDebitCardLimitsRetReq(req);
		
		try {
			validateUtil.validateRetRequest(debitCardLimitsRetReqWrapper);
		} catch (ApiException e) {
			Assertions.assertEquals(true, e instanceof ApiException);
		}


	}
	
	private DebitCardLimitsRetReq getDebitCardLimitsRetReq() {
		DebitCardLimitsRetReq req = new DebitCardLimitsRetReq();
		req.setApiRequestHeader(getApiHeaders());
		req.setCardId("11231231313");
		return req;
	}

	@Test
	void validatorUpdateTest() {
		
		Mockito.when(object.getMessageTemplate()).thenReturn("test error message template");
		violations.add(object);
		Mockito.when(config.getValue(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn("test");
		Mockito.when(validator.validate(ArgumentMatchers.any(),ArgumentMatchers.any())).thenReturn(violations);
		Mockito.when(debitCardLimitsSparrowUtil.getConfigStringValue(ArgumentMatchers.any())).thenReturn("error message");
		
		DebitCardLimitsUpdtReqWrapper debitCardLimitsUpdtReqWrapper= new DebitCardLimitsUpdtReqWrapper();
		debitCardLimitsUpdtReqWrapper.setApiRequestHeader(getApiHeaders());
		debitCardLimitsUpdtReqWrapper.setDebitCardLimitsUpdtReq(getDebitCardLimitsUpdtReq());
		
		try {
			validateUtil.validateUpdtRequest(debitCardLimitsUpdtReqWrapper);
		} catch (ApiException e) {
			Assertions.assertEquals(true, e instanceof ApiException);
		}


	}
	
	@Test
	void validatorUpdateCustomTest() {
		
		DebitCardLimitsUpdtReq req = new DebitCardLimitsUpdtReq();
		Limit limit= new Limit();
		limit.setCurrentLimit("4");
		limit.setLimitId("aa");
		List<Limit> limits = new ArrayList<>();
		req.setCardId("000000000");
		req.setLimits(limits);
		
		Mockito.when(object.getMessageTemplate()).thenReturn("test error message template");
		violations.add(object);
		Mockito.when(config.getValue(ArgumentMatchers.any(), ArgumentMatchers.any())).thenReturn("test");
		Mockito.when(validator.validate(ArgumentMatchers.any(),ArgumentMatchers.any())).thenReturn(violations);
		Mockito.when(debitCardLimitsSparrowUtil.getConfigStringValue(ArgumentMatchers.any())).thenReturn("error message");
		
		DebitCardLimitsUpdtReqWrapper debitCardLimitsUpdtReqWrapper= new DebitCardLimitsUpdtReqWrapper();
		debitCardLimitsUpdtReqWrapper.setApiRequestHeader(getApiHeaders());
		debitCardLimitsUpdtReqWrapper.setDebitCardLimitsUpdtReq(req);
		
		try {
			validateUtil.validateUpdtRequest(debitCardLimitsUpdtReqWrapper);
		} catch (ApiException e) {
			Assertions.assertEquals(true, e instanceof ApiException);
		}


	}
private DebitCardLimitsUpdtReq getDebitCardLimitsUpdtReq() {
	DebitCardLimitsUpdtReq req = new DebitCardLimitsUpdtReq();
	Limit limit= new Limit();
	limit.setCurrentLimit("4");
	limit.setLimitId("aa");
	List<Limit> limits = new ArrayList<>();
	req.setCardId("4234234234234234234");
	req.setLimits(limits);
		return req;
	}
	private ApiRequestHeader getApiHeaders() {
		ApiRequestHeader apiRequestHeader = new ApiRequestHeader();
		apiRequestHeader.setBusinessId("BWBRB");
		apiRequestHeader.setCorrelationId("d7ebfa84-e5e2-425e-999e-f07f70c3f751");
		apiRequestHeader.setCountryCode("BW");
		apiRequestHeader.setSystemId("IB");
		apiRequestHeader.setStaffId("IFE");
		apiRequestHeader.setConsumerUniqueReferenceId("1212312312312312");
		return apiRequestHeader;
	}
}
	