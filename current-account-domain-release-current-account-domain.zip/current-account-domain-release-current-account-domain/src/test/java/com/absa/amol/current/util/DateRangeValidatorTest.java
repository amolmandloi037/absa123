package com.absa.amol.current.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import javax.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import com.absa.amol.current.model.TransactionHistoryRequest;

public class DateRangeValidatorTest {
  @Mock
  private ConstraintValidatorContext context;

  @Mock
  private TransactionHistoryRequest transactionHistoryRequest;

  @InjectMocks
  private DateRangeValidator dateRangeValidator;

  @BeforeEach
  public void setup() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void validDateRangeTestOne() {
    Mockito.when(transactionHistoryRequest.getStartDate()).thenReturn("20201010");
    Mockito.when(transactionHistoryRequest.getEndDate()).thenReturn("20301010");
    Boolean isValid = dateRangeValidator.isValid(transactionHistoryRequest, context);
    assertEquals(true, isValid);
  }

  @Test
  public void validDateRangeTestTwo() {
    Mockito.when(transactionHistoryRequest.getStartDate()).thenReturn("20201010");
    Mockito.when(transactionHistoryRequest.getEndDate()).thenReturn(null);
    Boolean isValid = dateRangeValidator.isValid(transactionHistoryRequest, context);
    assertEquals(true, isValid);
  }

  @Test
  public void validDateRangeTestThree() {
    Mockito.when(transactionHistoryRequest.getStartDate()).thenReturn("20301010");
    Mockito.when(transactionHistoryRequest.getEndDate()).thenReturn(null);
    Boolean isValid = dateRangeValidator.isValid(transactionHistoryRequest, context);
    assertEquals(true, isValid);
  }

  @Test
  public void inValidDateRangeTestOne() {
    Mockito.when(transactionHistoryRequest.getStartDate()).thenReturn("20301010");
    Mockito.when(transactionHistoryRequest.getEndDate()).thenReturn("20201010");
    Boolean isValid = dateRangeValidator.isValid(transactionHistoryRequest, context);
    assertEquals(false, isValid);

  }

  @Test
  public void inValidDateRangeTestTwo() {
    Mockito.when(transactionHistoryRequest.getStartDate()).thenReturn("20301010");
    Mockito.when(transactionHistoryRequest.getEndDate()).thenReturn("202010101");
    Boolean isValid = dateRangeValidator.isValid(transactionHistoryRequest, context);
    assertEquals(true, isValid);
  }

  @Test
  public void inValidDateRangeTestThree() {
    Mockito.when(transactionHistoryRequest.getStartDate()).thenReturn("20301010");
    Mockito.when(transactionHistoryRequest.getEndDate()).thenReturn("202010101");
    Boolean isValid = dateRangeValidator.isValid(transactionHistoryRequest, context);
    assertEquals(true, isValid);
  }

  @Test
  public void inValidDateRangeTestFour() {
    Mockito.when(transactionHistoryRequest.getStartDate()).thenReturn("203011010");
    Mockito.when(transactionHistoryRequest.getEndDate()).thenReturn("202010101");
    Boolean isValid = dateRangeValidator.isValid(transactionHistoryRequest, context);
    assertEquals(true, isValid);
  }

}
