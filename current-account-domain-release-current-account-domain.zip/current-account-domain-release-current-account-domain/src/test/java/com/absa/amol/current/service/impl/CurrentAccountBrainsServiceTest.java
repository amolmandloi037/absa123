package com.absa.amol.current.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import com.absa.amol.common.exception.ApiException;
import com.absa.amol.common.exception.ApiResponseException;
import com.absa.amol.common.model.ApiRequestHeader;
import com.absa.amol.common.model.ResponseEntity;
import com.absa.amol.current.model.Account;
import com.absa.amol.current.model.AccountDetailsRequest;
import com.absa.amol.current.model.AccountRequest;
import com.absa.amol.current.model.AccountResponse;
import com.absa.amol.current.service.CurrentAccountService;
import com.absa.amol.current.service.impl.CurrentAccountServiceImpl;
import com.absa.amol.current.util.AccountDetailsDomainServiceClient;
import com.absa.amol.current.util.CurrentAccountConstant;

class CurrentAccountBrainsServiceTest {

	@InjectMocks
	private CurrentAccountServiceImpl currentAccountServiceImpl;

	@Mock
	private AccountRequest accountRequest;

	@Mock
	private AccountDetailsDomainServiceClient accountDetailsDomainServiceClient;

	@Mock
	private CurrentAccountService currentAccountService;

	@Mock
	private ResponseEntity<Account> accountNameEntity;

	@BeforeEach
	public void setup() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void testSuccessResponse() {
		Response response = Mockito.spy(getCurrentAccountResponse());
		Mockito.when(accountDetailsDomainServiceClient.getAccountDetails(Mockito.any(AccountRequest.class)))
				.thenReturn(response);
		Mockito.doReturn(getCurrentAccountResponseEntity()).when(response)
				.readEntity(new GenericType<ResponseEntity<AccountResponse>>() {
				});

		Mockito.when(accountDetailsDomainServiceClient.getAccountName(Mockito.any(AccountDetailsRequest.class)))
				.thenReturn(response);
		Mockito.doReturn(getCurrentAccountStub()).when(response).readEntity(new GenericType<ResponseEntity<Account>>() {
		});

		Response testResponse = currentAccountServiceImpl.getCurrentAccountDetails(getRequestStub());

		assertNotNull(testResponse);
		assertEquals(200, testResponse.getStatus());

	}

	@Test
	void testErrorResponse() {
		Mockito.when(accountDetailsDomainServiceClient.getAccountDetails(Mockito.any(AccountRequest.class)))
				.thenReturn(getCurrentAccountResponseError());
		Response testResponse = currentAccountServiceImpl.getCurrentAccountDetails(getRequestStub());

		assertNotNull(testResponse);
		assertEquals(500, testResponse.getStatus());

	}

	@Test
	void testApiResponse() {

		Response testResponse = currentAccountServiceImpl.getCurrentAccountDetails(getInvalidRequestStub());

		assertNotNull(testResponse);
		assertEquals(500, testResponse.getStatus());

	}

	@Test
	void testApiResponseException() {

		Mockito.when(accountDetailsDomainServiceClient.getAccountDetails(Mockito.any(AccountRequest.class)))
				.thenThrow(new ApiException("500", "Exception Occurred"));

		assertThrows(ApiException.class, () -> {
			currentAccountServiceImpl.getCurrentAccountDetails(getRequestStub());
		});

	}

	@Test
	void testFcrException() {

		assertThrows(Exception.class, () -> {
			currentAccountServiceImpl.getCurrentAccountDetailsFromFcr(getRequestStub());
		});
	}

	@Test
	public void testBrainException() {

		assertThrows(Exception.class, () -> {
			currentAccountServiceImpl.getCurrentAccountDetails(getRequestStub());
		});

	}

	@Test
	private void testExceptionResponse() {
		Mockito.when(accountDetailsDomainServiceClient.getAccountDetails(Mockito.any(AccountRequest.class)))
				.thenThrow(new ApiResponseException(CurrentAccountConstant.GET_CURRENT_ACCOUNT_DETAILS_FCR, null));

		assertThrows(ApiResponseException.class, () -> {
			currentAccountService.getCurrentAccountDetails(getInvalidRequestStub());
		});

	}

	private AccountRequest getRequestStub() {
		AccountRequest accountDetailRequest = new AccountRequest();
		accountDetailRequest.setCustomerNumber("123456789");

		ApiRequestHeader reqHeader = new ApiRequestHeader("KE", "AB011", "KEBRB",
				"56675952100015319000005667595212563");
		accountDetailRequest.setApiRequestHeader(reqHeader);

		return accountDetailRequest;
	}

	private Response getCurrentAccountResponse() {

		AccountResponse response = new AccountResponse();
		Account account = new Account();
		account.setAccountId("123658974");
		account.setAccountName("Savings Account");
		account.setAccountNumber("124569378");
		account.setAccountType("Z");

		List<Account> accounts = new ArrayList<Account>();
		accounts.add(account);
		response.setAccounts(accounts);
		ResponseEntity<AccountResponse> responseEntity = new ResponseEntity<AccountResponse>(
				CurrentAccountConstant.SUCCESS_CODE, CurrentAccountConstant.SUCCESS_MSG,
				CurrentAccountConstant.SUCCESS_MSG, response);

		return Response.ok(responseEntity).build();

	}

	private ResponseEntity getCurrentAccountResponseEntity() {

		AccountResponse response = new AccountResponse();
		Account account = new Account();
		account.setAccountId("123658974");
		account.setAccountName("Credit Card");
		account.setAccountNumber("124569378");
		account.setAccountType("Z");

		List<Account> accounts = new ArrayList<Account>();
		accounts.add(account);
		response.setAccounts(accounts);
		ResponseEntity<AccountResponse> responseEntity = new ResponseEntity<AccountResponse>(
				CurrentAccountConstant.SUCCESS_CODE, CurrentAccountConstant.SUCCESS_MSG,
				CurrentAccountConstant.SUCCESS_MSG, response);

		return responseEntity;

	}

	private Response getCurrentAccountResponseError() {
		return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
	}

	private AccountRequest getInvalidRequestStub() {
		AccountRequest accountDetailRequest = new AccountRequest();

		ApiRequestHeader reqHeader = new ApiRequestHeader("KE", "AB011", "KEBRB", "");
		accountDetailRequest.setApiRequestHeader(reqHeader);

		return accountDetailRequest;
	}

	private ResponseEntity getCurrentAccountStub() {

		// AccountResponse response = new AccountResponse();
		Account account = new Account();
		account.setAccountId("123658974");
		account.setAccountName("Savings Account");
		account.setAccountNumber("124569378");
		account.setAccountType("Z");

		// List<Account> accounts = new ArrayList<Account>();
		// accounts.add(account);
		// response.setAccounts(accounts);
		ResponseEntity<Account> responseEntity = new ResponseEntity<Account>(CurrentAccountConstant.SUCCESS_CODE,
				CurrentAccountConstant.SUCCESS_MSG, CurrentAccountConstant.SUCCESS_MSG, account);

		// return Response.ok(responseEntity).build();
		return responseEntity;

	}

}
