package com.absa.amol.current.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import javax.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import com.absa.amol.current.model.TransactionHistoryRequest;

public class AmountValidatorTest {

  @Mock
  private ConstraintValidatorContext context;

  @Mock
  private TransactionHistoryRequest transactionHistoryRequest;

  @InjectMocks
  private AmountValidator amountValidator;


  @BeforeEach
  public void setup() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void validAmountTestOne() {
    Mockito.when(transactionHistoryRequest.getAmountStart()).thenReturn("10.0");
    Mockito.when(transactionHistoryRequest.getAmountEnd()).thenReturn("5.0");
    Boolean isValid = amountValidator.isValid(transactionHistoryRequest, context);
    assertEquals(false, isValid);
  }

  @Test
  public void validAmountTestTwo() {
    Mockito.when(transactionHistoryRequest.getAmountStart()).thenReturn("10.0");
    Mockito.when(transactionHistoryRequest.getAmountEnd()).thenReturn("10.0");
    Boolean isValid = amountValidator.isValid(transactionHistoryRequest, context);
    assertEquals(true, isValid);

  }

  @Test
  public void validAmountTestThree() {
    Mockito.when(transactionHistoryRequest.getAmountStart()).thenReturn(null);
    Mockito.when(transactionHistoryRequest.getAmountEnd()).thenReturn("15.0");
    Boolean isValid = amountValidator.isValid(transactionHistoryRequest, context);
    assertEquals(false, isValid);
  }

  @Test
  public void validAmountTestFour() {
    Mockito.when(transactionHistoryRequest.getAmountStart()).thenReturn("20.0");
    Mockito.when(transactionHistoryRequest.getAmountEnd()).thenReturn(null);
    Boolean isValid = amountValidator.isValid(transactionHistoryRequest, context);
    assertEquals(false, isValid);
  }

  @Test
  public void validAmountTestFive() {
    Mockito.when(transactionHistoryRequest.getAmountStart()).thenReturn(null);
    Mockito.when(transactionHistoryRequest.getAmountEnd()).thenReturn(null);
    Boolean isValid = amountValidator.isValid(transactionHistoryRequest, context);
    assertEquals(true, isValid);
  }

  @Test
  public void inValidAmountTestOne() {
    Mockito.when(transactionHistoryRequest.getAmountStart()).thenReturn("10.0");
    Mockito.when(transactionHistoryRequest.getAmountEnd()).thenReturn("15.0");
    Boolean isValid = amountValidator.isValid(transactionHistoryRequest, context);
    assertEquals(true, isValid);
  }

  @Test
  public void inValidAmountTestTwo() {
    Mockito.when(transactionHistoryRequest.getAmountStart()).thenReturn("20.0");
    Mockito.when(transactionHistoryRequest.getAmountEnd()).thenReturn("15.0");
    Boolean isValid = amountValidator.isValid(transactionHistoryRequest, context);
    assertEquals(false, isValid);
  }

  @Test
  public void inValidAmountTestThree() {
    Mockito.when(transactionHistoryRequest.getAmountStart()).thenReturn("10.0");
    Mockito.when(transactionHistoryRequest.getAmountEnd()).thenReturn("10.0");
    Boolean isValid = amountValidator.isValid(transactionHistoryRequest, context);
    assertEquals(true, isValid);
  }

}
