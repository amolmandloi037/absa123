package com.absa.amol.current.util;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import javax.validation.ConstraintValidatorContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;


public class DateValidatorTest {

  @InjectMocks
  private DateValidator dateValidator;

  @Mock
  private Date date;

  private ConstraintValidatorContext context;

  @BeforeEach
  public void setup() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void validateDateTestOne() {
    Boolean isValid = dateValidator.isValid("20201010", context);
    assertEquals(false, isValid);
  }


  @Test
  public void validateDateTestTwo() {
    Boolean isValid = dateValidator.isValid(null, context);
    assertEquals(true, isValid);
  }

  @Test
  public void validateDateTestThree() {
    Boolean isValid = dateValidator.isValid("2020-10-10", context);
    assertEquals(true, isValid);
  }

  @Test
  public void validateDateTestFour() {
    Boolean isValid = dateValidator.isValid("", context);
    assertEquals(true, isValid);
  }

  @Test
  public void shouldNotThrowException() {
    dateValidator.initialize(date);
    assertDoesNotThrow(() -> dateValidator.initialize(date));
  }

}
