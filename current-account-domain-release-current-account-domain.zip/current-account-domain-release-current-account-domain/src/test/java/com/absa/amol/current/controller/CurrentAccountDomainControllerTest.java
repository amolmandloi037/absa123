package com.absa.amol.current.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import com.absa.amol.common.exception.ApiException;
import com.absa.amol.common.model.ApiRequestHeader;
import com.absa.amol.common.model.ResponseEntity;
import com.absa.amol.current.model.Account;
import com.absa.amol.current.model.AccountRequest;
import com.absa.amol.current.model.AccountResponse;
import com.absa.amol.current.model.Transaction;
import com.absa.amol.current.model.TransactionHistoryRequest;
import com.absa.amol.current.model.TransactionHistoryResponse;
import com.absa.amol.current.service.CountrySpecificService;
import com.absa.amol.current.service.CurrentAccountRequestValidatorService;
import com.absa.amol.current.service.impl.CurrentAccountServiceImpl;
import com.absa.amol.current.service.impl.TransactionHistoryRequestValidatorServiceImpl;
import com.absa.amol.current.service.impl.TransactionHistoryServiceImpl;
import com.absa.amol.current.util.CurrentAccountConstant;

class CurrentAccountDomainControllerTest {



  @InjectMocks
  private CurrentAccountDomainController currentAccountDomainController;

  @Mock
  private CurrentAccountServiceImpl currentAccountServiceImpl;
  @Mock
  private CountrySpecificService countrySpecificService;

  @Mock
  private CurrentAccountRequestValidatorService validatorService;

  @Mock
  private HttpHeaders header;

  @Mock
  private TransactionHistoryServiceImpl transactionHistoryServiceImpl;

  @Mock
  private TransactionHistoryRequestValidatorServiceImpl transactionHistoryRequestValidatorServiceImpl;

  @Mock
  private ResponseEntity responseEntity;

  @BeforeEach
  public void setup() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void testSuccessResponse() {

    // Mockito.doNothing().when(validatorService.validateRequest(getRequestStub()));
    Mockito.when(countrySpecificService.getAccountDetails(Mockito.any(AccountRequest.class)))
        .thenReturn(getSuccessResponseStub());
    Response testResponse =
        currentAccountDomainController.getCurrentAccountDetails(getRequestStub());

    assertNotNull(testResponse);
    assertEquals(200, testResponse.getStatus());
  }

  @Test
  public void testSuccessResponse1() {

    Response testResponse = currentAccountDomainController.fallbackForTimeout(getRequestStub());

    assertNotNull(testResponse);
    assertEquals(504, testResponse.getStatus());
  }

  @Test
  public void testErrorResponse() {
    Mockito.when(countrySpecificService.getAccountDetails(Mockito.any(AccountRequest.class)))
        .thenReturn(getErrorResponseStub());

    Mockito.when(responseEntity.getCode()).thenReturn(CurrentAccountConstant.ERROR_CODE);

    Response testResponse =
        currentAccountDomainController.getCurrentAccountDetails(getRequestStub());


    assertNotNull(testResponse);
    assertEquals(500, testResponse.getStatus());
  }



  private Response getSuccessResponseStub() {
    AccountResponse accountManagementResponse = new AccountResponse();
    List<Account> accountList = new ArrayList<Account>();
    Account account = new Account();
    account.setAccountId("1234");
    account.setAccountName("abcdCredit");
    account.setAccountNumber("124569378");
    accountList.add(account);
    accountManagementResponse.setAccounts(accountList);


    ResponseEntity<AccountResponse> responseEntity = new ResponseEntity<AccountResponse>(
        CurrentAccountConstant.SUCCESS_CODE, CurrentAccountConstant.SUCCESS_MSG,
        CurrentAccountConstant.SUCCESS_MSG, accountManagementResponse);


    return Response.ok(responseEntity).build();



  }



  private Response getErrorResponseStub() {

    return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
  }



  private AccountRequest getRequestStub() {
    AccountRequest accountDetailRequest = new AccountRequest();
    accountDetailRequest.setCustomerNumber("123456789");
    ApiRequestHeader reqHeader = new ApiRequestHeader("KY", "AB011", "KYBRB", "25632478912563");
    accountDetailRequest.setApiRequestHeader(reqHeader);
    return accountDetailRequest;
  }

  @Test
  public void notNullResponseObjectTest() {

    Mockito
        .when(transactionHistoryServiceImpl.getTransactionHistoryResponse(ArgumentMatchers.any()))
        .thenReturn(getTransactionHistoryStubbedResponse());
    final Response response =
        currentAccountDomainController.getTransactionHistoryResponse(getSampleRequest());
    assertNotNull(response, "response should not be null");
  }

  @Test
  public void testSuccessResponseTransHist() {

    Response testResponse = currentAccountDomainController.fallbackForTimeout(getSampleRequest());

    assertNotNull(testResponse);
    assertEquals(504, testResponse.getStatus());
  }

  @Test
  public void validateResponseObjectTest() {

    Mockito
        .when(transactionHistoryServiceImpl.getTransactionHistoryResponse(ArgumentMatchers.any()))
        .thenReturn(getTransactionHistoryStubbedResponse());
    Response response =
        currentAccountDomainController.getTransactionHistoryResponse(getSampleRequest());
    assertEquals(200, response.getStatus());

  }

  @Test
  public void shouldThrowExceptionTest() {
    Mockito
        .when(transactionHistoryServiceImpl.getTransactionHistoryResponse(ArgumentMatchers.any()))
        .thenThrow(new ApiException());
    Assertions.assertThrows(ApiException.class,
        () -> currentAccountDomainController.getTransactionHistoryResponse(getSampleRequest()));

  }

  private Response getTransactionHistoryStubbedResponse() {

    final TransactionHistoryResponse transactionHistoryResponse = new TransactionHistoryResponse();
    final Transaction transaction = new Transaction();
    transaction.setTitle("title 1");
    transactionHistoryResponse.setTransactions(Arrays.asList(transaction));
    ResponseEntity<TransactionHistoryResponse> entity =
        new ResponseEntity<>("200", null, "success", transactionHistoryResponse);
    return Response.status(Response.Status.OK).entity(entity).type("application/json").build();
  }

  private TransactionHistoryRequest getSampleRequest() {
    final ApiRequestHeader apiRequestHeader = new ApiRequestHeader();
    final TransactionHistoryRequest transactionHistoryRequest = new TransactionHistoryRequest();
    transactionHistoryRequest.setApiRequestHeader(apiRequestHeader);
    return transactionHistoryRequest;

  }
}
