package com.absa.amol.current.util;

import javax.ws.rs.core.Response;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import com.absa.amol.common.exception.ApiException;
import com.absa.amol.common.exception.DownStreamSystemUnavailableException;
import com.absa.amol.common.exception.GlobalException;
import com.absa.amol.common.model.ResponseEntity;
import com.absa.amol.current.model.AccountResponse;

public class ServerSideExceptionMapperTest {

  @InjectMocks
  private ServerSideExceptionMapper serverSideExceptionMapper;


  @BeforeEach
  public void setup() {
    MockitoAnnotations.initMocks(this);
  }


  @Test
  public void exceptionTest() {


    ResponseEntity<AccountResponse> responseEntity = new ResponseEntity<>();
    responseEntity.setMessage("Invalid account Id");
    responseEntity.setStatus("Failure");
    responseEntity.setCode("400");
    Response response = Response.status(Response.Status.BAD_REQUEST).entity(responseEntity)
        .type("application/json").build();

    Response responseTwo = Mockito.spy(response);
    Mockito.doReturn(responseEntity).when(responseTwo).readEntity(ResponseEntity.class);

    ApiException exception = serverSideExceptionMapper.toThrowable(responseTwo);
    Assertions.assertEquals(false, exception instanceof GlobalException);
  }

  @Test
  public void downStreamSystemExceptionTest() {

    ResponseEntity<AccountResponse> responseEntity = new ResponseEntity<>();
    responseEntity.setMessage("Invalid account Id");
    responseEntity.setStatus("Failure");
    responseEntity.setCode("404");
    Response response =
        Response.status(Response.Status.NOT_FOUND).entity(responseEntity).type("text/html").build();

    ApiException exception = serverSideExceptionMapper.toThrowable(response);
    Assertions.assertEquals(true, exception instanceof DownStreamSystemUnavailableException);
  }


  @Test
  public void apiReuestExceptionTest() {

    ResponseEntity<AccountResponse> responseEntity = new ResponseEntity<>();
    responseEntity.setMessage("Invalid account Id");
    responseEntity.setStatus("Failure");
    responseEntity.setCode("400");
    Response response = Response.status(Response.Status.BAD_REQUEST).entity(responseEntity)
        .type("text/html").build();

    ApiException exception = serverSideExceptionMapper.toThrowable(response);
    Assertions.assertEquals(true, exception instanceof GlobalException);
  }

}
