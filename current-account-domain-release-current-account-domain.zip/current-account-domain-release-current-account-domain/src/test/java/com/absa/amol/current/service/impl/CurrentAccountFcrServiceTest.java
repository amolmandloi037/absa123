package com.absa.amol.current.service.impl;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.core.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import com.absa.amol.common.exception.ApiResponseException;
import com.absa.amol.common.model.ApiRequestHeader;
import com.absa.amol.common.model.ResponseEntity;
import com.absa.amol.current.model.Account;
import com.absa.amol.current.model.AccountRequest;
import com.absa.amol.current.model.AccountResponse;
import com.absa.amol.current.service.CurrentAccountService;
import com.absa.amol.current.util.CurrentAccDetailFCRServiceClient;
import com.absa.amol.current.util.CurrentAccountConstant;


public class CurrentAccountFcrServiceTest {

  @InjectMocks
  private CurrentAccountServiceImpl currentAccountServiceImpl;

  @Mock
  private AccountRequest accountRequest;

  @Mock
  private CurrentAccDetailFCRServiceClient currentAccDetailFCRServiceClient;

  @Mock
  private CurrentAccountService currentAccountService;


  @BeforeEach
  public void setup() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void testSuccessResponse() {
    Mockito
        .when(currentAccDetailFCRServiceClient.getAccountDetails(Mockito.any(AccountRequest.class)))
        .thenReturn(getCurrentAccountResponse());
    Response testResponse =
        currentAccountServiceImpl.getCurrentAccountDetailsFromFcr(getRequestStub());

    assertNotNull(testResponse);
    assertEquals(200, testResponse.getStatus());

  }

  @Test
  public void testErrorResponse() {
    Mockito
        .when(currentAccDetailFCRServiceClient.getAccountDetails(Mockito.any(AccountRequest.class)))
        .thenReturn(getSavingsAccountResponseError());
    Response testResponse =
        currentAccountServiceImpl.getCurrentAccountDetailsFromFcr(getRequestStub());

    assertNotNull(testResponse);
    assertEquals(500, testResponse.getStatus());

  }

  @Test
  public void testApiResponse() {

    Response testResponse =
        currentAccountServiceImpl.getCurrentAccountDetailsFromFcr(getInvalidRequestStub());

    assertNotNull(testResponse);
    assertEquals(500, testResponse.getStatus());


  }



  @Test
  public void testApiResponseException() {

    Mockito
        .when(currentAccDetailFCRServiceClient.getAccountDetails(Mockito.any(AccountRequest.class)))
        .thenThrow(new ApiResponseException("500", "Exception Occurred"));


    assertThrows(ApiResponseException.class, () -> {
      currentAccountServiceImpl.getCurrentAccountDetailsFromFcr(getRequestStub());
    });



  }


  @Test
  private void testExceptionResponse() {
    Mockito
        .when(currentAccDetailFCRServiceClient.getAccountDetails(Mockito.any(AccountRequest.class)))
        .thenThrow(
            new ApiResponseException(CurrentAccountConstant.GET_CURRENT_ACCOUNT_DETAILS_FCR, null));

    assertThrows(ApiResponseException.class, () -> {
      currentAccountService.getCurrentAccountDetails(getInvalidRequestStub());
    });

  }

  private AccountRequest getRequestStub() {
    AccountRequest accountDetailRequest = new AccountRequest();
    accountDetailRequest.setCustomerNumber("123456789");

    ApiRequestHeader reqHeader =
        new ApiRequestHeader("KE", "AB011", "KEBRB", "56675952100015319000005667595212563");
    accountDetailRequest.setApiRequestHeader(reqHeader);

    return accountDetailRequest;
  }

  private ResponseEntity<AccountResponse> getCurrentAccountResponse() {

    AccountResponse response = new AccountResponse();
    Account account = new Account();
    account.setAccountId("123658974");
    account.setAccountName("CUrrent Account");
    account.setAccountNumber("124569378");
    account.setAccountType("Z");

    List<Account> accounts = new ArrayList<Account>();
    accounts.add(account);
    response.setAccounts(accounts);
    return new ResponseEntity<AccountResponse>(CurrentAccountConstant.SUCCESS_CODE,
        CurrentAccountConstant.SUCCESS_MSG, CurrentAccountConstant.SUCCESS_MSG, response);
  }

  private ResponseEntity<AccountResponse> getSavingsAccountResponseError() {
    ResponseEntity<AccountResponse> responseEntity =
        new ResponseEntity<AccountResponse>(CurrentAccountConstant.ERROR_CODE,
            CurrentAccountConstant.ERROR_MSG, CurrentAccountConstant.ERROR_MSG, null);
    return responseEntity;
  }

  private AccountRequest getInvalidRequestStub() {
    AccountRequest accountDetailRequest = new AccountRequest();

    ApiRequestHeader reqHeader = new ApiRequestHeader("KE", "AB011", "KEBRB", "");
    accountDetailRequest.setApiRequestHeader(reqHeader);

    return accountDetailRequest;
  }

}
