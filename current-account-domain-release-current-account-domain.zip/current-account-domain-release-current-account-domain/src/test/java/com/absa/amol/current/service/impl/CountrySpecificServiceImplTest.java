package com.absa.amol.current.service.impl;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import javax.ws.rs.core.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import com.absa.amol.common.exception.ApiRequestException;
import com.absa.amol.common.model.ApiRequestHeader;
import com.absa.amol.common.model.ResponseEntity;
import com.absa.amol.current.model.Account;
import com.absa.amol.current.model.AccountRequest;
import com.absa.amol.current.model.AccountResponse;
import com.absa.amol.current.service.CountrySpecificService;
import com.absa.amol.current.util.CurrentAccountConstant;


class CountrySpecificServiceImplTest {


  @InjectMocks
  private CountrySpecificServiceImpl countrySpecificServiceImpl;

  @Mock
  private Set<String> fcrCountry;

  @Mock
  private Set<String> brainsCountry;

  @Mock
  private AccountRequest accountManagementRequest;

  @Mock
  private CountrySpecificService countrySpecificService;
  @Mock
  private CurrentAccountServiceImpl currentAccountServiceImpl;

  @Mock
  private ResponseEntity responseEntity;

  @BeforeEach
  public void setup() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  void testSuccessResponseFCR() {
    // fcrCountry = setFcrCountry();
    /*
     * Mockito
     * .when(savingsAccountServiceImpl.getSavingsAccountDetails(Mockito.any(AccountRequest.class)))
     * .thenReturn(getCreditCardAccountResponse());
     */
    Mockito
        .when(currentAccountServiceImpl
            .getCurrentAccountDetailsFromFcr(Mockito.any(AccountRequest.class)))
        .thenReturn(getCurrentAccountResponse());

    Mockito.when(fcrCountry.contains(Mockito.any(String.class))).thenReturn(true);

    Response testResponse = countrySpecificServiceImpl.getAccountDetails(getRequestStub());
    assertNotNull(testResponse);
    assertEquals(200, testResponse.getStatus());

  }

  @Test
  void testSuccessResponseBRAIN() {
    // fcrCountry = setFcrCountry();
    Mockito
        .when(currentAccountServiceImpl.getCurrentAccountDetails(Mockito.any(AccountRequest.class)))
        .thenReturn(getCurrentAccountResponse());
    /*
     * Mockito .when(savingsAccountServiceImpl
     * .getSavingsAccountDetailsFcr(Mockito.any(AccountRequest.class)))
     * .thenReturn(getCreditCardAccountResponse());
     */
    // System.out.println("test fcr set " + fcrCountry.size() + fcrCountry);

    Mockito.when(fcrCountry.contains(Mockito.any(String.class))).thenReturn(false);

    Mockito.when(brainsCountry.contains(Mockito.any(String.class))).thenReturn(true);

    Response testResponse = countrySpecificServiceImpl.getAccountDetails(getRequestStub());
    assertNotNull(testResponse);
    assertEquals(200, testResponse.getStatus());

  }

  @Test
  void testErrorResponseFCR() {
    Mockito
        .when(currentAccountServiceImpl.getCurrentAccountDetails(Mockito.any(AccountRequest.class)))
        .thenReturn(getCurrentAccountResponseError());
    Mockito
        .when(currentAccountServiceImpl
            .getCurrentAccountDetailsFromFcr(Mockito.any(AccountRequest.class)))
        .thenReturn(getCurrentAccountResponseError());
    // Mockito.when(brainsCountry.contains(Mockito.any(String.class))).thenReturn(false);
    Mockito.when(fcrCountry.contains(Mockito.any(String.class))).thenReturn(true);

    Response testResponse = countrySpecificServiceImpl.getAccountDetails(getRequestStub());

    assertNotNull(testResponse);
    assertEquals(500, testResponse.getStatus());
  }

  @Test
  void testErrorResponseBrains() {
    Mockito
        .when(currentAccountServiceImpl.getCurrentAccountDetails(Mockito.any(AccountRequest.class)))
        .thenReturn(getCurrentAccountResponseError());
    Mockito
        .when(currentAccountServiceImpl
            .getCurrentAccountDetailsFromFcr(Mockito.any(AccountRequest.class)))
        .thenReturn(getCurrentAccountResponseError());
    Mockito.when(brainsCountry.contains(Mockito.any(String.class))).thenReturn(true);
    // Mockito.when(fcrCountry.contains(Mockito.any(String.class))).thenReturn(true);

    Response testResponse = countrySpecificServiceImpl.getAccountDetails(getRequestStub());

    assertNotNull(testResponse);
    assertEquals(500, testResponse.getStatus());

  }

  @Test
  void testErrorResponse() {

    Mockito.when(brainsCountry.contains(Mockito.any(String.class))).thenReturn(false);
    Mockito.when(fcrCountry.contains(Mockito.any(String.class))).thenReturn(false);

    assertThrows(ApiRequestException.class, () -> {
      countrySpecificServiceImpl.getAccountDetails(getRequestStub());
    });


  }

  @Test
  void testApiExceptionResponse() {
    // AccountRequest accountRequest = new AccountRequest();

    assertThrows(ApiRequestException.class, () -> {
      countrySpecificServiceImpl.getAccountDetails(getRequestStubtwo());
    });
  }


  private AccountRequest getRequestStub() {
    AccountRequest accountDetailRequest = new AccountRequest();
    accountDetailRequest.setCustomerNumber("123456789");

    ApiRequestHeader reqHeader =
        new ApiRequestHeader("KE", "AB011", "KEBRB", "56675952100015319000005667595212563");
    accountDetailRequest.setApiRequestHeader(reqHeader);

    return accountDetailRequest;
  }

  private Response getCurrentAccountResponse() {

    AccountResponse response = new AccountResponse();
    Account account = new Account();
    account.setAccountId("123658974");
    account.setAccountName("Credit Card");
    account.setAccountNumber("124569378");
    account.setAccountType("Z");

    List<Account> accounts = new ArrayList<Account>();
    accounts.add(account);
    ResponseEntity<AccountResponse> responseEntity =
        new ResponseEntity<AccountResponse>(CurrentAccountConstant.SUCCESS_CODE,
            CurrentAccountConstant.SUCCESS_MSG, CurrentAccountConstant.SUCCESS_MSG, response);

    return Response.ok(responseEntity).build();

  }

  private Response getCurrentAccountResponseError() {
    return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
  }

  private AccountRequest getInvalidRequestStub() {
    AccountRequest accountDetailRequest = new AccountRequest();

    ApiRequestHeader reqHeader = new ApiRequestHeader("KE", "AB011", "KEBRB", "");
    accountDetailRequest.setApiRequestHeader(reqHeader);

    return accountDetailRequest;
  }

  private AccountRequest getRequestStubtwo() {
    AccountRequest accountDetailRequest = new AccountRequest();
    accountDetailRequest.setCustomerNumber("123456789");

    ApiRequestHeader reqHeader = null;


    return accountDetailRequest;
  }


}
