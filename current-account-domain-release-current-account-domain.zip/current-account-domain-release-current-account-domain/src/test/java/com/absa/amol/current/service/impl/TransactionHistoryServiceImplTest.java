package com.absa.amol.current.service.impl;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import java.util.Arrays;
import javax.ws.rs.core.Response;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import com.absa.amol.common.exception.ApiException;
import com.absa.amol.common.exception.ApiResponseException;
import com.absa.amol.common.model.ApiRequestHeader;
import com.absa.amol.common.model.ResponseEntity;
import com.absa.amol.current.model.Transaction;
import com.absa.amol.current.model.TransactionHistoryRequest;
import com.absa.amol.current.model.TransactionHistoryResponse;
import com.absa.amol.current.util.TransHistorySystemServiceClient;

public class TransactionHistoryServiceImplTest {

  @Mock
  private TransHistorySystemServiceClient transHistorySystemServiceClient;

  @InjectMocks
  private TransactionHistoryServiceImpl transactionHistoryServiceImpl;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void notNullResponseObjectTest() {

    Mockito
        .when(transHistorySystemServiceClient.getTransactionHistoryResponse(ArgumentMatchers.any()))
        .thenReturn(getTransactionHistoryStubbedResponse());
    final Response response =
        transactionHistoryServiceImpl.getTransactionHistoryResponse(getSampleRequest());
    assertNotNull(response, "response should not be null");
  }

  @Test
  public void validateResponseObject() {

    Mockito
        .when(transHistorySystemServiceClient.getTransactionHistoryResponse(ArgumentMatchers.any()))
        .thenReturn(getTransactionHistoryStubbedResponse());
    Response response =
        transactionHistoryServiceImpl.getTransactionHistoryResponse(getSampleRequest());
    assertNotNull(response);
    Assertions.assertEquals(200, response.getStatus());
  }

  @Test
  public void validateResponseObjectTwo() {

    Mockito
        .when(transHistorySystemServiceClient.getTransactionHistoryResponse(ArgumentMatchers.any()))
        .thenReturn(getTransactionHistoryStubbedResponseTwo());
    Response response =
        transactionHistoryServiceImpl.getTransactionHistoryResponse(getSampleRequest());
    assertNotNull(response);
    Assertions.assertEquals(500, response.getStatus());
  }

  @Test
  public void shouldThrowExceptionTestOne() {
    Mockito
        .when(transHistorySystemServiceClient.getTransactionHistoryResponse(ArgumentMatchers.any()))
        .thenThrow(new ApiException());
    Assertions.assertThrows(ApiException.class,
        () -> transactionHistoryServiceImpl.getTransactionHistoryResponse(getSampleRequest()));

  }

  @Test
  public void shouldThrowExceptionTestTwo() {
    Mockito
        .when(transHistorySystemServiceClient.getTransactionHistoryResponse(ArgumentMatchers.any()))
        .thenThrow(new RuntimeException());
    Assertions.assertThrows(ApiResponseException.class,
        () -> transactionHistoryServiceImpl.getTransactionHistoryResponse(getSampleRequest()));

  }

  private ResponseEntity<TransactionHistoryResponse> getTransactionHistoryStubbedResponse() {

    TransactionHistoryResponse transactionHistoryResponse = new TransactionHistoryResponse();
    Transaction transaction = new Transaction();
    transaction.setTitle("title 1");
    transactionHistoryResponse.setTransactions(Arrays.asList(transaction));
    return new ResponseEntity<TransactionHistoryResponse>("200", null, "success",
        transactionHistoryResponse);
  }

  private TransactionHistoryRequest getSampleRequest() {

    ApiRequestHeader apiRequestHeader = new ApiRequestHeader();
    TransactionHistoryRequest transactionHistoryRequest = new TransactionHistoryRequest();
    transactionHistoryRequest.setApiRequestHeader(apiRequestHeader);
    return transactionHistoryRequest;

  }

  private ResponseEntity<TransactionHistoryResponse> getTransactionHistoryStubbedResponseTwo() {

    TransactionHistoryResponse transactionHistoryResponse = new TransactionHistoryResponse();
    Transaction transaction = new Transaction();
    transaction.setTitle("title 1");
    transactionHistoryResponse.setTransactions(Arrays.asList(transaction));
    return new ResponseEntity<TransactionHistoryResponse>("500", null, "failure",
        transactionHistoryResponse);
  }

}
