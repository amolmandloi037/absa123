package com.absa.amol.current.service.impl;

import java.util.HashSet;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.eclipse.microprofile.config.Config;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.absa.amol.common.exception.ApiRequestException;
import com.absa.amol.current.model.AccountRequest;
import com.absa.amol.current.service.impl.CurrentAccountRequestValidatorServiceImpl;

 class CurrentAccountRequestValidatorServiceImplTest {
	
	@InjectMocks
	  private CurrentAccountRequestValidatorServiceImpl ValidatorService;

	  @Mock
	  private Validator validator;

	  @Mock
	  private ConstraintViolation<Object> object;

	  @Mock
	  private Config config;

	  @InjectMocks
	  private HashSet<ConstraintViolation<Object>> violations;

	  @BeforeEach
	  public void setUp() {
	    MockitoAnnotations.initMocks(this);
	  }

	  @Test
	   void shouldThrowExceptionTestOne() {
	    Mockito.when(object.getMessageTemplate()).thenReturn("test error message template");
	    violations.add(object);
	    Mockito.when(config.getValue(ArgumentMatchers.any(), ArgumentMatchers.any()))
	        .thenThrow(new RuntimeException());
	    Mockito.when(validator.validate(ArgumentMatchers.any())).thenReturn(violations);
	    Assertions.assertThrows(ApiRequestException.class,
	        () -> ValidatorService.validateRequest(new AccountRequest()));
	  }

	  @Test
	   void shouldThrowExceptionTestTwo() {
	    Mockito.when(object.getMessageTemplate()).thenReturn("test error message template");
	    Mockito.when(config.getValue(ArgumentMatchers.any(), ArgumentMatchers.any()))
	        .thenReturn("test error message");
	    violations.add(object);
	    Mockito.when(validator.validate(ArgumentMatchers.any())).thenReturn(violations);
	    Assertions.assertThrows(ApiRequestException.class,
	        () -> ValidatorService.validateRequest(new AccountRequest()));
	  }

	  @Test
	   void ShouldNotThrowExceptionTest() {
	    ValidatorService.validateRequest(new AccountRequest());
	  }

}
