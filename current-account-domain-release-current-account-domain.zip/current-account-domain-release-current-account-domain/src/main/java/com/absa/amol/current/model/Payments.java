package com.absa.amol.current.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Payments {

  private String paymentInstanceRecord;

  private String paymentType;

  private String paymentDefinition;

  private String paymentProcOptionDef;

  private String paymentProcOptionSetting;

  private String paymentConfiguration;

  private String paymentSchedule;

  private String directDrMandateRef;

  private String directDrMandateSettings;

  private String billPayMandateRef;

  private String billPayMandateSettings;

  private String paymentTransaction;

  private String paymentTransPayeeACRef;

  private String paymentTransPayeeBankRef;

  private String paymentTransFeeType;

  private String paymentTransFeeCharge;

  private String paymentTransPaymentMech;

  private String paymentTransPaymentPurpose;

}
