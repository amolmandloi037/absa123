package com.absa.amol.current.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import com.absa.amol.common.exception.ApiException;
import com.absa.amol.common.logging.Logger;
import com.absa.amol.common.logging.LoggerFactory;
import com.absa.amol.common.model.ResponseEntity;
import com.absa.amol.common.util.CollectionUtil;
import com.absa.amol.common.util.CommonUtil;
import com.absa.amol.common.util.StringUtil;
import com.absa.amol.current.model.Account;
import com.absa.amol.current.model.AccountDetailsRequest;
import com.absa.amol.current.model.AccountDetailsResponse;
import com.absa.amol.current.model.AccountRequest;
import com.absa.amol.current.model.AccountResponse;
import com.absa.amol.current.service.CurrentAccountService;
import com.absa.amol.current.util.AccountDetailsDomainServiceClient;
import com.absa.amol.current.util.CurrentAccDetailFCRServiceClient;
import com.absa.amol.current.util.CurrentAccountConstant;

@ApplicationScoped
public class CurrentAccountServiceImpl implements CurrentAccountService {

  private static final Logger LOGGER = LoggerFactory.getLogger(CurrentAccountServiceImpl.class);

  @Inject
  @RestClient
  private AccountDetailsDomainServiceClient accountDetailsDomainServiceClient;

  @Inject
  @RestClient
  private CurrentAccDetailFCRServiceClient curreAccDetailFCRServiceClient;

  public Response getCurrentAccountDetails(AccountRequest accountRequest) {
    LOGGER.info(CurrentAccountConstant.GET_CURRENT_ACCOUNT_DETAILS,
        CurrentAccountConstant.getCorrelationId(accountRequest.getApiRequestHeader()),
        "start of getCurrentAccountDetails Method", "");
    boolean isPartialResponse = false;
    int counter = 1;
    try {

      if (StringUtil.isStringNotNullAndNotEmpty(accountRequest.getCustomerNumber())) {
        Response response = accountDetailsDomainServiceClient.getAccountDetails(accountRequest);
        if (response.getStatus() == CurrentAccountConstant.SUCCESS) {
          List<Account> responseAccountList = new ArrayList<>();
          ResponseEntity<AccountResponse> entity =
              response.readEntity(new GenericType<ResponseEntity<AccountResponse>>() {});
          if (CommonUtil.isNotNull(entity)
              && CollectionUtil.isNotNullAndNotEmpty(entity.getData().getAccounts())) {
            AccountDetailsRequest accountNameRequest = new AccountDetailsRequest();
            List<Account> accountList = entity.getData().getAccounts().stream()
                .filter(acc -> "C".equalsIgnoreCase(acc.getAccountType()))
                .collect(Collectors.toList());
            for (Account account : accountList) {
              isPartialResponse = getAccountName(accountRequest, accountNameRequest, account);
              if (!isPartialResponse) {
                account.setAccountId("A" + counter++);
                responseAccountList.add(account);
              }
            }
          }
          if (responseAccountList.isEmpty()) {
            response = Response.ok(new ResponseEntity<Account>(CurrentAccountConstant.SUCCESS_CODE,
                "No records found", "Success", null)).build();
          } else {
            entity.getData().setAccounts(responseAccountList);
            response = Response.ok(entity).build();
          }
        }
        return response;

      } else {
        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
      }

    } catch (ApiException e) {
      LOGGER.error(CurrentAccountConstant.GET_CURRENT_ACCOUNT_DETAILS,
          CurrentAccountConstant.getCorrelationId(accountRequest.getApiRequestHeader()),
          CurrentAccountConstant.EXCEPTION_OCCURED, e.getErrorMessage());
      LOGGER.debug(CurrentAccountConstant.GET_CURRENT_ACCOUNT_DETAILS,
          CurrentAccountConstant.getCorrelationId(accountRequest.getApiRequestHeader()),
          CurrentAccountConstant.EXCEPTION_OCCURED, e);
      throw e;
    } catch (Exception e) {
      LOGGER.error(CurrentAccountConstant.GET_CURRENT_ACCOUNT_DETAILS,
          CurrentAccountConstant.getCorrelationId(accountRequest.getApiRequestHeader()),
          CurrentAccountConstant.EXCEPTION_OCCURED, e.getMessage());
      LOGGER.debug(CurrentAccountConstant.GET_CURRENT_ACCOUNT_DETAILS,
          CurrentAccountConstant.getCorrelationId(accountRequest.getApiRequestHeader()),
          CurrentAccountConstant.EXCEPTION_OCCURED, e);
      throw new ApiException(CurrentAccountConstant.ERROR_CODE, e.getMessage());
    }

  }

  private boolean getAccountName(AccountRequest accountRequest,
      AccountDetailsRequest accountNameRequest, Account account) {
    LOGGER.info(CurrentAccountConstant.GET_ACCOUNT_NAME,
        CurrentAccountConstant.getCorrelationId(accountRequest.getApiRequestHeader()),
        "start of getAccountName Method", "");
    boolean isPartialResponse = false;
    try {

      accountNameRequest.setAccountNumber(account.getAccountNumber());
      accountNameRequest.setBranchCode(account.getBranchCode());
      accountNameRequest.setRequestHeader(accountRequest.getApiRequestHeader());

      Response nameResponse = accountDetailsDomainServiceClient.getAccountName(accountNameRequest);

      if (nameResponse.getStatus() == CurrentAccountConstant.SUCCESS) {
        ResponseEntity<AccountDetailsResponse> accountNameEntity =
            nameResponse.readEntity(new GenericType<ResponseEntity<AccountDetailsResponse>>() {});
        if (CommonUtil.isNotNull(accountNameEntity.getData())) {
          AccountDetailsResponse accountname = accountNameEntity.getData();
          if (StringUtil.isStringNotNullAndNotEmpty(accountname.getAccountTypeNarrative())) {
            account.setAccountName(accountname.getAccountTypeNarrative());
            account.setOfficialName(accountname.getAccountTypeNarrative());
          } else {
            account.setAccountName(accountname.getAccountName());
            account.setOfficialName(accountname.getOfficialName());
          }
        }

      }
    } catch (ApiException e) {
      isPartialResponse = true;
      LOGGER.error(CurrentAccountConstant.GET_ACCOUNT_NAME,
          CurrentAccountConstant.getCorrelationId(accountRequest.getApiRequestHeader()),
          CurrentAccountConstant.EXCEPTION_OCCURED, e.getErrorMessage());
      LOGGER.debug(CurrentAccountConstant.GET_ACCOUNT_NAME,
          CurrentAccountConstant.getCorrelationId(accountRequest.getApiRequestHeader()),
          CurrentAccountConstant.EXCEPTION_OCCURED, e);
    } catch (Exception e) {
      isPartialResponse = true;
      LOGGER.error(CurrentAccountConstant.GET_ACCOUNT_NAME,
          CurrentAccountConstant.getCorrelationId(accountRequest.getApiRequestHeader()),
          CurrentAccountConstant.EXCEPTION_OCCURED, e.getMessage());
      LOGGER.debug(CurrentAccountConstant.GET_ACCOUNT_NAME,
          CurrentAccountConstant.getCorrelationId(accountRequest.getApiRequestHeader()),
          CurrentAccountConstant.EXCEPTION_OCCURED, e);
    }
    return isPartialResponse;
  }

  public Response getCurrentAccountDetailsFromFcr(AccountRequest accountRequest) {
    LOGGER.info(CurrentAccountConstant.GET_CURRENT_ACCOUNT_DETAILS_FCR,
        CurrentAccountConstant.getCorrelationId(accountRequest.getApiRequestHeader()),
        "start of getSavingsAccountDetailsFcr Method", "");
    try {
      if (StringUtil.isStringNotNullAndNotEmpty(accountRequest.getCustomerNumber())) {
        ResponseEntity<AccountResponse> res =
            curreAccDetailFCRServiceClient.getAccountDetails(accountRequest);
        if (null != res && ("200").equals(res.getCode())) {
          return Response.ok(res).build();



        } else {
          return Response.status(null != res && StringUtil.isStringNotNullAndNotEmpty(res.getCode())
              ? Integer.parseInt(res.getCode())
              : CurrentAccountConstant.ERROR_CODE_INT).entity(res).build();
        }



      } else {
        return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
      }
    } catch (ApiException e) {
      LOGGER.error(CurrentAccountConstant.GET_CURRENT_ACCOUNT_DETAILS_FCR,
          CurrentAccountConstant.getCorrelationId(accountRequest.getApiRequestHeader()),
          CurrentAccountConstant.EXCEPTION_OCCURED, e.getErrorMessage());
      LOGGER.debug(CurrentAccountConstant.GET_CURRENT_ACCOUNT_DETAILS_FCR,
          CurrentAccountConstant.getCorrelationId(accountRequest.getApiRequestHeader()),
          CurrentAccountConstant.EXCEPTION_OCCURED, e);
      throw e;
    } catch (Exception e) {
      LOGGER.error(CurrentAccountConstant.GET_CURRENT_ACCOUNT_DETAILS_FCR,
          CurrentAccountConstant.getCorrelationId(accountRequest.getApiRequestHeader()),
          CurrentAccountConstant.EXCEPTION_OCCURED, e.getMessage());
      LOGGER.debug(CurrentAccountConstant.GET_CURRENT_ACCOUNT_DETAILS_FCR,
          CurrentAccountConstant.getCorrelationId(accountRequest.getApiRequestHeader()),
          CurrentAccountConstant.EXCEPTION_OCCURED, e);
      throw new ApiException(CurrentAccountConstant.ERROR_CODE, e.getMessage());
    }

  }

}
