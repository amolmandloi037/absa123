package com.absa.amol.current.model;


import org.eclipse.microprofile.openapi.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Schema(name = "Account", description = "POJO represent current account details.")
public class Account {
  private String accountNumber;
  private String accountId;
  private String accountType;
  private String accountStatus;
  private Balance balance;
  private String accountName;
  private String officialName;
  private String branchCode;
  private String productCode;
  private String associationType;
  private boolean internetBankingAccessFlag;
}
