package com.absa.amol.current.service;

import javax.ws.rs.core.Response;

import com.absa.amol.current.model.TransactionHistoryRequest;

public interface TransactionHistoryService {
	
	public Response getTransactionHistoryResponse(
		      TransactionHistoryRequest transactionHistoryRequest);

}
