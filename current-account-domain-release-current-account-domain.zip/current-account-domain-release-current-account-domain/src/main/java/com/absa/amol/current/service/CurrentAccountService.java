package com.absa.amol.current.service;

import javax.ws.rs.core.Response;

import com.absa.amol.current.model.AccountRequest;

public interface CurrentAccountService {
	
	public Response getCurrentAccountDetails(AccountRequest accountRequest);
	public Response getCurrentAccountDetailsFromFcr(AccountRequest accountRequest);

}
