package com.absa.amol.current.util;

import java.util.Arrays;
import java.util.List;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.ext.ResponseExceptionMapper;
import com.absa.amol.common.exception.ApiException;
import com.absa.amol.common.exception.ApiRequestException;
import com.absa.amol.common.exception.ApiResponseException;
import com.absa.amol.common.exception.DownStreamSystemUnavailableException;
import com.absa.amol.common.exception.GlobalException;
import com.absa.amol.common.logging.Logger;
import com.absa.amol.common.logging.LoggerFactory;
import com.absa.amol.common.model.ResponseEntity;

public class ServerSideExceptionMapper implements ResponseExceptionMapper<Exception> {
  private static final Logger logger = LoggerFactory.getLogger(ServerSideExceptionMapper.class);
  private static final List<Integer> errorStatus = Arrays.asList(404, 500, 400);
  private static final String TO_THROWABLE = "toThrowable";

  @Override
  public boolean handles(int status, MultivaluedMap<String, Object> headers) {
    return errorStatus.contains(status);
  }

  @Override
  public ApiException toThrowable(Response response) {
    try {
      if (response.hasEntity() && !MediaType.TEXT_HTML_TYPE.equals(response.getMediaType())
          && response.getStatus() != 400) {
        ResponseEntity<?> responseEntity = response.readEntity(ResponseEntity.class);
        ApiResponseException exception =
            new ApiResponseException(responseEntity.getCode(), responseEntity.getMessage());
        logger.error(TO_THROWABLE, "", responseEntity.getMessage(), exception.getMessage());
        return exception;

      } else if (response.getStatus() == 400) {
        ResponseEntity<?> responseEntity = response.readEntity(ResponseEntity.class);
        ApiRequestException exception =
            new ApiRequestException(responseEntity.getCode(), responseEntity.getMessage());
        logger.error("TO_THROWABLE", "", responseEntity.getMessage(), exception.getMessage());
        return exception;
      } else {
        DownStreamSystemUnavailableException exception = new DownStreamSystemUnavailableException(
            "503", "System Adapter Service is unavailable");
        logger.error("TO_THROWABLE", "", "Raising DownStreamSystemUnavailableException exception",
            exception.getMessage());
        return exception;
      }
    } catch (Exception ex) {

      return new GlobalException(CurrentAccountConstant.ERROR_CODE, "Internal Server Error.");

    }
  }
}
