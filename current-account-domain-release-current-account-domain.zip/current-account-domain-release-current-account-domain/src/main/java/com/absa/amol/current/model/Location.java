package com.absa.amol.current.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Location {

  private String address;

  private String city;

  private String state;

  private String zipCode;

  private String country;

  private Coordinates coordinates;

}