package com.absa.amol.current.service;

import com.absa.amol.current.model.AccountRequest;

public interface CurrentAccountRequestValidatorService {
  public void validateRequest(AccountRequest accountRequest);
}