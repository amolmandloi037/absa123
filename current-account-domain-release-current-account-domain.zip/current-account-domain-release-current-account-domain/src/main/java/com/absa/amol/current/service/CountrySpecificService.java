package com.absa.amol.current.service;

import javax.ws.rs.core.Response;

import com.absa.amol.current.model.AccountRequest;

public interface CountrySpecificService {
	public Response getAccountDetails(AccountRequest accountRequest);
}
