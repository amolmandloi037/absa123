package com.absa.amol.current.model;

import java.util.List;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Schema(name = "AccountResponse", description = "POJO represents current account response details")
public class AccountResponse {
  private List<Account> accounts;
 }