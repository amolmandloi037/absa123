package com.absa.amol.current.controller;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.eclipse.microprofile.faulttolerance.Fallback;
import org.eclipse.microprofile.faulttolerance.Timeout;
import org.eclipse.microprofile.faulttolerance.exceptions.TimeoutException;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponses;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;
import com.absa.amol.common.logging.Logger;
import com.absa.amol.common.logging.LoggerFactory;
import com.absa.amol.common.model.ResponseEntity;
import com.absa.amol.current.model.AccountRequest;
import com.absa.amol.current.model.TransactionHistoryRequest;
import com.absa.amol.current.service.CountrySpecificService;
import com.absa.amol.current.service.CurrentAccountRequestValidatorService;
import com.absa.amol.current.service.TransactionHistoryService;
import com.absa.amol.current.service.impl.TransactionHistoryRequestValidatorServiceImpl;
import com.absa.amol.current.util.CurrentAccountConstant;

@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Tag(name = " Current Account Domain - OpenAPI Resources")
@ApplicationScoped
@Path("/current-account-fulfillment")

public class CurrentAccountDomainController {

  private static final Logger logger =
      LoggerFactory.getLogger(CurrentAccountDomainController.class);

  @Inject
  private CountrySpecificService countrySpecificService;

  @Inject
  private CurrentAccountRequestValidatorService validatorService;

  @Inject
  private TransactionHistoryService transactionHistoryService;

  @Inject
  private TransactionHistoryRequestValidatorServiceImpl transHistReqValidatorService;


  @GET
  @Path("/account-information/retail/retrieval")
  @Timeout(CurrentAccountConstant.FALLBACK_TIMEOUT)
  @Fallback(fallbackMethod = CurrentAccountConstant.FALLBACK_METHOD_FOR_TIMEOUT,
      applyOn = {TimeoutException.class})
  @Operation(summary = CurrentAccountConstant.SUMMERY, description = CurrentAccountConstant.DESC)
  @APIResponses(value = {
      @APIResponse(name = CurrentAccountConstant.NAME,
          responseCode = CurrentAccountConstant.SUCCESS_CODE,
          description = CurrentAccountConstant.SUCCESS_RESPONSE_MESSAGE,
          content = @Content(mediaType = "application/json")),
      @APIResponse(responseCode = CurrentAccountConstant.BAD_CODE_REQUEST,
          description = CurrentAccountConstant.BAD_REQUEST_MSG,
          content = @Content(mediaType = "text/plain")),
      @APIResponse(responseCode = CurrentAccountConstant.INTERNAL_ERROR_CODE,
          description = CurrentAccountConstant.INTERNAL_ERROR_MSG,
          content = @Content(mediaType = "text/plane"))

  })

  public Response getCurrentAccountDetails(@BeanParam AccountRequest accountRequest) {
    validatorService.validateRequest(accountRequest);
    logger.info("getSavingsAccountDetails",
        CurrentAccountConstant.getCorrelationId(accountRequest.getApiRequestHeader()),
        "start of getSavingsAccountDetails Method", "");

    return countrySpecificService.getAccountDetails(accountRequest);
  }

  /*
   * Request validation and Call to Transaction History Service
   */
  @GET
  @Path("/transaction-history/retail/retrieval")
  @Timeout(CurrentAccountConstant.FALLBACK_TIMEOUT)
  @Fallback(fallbackMethod = CurrentAccountConstant.FALLBACK_METHOD_FOR_TIMEOUT,
      applyOn = {TimeoutException.class})
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)

  @APIResponses(value = {
      @APIResponse(responseCode = "200", description = "Transaction History for given request ",
          content = @Content(mediaType = "application/json",
              schema = @Schema(implementation = ResponseEntity.class))),
      @APIResponse(responseCode = "500", description = "Internal Server Error",
          content = @Content(mediaType = "application/json",
              schema = @Schema(implementation = ResponseEntity.class)))}

  )

  @Operation(summary = "Retrieve transaction history details",
      description = "Retrive and return transaction history of given account number")
  public Response getTransactionHistoryResponse(
      @BeanParam TransactionHistoryRequest transactionHistoryRequest) {

    transHistReqValidatorService.validateRequest(transactionHistoryRequest);

    logger.info("getTransactionHistoryResponse",
        transactionHistoryRequest.getApiRequestHeader().getCorrelationId(),
        "inside controller: calling transaction history service ", "");

    return transactionHistoryService.getTransactionHistoryResponse(transactionHistoryRequest);

  }

  public Response fallbackForTimeout(AccountRequest accountRequest) {
    logger.info(CurrentAccountConstant.FALLBACK_METHOD_FOR_TIMEOUT,
        accountRequest.getApiRequestHeader().getCorrelationId(),
        "Fallback method after waiting milliseconds!=",
        String.valueOf(CurrentAccountConstant.FALLBACK_TIMEOUT));
    ResponseEntity<String> responseEntity =
        new ResponseEntity<>(CurrentAccountConstant.TIMEOUT_CODE,
            "No response from downstream service", CurrentAccountConstant.FAILURE_MSG, null);
    return Response.status(504).entity(responseEntity).build();
  }

  public Response fallbackForTimeout(TransactionHistoryRequest tranHistReq) {
    logger.info(CurrentAccountConstant.FALLBACK_METHOD_FOR_TIMEOUT,
        tranHistReq.getApiRequestHeader().getCorrelationId(),
        "Fallback method after waiting milliseconds!=",
        String.valueOf(CurrentAccountConstant.FALLBACK_TIMEOUT));
    ResponseEntity<String> responseEntity =
        new ResponseEntity<>(CurrentAccountConstant.TIMEOUT_CODE,
            "No response from downstream service", CurrentAccountConstant.FAILURE_MSG, null);
    return Response.status(504).entity(responseEntity).build();
  }
}
