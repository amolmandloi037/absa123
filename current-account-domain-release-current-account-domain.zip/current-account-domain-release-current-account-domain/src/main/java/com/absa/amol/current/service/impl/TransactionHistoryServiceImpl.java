package com.absa.amol.current.service.impl;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import com.absa.amol.common.exception.ApiException;
import com.absa.amol.common.exception.ApiResponseException;
import com.absa.amol.common.logging.Logger;
import com.absa.amol.common.logging.LoggerFactory;
import com.absa.amol.common.model.ResponseEntity;
import com.absa.amol.common.util.StringUtil;
import com.absa.amol.current.model.TransactionHistoryRequest;
import com.absa.amol.current.model.TransactionHistoryResponse;
import com.absa.amol.current.service.TransactionHistoryService;
import com.absa.amol.current.util.CurrentAccountConstant;
import com.absa.amol.current.util.TransHistorySystemServiceClient;

@ApplicationScoped
public class TransactionHistoryServiceImpl implements TransactionHistoryService {

  @Inject
  @RestClient
  private TransHistorySystemServiceClient transHistorySystemServiceClient;

  private static final Logger logger = LoggerFactory.getLogger(TransactionHistoryServiceImpl.class);

  public Response getTransactionHistoryResponse(
      TransactionHistoryRequest transactionHistoryRequest) {

    logger.info("getTransactionHistoryResponse",
        transactionHistoryRequest.getApiRequestHeader().getCorrelationId(),
        "inside Service : invoking system service client", "");
    try {

      ResponseEntity<TransactionHistoryResponse> res =
          transHistorySystemServiceClient.getTransactionHistoryResponse(transactionHistoryRequest);

      if (null != res && ("200").equals(res.getCode())) {

        logger.info(CurrentAccountConstant.GET_TRANSACTION_HISTORY_RESPONSE,
            transactionHistoryRequest.getApiRequestHeader().getCorrelationId(),
            "Received success response from system service", "Status Code : " + res.getCode());
        return Response.ok(res).build();
      } else {

        return Response.status(null != res && StringUtil.isStringNotNullAndNotEmpty(res.getCode())
            ? Integer.parseInt(res.getCode())
            : CurrentAccountConstant.ERROR_CODE_INT).entity(res).build();
      }
    } catch (ApiException exception) {

      logger.error(CurrentAccountConstant.GET_TRANSACTION_HISTORY_RESPONSE,
          transactionHistoryRequest.getApiRequestHeader().getCorrelationId(),
          CurrentAccountConstant.EXCEPTION_OCCURED_FROM_SERVER, exception.getErrorMessage());
      logger.debug(CurrentAccountConstant.GET_TRANSACTION_HISTORY_RESPONSE,
          transactionHistoryRequest.getApiRequestHeader().getCorrelationId(),
          CurrentAccountConstant.EXCEPTION_OCCURED_FROM_SERVER, exception);
      throw exception;
    } catch (Exception exception) {

      logger.error(CurrentAccountConstant.GET_TRANSACTION_HISTORY_RESPONSE,
          transactionHistoryRequest.getApiRequestHeader().getCorrelationId(),
          CurrentAccountConstant.EXCEPTION_OCCURED_FROM_SERVER, exception.getMessage());
      logger.debug(CurrentAccountConstant.GET_TRANSACTION_HISTORY_RESPONSE,
          transactionHistoryRequest.getApiRequestHeader().getCorrelationId(),
          CurrentAccountConstant.EXCEPTION_OCCURED_FROM_SERVER, exception);
      throw new ApiResponseException("500", "Internal Server Error");
    }
  }
}
