package com.absa.amol.current.service.impl;

import java.util.LinkedHashSet;
import java.util.Set;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.eclipse.microprofile.config.Config;

import com.absa.amol.common.exception.ApiRequestException;
import com.absa.amol.common.logging.Logger;
import com.absa.amol.common.logging.LoggerFactory;
import com.absa.amol.current.model.TransactionHistoryRequest;
import com.absa.amol.current.service.TransactionHistoryRequestValidatorService;
import com.absa.amol.current.util.CurrentAccountConstant;

@ApplicationScoped
public class TransactionHistoryRequestValidatorServiceImpl
    implements TransactionHistoryRequestValidatorService {

  @Inject
  private Validator validator;

  @Inject
  Config config;

  private static final Logger logger =
      LoggerFactory.getLogger(TransactionHistoryRequestValidatorServiceImpl.class);

  public void validateRequest(TransactionHistoryRequest transactionHistoryRequest) {

    logger.info(CurrentAccountConstant.VALIDATE_REQUEST, "", "validating the request", "");
    Set<String> annoBeansValErrList = validateAnnotatedBeans(transactionHistoryRequest);
    if (!annoBeansValErrList.isEmpty()) {
      String errorMessage = String.join(",", annoBeansValErrList);
      ApiRequestException exception = new ApiRequestException("400", errorMessage);
      logger.error(CurrentAccountConstant.VALIDATE_REQUEST, "",
          "Exception occured while validating request", exception.getErrorMessage());
      logger.debug(CurrentAccountConstant.VALIDATE_REQUEST, "",
          "Exception occured while validating request", exception);
      throw exception;
    }
    logger.info(CurrentAccountConstant.VALIDATE_REQUEST, "", "No validation errors found", "");

  }

  private Set<String> validateAnnotatedBeans(TransactionHistoryRequest transactionHistoryRequest) {
    Set<String> errorList = new LinkedHashSet<>();
    Set<ConstraintViolation<Object>> violations = validator.validate(transactionHistoryRequest);
    for (ConstraintViolation<Object> error : violations) {
      String customErroMsg = getPropertyValue(error.getMessageTemplate());
      if (customErroMsg == null || customErroMsg.isEmpty())
        customErroMsg = error.getMessage();
      errorList.add(customErroMsg);
    }
    return errorList;
  }

  private String getPropertyValue(String key) {
    try {
      return config.getValue(key, String.class);
    } catch (Exception exception) {
      logger.error("getPropertyValue", "", "Exception while reading property for the key ::" + key,
          exception.getMessage());
      logger.debug("getPropertyValue", "", "Exception while reading property for the key ::" + key,
          exception);
    }
    return "";
  }

}
