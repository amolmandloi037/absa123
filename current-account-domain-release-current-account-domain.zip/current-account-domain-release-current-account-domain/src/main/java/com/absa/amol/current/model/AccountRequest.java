package com.absa.amol.current.model;

import javax.json.bind.annotation.JsonbProperty;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.ws.rs.BeanParam;
import javax.ws.rs.QueryParam;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import com.absa.amol.common.model.ApiRequestHeader;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Schema(name = "AccountRequest", description = "POJO represents current account request details")
public class AccountRequest {
  @JsonbProperty(value = "customerNumber")
  @NotNull(message = "customerNumber.nullorEmpty.error.message")
  @NotEmpty(message = "customerNumber.nullorEmpty.error.message")
  @Pattern(regexp = "^[0-9]*", message = "customerNumber.pattern.error.message")
  @Size(min = 5, max = 10, message = "customerNumber.size.error.message")
  @Schema(required = true, example = "180005410555")
  @QueryParam(value = "customerNumber")
  private String customerNumber;
  @Valid
  @BeanParam
  private ApiRequestHeader apiRequestHeader;

}
