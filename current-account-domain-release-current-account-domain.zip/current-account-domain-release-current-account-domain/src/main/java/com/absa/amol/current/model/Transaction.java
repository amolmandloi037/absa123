package com.absa.amol.current.model;

import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Transaction {

  private String transactionId;

  private String accountNumber;

  private String description;

  private String title;

  private String transactionType;

  private BigDecimal amount;

  private String currencyCode;

  private String merchant;

  private String payee;

  private Location location;

  private String status;

  private String checkNumber;

  private String transactionDate;

  private String postDate;

  private String[] category;

  private DepositsAndWithdrawals depositsAndWithdrawals;

  private Payments payments;
}
