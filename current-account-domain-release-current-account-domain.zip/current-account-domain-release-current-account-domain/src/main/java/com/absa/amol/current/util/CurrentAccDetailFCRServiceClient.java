package com.absa.amol.current.util;

import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;
import com.absa.amol.common.model.ResponseEntity;
import com.absa.amol.current.model.AccountRequest;
import com.absa.amol.current.model.AccountResponse;

@RegisterRestClient(configKey = "fcrsystemservice")
@RegisterProvider(ServerSideExceptionMapper.class)
public interface CurrentAccDetailFCRServiceClient {

  @GET
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  public ResponseEntity<AccountResponse> getAccountDetails(
      @BeanParam AccountRequest accountRequest);

}

