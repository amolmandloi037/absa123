package com.absa.amol.current.model;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.ws.rs.BeanParam;
import javax.ws.rs.QueryParam;
import com.absa.amol.common.model.ApiRequestHeader;
import com.absa.amol.current.util.Date;
import com.absa.amol.current.util.ValidAmounts;
import com.absa.amol.current.util.ValidDateRange;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@ValidAmounts(message = "invalid.amountrange.error.message")
@ValidDateRange(message = "invalid.daterange.error.message")
public class TransactionHistoryRequest {

  @BeanParam
  @Valid
  private ApiRequestHeader apiRequestHeader;

  @NotNull(message = "accountId.nullOrEmpty.error.message")
  @NotEmpty(message = "accountId.nullOrEmpty.error.message")
  @Size(min = 1, max = 16, message = "accountId.size.error.message")
  @Pattern(regexp = "^[0-9]*", message = "accountId.pattern.error.message")
  @QueryParam("accountId")
  private String accountId;

  @NotNull(message = "startDate.nullOrEmpty.error.message")
  @NotEmpty(message = "startDate.nullOrEmpty.error.message")
  @Date(message = "startDate.invalid.error.message", format = "yyyyMMdd")
  @Pattern(regexp = "^[0-9]*", message = "startDate.pattern.error.message")
  @QueryParam("startDate")
  private String startDate;

  @NotNull(message = "endDate.nullOrEmpty.error.message")
  @NotEmpty(message = "endDate.nullOrEmpty.error.message")
  @Date(message = "endDate.invalid.error.message", format = "yyyyMMdd")
  @Pattern(regexp = "^[0-9]*", message = "endDate.pattern.error.message")
  @QueryParam("endDate")
  private String endDate;

  @Pattern(regexp = "(^$)|(^[C])|(^[D])", message = "drCrInd.pattern.error.message")
  @QueryParam("drCrInd")
  private String drCrInd;

  @Pattern(regexp = "(^$)|(^[-0-9]{1,15}(?:\\.[0-9]{1,7})?$)",
      message = "amountStart.pattern.error.message")
  @QueryParam("amountStart")
  private String amountStart;

  @Pattern(regexp = "(^$)|(^[-0-9]{1,15}(?:\\.[0-9]{1,7})?$)",
      message = "amountEnd.pattern.error.message")
  @QueryParam("amountEnd")
  private String amountEnd;

  @Size(min = 0, max = 3, message = "pageNo.size.error.message")
  @Pattern(regexp = "(^$)|^((?!(0))[0-9]+)$", message = "pageNo.pattern.error.message")
  @QueryParam("pageNo")
  private String pageNo;

  @Size(min = 0, max = 5, message = "pageSize.size.error.message")
  @Pattern(regexp = "(^$)|^((?!(0))[0-9]+)$", message = "pageSize.pattern.error.message")
  @QueryParam("pageSize")
  private String pageSize;

  @Pattern(regexp = "^[0-9]*", message = "branchCode.pattern.error.message")
  @Size(max = 3, message = "branchCode.size.error.message")
  @QueryParam("branchCode")
  private String branchCode;

}
