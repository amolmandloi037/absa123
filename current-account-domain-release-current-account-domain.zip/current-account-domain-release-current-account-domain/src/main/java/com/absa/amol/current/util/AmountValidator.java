package com.absa.amol.current.util;


import java.util.Objects;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import com.absa.amol.current.model.TransactionHistoryRequest;


public class AmountValidator


    implements ConstraintValidator<ValidAmounts, TransactionHistoryRequest> {


  @Override


  public boolean isValid(TransactionHistoryRequest request, ConstraintValidatorContext context) {


    if (Objects.isNull(request.getAmountStart()) && Objects.isNull(request.getAmountEnd())) {


      return true;


    }


    if ((Objects.nonNull(request.getAmountStart()) && Objects.nonNull(request.getAmountEnd()))


        && (validateNumber(request.getAmountStart()) && validateNumber(request.getAmountEnd()))


        && (Double.parseDouble(request.getAmountStart()) > Double


            .parseDouble(request.getAmountEnd()))) {


      return false;


    }


    if (Objects.isNull(request.getAmountStart()) || Objects.isNull(request.getAmountEnd())) {


      return false;


    }


    return true;


  }


  public boolean validateNumber(String amount) {


    return amount.matches("^[-0-9]*.?[0-9]+$");


  }


}


