package com.absa.amol.current.service.impl;

import static com.absa.amol.common.util.CommonUtil.isNotNull;

import java.util.Set;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.core.Response;

import org.eclipse.microprofile.config.inject.ConfigProperty;

import com.absa.amol.common.exception.ApiRequestException;
import com.absa.amol.common.logging.Logger;
import com.absa.amol.common.logging.LoggerFactory;
import com.absa.amol.current.model.AccountRequest;
import com.absa.amol.current.service.CountrySpecificService;
import com.absa.amol.current.util.CurrentAccountConstant;


@ApplicationScoped
public class CountrySpecificServiceImpl implements CountrySpecificService {
	private static final Logger LOGGER = LoggerFactory.getLogger(CountrySpecificServiceImpl.class);
	@Inject
	private CurrentAccountServiceImpl currentAccountDetailsService;

	@Inject
	@ConfigProperty(name = "fcrcountry", defaultValue = "TZ-TZNBC,UG-UGBRB,KE-KEBRB,MZ-MZBRB")
	Set<String> fcrCountry;

	@Inject
	@ConfigProperty(name = "brainscountry", defaultValue = "GH-GHBRB,TZ-TZBRB,ZM-ZMBRB,SC-SCBRB,MU-MUBRB,BW,ZW")
	Set<String> brainsCountry;

	public Response getAccountDetails(AccountRequest accountRequest) {
		LOGGER.info("getAccountDetails", CurrentAccountConstant.getCorrelationId(accountRequest.getApiRequestHeader()),
				"start of getAccountDetails Method", "");
		if (isNotNull(accountRequest.getApiRequestHeader())) {
			String countryCode = String.format("%s-%s", accountRequest.getApiRequestHeader().getCountryCode(),
					accountRequest.getApiRequestHeader().getBusinessId());
			if (fcrCountry.contains(countryCode)) {
				return currentAccountDetailsService.getCurrentAccountDetailsFromFcr(accountRequest);
			} else if (brainsCountry.contains(countryCode)) {
				return currentAccountDetailsService.getCurrentAccountDetails(accountRequest);
			} else {
				throw new ApiRequestException(CurrentAccountConstant.BAD_REQUEST_CODE,
						"Invalid Country Code or Business Id..");
			}
		} else {
			throw new ApiRequestException(CurrentAccountConstant.BAD_REQUEST_CODE, "Incorrect Country-Code/Business-Id. Please enter a valid value.");
		}
	}

}
