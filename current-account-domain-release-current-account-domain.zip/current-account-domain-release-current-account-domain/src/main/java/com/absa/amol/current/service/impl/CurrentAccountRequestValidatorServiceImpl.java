package com.absa.amol.current.service.impl;

import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.eclipse.microprofile.config.Config;

import com.absa.amol.common.exception.ApiRequestException;
import com.absa.amol.common.logging.Logger;
import com.absa.amol.common.logging.LoggerFactory;
import com.absa.amol.common.model.ApiRequestHeader;
import com.absa.amol.common.util.StringUtil;
import com.absa.amol.current.model.AccountRequest;
import com.absa.amol.current.service.CurrentAccountRequestValidatorService;
import com.absa.amol.current.util.CurrentAccountConstant;

import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.eclipse.microprofile.config.Config;

import com.absa.amol.common.exception.ApiRequestException;
import com.absa.amol.common.logging.Logger;
import com.absa.amol.common.logging.LoggerFactory;
import com.absa.amol.common.model.ApiRequestHeader;
import com.absa.amol.common.util.StringUtil;
import com.absa.amol.current.model.AccountRequest;
import com.absa.amol.current.util.CurrentAccountConstant;

@ApplicationScoped
public class CurrentAccountRequestValidatorServiceImpl implements CurrentAccountRequestValidatorService {

  @Inject
  private Validator validator;

  @Inject
  Config config;

  private static final Logger logger =
      LoggerFactory.getLogger(CurrentAccountRequestValidatorServiceImpl.class);

  @Override
  public void validateRequest(AccountRequest accountRequest) {

    logger.info(CurrentAccountConstant.VALIDATE_REQUEST, "", "Validating the request", "");
    Set<String> errorList = validatedAnnotedBeans(accountRequest);
    if (!errorList.isEmpty()) {
      String errorMessage = String.join(",", errorList);
      ApiRequestException exception =
          new ApiRequestException(CurrentAccountConstant.BAD_REQUEST_CODE, errorMessage);
      logger.error(CurrentAccountConstant.VALIDATE_REQUEST, "", "Validation failed:",
          exception.getErrorMessage());
      throw exception;
    }
    logger.info(CurrentAccountConstant.VALIDATE_REQUEST, "", "No validation errors found", "");
  }

  private Set<String> validatedAnnotedBeans(AccountRequest accountRequest) {
    Set<ConstraintViolation<AccountRequest>> violations = validator.validate(accountRequest);
    return violations.stream().map(constraint -> {
      String customErroMsg = getPropertyValue(constraint.getMessageTemplate());
      return StringUtil.isStringNullOrEmpty(customErroMsg) ? constraint.getMessage()
          : customErroMsg;
    }).collect(Collectors.toSet());
  }

  private String getPropertyValue(String confKey) {
    try {
      return config.getValue(confKey, String.class);
    } catch (Exception e) {
      logger.error("getPropertyValue", "",
          "Exception while reading property for the key ::" + confKey, e.getMessage());
    }
    return "";
  }
}