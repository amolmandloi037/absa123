package com.absa.amol.current.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Objects;
import javax.inject.Inject;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.eclipse.microprofile.config.Config;
import com.absa.amol.current.model.TransactionHistoryRequest;


public class DateRangeValidator
    implements ConstraintValidator<ValidDateRange, TransactionHistoryRequest> {

  @Inject
  private Config config;

  LocalDate startDate;
  LocalDate endDate;


  @Override
  public boolean isValid(TransactionHistoryRequest transHist,
      ConstraintValidatorContext consValid) {

    if (Objects.isNull(transHist.getStartDate()) || Objects.isNull(transHist.getEndDate())) {
      return true;
    }
    String inputStartDate = transHist.getStartDate();
    String inputEndDate = transHist.getEndDate();
    try {
      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
      startDate = LocalDate.parse(inputStartDate, formatter);
      endDate = LocalDate.parse(inputEndDate, formatter);
    } catch (Exception e) {
      return true;
    }

    return startDate.isBefore(endDate) || startDate.isEqual(endDate);
  }

}
