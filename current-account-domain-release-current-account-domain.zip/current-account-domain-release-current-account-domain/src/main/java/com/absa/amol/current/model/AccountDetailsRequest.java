package com.absa.amol.current.model;

import javax.validation.Valid;
import javax.ws.rs.BeanParam;
import javax.ws.rs.QueryParam;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import com.absa.amol.common.model.ApiRequestHeader;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Schema(name = "AccountDetailsRequest",
    description = "POJO represents current account details request.")
public class AccountDetailsRequest {
  @QueryParam(value = "accountNumber")
  private String accountNumber;
  @QueryParam(value = "branchCode")
  private String branchCode;
  @Valid
  @BeanParam
  private ApiRequestHeader requestHeader;
}
