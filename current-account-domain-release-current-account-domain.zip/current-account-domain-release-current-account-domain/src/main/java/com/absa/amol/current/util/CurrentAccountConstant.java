package com.absa.amol.current.util;

import static com.absa.amol.common.util.CommonUtil.isNotNull;
import com.absa.amol.common.model.ApiRequestHeader;

public final class CurrentAccountConstant {

  private CurrentAccountConstant() {}

  public static final String SUCCESS_CODE = "200";

  public static final String ERROR_CODE = "500";

  public static final int ERROR_CODE_INT = 500;

  public static final String BAD_REQUEST_CODE = "400";

  public static final int SUCCESS = 200;

  public static final String SUCCESS_MSG = "SUCCESS";

  public static final String ERROR_MSG = "ERROR";

  public static final String PRODUCT_PROCESSOR_HEADER = "ProductProcessorID";

  public static final String GET_CURRENT_ACCOUNT_DETAILS = "getCurrentAccountDetails";

  public static final String EXCEPTION_OCCURED = "Exception Occured";

  public static final String IO_EXCEPTION = "IO exception occurred!";

  public static final String FILE_NOT_FOUND_EXCEPTION = "File not found!";

  public static final String GET_ACCOUNT_NAME = "getAccountName";

  public static final String CONFIG_SOURCE_NAME = "FileSystemConfigSource";

  public static final String GET_CURRENT_ACCOUNT_DETAILS_FCR =
      "Get Current account details from FCR";

  public static final String INVALID_HEADER = "Invalid header.";

  public static final String INVALID_COUNTRY_CODE_AND_BUSINESSID =
      "Invalid Country Code or Business Id..";

  public static final String VALIDATE_REQUEST = "validateRequest";

  public static final String BAD_CODE_REQUEST = "404";
  public static final String BAD_REQUEST_MSG = "Customer Number not found.";

  public static final String INTERNAL_ERROR_CODE = "500";
  public static final String INTERNAL_ERROR_MSG = "Internal Server Error.";

  public static final String SUCCESS_RESPONSE_MESSAGE = "Get Customer Details";
  public static final String NAME = "OK";

  public static final String SUMMERY = "Get current Account details by Customer Number";
  public static final String DESC = "Get current account details";

  public static final String TITLE = "Current Account Detail Service openAPI";
  public static final String CONTACT_NAME = "Amol";
  public static final String LICENSE_NAME = "Amol";
  public static final String CONTACT_EMAIL = "abc@absa.africa";
  public static final String VERSION = "1.0.0";

  public static final String TIMEOUT_CODE = "504";
  public static final long FALLBACK_TIMEOUT = 10000;
  public static final String FALLBACK_METHOD_FOR_TIMEOUT = "fallbackForTimeout";
  public static final String FAILURE_MSG = "Failure";

  public static final String GET_TRANSACTION_HISTORY_RESPONSE = "getTransactionHistoryResponse";
  public static final String EXCEPTION_OCCURED_FROM_SERVER =
      "exception occured while invoking system service";

  public static final String getCorrelationId(ApiRequestHeader requestHeader) {
    if (isNotNull(requestHeader) && isNotNull(requestHeader.getCorrelationId())) {
      return requestHeader.getCorrelationId();
    }
    return "";
  }

}
