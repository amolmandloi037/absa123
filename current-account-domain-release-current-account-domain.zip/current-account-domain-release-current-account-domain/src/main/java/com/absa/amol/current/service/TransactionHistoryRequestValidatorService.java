package com.absa.amol.current.service;

import com.absa.amol.current.model.TransactionHistoryRequest;

public interface TransactionHistoryRequestValidatorService {

  public void validateRequest(TransactionHistoryRequest transactionHistoryRequest);

}
