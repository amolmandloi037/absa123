package com.absa.amol.payment.config;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

public class FileSystemConfigSourceTest {
  @InjectMocks
  FileSystemConfigSource fileSystemConfigSource;

  @BeforeEach
  public void init() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void configTest() {
    String file = getClass().getClassLoader()
        .getResource("properties/dev/bill-payment-system-fcr-dev.properties").getFile();
    System.setProperty("properties.path", file);
    assertEquals("FileSystemConfigSource", fileSystemConfigSource.getName());
  }

  @Test
  public void getNameTest() {
    assertEquals("FileSystemConfigSource", fileSystemConfigSource.getName());
  }

  @Test
  public void getPropertiesTest() {
    assertNotNull(fileSystemConfigSource.getProperties());
  }

  @Test
  public void getValueTest() {
    assertEquals(null, fileSystemConfigSource.getValue("test data"));
  }

}
