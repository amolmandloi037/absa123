package com.absa.amol.payment.route;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.RoutesBuilder;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import com.absa.amol.common.exception.ApiRequestException;
import com.absa.amol.common.exception.ApiResponseException;
import com.absa.amol.common.exception.GlobalException;

public class ExceptionHandlerRouteTest extends CamelTestSupport {

  @Produce(uri = "direct:ExceptionHandler")
  protected ProducerTemplate producerTemplate;

  @Mock
  Exchange exchange;

  @Mock
  Message inMsg;



  @BeforeEach
  public void init() throws Exception {
    MockitoAnnotations.initMocks(this);
    super.setUp();
  }

  protected RoutesBuilder createRouteBuilder() {
    return new ExceptionHandlerRoute();
  }

  @Test
  void apiRequestExceptionTest() throws InterruptedException {
    Mockito.when(exchange.getIn()).thenReturn(inMsg);
    producerTemplate.sendBody("direct:ExceptionHandler", new ApiRequestException("400", "Failure"));
    assertMockEndpointsSatisfied();
  }

  @Test
  void apiResponseExceptionTest() throws InterruptedException {
    Mockito.when(exchange.getIn()).thenReturn(inMsg);
    producerTemplate.sendBody("direct:ExceptionHandler",
        new ApiResponseException("400", "Failure"));
    assertMockEndpointsSatisfied();
  }

  @Test
  void globalExceptionTest() throws InterruptedException {
    Mockito.when(exchange.getIn()).thenReturn(inMsg);
    producerTemplate.sendBody("direct:ExceptionHandler", new GlobalException("400", "Failure"));
    assertMockEndpointsSatisfied();
  }

}
