package com.absa.amol.payment.processor;

import org.apache.camel.Exchange;
import org.apache.camel.ExchangeTimedOutException;
import org.apache.camel.Message;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import com.absa.amol.common.exception.ApiRequestException;
import com.absa.amol.common.exception.ApiResponseException;
import com.absa.amol.common.exception.GlobalException;
import com.absa.amol.common.model.ApiRequestHeader;
import com.absa.amol.common.model.ResponseEntity;
import com.absa.amol.payment.model.BillPaymentRequest;
import com.iflex.fcr.app.bill.spi.FatalException;
import com.iflex.fcr.infra.exception.ReplyMessage;

class ExceptionProcessTest {

  @Mock
  Exchange exchange;

  @Mock
  Message inMsg;

  @Mock
  Message outMsg;

  @InjectMocks
  private ExceptionProcess processor = new ExceptionProcess();

  @BeforeEach
  public void init() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void apiRequestExceptionTest() throws Exception {

    Mockito.when(exchange.getIn()).thenReturn(inMsg);
    Mockito.when(exchange.getOut()).thenReturn(outMsg);
    Mockito.when(exchange.getProperty("billPaymentRequest")).thenReturn(getTransHistReqPayload());

    Mockito.when(exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class))
        .thenReturn(new ApiRequestException("200", "Failure"));
    processor.process(exchange);
    Assertions.assertNull(exchange.getOut().getBody(ResponseEntity.class));
  }

  @Test
  public void apiResponsetExceptionTest() throws Exception {

    Mockito.when(exchange.getIn()).thenReturn(inMsg);
    Mockito.when(exchange.getOut()).thenReturn(outMsg);
    Mockito.when(exchange.getProperty("billPaymentRequest")).thenReturn(getTransHistReqPayload());

    Mockito.when(exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class))
        .thenReturn(new ApiResponseException("400", "Failure"));
    processor.process(exchange);
    Assertions.assertNull(exchange.getOut().getBody(ResponseEntity.class));
  }

  @Test
  public void globalExceptionTest() throws Exception {

    Mockito.when(exchange.getIn()).thenReturn(inMsg);
    Mockito.when(exchange.getOut()).thenReturn(outMsg);
    Mockito.when(exchange.getProperty("billPaymentRequest")).thenReturn(getTransHistReqPayload());

    Mockito.when(exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class))
        .thenReturn(new GlobalException("500", "Failure"));
    processor.process(exchange);
    Assertions.assertNull(exchange.getOut().getBody(ResponseEntity.class));
  }

  @Test
  public void exchangeTimedOutExceptionTest() throws Exception {

    Mockito.when(exchange.getIn()).thenReturn(inMsg);
    Mockito.when(exchange.getOut()).thenReturn(outMsg);
    Mockito.when(exchange.getProperty("billPaymentRequest")).thenReturn(getTransHistReqPayload());

    Mockito.when(exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class))
        .thenReturn(new ExchangeTimedOutException(null, 1));
    processor.process(exchange);
    Assertions.assertNull(exchange.getOut().getBody(ResponseEntity.class));
  }

  @Test
  public void fatalExceptionTest1() throws Exception {
    com.iflex.fcr.infra.exception.FatalException faultInfo =
        new com.iflex.fcr.infra.exception.FatalException();
    ReplyMessage reason = new ReplyMessage();
    reason.setCode("20");
    reason.setMessage("Test");
    faultInfo.setReason(reason);

    Mockito.when(exchange.getIn()).thenReturn(inMsg);
    Mockito.when(exchange.getOut()).thenReturn(outMsg);
    Mockito.when(exchange.getProperty("billPaymentRequest")).thenReturn(getTransHistReqPayload());

    Mockito.when(exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class))
        .thenReturn(new FatalException("Insufficient Balance", faultInfo));
    processor.process(exchange);
    Assertions.assertNull(exchange.getOut().getBody(ResponseEntity.class));
  }

  @Test
  public void fatalExceptionTest2() throws Exception {

    Mockito.when(exchange.getIn()).thenReturn(inMsg);
    Mockito.when(exchange.getOut()).thenReturn(outMsg);
    Mockito.when(exchange.getProperty("billPaymentRequest")).thenReturn(getTransHistReqPayload());

    Mockito.when(exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class)).thenReturn(
        new FatalException("com.iflex.fcr.infra.exception.FatalException: Account Id not Found",
            null));
    processor.process(exchange);
    Assertions.assertNull(exchange.getOut().getBody(ResponseEntity.class));
  }

  @Test
  public void nullPointerExceptionTest() throws Exception {

    Mockito.when(exchange.getIn()).thenReturn(inMsg);
    Mockito.when(exchange.getOut()).thenReturn(outMsg);
    Mockito.when(exchange.getProperty("billPaymentRequest")).thenReturn(getTransHistReqPayload());

    Mockito.when(exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class))
        .thenReturn(new NullPointerException("Null exception"));
    processor.process(exchange);
    Assertions.assertNull(exchange.getOut().getBody(ResponseEntity.class));
  }

  @Test
  public void correlationIdInvalidTest() throws Exception {

    Mockito.when(exchange.getIn()).thenReturn(inMsg);
    Mockito.when(exchange.getOut()).thenReturn(outMsg);

    Mockito.when(exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class))
        .thenReturn(new ApiRequestException("200", "Failure"));
    processor.process(exchange);
    Assertions.assertNull(exchange.getOut().getBody(ResponseEntity.class));
  }

  public BillPaymentRequest getTransHistReqPayload() {
    BillPaymentRequest request = new BillPaymentRequest();
    request.setAccountId("1234567890");
    request.setBillNo(125694);
    request.setAccountCurrencyRate((float) 12569.00);
    request.setBillerType('n');
    request.setConsumerNo("aaaa");
    request.setPaymentDueDate("05/07/2020");
    request.setNarrative("aaaaaaa");
    request.setPrimaryReferenceNo("ssss");
    request.setSecondaryReferenceNo("yyyyyy");
    request.setServiceChargeCode(1589745612);
    request.setTransactionType(1);
    request.setUtilityCompanyId(123);

    ApiRequestHeader apiRequestHeader = new ApiRequestHeader();
    apiRequestHeader.setBusinessId("MB");
    apiRequestHeader.setSystemId("KBBRB");
    apiRequestHeader.setCountryCode("KE");
    apiRequestHeader.setCorrelationId("1122334455");
    request.setApiRequestHeader(apiRequestHeader);
    return request;
  }
}
