package com.absa.amol.payment;



import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import javax.ws.rs.core.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import com.absa.amol.common.exception.ApiResponseException;
import com.absa.amol.common.model.ApiRequestHeader;
import com.absa.amol.common.model.ResponseEntity;
import com.absa.amol.payment.model.BillPaymentRequest;
import com.absa.amol.payment.model.BillPaymentResponse;
import com.absa.amol.payment.model.Status;
import com.absa.amol.payment.service.BillPaymentService;
import com.absa.amol.payment.service.impl.ValidatorServiceImpl;

class BillPaymentSystemControllerTest {


  @InjectMocks
  BillPaymentSystemController billPaymentSystemController;

  @Mock
  BillPaymentService billPaymentService;

  @Mock
  ValidatorServiceImpl validatorService;

  private ApiRequestHeader apiRequestHeader;

  @BeforeEach
  public void setup() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void testSuccessResponse() {
    Mockito.when(billPaymentService.payUtilityBill(ArgumentMatchers.any()))
        .thenReturn(getSuccessResponseStub());

    Mockito.when(billPaymentService.payUtilityBill(Mockito.any(BillPaymentRequest.class)))
        .thenReturn(getSuccessResponseStub());
    // Mockito.when(validatorService.validateRequest(Mockito.any(BillPaymentRequest.class))).the



    Response response =
        billPaymentSystemController.payUtilityBillByAccount(getRequestStub(), apiRequestHeader);

    /*
     * ResponseEntity responseEntity = (ResponseEntity) response.getEntity(); BillPaymentResponse
     * transHistRes = (BillPaymentResponse) responseEntity.getData();
     */

    assertNotNull(response);
    assertEquals(200, response.getStatus());
    /*
     * assertEquals(1, transHistRes.getTransactions().size());
     * 
     * assertEquals("Success", responseEntity.getMessage()); Transaction testTrans =
     * transHistRes.getTransactions().get(0);
     */
    // assertEquals("147896523", testTrans.getAccountId());

  }

  @Test
  public void testErrorResponse_500() {
    Mockito.when(billPaymentService.payUtilityBill(ArgumentMatchers.any()))
        .thenReturn(getErrorResponseStub_500());

    Response response =
        billPaymentSystemController.payUtilityBillByAccount(getRequestStub(), apiRequestHeader);

    // ResponseEntity responseEntity = (ResponseEntity) response.getEntity();
    // TransactionHistoryResponse transHistRes = (TransactionHistoryResponse)
    // responseEntity.getData();

    assertEquals(500, response.getStatus());
    // assertEquals("Internal server error", response.getMessage());
  }

  @Test
  public void testErrorResponse_400() {

    BillPaymentRequest transactionhistorydetails = new BillPaymentRequest();
    Mockito.when(billPaymentService.payUtilityBill(ArgumentMatchers.any()))
        .thenReturn(getErrorResponseStub_400());

    Response response = billPaymentSystemController
        .payUtilityBillByAccount(transactionhistorydetails, apiRequestHeader);

    // ResponseEntity responseEntity = (ResponseEntity) response.getEntity();
    // TransactionHistoryResponse transHistRes = (TransactionHistoryResponse)
    // responseEntity.getData();

    assertEquals(400, response.getStatus());
    // assertEquals("Internal server error", responseEntity.getMessage());
  }

  @Test
  void transHistControllerfallbackTest() {
    BillPaymentRequest transactionhistoryReq = new BillPaymentRequest();
    transactionhistoryReq = getRequestStub();
    Response response =
        billPaymentSystemController.fallbackForTimeout(transactionhistoryReq, apiRequestHeader);
    assertEquals(504, response.getStatus());
  }

  private BillPaymentRequest getRequestStub() {
    BillPaymentRequest transactionhistorydetails = new BillPaymentRequest();
    ApiRequestHeader apiRequestHeader = new ApiRequestHeader();

    apiRequestHeader.setCorrelationId("123456");

    transactionhistorydetails.setAccountId("123456789");
    transactionhistorydetails.setApiRequestHeader(apiRequestHeader);

    return transactionhistorydetails;
  }

  private Response getSuccessResponseStub() {

    BillPaymentResponse transactiondetail = new BillPaymentResponse();
    Status transhist = new Status();
    transhist.setIsServiceChargeApplied(true);
    transhist.setUserReferenceNumber("123456");
    transactiondetail.setStatus(transhist);

    ResponseEntity<BillPaymentResponse> responseEntity = new ResponseEntity<BillPaymentResponse>();



    responseEntity.setData(transactiondetail);
    responseEntity.setCode("200");
    responseEntity.setMessage("Success");
    return Response.ok(responseEntity).build();

  }

  private Response getErrorResponseStub_500() {
    ApiResponseException exception = new ApiResponseException("500", "Internal server error");

    ResponseEntity<BillPaymentResponse> responseEntity = new ResponseEntity<BillPaymentResponse>(
        "500", exception.getErrorMessage(), "Failure", null);
    return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
  }

  private Response getErrorResponseStub_400() {
    ApiResponseException exception = new ApiResponseException("400", "Internal server error");

    ResponseEntity<BillPaymentResponse> responseEntity = new ResponseEntity<BillPaymentResponse>(
        "400", exception.getErrorMessage(), "Failure", null);
    return Response.status(Response.Status.BAD_REQUEST).build();
  }
}


