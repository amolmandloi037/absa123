package com.absa.amol.payment.processor;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.eclipse.microprofile.config.Config;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import com.absa.amol.common.model.ApiRequestHeader;
import com.absa.amol.payment.model.BillAmount;
import com.absa.amol.payment.model.BillPaymentRequest;
import com.iflex.fcr.entity.global.dto.CurrencyAmountDTO;


public class PaymentRequestProcessTest {
  @Mock
  private Exchange exchange;

  @Mock
  private Message inMsg;

  @Mock
  private Config config;



  @InjectMocks
  private PaymentRequestProcess processor = new PaymentRequestProcess();

  @BeforeEach
  public void init() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void processTest() throws Exception {
    Mockito.when(exchange.getIn()).thenReturn(inMsg);
    Mockito.when(inMsg.getBody(BillPaymentRequest.class)).thenReturn(getBillPaymentRequestData());
    // Mockito.when(processor.getPropertyValue("bankcode")).thenReturn("3");
    //
    // Mockito.when(processor.getPropertyValue("channel")).thenReturn("MB");
    //
    // Mockito.when(processor.getPropertyValue("transbranch")).thenReturn("999");
    //
    // Mockito.when(processor.getPropertyValue("userid")).thenReturn("IFE");

    Mockito.when(inMsg.getBody(CurrencyAmountDTO.class)).thenReturn(getDtoRequestStub());
    try {
      // processor.process(exchange);
    } catch (Exception e) {

    }
  }

  @Test
  public void getFCRParamListMethodTest() throws Exception {
    BillPaymentRequest request = getBillPaymentRequestData();

    Map<String, String> billPayPropertyMap = new HashMap<String, String>();
    billPayPropertyMap.put("bankcode", "1");
    billPayPropertyMap.put("transbranch", "38");
    billPayPropertyMap.put("externalbatchnumber", "5");
    billPayPropertyMap.put("externalsystemaudittrailnumber", "89");
    billPayPropertyMap.put("userid", "IFE");
    billPayPropertyMap.put("channel", "AB");

    List<Object> paramList = processor.getFCRParamList(billPayPropertyMap, request);
    Assertions.assertNotNull(paramList);


  }


  @Test
  public void getFCRParamListMethodTest2() throws Exception {
    BillPaymentRequest request = getBillPaymentRequestData();
    request.setServiceChargeCode(0);
    Map<String, String> billPayPropertyMap = new HashMap<String, String>();
    billPayPropertyMap.put("bankcode", null);
    billPayPropertyMap.put("transbranch", null);
    billPayPropertyMap.put("externalbatchnumber", null);
    billPayPropertyMap.put("externalsystemaudittrailnumber", null);
    billPayPropertyMap.put("userid", "");
    billPayPropertyMap.put("channel", "");

    List<Object> paramList = processor.getFCRParamList(billPayPropertyMap, request);
    Assertions.assertNotNull(paramList);

  }

  @Test
  public void getFCRParamListMethodTest3() throws Exception {
    BillPaymentRequest request = getBillPaymentRequestData2();
    request.setServiceChargeCode(0);
    Map<String, String> billPayPropertyMap = new HashMap<String, String>();
    billPayPropertyMap.put("bankcode", "1");
    billPayPropertyMap.put("transbranch", "38");
    billPayPropertyMap.put("externalbatchnumber", "5");
    billPayPropertyMap.put("externalsystemaudittrailnumber", "89");
    billPayPropertyMap.put("userid", "IFE");
    billPayPropertyMap.put("channel", "AB");

    List<Object> paramList = processor.getFCRParamList(billPayPropertyMap, request);
    Assertions.assertNotNull(paramList);

  }

  public CurrencyAmountDTO getDtoRequestStub() {
    CurrencyAmountDTO cu = new CurrencyAmountDTO();
    BillAmount billAmount = new BillAmount();
    billAmount.setCurrencyCode("yes");
    BigDecimal b1 = new BigDecimal("12356.2589");
    billAmount.setMonetaryValue(b1);
    return cu;
  }

  public BillPaymentRequest getBillPaymentRequestData() {
    BillPaymentRequest request = new BillPaymentRequest();
    ApiRequestHeader apiRequestHeader = new ApiRequestHeader();
    BillAmount billAmount = new BillAmount();
    request.setUtilityCompanyId(123);
    request.setAccountId("1234567890");
    request.setBillNo(125694);
    request.setAccountCurrencyRate((float) 12569.00);
    request.setBillerType('N');
    request.setBillAmount(billAmount);
    billAmount.setCurrencyCode("yes");
    BigDecimal b1 = new BigDecimal("12356.2589");
    billAmount.setMonetaryValue(b1);

    request.setConsumerNo("aaaa");
    request.setPaymentDueDate("2011-11-02T02:50:12.208Z");
    request.setNarrative("aaaaaaa");
    request.setPrimaryReferenceNo("ssss");
    request.setSecondaryReferenceNo("yyyyyy");
    request.setServiceChargeCode(1589745612);
    request.setTransactionType(1);



    apiRequestHeader.setBusinessId("KEBRB");
    apiRequestHeader.setCorrelationId("125645875");
    apiRequestHeader.setCountryCode("KE");
    apiRequestHeader.setSystemId("MB");
    request.setApiRequestHeader(apiRequestHeader);
    return request;
  }

  public BillPaymentRequest getBillPaymentRequestData2() {
    BillPaymentRequest request = new BillPaymentRequest();
    ApiRequestHeader apiRequestHeader = new ApiRequestHeader();
    BillAmount billAmount = new BillAmount();
    request.setUtilityCompanyId(123);
    request.setAccountId("1234567890");
    request.setBillNo(125694);
    request.setAccountCurrencyRate((float) 12569.00);
    request.setBillAmount(billAmount);
    billAmount.setCurrencyCode("yes");
    BigDecimal b1 = new BigDecimal("12356.2589");
    billAmount.setMonetaryValue(b1);

    request.setConsumerNo("aaaa");
    request.setPaymentDueDate("2011-11-02T02:50:12.208Z");
    request.setNarrative("aaaaaaa");
    request.setPrimaryReferenceNo("ssss");
    request.setSecondaryReferenceNo("yyyyyy");
    request.setServiceChargeCode(1589745612);
    request.setTransactionType(1);
    request.setUsrNarrative("TEST");



    apiRequestHeader.setBusinessId("KEBRB");
    apiRequestHeader.setCorrelationId("125645875");
    apiRequestHeader.setCountryCode("KE");
    apiRequestHeader.setSystemId("MB");
    request.setApiRequestHeader(apiRequestHeader);
    return request;
  }
}
