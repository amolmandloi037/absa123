package com.absa.amol.payment.processor;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import com.absa.amol.common.model.ApiRequestHeader;
import com.absa.amol.payment.model.BillPaymentRequest;
import com.absa.amol.payment.model.BillPaymentResponse;
import com.absa.amol.payment.model.Status;
import com.iflex.fcr.app.bill.spi.dto.PayUtilityBillByAccountResponse;
import com.iflex.fcr.entity.transaction.TransactionStatus;
import com.iflex.fcr.infra.exception.ArrayOfTns10ReplyMessage;
import com.iflex.fcr.infra.exception.ExtendedReply;
import com.iflex.fcr.infra.exception.ReplyMessage;
import com.iflex.fcr.infra.validation.error.ArrayOfTns12ValidationError;
import com.iflex.fcr.infra.validation.error.ValidationError;


public class PaymentResponseProcessTest {



  @Mock
  Exchange exchange;

  @Mock
  Message inMsg;

  @Mock
  BillPaymentRequest billPaymentReq;


  private PaymentResponseProcess processor = new PaymentResponseProcess();


  @Mock
  private PayUtilityBillByAccountResponse fcrResponse;

  @BeforeEach
  public void init() {
    MockitoAnnotations.initMocks(this);

  }

  @Test
  public void processTest() throws Exception {

    Mockito.when(exchange.getIn()).thenReturn(inMsg);
    Mockito.when(exchange.getProperty("billPaymentRequest", BillPaymentRequest.class))
        .thenReturn(getbillPaymentReqPayload());
    Mockito.when(inMsg.getBody(PayUtilityBillByAccountResponse.class))
        .thenReturn(getFCRResponsePayload());
    Mockito.when(exchange.getIn().getBody(PayUtilityBillByAccountResponse.class))
        .thenReturn(getFCRResponsePayload());

    Mockito.when(inMsg.getBody(BillPaymentResponse.class)).thenReturn(getTransformedData());

    processor.process(exchange);

    Assertions.assertNotNull(exchange.getIn().getBody(PayUtilityBillByAccountResponse.class));
    Assertions.assertEquals(BigDecimal.valueOf(12356.25),
        exchange.getIn().getBody(PayUtilityBillByAccountResponse.class).getAvailableBalance());

    Assertions.assertNotNull(exchange.getIn().getBody(BillPaymentResponse.class));


  }

  @Test
  public void processValidationMsgTest() throws Exception {

    Mockito.when(exchange.getIn()).thenReturn(inMsg);
    Mockito.when(exchange.getProperty("billPaymentRequest", BillPaymentRequest.class))
        .thenReturn(getbillPaymentReqPayload());
    Mockito.when(inMsg.getBody(PayUtilityBillByAccountResponse.class))
        .thenReturn(getFCRResponsePayload());
    Mockito.when(exchange.getIn().getBody(PayUtilityBillByAccountResponse.class))
        .thenReturn(getFCRResponseErrPayload());

    Mockito.when(inMsg.getBody(BillPaymentResponse.class)).thenReturn(getTransformedData());

    processor.process(exchange);

    Assertions.assertNotNull(exchange.getIn().getBody(PayUtilityBillByAccountResponse.class));

    Assertions.assertEquals(BigDecimal.valueOf(0.0),
        exchange.getIn().getBody(PayUtilityBillByAccountResponse.class).getAvailableBalance());

    Assertions.assertNotNull(exchange.getIn().getBody(BillPaymentResponse.class));


  }



  public BillPaymentResponse getTransformedData() {

    Status status = new Status();
    status.setMemo("abcde");
    status.setReplyText("new");
    status.setInputOverridenWarnings("aaaaa");
    BillPaymentResponse response = new BillPaymentResponse();
    response.setStatus(status);
    return response;
  }


  public PayUtilityBillByAccountResponse getFCRResponsePayload() {

    PayUtilityBillByAccountResponse request = new PayUtilityBillByAccountResponse();

    request.setAvailableBalance(BigDecimal.valueOf(12356.25));
    ReplyMessage message = new ReplyMessage();
    message.setCode("agdgdggg");
    message.setMessage("new");
    TransactionStatus status = new TransactionStatus();
    ArrayOfTns10ReplyMessage arrayItemDTO = new ArrayOfTns10ReplyMessage();
    arrayItemDTO.getItem().add(message);
    ExtendedReply extended = new ExtendedReply();
    extended.setMessages(arrayItemDTO);
    status.setErrorCode("500");
    status.setReplyCode(600);
    status.setExtendedReply(extended);
    request.setStatus(status);
    return request;
  }

  public PayUtilityBillByAccountResponse getFCRResponseErrPayload() {

    PayUtilityBillByAccountResponse request = new PayUtilityBillByAccountResponse();

    request.setAvailableBalance(BigDecimal.valueOf(0.0));
    ReplyMessage message = new ReplyMessage();
    message.setCode("Error occurred");
    message.setMessage("Invalid data found");
    TransactionStatus status = new TransactionStatus();
    ArrayOfTns10ReplyMessage arrayItemDTO = new ArrayOfTns10ReplyMessage();
    arrayItemDTO.getItem().add(message);
    ExtendedReply extended = new ExtendedReply();
    extended.setMessages(arrayItemDTO);
    status.setErrorCode("500");
    status.setReplyCode(600);
    status.setExtendedReply(extended);
    List<ValidationError> errorList = new ArrayList<ValidationError>();
    ValidationError vErr = new ValidationError();
    vErr.setApplicableAttributes("abc");
    vErr.setAttributeName("twse");
    vErr.setAttributeValue("test");
    vErr.setErrorCode("123");
    vErr.setErrorMessage("Message");
    vErr.setMethodName("Name");
    vErr.setObjectName("obj");
    // errorList.add(vErr);
    ArrayOfTns12ValidationError item = new ArrayOfTns12ValidationError();
    item.getItem().add(vErr);
    status.setValidationErrors(item);
    request.setStatus(status);
    return request;
  }



  public BillPaymentRequest getbillPaymentReqPayload() {
    BillPaymentRequest request = new BillPaymentRequest();
    request.setAccountId("1234567890");
    request.setBillNo(125694);
    request.setAccountCurrencyRate((float) 12569.00);
    request.setBillerType('n');
    request.setConsumerNo("aaaa");
    request.setPaymentDueDate("05/07/2020");
    request.setNarrative("aaaaaaa");
    request.setPrimaryReferenceNo("ssss");
    request.setSecondaryReferenceNo("yyyyyy");
    request.setServiceChargeCode(1589745612);
    request.setTransactionType(1);
    request.setUtilityCompanyId(123);
    ApiRequestHeader apiRequestHeader = new ApiRequestHeader();
    apiRequestHeader.setBusinessId("KEBRB");
    apiRequestHeader.setCorrelationId("125645875");
    apiRequestHeader.setCountryCode("KE");
    apiRequestHeader.setSystemId("MB");
    request.setApiRequestHeader(apiRequestHeader);
    return request;
  }

}


