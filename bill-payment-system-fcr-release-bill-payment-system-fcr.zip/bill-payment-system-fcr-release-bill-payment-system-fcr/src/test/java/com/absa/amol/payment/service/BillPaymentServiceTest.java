package com.absa.amol.payment.service;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.apache.camel.ProducerTemplate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import com.absa.amol.common.exception.ApiException;
import com.absa.amol.common.exception.ApiRequestException;
import com.absa.amol.common.exception.ApiResponseException;
import com.absa.amol.common.exception.DownStreamSystemUnavailableException;
import com.absa.amol.common.exception.GlobalException;
import com.absa.amol.common.model.ApiRequestHeader;
import com.absa.amol.common.model.ResponseEntity;
import com.absa.amol.payment.model.BillPaymentRequest;
import com.absa.amol.payment.model.BillPaymentResponse;
import com.absa.amol.payment.model.Status;
import com.absa.amol.payment.service.impl.BillPaymentServiceImpl;

public class BillPaymentServiceTest {

  @InjectMocks
  BillPaymentService billPayService = new BillPaymentServiceImpl();

  @Mock
  ProducerTemplate producerTemplate;

  @Mock
  BillPaymentRequest billPaymentReq;

  @BeforeEach
  public void init() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  void billPaymentServiceTest() {

    BillPaymentRequest transHistReq = new BillPaymentRequest();
    transHistReq = getReqPayload();
    BillPaymentResponse tranHistRes = new BillPaymentResponse();
    tranHistRes = getResData();
    ResponseEntity<BillPaymentResponse> transHistResEnt =
        new ResponseEntity<BillPaymentResponse>("200", "", "Success", tranHistRes);

    Mockito.when(producerTemplate.requestBody("direct:payUtilityBillByAccountSoapcall",
        transHistReq, ResponseEntity.class)).thenReturn(transHistResEnt);

    assertEquals("200", transHistResEnt.getCode());
  }

  @Test
  void billPay_ExceptionTest() throws ApiRequestException {

    ApiException reqe = new ApiException("500", "Unknown Exception");
    Mockito.when(producerTemplate.requestBody("direct:payUtilityBillByAccountSoapcall",
        billPaymentReq, ResponseEntity.class)).thenThrow(reqe);

    ApiException exceptionThrown = assertThrows(ApiException.class, new Executable() {

      @Override
      public void execute() throws Throwable {
        billPayService.payUtilityBill(billPaymentReq);
      }
    });
    assertEquals("500", exceptionThrown.getErrorCode());
  }

  @Test
  void payBillServiceThrow_ApiExceptionTest() throws ApiException {

    final BillPaymentRequest billPaymentReq = new BillPaymentRequest();
    ApiRequestHeader apiRequestHeader = new ApiRequestHeader();
    apiRequestHeader.setCorrelationId("1122334455");
    billPaymentReq.setApiRequestHeader(apiRequestHeader);

    GlobalException reqe = new GlobalException("500", "Internal error occured");
    Mockito.when(producerTemplate.requestBody("direct:payUtilityBillByAccountSoapcall",
        billPaymentReq, ResponseEntity.class)).thenThrow(reqe);
    ApiException exceptionThrown = assertThrows(ApiException.class, new Executable() {
      @Override
      public void execute() throws Throwable {
        billPayService.payUtilityBill(billPaymentReq);
      }
    });
    assertEquals("500", exceptionThrown.getErrorCode());
    assertEquals("Internal error occured", exceptionThrown.getErrorMessage());
  }

  // @Test
  void payBillServiceThrow_DownStreamApiExceptionTest() throws ApiException {

    final BillPaymentRequest billPaymentReq = new BillPaymentRequest();
    ApiRequestHeader apiRequestHeader = new ApiRequestHeader();
    apiRequestHeader.setCorrelationId("1122334455");
    billPaymentReq.setApiRequestHeader(apiRequestHeader);


    Mockito.when(producerTemplate.requestBody("direct:payUtilityBillByAccountSoapcall",
        billPaymentReq, ResponseEntity.class))
        .thenThrow(new DownStreamSystemUnavailableException("500", ""));
    ApiException exceptionThrown = assertThrows(ApiException.class, new Executable() {
      @Override
      public void execute() throws Throwable {
        billPayService.payUtilityBill(billPaymentReq);
      }
    });
    assertEquals("500", exceptionThrown.getErrorCode());
    assertEquals("Internal error occured", exceptionThrown.getErrorMessage());
  }

  @Test
  void billPaymentServiceGlobalExceptionTest() throws ApiException {

    final BillPaymentRequest billPayReq = new BillPaymentRequest();
    ApiRequestHeader apiRequestHeader = new ApiRequestHeader();
    apiRequestHeader.setCorrelationId("1122334455");
    billPayReq.setApiRequestHeader(apiRequestHeader);
    Mockito.when(producerTemplate.requestBody("direct:payUtilityBillByAccountSoapcall", billPayReq,
        ResponseEntity.class)).thenReturn(getResEntityWith500ErrorData());
    GlobalException exceptionThrown = assertThrows(GlobalException.class, new Executable() {

      @Override
      public void execute() throws Throwable {
        billPayService.payUtilityBill(billPayReq);
      }
    });
    assertEquals("500", exceptionThrown.getErrorCode());
  }

  @Test
  void billPaymentServiceAPIExceptionTest() throws ApiException {

    final BillPaymentRequest billPayReq = new BillPaymentRequest();
    ApiRequestHeader apiRequestHeader = new ApiRequestHeader();
    apiRequestHeader.setCorrelationId("1122334455");
    billPayReq.setApiRequestHeader(apiRequestHeader);
    Mockito.when(producerTemplate.requestBody("direct:payUtilityBillByAccountSoapcall", billPayReq,
        ResponseEntity.class)).thenThrow(ApiRequestException.class);
    assertThrows(ApiRequestException.class, new Executable() {

      @Override
      public void execute() throws Throwable {
        billPayService.payUtilityBill(billPayReq);
      }
    });
  }

  @Test
  void billPaymentServiceApiResponseExceptionTest() throws ApiException {

    final BillPaymentRequest billPayReq = new BillPaymentRequest();
    ApiRequestHeader apiRequestHeader = new ApiRequestHeader();
    apiRequestHeader.setCorrelationId("1122334455");
    billPayReq.setApiRequestHeader(apiRequestHeader);
    Mockito.when(producerTemplate.requestBody("direct:payUtilityBillByAccountSoapcall", billPayReq,
        ResponseEntity.class)).thenThrow(ApiResponseException.class);
    assertThrows(ApiResponseException.class, new Executable() {

      @Override
      public void execute() throws Throwable {
        billPayService.payUtilityBill(billPayReq);
      }
    });
  }


  public BillPaymentRequest getReqPayload() {
    BillPaymentRequest request = new BillPaymentRequest();
    request.setAccountId("1234567890");
    request.setBillNo(125694);
    request.setAccountCurrencyRate((float) 12569.00);
    request.setBillerType('n');
    request.setConsumerNo("aaaa");
    request.setPaymentDueDate("05/07/2020");
    request.setNarrative("aaaaaaa");
    request.setPrimaryReferenceNo("ssss");
    request.setSecondaryReferenceNo("yyyyyy");
    request.setServiceChargeCode(1589745612);
    request.setTransactionType(1);
    request.setUtilityCompanyId(123);

    ApiRequestHeader apiRequestHeader = new ApiRequestHeader();
    apiRequestHeader.setBusinessId("MB");
    apiRequestHeader.setSystemId("KBBRB");
    apiRequestHeader.setCountryCode("KE");
    apiRequestHeader.setCorrelationId("1122334455");
    request.setApiRequestHeader(apiRequestHeader);
    return request;
  }

  public BillPaymentResponse getResData() {
    Status status = new Status();
    status.setMemo("abcde");
    status.setReplyText("new");
    status.setInputOverridenWarnings("aaaaa");
    BillPaymentResponse response = new BillPaymentResponse();
    response.setStatus(status);
    return response;
  }

  public ResponseEntity<BillPaymentResponse> getResEntityWith500ErrorData() {
    ResponseEntity<BillPaymentResponse> response =
        new ResponseEntity<BillPaymentResponse>("500", "Unknown Exception", "", getResData());
    return response;
  }

  public ResponseEntity<BillPaymentResponse> getResEntityWith400ErrorData() {
    ResponseEntity<BillPaymentResponse> response =
        new ResponseEntity<BillPaymentResponse>("400", "Unknown Exception", "", getResData());
    return response;
  }

}
