package com.absa.amol.payment;

import static org.junit.Assert.assertNotNull;
import org.junit.jupiter.api.Test;

class BillPaymentSystemRestApplicationTest {

  @Test
  void constructorTest() {
    BillPaymentSystemRestApplication thsr = new BillPaymentSystemRestApplication();
    assertNotNull(thsr);
  }

}


