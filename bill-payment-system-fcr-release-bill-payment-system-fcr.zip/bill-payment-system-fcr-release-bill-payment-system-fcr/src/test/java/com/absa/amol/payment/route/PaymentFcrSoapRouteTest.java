package com.absa.amol.payment.route;

import java.math.BigDecimal;
import org.apache.camel.EndpointInject;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.RoutesBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.eclipse.microprofile.config.Config;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import com.absa.amol.payment.model.BillAmount;
import com.absa.amol.payment.model.BillPaymentRequest;

public class PaymentFcrSoapRouteTest extends CamelTestSupport {

  @Produce(uri = "direct:payUtilityBillByAccountSoapcall")
  protected ProducerTemplate producerTemplate;


  @EndpointInject(
      uri = "mock:cxf://https://fcruat-ug.intra.absaafrica/services/services/BillPaymentManagerSpi?serviceClass=BillPaymentManagerSpi"
          + "&synchronous=true&wsdlURL=/BillPaymentManagerSpi.wsdl")
  private MockEndpoint resultEndpoint;


  @Mock
  private BillPaymentRequest request;

  @Mock
  Exchange exchange;

  @Mock
  Message inMsg;

  @Mock
  Config config;

  @InjectMocks
  private PaymentFcrSoapRoute route = new PaymentFcrSoapRoute();

  @BeforeEach
  public void init() throws Exception {

    try {
      MockitoAnnotations.initMocks(this);
      super.setUp();
    } catch (Exception e) {
    }
  }

  protected RoutesBuilder createRouteBuilder() {
    return new PaymentFcrSoapRoute();
  }

  @Test
  void apiRequestExceptionTest() throws InterruptedException {

    Mockito.when(exchange.getIn()).thenReturn(inMsg);


    Mockito.when(config.getValue("operation.name", String.class))
        .thenReturn("payUtilityBillByAccount");

    Mockito.when(config.getValue("operation.namespace", String.class))
        .thenReturn("http://spi.bill.app.fcr.iflex.com");

    Mockito.when(config.getValue("endpoint", String.class))
        .thenReturn("https://fcruat-ug.intra.absaafrica/services/services/BillPaymentManagerSpi");

    try {
      producerTemplate.sendBody("direct:payUtilityBillByAccountSoapcall", getRequestStub());
      resultEndpoint.assertIsSatisfied();
      assertMockEndpointsSatisfied();
    } catch (Exception e) {
    }
  }

  public BillPaymentRequest getRequestStub() {
    BillPaymentRequest request = new BillPaymentRequest();
    BillAmount amt = new BillAmount();
    amt.setCurrencyCode("UGX");
    amt.setMonetaryValue(new BigDecimal(100.58));
    request.setBillAmount(amt);
    request.setAccountId("test");
    request.setAccountCurrencyRate(0.0f);
    request.setConsumerNo("1256");
    return request;
  }

}
