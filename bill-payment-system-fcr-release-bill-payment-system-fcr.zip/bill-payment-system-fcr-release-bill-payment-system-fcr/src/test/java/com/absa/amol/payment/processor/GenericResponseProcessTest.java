package com.absa.amol.payment.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import com.absa.amol.payment.model.BillPaymentResponse;
import com.absa.amol.payment.model.Status;


public class GenericResponseProcessTest {



  @InjectMocks
  private GenericReponseProcess processor = new GenericReponseProcess();

  @Mock
  private Exchange exchange;

  @Mock
  private Message inMsg;

  @Mock
  Status status;



  @BeforeEach
  public void init() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void processTest() throws Exception {


    Mockito.when(exchange.getIn()).thenReturn(inMsg);
    Mockito.when(inMsg.getBody(BillPaymentResponse.class)).thenReturn(getReqPayload());


    processor.process(exchange);

  }

  private BillPaymentResponse getReqPayload() {

    BillPaymentResponse response = new BillPaymentResponse();
    Status status = new Status();
    status.setInputOverridenWarnings("1234");
    status.setMemo("new");
    status.setIsServiceChargeApplied(true);
    status.setReplyCode(600);
    status.setReplyText("aaaa");
    return response;

    /*
     * transaction.setAccountId("2134568"); transaction.setTransactionType("C");
     * transaction.setCurrencyCode("TNZ"); transaction.setTransactionId("0");
     * transaction.setDescription(""); transaction.setPostDate(""); transaction.setTitle("");
     * transaction.setStatus("Posted"); transaction.setLocation(location);
     * transaction.setCheckNumber("123"); transaction.setMerchant("XYZ"); //
     * transaction.setPayee("NA"); transaction.setTransactionDate("NA");
     * 
     * transactiondetail.setTransactions(Arrays.asList(transaction)); return transactiondetail;
     */
  }
}


