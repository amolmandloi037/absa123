package com.absa.amol.payment.service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import org.eclipse.microprofile.config.Config;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import com.absa.amol.common.exception.ApiRequestException;
import com.absa.amol.common.model.ApiRequestHeader;
import com.absa.amol.payment.model.BillPaymentRequest;
import com.absa.amol.payment.service.impl.ValidatorServiceImpl;

public class ValidatorServiceTest {

  @InjectMocks
  private ValidatorService validatorService = new ValidatorServiceImpl();

  @Mock
  private static Validator validator;

  @Mock
  private ConstraintViolation<Object> object;

  @Mock
  private Config config;

  @InjectMocks
  private HashSet<ConstraintViolation<Object>> violations;

  @Mock
  private BillPaymentRequest billPaymentRequest;

  @Mock
  List<String> errorList;

  @Mock
  Set<String> errorSet;


  @BeforeEach
  public void setUp() {
    MockitoAnnotations.initMocks(this);
  }


  @Test
  public void shouldThrowExceptionTestOne() {
    Mockito.when(object.getMessageTemplate()).thenReturn("test error message template");
    violations.add(object);
    Mockito.when(config.getValue(ArgumentMatchers.any(), ArgumentMatchers.any()))
        .thenThrow(new RuntimeException());
    Mockito.when(validator.validate(ArgumentMatchers.any())).thenReturn(violations);
    Assertions.assertThrows(ApiRequestException.class,
        () -> validatorService.validateRequest(new BillPaymentRequest()));
  }

  @Test
  public void shouldThrowExceptionTestTwo() {
    Mockito.when(object.getMessageTemplate()).thenReturn("test error message template");
    violations.add(object);
    Mockito.when(config.getValue(ArgumentMatchers.any(), ArgumentMatchers.any()))
        .thenReturn("test error message");
    Mockito.when(validator.validate(ArgumentMatchers.any())).thenReturn(violations);
    Assertions.assertThrows(ApiRequestException.class,
        () -> validatorService.validateRequest(new BillPaymentRequest()));
  }

  @Test
  public void shouldThrowExceptionTestThree() {
    Mockito.when(object.getMessageTemplate()).thenReturn("test error message template");
    violations.add(object);
    Mockito.when(config.getValue(ArgumentMatchers.any(), ArgumentMatchers.any()))
        .thenReturn("test error message");
    Mockito.when(validator.validate(ArgumentMatchers.any())).thenReturn(violations);
    Assertions.assertThrows(ApiRequestException.class,
        () -> validatorService.validateRequest(new BillPaymentRequest()));
  }


  @Test
  public void shouldNotThrowException() {
    validatorService.validateRequest(getValidReqPayload());
  }

  public BillPaymentRequest getValidReqPayload() {
    BillPaymentRequest request = new BillPaymentRequest();
    request.setAccountId("1234567890");
    request.setBillNo(125694);
    request.setAccountCurrencyRate((float) 12569.00);
    request.setBillerType('n');
    request.setConsumerNo("aaaa");
    request.setPaymentDueDate("05/07/2020");
    request.setNarrative("aaaaaaa");
    request.setPrimaryReferenceNo("ssss");
    request.setSecondaryReferenceNo("yyyyyy");
    request.setServiceChargeCode(1589745612);
    request.setTransactionType(1);
    request.setUtilityCompanyId(123);

    ApiRequestHeader apiRequestHeader = new ApiRequestHeader();
    apiRequestHeader.setBusinessId("MB");
    apiRequestHeader.setSystemId("KBBRB");
    apiRequestHeader.setCountryCode("KE");
    apiRequestHeader.setCorrelationId("1122334455");
    request.setApiRequestHeader(apiRequestHeader);

    return request;
  }

}
