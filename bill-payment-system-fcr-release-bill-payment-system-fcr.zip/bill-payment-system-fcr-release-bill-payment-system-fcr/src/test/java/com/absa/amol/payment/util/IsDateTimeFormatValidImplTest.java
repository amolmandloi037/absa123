package com.absa.amol.payment.util;

import java.text.ParseException;
import javax.validation.ConstraintValidatorContext;
import org.apache.camel.Message;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import com.absa.amol.common.model.ApiRequestHeader;
import com.absa.amol.payment.model.BillPaymentRequest;

class IsDateTimeFormatValidImplTest {
  @InjectMocks
  IsDateTimeFormatValidImpl isDateTimeFormatValidImpl;

  @Mock
  ConstraintValidatorContext consValid;

  @Mock
  private Message inMsg;

  @Mock
  BillPaymentRequest billPaymentRequest;

  @BeforeEach
  public void init() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  public void isNullTest() {
    BillPaymentRequest billPaymentRequest = new BillPaymentRequest();
    billPaymentRequest.setPaymentDueDate(null);
    Boolean flag = false;
    flag = isDateTimeFormatValidImpl.isValid(billPaymentRequest.getPaymentDueDate(), consValid);
    Assertions.assertEquals(true, flag);
  }

  @Test
  public void isDateValid_NullTest() {
    BillPaymentRequest billPaymentRequest = getReqWithoutDateValueStub();
    Boolean flag = false;
    flag = isDateTimeFormatValidImpl.isValid(billPaymentRequest.getPaymentDueDate(), consValid);
    Assertions.assertEquals(true, flag);
  }

  // @Test
  // public void isDateValid_NotNullTest() {
  // BillPaymentRequest billPaymentRequest = getReqStub();
  // Boolean flag = false;
  // flag = isDateTimeFormatValidImpl.isValid(billPaymentRequest.getPaymentDueDate(), consValid);
  // Assertions.assertEquals(true, flag);
  // }


  @Test
  public void DateInvalidTest() throws ParseException {
    BillPaymentRequest billPaymentRequest = new BillPaymentRequest();
    billPaymentRequest.setPaymentDueDate("MM");
    Boolean flag = true;
    flag = isDateTimeFormatValidImpl.isValid(billPaymentRequest.getPaymentDueDate(), consValid);
    Assertions.assertEquals(false, flag);
  }

  // @Test
  // public void DateValidTest() throws ParseException {
  // BillPaymentRequest billPaymentRequest = new BillPaymentRequest();
  // billPaymentRequest.setPaymentDueDate("20200101");
  // Boolean flag = true;
  // flag = isDateTimeFormatValidImpl.isValid(billPaymentRequest.getPaymentDueDate(), consValid);
  // Assertions.assertEquals(true, flag);
  // }

  public BillPaymentRequest getReqStub() {
    BillPaymentRequest request = new BillPaymentRequest();
    request.setAccountId("1234567890");
    request.setUtilityCompanyId(0);
    request.setBillNo(0);
    request.setConsumerNo("256759990542");
    request.setNarrative("Test ADD");
    request.setPaymentDueDate("20230502");
    request.setPrimaryReferenceNo("0");
    request.setSecondaryReferenceNo("0");
    request.setTransactionType(0);
    request.setUserReferenceNo("0");
    request.setUtilityCompanyId(38);
    ApiRequestHeader apiRequestHeader = new ApiRequestHeader();
    apiRequestHeader.setBusinessId("MB");
    apiRequestHeader.setSystemId("KBBRB");
    apiRequestHeader.setCountryCode("KE");
    apiRequestHeader.setCorrelationId("1122334455");
    request.setApiRequestHeader(apiRequestHeader);

    return request;
  }

  public BillPaymentRequest getReqWithoutDateValueStub() {
    BillPaymentRequest request = new BillPaymentRequest();
    request.setAccountId("1234567890");
    request.setUtilityCompanyId(0);
    request.setBillNo(0);
    request.setConsumerNo("256759990542");
    request.setNarrative("Test ADD");
    request.setPrimaryReferenceNo("0");
    request.setSecondaryReferenceNo("0");
    request.setTransactionType(0);
    request.setUserReferenceNo("0");
    request.setUtilityCompanyId(38);
    ApiRequestHeader apiRequestHeader = new ApiRequestHeader();
    apiRequestHeader.setBusinessId("MB");
    apiRequestHeader.setSystemId("KBBRB");
    apiRequestHeader.setCountryCode("KE");
    apiRequestHeader.setCorrelationId("1122334455");
    request.setApiRequestHeader(apiRequestHeader);

    return request;
  }



}
