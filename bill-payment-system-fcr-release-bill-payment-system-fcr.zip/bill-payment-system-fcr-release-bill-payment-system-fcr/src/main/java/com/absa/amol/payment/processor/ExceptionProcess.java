package com.absa.amol.payment.processor;

import org.apache.camel.Exchange;
import org.apache.camel.ExchangeTimedOutException;
import org.apache.camel.Processor;
import com.absa.amol.common.exception.ApiRequestException;
import com.absa.amol.common.exception.ApiResponseException;
import com.absa.amol.common.exception.GlobalException;
import com.absa.amol.common.logging.Logger;
import com.absa.amol.common.logging.LoggerFactory;
import com.absa.amol.common.model.ResponseEntity;
import com.absa.amol.payment.model.BillPaymentRequest;
import com.absa.amol.payment.model.BillPaymentResponse;
import com.absa.amol.payment.util.BillPaymentConstant;
import com.iflex.fcr.app.bill.spi.FatalException;

public class ExceptionProcess implements Processor {
  Logger logger = LoggerFactory.getLogger(ExceptionProcess.class);

  @Override
  public void process(Exchange exchange) throws Exception {
    ResponseEntity<BillPaymentResponse> billPaymentRespoEntity = null;
    Throwable caused = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class);
    String correlationId = "";
    try {
      BillPaymentRequest billPaymentRequest =
          (BillPaymentRequest) exchange.getProperty("billPaymentRequest");
      correlationId = billPaymentRequest.getApiRequestHeader().getCorrelationId();
    } catch (Exception e) {
      correlationId = "";
    }

    if (caused instanceof ApiRequestException) {

      ApiRequestException apiReqException = (ApiRequestException) caused;
      billPaymentRespoEntity = new ResponseEntity<>(BillPaymentConstant.BAD_REQUEST_CODE,
          apiReqException.getErrorMessage(), BillPaymentConstant.FAILURE_MSG, null);
      exchange.getOut().setBody(billPaymentRespoEntity);
      logger.error(BillPaymentConstant.CONFIGURE, correlationId,
          "In Exception Route handler:ApiRequestException Caught",
          apiReqException.getErrorMessage());
    } else if (caused instanceof ApiResponseException) {
      ApiResponseException apiRespException = (ApiResponseException) caused;
      billPaymentRespoEntity = new ResponseEntity<>(BillPaymentConstant.BAD_REQUEST_CODE,
          apiRespException.getErrorMessage(), BillPaymentConstant.FAILURE_MSG, null);
      exchange.getOut().setBody(billPaymentRespoEntity);
      logger.error(BillPaymentConstant.CONFIGURE, correlationId,
          "In Exception Route handler:ApiResponseException Caught",
          apiRespException.getErrorMessage());
    } else if (caused instanceof GlobalException) {
      GlobalException gloException = (GlobalException) caused;
      billPaymentRespoEntity = new ResponseEntity<>(BillPaymentConstant.BAD_REQUEST_CODE,
          gloException.getErrorMessage(), BillPaymentConstant.FAILURE_MSG, null);
      exchange.getOut().setBody(billPaymentRespoEntity);
      logger.error(BillPaymentConstant.CONFIGURE, correlationId,
          "In Exception Route handler:GlobalException Caught", gloException.getErrorMessage());
    } else if (caused instanceof ExchangeTimedOutException) {
      ExchangeTimedOutException timeoutExce = (ExchangeTimedOutException) caused;
      billPaymentRespoEntity = new ResponseEntity<>(BillPaymentConstant.ERROR_CODE,
          timeoutExce.getMessage(), BillPaymentConstant.FAILURE_MSG, null);
      exchange.getOut().setBody(billPaymentRespoEntity);
      logger.error(BillPaymentConstant.CONFIGURE, correlationId,
          "In Exception Route handler:ExchangeTimedOutException Caught", timeoutExce.getMessage());
    } else if (caused instanceof FatalException) {
      FatalException fatalException = (FatalException) caused;
      if (fatalException.getMessage().contains(BillPaymentConstant.NO_BILL_PAY_ERR)) {
        billPaymentRespoEntity = new ResponseEntity<>(BillPaymentConstant.SUCCESS_CODE,
            BillPaymentConstant.NO_RECORD_FOUND, BillPaymentConstant.SUCCESS_MSG, null);
      } else {
        String errMsg =
            fatalException.getMessage() + fatalException.getFaultInfo().getReason().getMessage();
        billPaymentRespoEntity = new ResponseEntity<>(BillPaymentConstant.ERROR_CODE, errMsg,
            BillPaymentConstant.FAILURE_MSG, null);
      }
      logger.error(BillPaymentConstant.CONFIGURE, correlationId,
          "In Exception Route handler:FatalException Caught", fatalException.getMessage());
      exchange.getOut().setBody(billPaymentRespoEntity);
    } else if (caused instanceof Exception) {
      logger.error(BillPaymentConstant.CONFIGURE, correlationId,
          "In Exception Route handler :Exception Caught", caused.getMessage());

      billPaymentRespoEntity = new ResponseEntity<>(BillPaymentConstant.ERROR_CODE,
          "Internal Server Error", BillPaymentConstant.FAILURE_MSG, null);
      exchange.getOut().setBody(billPaymentRespoEntity);
    }
  }

}
