package com.absa.amol.payment.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import com.absa.amol.common.model.ResponseEntity;
import com.absa.amol.payment.model.BillPaymentResponse;
import com.absa.amol.payment.util.BillPaymentConstant;

public class GenericReponseProcess implements Processor {

  public void process(Exchange exchange) throws Exception {

    BillPaymentResponse billPaymentResponse = exchange.getIn().getBody(BillPaymentResponse.class);
    String message = BillPaymentConstant.NO_RECORD_FOUND;
    if (billPaymentResponse != null) {
      message = "";
    }
    ResponseEntity<BillPaymentResponse> billPaymentResponseEntity =
        new ResponseEntity<>(BillPaymentConstant.SUCCESS_CODE, message,
            BillPaymentConstant.SUCCESS_MSG, billPaymentResponse);

    exchange.getIn().setBody(billPaymentResponseEntity, ResponseEntity.class);
  }
}
