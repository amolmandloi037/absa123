package com.absa.amol.payment.config;


import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import org.eclipse.microprofile.config.spi.ConfigSource;
import com.absa.amol.common.logging.Logger;
import com.absa.amol.common.logging.LoggerFactory;

public class FileSystemConfigSource implements ConfigSource {
  private static final Logger LOGGER = LoggerFactory.getLogger(FileSystemConfigSource.class);

  private static final String CONFIG_SOURCE_NAME = "FileSystemConfigSource";
  private static final String EMPTY = "";
  private Map<String, String> custmap = new HashMap<>();

  public FileSystemConfigSource() {

    Properties properties = new Properties();
    String path = System.getProperty("properties.path");
    LOGGER.debug(CONFIG_SOURCE_NAME, EMPTY, "properties path", path);
    try (FileInputStream fileInputStream = new FileInputStream(new File(path))) {
      properties.load(fileInputStream);
      properties.forEach((k, v) -> custmap.put(String.valueOf(k), String.valueOf(v)));
    } catch (Exception e) {
      LOGGER.error(CONFIG_SOURCE_NAME, EMPTY, "Exception", e.getMessage());
      LOGGER.debug(CONFIG_SOURCE_NAME, EMPTY, "Detailed Exception : ", e);
    }
  }

  @Override
  public Map<String, String> getProperties() {
    return custmap;
  }

  @Override
  public String getValue(String s) {
    return custmap.get(s);
  }

  @Override
  public String getName() {
    return CONFIG_SOURCE_NAME;
  }

}
