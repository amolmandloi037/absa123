package com.absa.amol.payment.service.impl;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.core.Response;
import org.apache.camel.ProducerTemplate;
import com.absa.amol.common.exception.ApiRequestException;
import com.absa.amol.common.exception.ApiResponseException;
import com.absa.amol.common.exception.GlobalException;
import com.absa.amol.common.logging.Logger;
import com.absa.amol.common.logging.LoggerFactory;
import com.absa.amol.common.model.ResponseEntity;
import com.absa.amol.payment.model.BillPaymentRequest;
import com.absa.amol.payment.model.BillPaymentResponse;
import com.absa.amol.payment.service.BillPaymentService;
import com.absa.amol.payment.util.BillPaymentConstant;

@ApplicationScoped
public class BillPaymentServiceImpl implements BillPaymentService {
  Logger LOGGER = LoggerFactory.getLogger(BillPaymentServiceImpl.class);

  @Inject
  private ProducerTemplate producerTemplate;

  @Override
  public Response payUtilityBill(BillPaymentRequest billPaymentRequest) {
    ResponseEntity<BillPaymentResponse> responseEntity;
    try {
      responseEntity = producerTemplate.requestBody("direct:payUtilityBillByAccountSoapcall",
          billPaymentRequest, ResponseEntity.class);
      if (BillPaymentConstant.ERROR_CODE.equals(responseEntity.getCode())) {
        throw new GlobalException(BillPaymentConstant.ERROR_CODE, responseEntity.getMessage());
      }
      return Response.ok(responseEntity).build();
    } catch (ApiRequestException reqe) {
      LOGGER.error(BillPaymentConstant.BILL_PAYMENT_SERVICE,
          BillPaymentConstant.getCorrelationId(billPaymentRequest.getApiRequestHeader()),
          "Inside ApiRequestException", reqe.getErrorMessage());
      throw reqe;
    } catch (ApiResponseException rese) {
      LOGGER.error(BillPaymentConstant.BILL_PAYMENT_SERVICE,
          BillPaymentConstant.getCorrelationId(billPaymentRequest.getApiRequestHeader()),
          "Inside ApiResponsetException", rese.getErrorMessage());
      throw rese;
    } catch (GlobalException globEx) {
      LOGGER.error(BillPaymentConstant.BILL_PAYMENT_SERVICE,
          BillPaymentConstant.getCorrelationId(billPaymentRequest.getApiRequestHeader()),
          "Inside ApiResponsetException", globEx.getErrorMessage());
      throw globEx;
    } catch (Exception e) {
      LOGGER.error(BillPaymentConstant.BILL_PAYMENT_SERVICE,
          BillPaymentConstant.getCorrelationId(billPaymentRequest.getApiRequestHeader()),
          "inside Exception", e.getMessage());
      throw new GlobalException(BillPaymentConstant.ERROR_CODE, "Internal Server Error");
    }
  }
}
