package com.absa.amol.payment.model;

import java.util.List;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Schema(name = "Status", description = "Represent Status")


public class Status {
  private String errorCode;
  private ExtendedReply extendedReply;
  private String externalReferenceNo;
  private String inputOverridenWarnings;
  private Boolean isOverriden;
  private Boolean isServiceChargeApplied;
  private String memo;
  private long replyCode;
  private String replyText;
  private long spReturnValue;
  private String transactionDateTimeText;
  private String userReferenceNumber;
  private List<ValidationErrors> validationErrors;
}
