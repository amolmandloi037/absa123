package com.absa.amol.payment.processor;

import java.util.ArrayList;
import java.util.List;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import com.absa.amol.common.logging.Logger;
import com.absa.amol.common.logging.LoggerFactory;
import com.absa.amol.common.util.CommonUtil;
import com.absa.amol.payment.model.BillPaymentRequest;
import com.absa.amol.payment.model.BillPaymentResponse;
import com.absa.amol.payment.model.ExtendedReply;
import com.absa.amol.payment.model.Message;
import com.absa.amol.payment.model.Status;
import com.absa.amol.payment.model.TnsReplyMessage;
import com.absa.amol.payment.model.ValidationErrors;
import com.absa.amol.payment.util.BillPaymentConstant;
import com.iflex.fcr.app.bill.spi.dto.PayUtilityBillByAccountResponse;
import com.iflex.fcr.infra.exception.ReplyMessage;
import com.iflex.fcr.infra.validation.error.ValidationError;



public class PaymentResponseProcess implements Processor {
  private static final Logger LOGGER = LoggerFactory.getLogger(PaymentResponseProcess.class);

  @Override
  public void process(Exchange exchange) throws Exception {
    BillPaymentRequest domainRequest =
        exchange.getProperty("billPaymentRequest", BillPaymentRequest.class);
    PayUtilityBillByAccountResponse fcrResponse =
        exchange.getIn().getBody(PayUtilityBillByAccountResponse.class);
    LOGGER.info("process",
        BillPaymentConstant.getCorrelationId(domainRequest.getApiRequestHeader()),
        "response processing:", "Mapping FCR response To Domain Response.");

    BillPaymentResponse res = new BillPaymentResponse();
    Status status = new Status();
    ExtendedReply extendedReply = new ExtendedReply();
    TnsReplyMessage tnsReplyMessage = new TnsReplyMessage();
    List<ValidationErrors> validationErrors = new ArrayList<>();
    List<Message> list = new ArrayList<>();
    status.setErrorCode(fcrResponse.getStatus().getErrorCode());
    if (CommonUtil.isNotNull(fcrResponse.getStatus().getExtendedReply().getMessages()) && CommonUtil
        .isNotNull(fcrResponse.getStatus().getExtendedReply().getMessages().getItem())) {
      for (ReplyMessage msg : fcrResponse.getStatus().getExtendedReply().getMessages().getItem()) {
        Message replyMessage = new Message();
        replyMessage.setCode(msg.getCode());
        replyMessage.setMsg(msg.getMessage());
        list.add(replyMessage);
      }
    }
    tnsReplyMessage.setItem(list);
    extendedReply.setMessages(tnsReplyMessage);
    status.setExtendedReply(extendedReply);

    if (CommonUtil.isNotNull(fcrResponse.getStatus().getValidationErrors())
        && CommonUtil.isNotNull(fcrResponse.getStatus().getValidationErrors().getItem())) {
      for (ValidationError errorItem : fcrResponse.getStatus().getValidationErrors().getItem()) {
        ValidationErrors error = new ValidationErrors();
        error.setApplicableAttributes(errorItem.getApplicableAttributes());
        error.setAttributeName(errorItem.getAttributeName());
        error.setAttributeValue(errorItem.getAttributeValue());
        error.setErrorCode(errorItem.getErrorCode());
        error.setErrorMessage(errorItem.getErrorMessage());
        error.setMethodName(errorItem.getMethodName());
        error.setObjectName(errorItem.getObjectName());
        validationErrors.add(error);
      }
    }
    status.setValidationErrors(validationErrors);

    status.setExternalReferenceNo(fcrResponse.getStatus().getExternalReferenceNo());
    status.setInputOverridenWarnings(fcrResponse.getStatus().getInputOverridenWarnings());
    status.setIsOverriden(fcrResponse.getStatus().isIsOverriden());
    status.setIsServiceChargeApplied(fcrResponse.getStatus().isIsServiceChargeApplied());
    status.setReplyCode(fcrResponse.getStatus().getReplyCode());
    status.setReplyText(fcrResponse.getStatus().getReplyText());
    status.setSpReturnValue(fcrResponse.getStatus().getSpReturnValue());
    status.setTransactionDateTimeText(fcrResponse.getStatus().getTransactionDateTimeText());

    res.setStatus(status);
    res.setAvailableBalance(fcrResponse.getAvailableBalance());

    exchange.getIn().setBody(res);
  }

}
