package com.absa.amol.payment.model;

import javax.json.bind.annotation.JsonbProperty;
import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.ws.rs.BeanParam;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import com.absa.amol.common.model.ApiRequestHeader;
import com.absa.amol.payment.util.IsDateTimeFormatValid;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Schema(name = "BillPaymentRequest", description = "Represent Bill Payment Request")
public class BillPaymentRequest {
  // @Valid
  // @BeanParam
  // private SessionContext sessionContext;

  @JsonbProperty(value = "paymentDueDate")
  @Schema(nullable = false, required = true,
      description = "Bill payment due date. Date should be in 'yyyyMMdd' format")
  @NotEmpty(message = "paymentDueDate.null")
  @IsDateTimeFormatValid(format = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", message = "paymentDueDate.format")
  private String paymentDueDate;


  @JsonbProperty(value = "billAmount")
  @Valid
  private BillAmount billAmount;

  @JsonbProperty(value = "utilityCompanyId")
  @NotNull(message = "utilityCompanyId.noempty.error.message")
  @Digits(integer = 5, fraction = 0, message = "utilityCompanyId.error.message")
  private Integer utilityCompanyId;

  @JsonbProperty(value = "billNo")
  @NotNull(message = "billNo.noempty.error.message")
  @Digits(integer = 40, fraction = 0, message = "billNo.length.error.message")
  private Integer billNo;

  @JsonbProperty(value = "billerType")
  private char billerType;

  @JsonbProperty(value = "accountId")
  @NotNull(message = "accountId.noempty.error.message")
  @NotEmpty(message = "accountId.noempty.error.message")
  @Pattern(regexp = "^[0-9]*", message = "accountId.digit.error.message")
  @Size(min = 1, max = 16, message = "accountId.length.error.message")
  private String accountId;

  @JsonbProperty(value = "consumerNo")
  @NotNull(message = "consumerNo.noempty.error.message")
  @NotEmpty(message = "consumerNo.noempty.error.message")
  @Size(min = 1, max = 40, message = "consumerNo.length.error.message")
  private String consumerNo;

  @JsonbProperty(value = "accountCurrencyRate")
  @NotNull(message = "accountCurrencyRate.noempty.error.message")
  @Digits(integer = 3, fraction = 0, message = "accountCurrencyRate.length.error.message")
  private Float accountCurrencyRate;

  @JsonbProperty(value = "primaryReferenceNo")
  @Size(min = 0, max = 40, message = "primaryReferenceNo.length.error.message")
  private String primaryReferenceNo;

  @JsonbProperty(value = "secondaryReferenceNo")
  @Size(min = 0, max = 40, message = "secondaryReferenceNo.length.error.message")
  private String secondaryReferenceNo;

  @JsonbProperty(value = "userReferenceNo")
  @Size(min = 0, max = 40, message = "userReferenceNo.length.error.message")
  private String userReferenceNo;

  @JsonbProperty(value = "serviceChargeRequest")
  private ServiceChargeReq serviceChargeRequest;

  @JsonbProperty(value = "narrative")
  @Size(min = 0, max = 40, message = "narrative.length.error.message")
  private String narrative;

  @JsonbProperty(value = "usrNarrative")
  @Size(min = 0, max = 40, message = "usrNarrative.length.error.message")
  private String usrNarrative;

  @JsonbProperty(value = "transactionType")
  @NotNull(message = "transactionType.noempty.error.message")
  @Digits(integer = 1, fraction = 0, message = "transactionType.length.error.message")
  private Integer transactionType;

  @JsonbProperty(value = "serviceChargeCode")
  @Digits(integer = 1, fraction = 0, message = "serviceChargeCode.digit.error.message")
  private long serviceChargeCode;

  @JsonbProperty(value = "originalTransactionReference")
  @Pattern(regexp = "^[0-9]*", message = "originalTransactionReference.digit.message")
  @Size(min = 10, max = 40, message = "originalTransactionReference.length.message")
  private String originalTransactionReference;

  @BeanParam
  @Schema(hidden = true)
  @Valid
  private ApiRequestHeader apiRequestHeader;

}
