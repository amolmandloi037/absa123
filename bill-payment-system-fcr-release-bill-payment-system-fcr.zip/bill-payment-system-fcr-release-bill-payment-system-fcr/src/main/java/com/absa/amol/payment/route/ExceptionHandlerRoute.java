package com.absa.amol.payment.route;

import org.apache.camel.builder.RouteBuilder;
import com.absa.amol.common.logging.Logger;
import com.absa.amol.common.logging.LoggerFactory;

public class ExceptionHandlerRoute extends RouteBuilder {
  Logger logger = LoggerFactory.getLogger(ExceptionHandlerRoute.class);

  public void configure() throws Exception {
    from("direct:ExceptionHandler").process(new com.absa.amol.payment.processor.ExceptionProcess());
  }
}
