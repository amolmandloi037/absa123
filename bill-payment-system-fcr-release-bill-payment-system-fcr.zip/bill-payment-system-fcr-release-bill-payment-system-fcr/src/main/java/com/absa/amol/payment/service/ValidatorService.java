package com.absa.amol.payment.service;

import com.absa.amol.payment.model.BillPaymentRequest;

public interface ValidatorService {
  public void validateRequest(BillPaymentRequest billPaymentRequest);
}
