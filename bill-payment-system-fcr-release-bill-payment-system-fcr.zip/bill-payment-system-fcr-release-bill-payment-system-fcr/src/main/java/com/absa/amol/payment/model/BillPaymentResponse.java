package com.absa.amol.payment.model;

import java.math.BigDecimal;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Schema(name = "BillPaymentResponse", description = "Represent Bill Payment Response")
public class BillPaymentResponse {
  private Status status;
  private BigDecimal availableBalance;
}
