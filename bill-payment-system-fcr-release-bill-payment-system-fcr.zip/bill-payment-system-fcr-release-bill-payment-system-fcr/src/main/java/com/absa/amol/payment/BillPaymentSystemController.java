package com.absa.amol.payment;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.eclipse.microprofile.faulttolerance.Fallback;
import org.eclipse.microprofile.faulttolerance.Timeout;
import org.eclipse.microprofile.faulttolerance.exceptions.TimeoutException;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponses;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;
import com.absa.amol.common.logging.Logger;
import com.absa.amol.common.logging.LoggerFactory;
import com.absa.amol.common.model.ApiRequestHeader;
import com.absa.amol.common.model.ResponseEntity;
import com.absa.amol.payment.model.BillPaymentRequest;
import com.absa.amol.payment.service.BillPaymentService;
import com.absa.amol.payment.service.impl.ValidatorServiceImpl;
import com.absa.amol.payment.util.BillPaymentConstant;

@Path("/payment-initiation/payment-initiation-transaction/beneficiary-payment")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Tag(name = " Bill Payment FCR - OpenAPI Resources")
@ApplicationScoped
public class BillPaymentSystemController {
  private static final Logger LOGGER = LoggerFactory.getLogger(BillPaymentSystemController.class);
  @Inject
  private ValidatorServiceImpl validatorService;
  @Inject
  private BillPaymentService billPaymentService;

  @POST
  @Path("/retail/initiation")
  @Timeout(BillPaymentConstant.FALLBACK_TIMEOUT)
  @Fallback(fallbackMethod = BillPaymentConstant.FALLBACK_METHOD_FOR_TIMEOUT,
      applyOn = {TimeoutException.class})
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @APIResponses(value = {
      @APIResponse(name = "ok", responseCode = "200", description = "Get customer details.",
          content = @Content(mediaType = "application/json")),
      @APIResponse(responseCode = "404", description = "not found."),
      @APIResponse(responseCode = "500", description = "Internal server error.")})
  @Operation(summary = "Bill Payment System FCR", description = "Bill Payment System FCR")
  public Response payUtilityBillByAccount(BillPaymentRequest request,
      @BeanParam ApiRequestHeader apiRequestHeader) {
    request.setApiRequestHeader(apiRequestHeader);
    LOGGER.info("payUtilityBillByAccount", "", "Inside Controller", "Request Start");
    validatorService.validateRequest(request);
    return billPaymentService.payUtilityBill(request);
  }

  public Response fallbackForTimeout(BillPaymentRequest request,
      ApiRequestHeader apiRequestHeader) {
    LOGGER.info(BillPaymentConstant.FALLBACK_METHOD_FOR_TIMEOUT,
        ValidatorServiceImpl.getCorrelationId(request.getApiRequestHeader()),
        "Fallback method after waiting milliseconds!=",
        String.valueOf(BillPaymentConstant.FALLBACK_TIMEOUT));
    ResponseEntity<String> responseEntity = new ResponseEntity<>(BillPaymentConstant.TIMEOUT_CODE,
        "Gateway Timeout ", BillPaymentConstant.FAILURE_MSG, null);
    return Response.status(504).entity(responseEntity).build();
  }


}
