package com.absa.amol.payment.processor;

import static com.absa.amol.common.util.StringUtil.isStringNotNullAndNotEmpty;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.eclipse.microprofile.config.Config;
import org.eclipse.microprofile.config.ConfigProvider;
import com.absa.amol.common.logging.Logger;
import com.absa.amol.common.logging.LoggerFactory;
import com.absa.amol.common.util.CommonUtil;
import com.absa.amol.payment.model.BillPaymentRequest;
import com.absa.amol.payment.util.BillPaymentConstant;
import com.iflex.fcr.app.charge.ServiceChargeRequest;
import com.iflex.fcr.app.context.SessionContext;
import com.iflex.fcr.entity.global.dto.CurrencyAmountDTO;

public class PaymentRequestProcess implements Processor {

  private static final Logger LOGGER = LoggerFactory.getLogger(PaymentRequestProcess.class);

  @Override
  public void process(Exchange exchange) throws Exception {
    BillPaymentRequest domainRequest = exchange.getIn().getBody(BillPaymentRequest.class);

    LOGGER.info("process",
        BillPaymentConstant.getCorrelationId(domainRequest.getApiRequestHeader()),
        "request processing:", "Mapping Domain Request To FCR Request.");
    Map<String, String> billPayPropertyMap = getFCRPropertyMap();

    exchange.getIn().setBody(getFCRParamList(billPayPropertyMap, domainRequest));

  }

  public List<Object> getFCRParamList(Map<String, String> billPayPropertyMap,
      BillPaymentRequest domainRequest) throws ParseException {
    SessionContext sessionContext = new SessionContext();
    sessionContext.setBankCode(
        isStringNotNullAndNotEmpty(billPayPropertyMap.get(BillPaymentConstant.BANK_CODE))
            ? Integer.parseInt(billPayPropertyMap.get(BillPaymentConstant.BANK_CODE))
            : 0);
    sessionContext.setChannel(domainRequest.getApiRequestHeader().getSystemId());
    sessionContext.setExternalBatchNumber(isStringNotNullAndNotEmpty(
        billPayPropertyMap.get(BillPaymentConstant.EXTERNAL_BATCH_NUMBER))
            ? Long.parseLong(billPayPropertyMap.get(BillPaymentConstant.EXTERNAL_BATCH_NUMBER))
            : 0);
    sessionContext.setTransactionBranch(
        isStringNotNullAndNotEmpty(billPayPropertyMap.get(BillPaymentConstant.TRANS_BRANCH))
            ? Integer.parseInt(billPayPropertyMap.get(BillPaymentConstant.TRANS_BRANCH))
            : 0);
    sessionContext.setExternalSystemAuditTrailNumber(isStringNotNullAndNotEmpty(
        billPayPropertyMap.get(BillPaymentConstant.EXTERNAL_SYSTEM_AUDIT_TRAIL_NUMBER))
            ? Long.parseLong(
                billPayPropertyMap.get(BillPaymentConstant.EXTERNAL_SYSTEM_AUDIT_TRAIL_NUMBER))
            : 0);
    sessionContext.setUserId(billPayPropertyMap.get(BillPaymentConstant.USERID));
    sessionContext.setOriginalReferenceNo(domainRequest.getOriginalTransactionReference());

    CurrencyAmountDTO currencyAmountDTO = new CurrencyAmountDTO();
    currencyAmountDTO.setCurrencyCode(domainRequest.getBillAmount().getCurrencyCode());
    currencyAmountDTO.setMonetaryValue(domainRequest.getBillAmount().getMonetaryValue());

    ServiceChargeRequest serviceChargeRequest = new ServiceChargeRequest();
    if (CommonUtil.isNotNull(domainRequest.getServiceChargeRequest())) {
      serviceChargeRequest.setIsServiceChargeApplicable(
          domainRequest.getServiceChargeRequest().isServiceChargeApplicable());
    }

    List<Object> fcrParams = new ArrayList<>();
    fcrParams.add(sessionContext);
    fcrParams.add(domainRequest.getUtilityCompanyId());
    fcrParams.add(String.valueOf(domainRequest.getBillNo()));
    fcrParams.add(domainRequest.getAccountId());
    fcrParams.add(domainRequest.getConsumerNo());
    fcrParams.add(BillPaymentConstant.formatDate(domainRequest.getPaymentDueDate()));
    fcrParams.add(currencyAmountDTO);
    fcrParams.add(domainRequest.getAccountCurrencyRate());
    fcrParams.add(domainRequest.getPrimaryReferenceNo());
    fcrParams.add(domainRequest.getSecondaryReferenceNo());
    fcrParams.add(domainRequest.getUserReferenceNo());
    fcrParams.add(serviceChargeRequest);
    fcrParams.add(domainRequest.getNarrative());
    fcrParams.add(domainRequest.getTransactionType());
    fcrParams.add(domainRequest.getServiceChargeCode());
    return fcrParams;
  }

  private Map<String, String> getFCRPropertyMap() {

    Map<String, String> billPayPropertyMap = new HashMap<>();
    billPayPropertyMap.put(BillPaymentConstant.BANK_CODE, getPropertyValue("bankcode"));
    billPayPropertyMap.put(BillPaymentConstant.TRANS_BRANCH, getPropertyValue("transbranch"));
    billPayPropertyMap.put(BillPaymentConstant.EXTERNAL_BATCH_NUMBER,
        getPropertyValue("externalbatchnumber"));
    billPayPropertyMap.put(BillPaymentConstant.EXTERNAL_SYSTEM_AUDIT_TRAIL_NUMBER,
        getPropertyValue("externalsystemaudittrailnumber"));
    billPayPropertyMap.put(BillPaymentConstant.USERID,
        getPropertyValue(BillPaymentConstant.USERID));
    return billPayPropertyMap;
  }

  private String getPropertyValue(String confKey) {
    Config config = ConfigProvider.getConfig();
    LOGGER.infoCustom("getPropertyValue ::{}", confKey);
    try {
      return config.getValue(confKey, String.class);
    } catch (Exception e) {
      LOGGER.error("getPropertyValue", "",
          "Exception while reading property for the key ::" + confKey, e.getMessage());
    }
    return "";
  }

}
