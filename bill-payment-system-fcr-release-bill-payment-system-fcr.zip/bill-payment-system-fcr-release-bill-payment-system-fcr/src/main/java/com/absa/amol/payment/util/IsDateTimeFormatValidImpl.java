package com.absa.amol.payment.util;

import static com.absa.amol.common.util.StringUtil.isStringNullOrEmpty;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.absa.amol.common.logging.Logger;
import com.absa.amol.common.logging.LoggerFactory;

public class IsDateTimeFormatValidImpl implements ConstraintValidator<IsDateTimeFormatValid, String> {
	private static final Logger LOGGER = LoggerFactory.getLogger(IsDateTimeFormatValidImpl.class);
	private String dateFormat="";
	@Override
	public void initialize(IsDateTimeFormatValid constraintAnnotation) {
		this.dateFormat=constraintAnnotation.format();
	}
	
	@Override
	public boolean isValid(String data, ConstraintValidatorContext constraintValidatorContext) {
		 try {
			 if(isStringNullOrEmpty(data)) {
			    	return true;
			    }
		    	SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dateFormat);
		    	Date date=simpleDateFormat.parse(data);
		    	return data.equals(simpleDateFormat.format(date));
		    } catch (ParseException e) {
		    	LOGGER.debug("isValid", "", "Exception in date parse", e.getMessage());	
		    	LOGGER.error("isValid", "", "Exception in date parse", e);	
		      return false;
		    }
	}

}
