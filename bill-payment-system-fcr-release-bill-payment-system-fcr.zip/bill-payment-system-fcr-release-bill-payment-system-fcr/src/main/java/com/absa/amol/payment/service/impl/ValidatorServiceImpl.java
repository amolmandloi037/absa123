package com.absa.amol.payment.service.impl;

import static com.absa.amol.common.util.CommonUtil.isNotNull;
import java.util.Set;
import java.util.stream.Collectors;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import org.eclipse.microprofile.config.Config;
import com.absa.amol.common.exception.ApiRequestException;
import com.absa.amol.common.logging.Logger;
import com.absa.amol.common.logging.LoggerFactory;
import com.absa.amol.common.model.ApiRequestHeader;
import com.absa.amol.common.util.StringUtil;
import com.absa.amol.payment.model.BillPaymentRequest;
import com.absa.amol.payment.service.ValidatorService;
import com.absa.amol.payment.util.BillPaymentConstant;

@ApplicationScoped
public class ValidatorServiceImpl implements ValidatorService {
  private static final String VALIDATE_REQUEST = "validateRequest";
  @Inject
  private Validator validator;

  @Inject
  Config config;

  private static final Logger LOGGER = LoggerFactory.getLogger(ValidatorServiceImpl.class);

  @Override
  public void validateRequest(BillPaymentRequest billPaymentRequest) {


    LOGGER.info(VALIDATE_REQUEST, getCorrelationId(billPaymentRequest.getApiRequestHeader()),
        "Validating the request", "");

    Set<String> errorList = validatedAnnotedBeans(billPaymentRequest);
    customValidation(billPaymentRequest, errorList);
    if (!errorList.isEmpty()) {
      String errorMessage = String.join(",", errorList);
      ApiRequestException exception =
          new ApiRequestException(BillPaymentConstant.BAD_REQUEST_CODE, errorMessage);

      LOGGER.error(VALIDATE_REQUEST, getCorrelationId(billPaymentRequest.getApiRequestHeader()),
          "Validation failed:", exception.getErrorMessage());

      throw exception;
    }

    LOGGER.info(VALIDATE_REQUEST, getCorrelationId(billPaymentRequest.getApiRequestHeader()),
        "No validation errors found", "");

  }

  private Set<String> validatedAnnotedBeans(BillPaymentRequest billPaymentRequest) {
    Set<ConstraintViolation<BillPaymentRequest>> violations =
        validator.validate(billPaymentRequest);
    return violations.stream().map(constraint -> {
      String customErroMsg = getPropertyValue(constraint.getMessageTemplate());
      return StringUtil.isStringNullOrEmpty(customErroMsg) ? constraint.getMessage()
          : customErroMsg;
    }).collect(Collectors.toSet());
  }

  private Set<String> customValidation(BillPaymentRequest billPaymentRequest, Set<String> errors) {
    if (billPaymentRequest.getBillerType() == 'C'
        && (StringUtil.isStringNullOrEmpty(billPaymentRequest.getPrimaryReferenceNo())
            || billPaymentRequest.getPrimaryReferenceNo().trim().isEmpty())) {

      String customErroMsg = getPropertyValue("primaryReferenceNo.noempty.error.message");
      errors.add(customErroMsg);

    }
    if ((billPaymentRequest.getTransactionType() != null)
        && ((billPaymentRequest.getTransactionType().intValue() == 3)
            || (billPaymentRequest.getTransactionType().intValue() == 2))
        && (StringUtil.isStringNullOrEmpty(billPaymentRequest.getOriginalTransactionReference())
            || billPaymentRequest.getOriginalTransactionReference().trim().isEmpty())) {
      String customErroMsg = getPropertyValue("originalTransactionReference.noempty.error.message");
      errors.add(customErroMsg);
    }
    return errors;
  }

  private String getPropertyValue(String confKey) {
    try {
      return config.getValue(confKey, String.class);
    } catch (Exception e) {
      LOGGER.error("getPropertyValue", "",
          "Exception while reading property for the key ::" + confKey, e.getMessage());
    }
    return "";
  }

  public static final String getCorrelationId(ApiRequestHeader requestHeader) {
    if (isNotNull(requestHeader) && isNotNull(requestHeader.getCorrelationId())) {
      return requestHeader.getCorrelationId();
    }
    return "";
  }
}
