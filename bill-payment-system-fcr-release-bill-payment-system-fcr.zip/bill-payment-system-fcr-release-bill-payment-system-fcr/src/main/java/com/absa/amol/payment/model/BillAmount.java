package com.absa.amol.payment.model;

import java.math.BigDecimal;
import javax.json.bind.annotation.JsonbProperty;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class BillAmount {

  @JsonbProperty(value = "currencyCode")
  @NotEmpty(message = "currencyCode.noempty.error.message")
  @Size(min = 3, max = 3, message = "currencyCode.length.error.message")
  private String currencyCode;

  @JsonbProperty(value = "monetaryValue")
  @NotNull(message = "monetaryValue.noempty.error.message")
  @Digits(integer = 13, fraction = 2, message = "monetaryValue.error.message")
  private BigDecimal monetaryValue;
}
