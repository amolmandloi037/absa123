package com.absa.amol.payment.service;

import javax.ws.rs.core.Response;
import com.absa.amol.payment.model.BillPaymentRequest;

public interface BillPaymentService {
  public Response payUtilityBill(BillPaymentRequest billPaymentRequest);
}
