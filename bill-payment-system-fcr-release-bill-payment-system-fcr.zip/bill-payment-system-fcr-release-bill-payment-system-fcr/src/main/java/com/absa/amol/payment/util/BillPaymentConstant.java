package com.absa.amol.payment.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Objects;
import com.absa.amol.common.model.ApiRequestHeader;
import com.absa.amol.common.util.StringUtil;

public final class BillPaymentConstant {
  private BillPaymentConstant() {}


  public static final String SUCCESS_CODE = "200";
  public static final int SUCCESS = 200;
  public static final String BAD_REQUEST_CODE = "400";
  public static final String SUCCESS_MSG = "Success";
  public static final String ERROR_CODE = "500";
  public static final String ERROR_MSG = "ERROR";

  public static final String TIMEOUT_CODE = "504";
  public static final long FALLBACK_TIMEOUT = 10000;
  public static final String FALLBACK_METHOD_FOR_TIMEOUT = "fallbackForTimeout";
  public static final String FAILURE_MSG = "Failure";
  public static final String NO_RECORD_FOUND = "No records found";

  public static final String CONFIGURE = "configure";
  public static final String NO_BILL_PAY_ERR = "Account Id not Found";
  public static final String BILL_PAYMENT_SERVICE = "payUtilityBill";
  public static final String BANK_CODE = "bankCode";
  public static final String USERID = "userid";
  public static final String EXTERNAL_SYSTEM_AUDIT_TRAIL_NUMBER = "externalSystemAuditTrailNumber";
  public static final String EXTERNAL_BATCH_NUMBER = "externalBatchNumber";
  public static final String TRANS_BRANCH = "transBranch";

  private static final String FROM_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
  private static final String TO_DATE_FORMAT = "yyyyMMdd";

  public static final String getCorrelationId(ApiRequestHeader requestHeader) {

    if (!Objects.isNull(requestHeader) && !Objects.isNull(requestHeader.getCorrelationId())) {
      return requestHeader.getCorrelationId();
    }
    return "";
  }

  public static final String formatDate(String date) throws ParseException {
    String strDate = "";
    if (StringUtil.isStringNotNullAndNotEmpty(date)) {
      java.util.Date date1 = new SimpleDateFormat(FROM_DATE_FORMAT).parse(date);
      SimpleDateFormat formatter = new SimpleDateFormat(TO_DATE_FORMAT);
      strDate = formatter.format(date1);
    }
    return strDate;
  }

}
