
package com.absa.amol.payment.model;

import org.eclipse.microprofile.openapi.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Schema(name = "SessionContext", description = "Represent Session Context")


public class SessionContext {
  private String bankCode;
  private String channel;
  private String externalBatchNumber;
  private String externalSystemAuditTrailNumber;
  private String overridenWarnings;
  private String reasonCode;
  private String transactionBranch;
  private String userId;
  private String userReferenceNumber;
}
