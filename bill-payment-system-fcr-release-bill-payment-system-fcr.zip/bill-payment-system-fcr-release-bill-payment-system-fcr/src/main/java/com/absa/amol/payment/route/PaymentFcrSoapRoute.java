package com.absa.amol.payment.route;

import javax.inject.Inject;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.eclipse.microprofile.config.Config;
import com.absa.amol.common.exception.ApiException;
import com.absa.amol.payment.processor.GenericReponseProcess;
import com.absa.amol.payment.processor.PaymentRequestProcess;
import com.absa.amol.payment.processor.PaymentResponseProcess;
import com.iflex.fcr.app.bill.spi.BillPaymentManagerSpi;

public class PaymentFcrSoapRoute extends RouteBuilder {

  @Inject
  private Config config;

  @Override
  public void configure() {
    onException(ApiException.class).handled(true).to("direct:ExceptionHandler").end();
    onException(com.iflex.fcr.app.bill.spi.FatalException.class).handled(true)
        .to("direct:ExceptionHandler").end();

    from("direct:payUtilityBillByAccountSoapcall").setProperty("billPaymentRequest", body())
        .process(new PaymentRequestProcess())
        .setHeader(CxfConstants.OPERATION_NAME,
            constant(config.getValue("operation.name", String.class)))
        .setHeader(CxfConstants.OPERATION_NAMESPACE,
            constant(config.getValue("operation.namespace", String.class)))
        .to("cxf://" + config.getValue("endpoint", String.class) + "?serviceClass="
            + BillPaymentManagerSpi.class.getName() + "&synchronous=true&wsdlURL="
            + config.getValue("WSDL_URL", String.class))
        .process(new PaymentResponseProcess()).process(new GenericReponseProcess());
  }

}
