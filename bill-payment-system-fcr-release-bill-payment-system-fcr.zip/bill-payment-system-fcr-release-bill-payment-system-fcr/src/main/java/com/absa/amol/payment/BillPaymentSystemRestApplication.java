package com.absa.amol.payment;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;
import org.eclipse.microprofile.openapi.annotations.OpenAPIDefinition;
import org.eclipse.microprofile.openapi.annotations.info.Info;


@OpenAPIDefinition(info = @Info(
    title = "Utility Bill Payment By Account FCR System Adaptor OpenAPI", version = "1.0.0"))
@ApplicationPath("/bill-payment-system-fcr/")
public class BillPaymentSystemRestApplication extends Application {

}
