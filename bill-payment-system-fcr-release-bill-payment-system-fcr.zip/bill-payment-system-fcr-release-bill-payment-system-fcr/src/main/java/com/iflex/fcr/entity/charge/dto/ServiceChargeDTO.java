
package com.iflex.fcr.entity.charge.dto;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.iflex.fcr.entity.global.dto.CurrencyAmountDTO;
import com.iflex.fcr.entity.rule.ArrayOfTns5RuleEvaluationHistory;


/**
 * <p>Java class for ServiceChargeDTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ServiceChargeDTO">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="additionalIncomeLedgerCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="additionalSCAmountInAccountCurrency" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="additionalSCAmountInLocalCurrency" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="additionalSCAmountInTransactionCurrency" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="additionalSCCode" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="additionalSCCurrency" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="amountInAccountCurrency" type="{http://dto.global.entity.fcr.iflex.com}CurrencyAmountDTO"/>
 *         &lt;element name="amountInLocalCurrency" type="{http://dto.global.entity.fcr.iflex.com}CurrencyAmountDTO"/>
 *         &lt;element name="amountInServiceChargeCurrency" type="{http://dto.global.entity.fcr.iflex.com}CurrencyAmountDTO"/>
 *         &lt;element name="amountInTransactionCurrency" type="{http://dto.global.entity.fcr.iflex.com}CurrencyAmountDTO"/>
 *         &lt;element name="code" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="cumulativeDebitFlag" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="debitAccountBranchCode" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="debitAccountId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="incomeLedgerCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="isFlgAmort" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="name" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="parentSCAmountInAccountCurrency" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="parentSCAmountInLocalCurrency" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="parentSCAmountInTransactionCurrency" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="ruleReferenceNumber" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="rules" type="{http://rule.entity.fcr.iflex.com}ArrayOf_tns5_RuleEvaluationHistory"/>
 *         &lt;element name="scCurrencyOption" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="scNature" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="transactionReferenceNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ServiceChargeDTO", propOrder = {
    "additionalIncomeLedgerCode",
    "additionalSCAmountInAccountCurrency",
    "additionalSCAmountInLocalCurrency",
    "additionalSCAmountInTransactionCurrency",
    "additionalSCCode",
    "additionalSCCurrency",
    "amountInAccountCurrency",
    "amountInLocalCurrency",
    "amountInServiceChargeCurrency",
    "amountInTransactionCurrency",
    "code",
    "cumulativeDebitFlag",
    "debitAccountBranchCode",
    "debitAccountId",
    "incomeLedgerCode",
    "isFlgAmort",
    "name",
    "parentSCAmountInAccountCurrency",
    "parentSCAmountInLocalCurrency",
    "parentSCAmountInTransactionCurrency",
    "ruleReferenceNumber",
    "rules",
    "scCurrencyOption",
    "scNature",
    "transactionReferenceNumber"
})
public class ServiceChargeDTO {

    @XmlElement(required = true, nillable = true)
    protected String additionalIncomeLedgerCode;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal additionalSCAmountInAccountCurrency;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal additionalSCAmountInLocalCurrency;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal additionalSCAmountInTransactionCurrency;
    protected int additionalSCCode;
    protected int additionalSCCurrency;
    @XmlElement(required = true, nillable = true)
    protected CurrencyAmountDTO amountInAccountCurrency;
    @XmlElement(required = true, nillable = true)
    protected CurrencyAmountDTO amountInLocalCurrency;
    @XmlElement(required = true, nillable = true)
    protected CurrencyAmountDTO amountInServiceChargeCurrency;
    @XmlElement(required = true, nillable = true)
    protected CurrencyAmountDTO amountInTransactionCurrency;
    protected long code;
    @XmlElement(required = true, nillable = true)
    protected String cumulativeDebitFlag;
    protected int debitAccountBranchCode;
    @XmlElement(required = true, nillable = true)
    protected String debitAccountId;
    @XmlElement(required = true, nillable = true)
    protected String incomeLedgerCode;
    @XmlElement(required = true, nillable = true)
    protected String isFlgAmort;
    @XmlElement(required = true, nillable = true)
    protected String name;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal parentSCAmountInAccountCurrency;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal parentSCAmountInLocalCurrency;
    @XmlElement(required = true, nillable = true)
    protected BigDecimal parentSCAmountInTransactionCurrency;
    protected long ruleReferenceNumber;
    @XmlElement(required = true, nillable = true)
    protected ArrayOfTns5RuleEvaluationHistory rules;
    @XmlElement(required = true, nillable = true)
    protected String scCurrencyOption;
    @XmlElement(required = true, nillable = true)
    protected String scNature;
    @XmlElement(required = true, nillable = true)
    protected String transactionReferenceNumber;

    /**
     * Gets the value of the additionalIncomeLedgerCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdditionalIncomeLedgerCode() {
        return additionalIncomeLedgerCode;
    }

    /**
     * Sets the value of the additionalIncomeLedgerCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdditionalIncomeLedgerCode(String value) {
        this.additionalIncomeLedgerCode = value;
    }

    /**
     * Gets the value of the additionalSCAmountInAccountCurrency property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAdditionalSCAmountInAccountCurrency() {
        return additionalSCAmountInAccountCurrency;
    }

    /**
     * Sets the value of the additionalSCAmountInAccountCurrency property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAdditionalSCAmountInAccountCurrency(BigDecimal value) {
        this.additionalSCAmountInAccountCurrency = value;
    }

    /**
     * Gets the value of the additionalSCAmountInLocalCurrency property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAdditionalSCAmountInLocalCurrency() {
        return additionalSCAmountInLocalCurrency;
    }

    /**
     * Sets the value of the additionalSCAmountInLocalCurrency property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAdditionalSCAmountInLocalCurrency(BigDecimal value) {
        this.additionalSCAmountInLocalCurrency = value;
    }

    /**
     * Gets the value of the additionalSCAmountInTransactionCurrency property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAdditionalSCAmountInTransactionCurrency() {
        return additionalSCAmountInTransactionCurrency;
    }

    /**
     * Sets the value of the additionalSCAmountInTransactionCurrency property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAdditionalSCAmountInTransactionCurrency(BigDecimal value) {
        this.additionalSCAmountInTransactionCurrency = value;
    }

    /**
     * Gets the value of the additionalSCCode property.
     * 
     */
    public int getAdditionalSCCode() {
        return additionalSCCode;
    }

    /**
     * Sets the value of the additionalSCCode property.
     * 
     */
    public void setAdditionalSCCode(int value) {
        this.additionalSCCode = value;
    }

    /**
     * Gets the value of the additionalSCCurrency property.
     * 
     */
    public int getAdditionalSCCurrency() {
        return additionalSCCurrency;
    }

    /**
     * Sets the value of the additionalSCCurrency property.
     * 
     */
    public void setAdditionalSCCurrency(int value) {
        this.additionalSCCurrency = value;
    }

    /**
     * Gets the value of the amountInAccountCurrency property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAmountDTO }
     *     
     */
    public CurrencyAmountDTO getAmountInAccountCurrency() {
        return amountInAccountCurrency;
    }

    /**
     * Sets the value of the amountInAccountCurrency property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAmountDTO }
     *     
     */
    public void setAmountInAccountCurrency(CurrencyAmountDTO value) {
        this.amountInAccountCurrency = value;
    }

    /**
     * Gets the value of the amountInLocalCurrency property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAmountDTO }
     *     
     */
    public CurrencyAmountDTO getAmountInLocalCurrency() {
        return amountInLocalCurrency;
    }

    /**
     * Sets the value of the amountInLocalCurrency property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAmountDTO }
     *     
     */
    public void setAmountInLocalCurrency(CurrencyAmountDTO value) {
        this.amountInLocalCurrency = value;
    }

    /**
     * Gets the value of the amountInServiceChargeCurrency property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAmountDTO }
     *     
     */
    public CurrencyAmountDTO getAmountInServiceChargeCurrency() {
        return amountInServiceChargeCurrency;
    }

    /**
     * Sets the value of the amountInServiceChargeCurrency property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAmountDTO }
     *     
     */
    public void setAmountInServiceChargeCurrency(CurrencyAmountDTO value) {
        this.amountInServiceChargeCurrency = value;
    }

    /**
     * Gets the value of the amountInTransactionCurrency property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAmountDTO }
     *     
     */
    public CurrencyAmountDTO getAmountInTransactionCurrency() {
        return amountInTransactionCurrency;
    }

    /**
     * Sets the value of the amountInTransactionCurrency property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAmountDTO }
     *     
     */
    public void setAmountInTransactionCurrency(CurrencyAmountDTO value) {
        this.amountInTransactionCurrency = value;
    }

    /**
     * Gets the value of the code property.
     * 
     */
    public long getCode() {
        return code;
    }

    /**
     * Sets the value of the code property.
     * 
     */
    public void setCode(long value) {
        this.code = value;
    }

    /**
     * Gets the value of the cumulativeDebitFlag property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCumulativeDebitFlag() {
        return cumulativeDebitFlag;
    }

    /**
     * Sets the value of the cumulativeDebitFlag property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCumulativeDebitFlag(String value) {
        this.cumulativeDebitFlag = value;
    }

    /**
     * Gets the value of the debitAccountBranchCode property.
     * 
     */
    public int getDebitAccountBranchCode() {
        return debitAccountBranchCode;
    }

    /**
     * Sets the value of the debitAccountBranchCode property.
     * 
     */
    public void setDebitAccountBranchCode(int value) {
        this.debitAccountBranchCode = value;
    }

    /**
     * Gets the value of the debitAccountId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDebitAccountId() {
        return debitAccountId;
    }

    /**
     * Sets the value of the debitAccountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDebitAccountId(String value) {
        this.debitAccountId = value;
    }

    /**
     * Gets the value of the incomeLedgerCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIncomeLedgerCode() {
        return incomeLedgerCode;
    }

    /**
     * Sets the value of the incomeLedgerCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIncomeLedgerCode(String value) {
        this.incomeLedgerCode = value;
    }

    /**
     * Gets the value of the isFlgAmort property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIsFlgAmort() {
        return isFlgAmort;
    }

    /**
     * Sets the value of the isFlgAmort property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIsFlgAmort(String value) {
        this.isFlgAmort = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the parentSCAmountInAccountCurrency property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getParentSCAmountInAccountCurrency() {
        return parentSCAmountInAccountCurrency;
    }

    /**
     * Sets the value of the parentSCAmountInAccountCurrency property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setParentSCAmountInAccountCurrency(BigDecimal value) {
        this.parentSCAmountInAccountCurrency = value;
    }

    /**
     * Gets the value of the parentSCAmountInLocalCurrency property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getParentSCAmountInLocalCurrency() {
        return parentSCAmountInLocalCurrency;
    }

    /**
     * Sets the value of the parentSCAmountInLocalCurrency property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setParentSCAmountInLocalCurrency(BigDecimal value) {
        this.parentSCAmountInLocalCurrency = value;
    }

    /**
     * Gets the value of the parentSCAmountInTransactionCurrency property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getParentSCAmountInTransactionCurrency() {
        return parentSCAmountInTransactionCurrency;
    }

    /**
     * Sets the value of the parentSCAmountInTransactionCurrency property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setParentSCAmountInTransactionCurrency(BigDecimal value) {
        this.parentSCAmountInTransactionCurrency = value;
    }

    /**
     * Gets the value of the ruleReferenceNumber property.
     * 
     */
    public long getRuleReferenceNumber() {
        return ruleReferenceNumber;
    }

    /**
     * Sets the value of the ruleReferenceNumber property.
     * 
     */
    public void setRuleReferenceNumber(long value) {
        this.ruleReferenceNumber = value;
    }

    /**
     * Gets the value of the rules property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfTns5RuleEvaluationHistory }
     *     
     */
    public ArrayOfTns5RuleEvaluationHistory getRules() {
        return rules;
    }

    /**
     * Sets the value of the rules property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfTns5RuleEvaluationHistory }
     *     
     */
    public void setRules(ArrayOfTns5RuleEvaluationHistory value) {
        this.rules = value;
    }

    /**
     * Gets the value of the scCurrencyOption property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScCurrencyOption() {
        return scCurrencyOption;
    }

    /**
     * Sets the value of the scCurrencyOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScCurrencyOption(String value) {
        this.scCurrencyOption = value;
    }

    /**
     * Gets the value of the scNature property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getScNature() {
        return scNature;
    }

    /**
     * Sets the value of the scNature property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setScNature(String value) {
        this.scNature = value;
    }

    /**
     * Gets the value of the transactionReferenceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionReferenceNumber() {
        return transactionReferenceNumber;
    }

    /**
     * Sets the value of the transactionReferenceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionReferenceNumber(String value) {
        this.transactionReferenceNumber = value;
    }

}
