
package com.iflex.fcr.app.bill.spi;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.iflex.fcr.app.charge.ServiceChargeRequest;
import com.iflex.fcr.app.context.SessionContext;
import com.iflex.fcr.entity.global.dto.CurrencyAmountDTO;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="sessionContext" type="{http://context.app.fcr.iflex.com}SessionContext"/>
 *         &lt;element name="utilityCompanyId" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="billNo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="accountId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="consumerNo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="paymentDueDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="billAmount" type="{http://dto.global.entity.fcr.iflex.com}CurrencyAmountDTO"/>
 *         &lt;element name="accountCurrencyRate" type="{http://www.w3.org/2001/XMLSchema}float"/>
 *         &lt;element name="primaryReferenceNo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="secondaryReferenceNo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="userReferenceNo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="chargeRequest" type="{http://charge.app.fcr.iflex.com}ServiceChargeRequest"/>
 *         &lt;element name="narrative" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="transactionType" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="serviceChargeCode" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "sessionContext",
    "utilityCompanyId",
    "billNo",
    "accountId",
    "consumerNo",
    "paymentDueDate",
    "billAmount",
    "accountCurrencyRate",
    "primaryReferenceNo",
    "secondaryReferenceNo",
    "userReferenceNo",
    "chargeRequest",
    "narrative",
    "transactionType",
    "serviceChargeCode"
})
@XmlRootElement(name = "payUtilityBillByAccount")
public class PayUtilityBillByAccount {

    @XmlElement(required = true)
    protected SessionContext sessionContext;
    protected int utilityCompanyId;
    @XmlElement(required = true)
    protected String billNo;
    @XmlElement(required = true)
    protected String accountId;
    @XmlElement(required = true)
    protected String consumerNo;
    @XmlElement(required = true)
    protected String paymentDueDate;
    @XmlElement(required = true)
    protected CurrencyAmountDTO billAmount;
    protected float accountCurrencyRate;
    @XmlElement(required = true)
    protected String primaryReferenceNo;
    @XmlElement(required = true)
    protected String secondaryReferenceNo;
    @XmlElement(required = true)
    protected String userReferenceNo;
    @XmlElement(required = true)
    protected ServiceChargeRequest chargeRequest;
    @XmlElement(required = true)
    protected String narrative;
    protected int transactionType;
    protected long serviceChargeCode;

    /**
     * Gets the value of the sessionContext property.
     * 
     * @return
     *     possible object is
     *     {@link SessionContext }
     *     
     */
    public SessionContext getSessionContext() {
        return sessionContext;
    }

    /**
     * Sets the value of the sessionContext property.
     * 
     * @param value
     *     allowed object is
     *     {@link SessionContext }
     *     
     */
    public void setSessionContext(SessionContext value) {
        this.sessionContext = value;
    }

    /**
     * Gets the value of the utilityCompanyId property.
     * 
     */
    public int getUtilityCompanyId() {
        return utilityCompanyId;
    }

    /**
     * Sets the value of the utilityCompanyId property.
     * 
     */
    public void setUtilityCompanyId(int value) {
        this.utilityCompanyId = value;
    }

    /**
     * Gets the value of the billNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillNo() {
        return billNo;
    }

    /**
     * Sets the value of the billNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillNo(String value) {
        this.billNo = value;
    }

    /**
     * Gets the value of the accountId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAccountId() {
        return accountId;
    }

    /**
     * Sets the value of the accountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAccountId(String value) {
        this.accountId = value;
    }

    /**
     * Gets the value of the consumerNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsumerNo() {
        return consumerNo;
    }

    /**
     * Sets the value of the consumerNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsumerNo(String value) {
        this.consumerNo = value;
    }

    /**
     * Gets the value of the paymentDueDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaymentDueDate() {
        return paymentDueDate;
    }

    /**
     * Sets the value of the paymentDueDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaymentDueDate(String value) {
        this.paymentDueDate = value;
    }

    /**
     * Gets the value of the billAmount property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAmountDTO }
     *     
     */
    public CurrencyAmountDTO getBillAmount() {
        return billAmount;
    }

    /**
     * Sets the value of the billAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAmountDTO }
     *     
     */
    public void setBillAmount(CurrencyAmountDTO value) {
        this.billAmount = value;
    }

    /**
     * Gets the value of the accountCurrencyRate property.
     * 
     */
    public float getAccountCurrencyRate() {
        return accountCurrencyRate;
    }

    /**
     * Sets the value of the accountCurrencyRate property.
     * 
     */
    public void setAccountCurrencyRate(float value) {
        this.accountCurrencyRate = value;
    }

    /**
     * Gets the value of the primaryReferenceNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrimaryReferenceNo() {
        return primaryReferenceNo;
    }

    /**
     * Sets the value of the primaryReferenceNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrimaryReferenceNo(String value) {
        this.primaryReferenceNo = value;
    }

    /**
     * Gets the value of the secondaryReferenceNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSecondaryReferenceNo() {
        return secondaryReferenceNo;
    }

    /**
     * Sets the value of the secondaryReferenceNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSecondaryReferenceNo(String value) {
        this.secondaryReferenceNo = value;
    }

    /**
     * Gets the value of the userReferenceNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserReferenceNo() {
        return userReferenceNo;
    }

    /**
     * Sets the value of the userReferenceNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserReferenceNo(String value) {
        this.userReferenceNo = value;
    }

    /**
     * Gets the value of the chargeRequest property.
     * 
     * @return
     *     possible object is
     *     {@link ServiceChargeRequest }
     *     
     */
    public ServiceChargeRequest getChargeRequest() {
        return chargeRequest;
    }

    /**
     * Sets the value of the chargeRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link ServiceChargeRequest }
     *     
     */
    public void setChargeRequest(ServiceChargeRequest value) {
        this.chargeRequest = value;
    }

    /**
     * Gets the value of the narrative property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNarrative() {
        return narrative;
    }

    /**
     * Sets the value of the narrative property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNarrative(String value) {
        this.narrative = value;
    }

    /**
     * Gets the value of the transactionType property.
     * 
     */
    public int getTransactionType() {
        return transactionType;
    }

    /**
     * Sets the value of the transactionType property.
     * 
     */
    public void setTransactionType(int value) {
        this.transactionType = value;
    }

    /**
     * Gets the value of the serviceChargeCode property.
     * 
     */
    public long getServiceChargeCode() {
        return serviceChargeCode;
    }

    /**
     * Sets the value of the serviceChargeCode property.
     * 
     */
    public void setServiceChargeCode(long value) {
        this.serviceChargeCode = value;
    }

}
