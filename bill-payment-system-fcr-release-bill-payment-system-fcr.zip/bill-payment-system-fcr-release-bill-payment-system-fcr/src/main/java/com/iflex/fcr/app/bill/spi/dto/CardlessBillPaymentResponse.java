
package com.iflex.fcr.app.bill.spi.dto;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.iflex.fcr.entity.dto.BaseResponse;


/**
 * <p>Java class for CardlessBillPaymentResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="CardlessBillPaymentResponse">
 *   &lt;complexContent>
 *     &lt;extension base="{http://dto.entity.fcr.iflex.com}BaseResponse">
 *       &lt;sequence>
 *         &lt;element name="availableBalance" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="uniqueReferenceNo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CardlessBillPaymentResponse", propOrder = {
    "availableBalance",
    "uniqueReferenceNo"
})
public class CardlessBillPaymentResponse
    extends BaseResponse
{

    @XmlElement(required = true, nillable = true)
    protected BigDecimal availableBalance;
    @XmlElement(required = true, nillable = true)
    protected String uniqueReferenceNo;

    /**
     * Gets the value of the availableBalance property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAvailableBalance() {
        return availableBalance;
    }

    /**
     * Sets the value of the availableBalance property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAvailableBalance(BigDecimal value) {
        this.availableBalance = value;
    }

    /**
     * Gets the value of the uniqueReferenceNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUniqueReferenceNo() {
        return uniqueReferenceNo;
    }

    /**
     * Sets the value of the uniqueReferenceNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUniqueReferenceNo(String value) {
        this.uniqueReferenceNo = value;
    }

}
