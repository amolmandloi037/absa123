
package com.iflex.fcr.entity.rule;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.iflex.fcr.entity.common.PersistableEntity;


/**
 * <p>Java class for RuleEvaluationHistory complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RuleEvaluationHistory">
 *   &lt;complexContent>
 *     &lt;extension base="{http://common.entity.fcr.iflex.com}PersistableEntity">
 *       &lt;sequence>
 *         &lt;element name="conditionNumber" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="newAmount" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="originalAmount" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *         &lt;element name="reason" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="returnValueDesc" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ruleId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ruleReferenceNumber" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="ruleReturnValue" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RuleEvaluationHistory", propOrder = {
    "conditionNumber",
    "newAmount",
    "originalAmount",
    "reason",
    "returnValueDesc",
    "ruleId",
    "ruleReferenceNumber",
    "ruleReturnValue"
})
public class RuleEvaluationHistory
    extends PersistableEntity
{

    protected int conditionNumber;
    protected double newAmount;
    protected double originalAmount;
    @XmlElement(required = true, nillable = true)
    protected String reason;
    @XmlElement(required = true, nillable = true)
    protected String returnValueDesc;
    @XmlElement(required = true, nillable = true)
    protected String ruleId;
    protected long ruleReferenceNumber;
    @XmlElement(required = true, nillable = true)
    protected String ruleReturnValue;

    /**
     * Gets the value of the conditionNumber property.
     * 
     */
    public int getConditionNumber() {
        return conditionNumber;
    }

    /**
     * Sets the value of the conditionNumber property.
     * 
     */
    public void setConditionNumber(int value) {
        this.conditionNumber = value;
    }

    /**
     * Gets the value of the newAmount property.
     * 
     */
    public double getNewAmount() {
        return newAmount;
    }

    /**
     * Sets the value of the newAmount property.
     * 
     */
    public void setNewAmount(double value) {
        this.newAmount = value;
    }

    /**
     * Gets the value of the originalAmount property.
     * 
     */
    public double getOriginalAmount() {
        return originalAmount;
    }

    /**
     * Sets the value of the originalAmount property.
     * 
     */
    public void setOriginalAmount(double value) {
        this.originalAmount = value;
    }

    /**
     * Gets the value of the reason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReason() {
        return reason;
    }

    /**
     * Sets the value of the reason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReason(String value) {
        this.reason = value;
    }

    /**
     * Gets the value of the returnValueDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReturnValueDesc() {
        return returnValueDesc;
    }

    /**
     * Sets the value of the returnValueDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReturnValueDesc(String value) {
        this.returnValueDesc = value;
    }

    /**
     * Gets the value of the ruleId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRuleId() {
        return ruleId;
    }

    /**
     * Sets the value of the ruleId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRuleId(String value) {
        this.ruleId = value;
    }

    /**
     * Gets the value of the ruleReferenceNumber property.
     * 
     */
    public long getRuleReferenceNumber() {
        return ruleReferenceNumber;
    }

    /**
     * Sets the value of the ruleReferenceNumber property.
     * 
     */
    public void setRuleReferenceNumber(long value) {
        this.ruleReferenceNumber = value;
    }

    /**
     * Gets the value of the ruleReturnValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRuleReturnValue() {
        return ruleReturnValue;
    }

    /**
     * Sets the value of the ruleReturnValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRuleReturnValue(String value) {
        this.ruleReturnValue = value;
    }

}
