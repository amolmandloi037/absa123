@javax.xml.bind.annotation.XmlSchema(namespace = "http://rule.entity.fcr.iflex.com", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.iflex.fcr.entity.rule;
