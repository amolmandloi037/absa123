
package com.iflex.fcr.app.context;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SessionContext complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SessionContext">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="bankCode" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="channel" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="externalBatchNumber" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="externalReferenceNo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="externalSystemAuditTrailNumber" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="localDateTimeText" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="originalReferenceNo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="overridenWarnings" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="postingDateText" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="reason" type="{http://context.app.fcr.iflex.com}AuthorizationReason"/>
 *         &lt;element name="serviceCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="sessionTicket" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="supervisorContext" type="{http://context.app.fcr.iflex.com}UserContext"/>
 *         &lt;element name="transactionBranch" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="userId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="userReferenceNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="valueDateText" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SessionContext", propOrder = {
    "bankCode",
    "channel",
    "externalBatchNumber",
    "externalReferenceNo",
    "externalSystemAuditTrailNumber",
    "localDateTimeText",
    "originalReferenceNo",
    "overridenWarnings",
    "postingDateText",
    "reason",
    "serviceCode",
    "sessionTicket",
    "supervisorContext",
    "transactionBranch",
    "userId",
    "userReferenceNumber",
    "valueDateText"
})
public class SessionContext {

    protected int bankCode;
    @XmlElement(required = true, nillable = true)
    protected String channel;
    protected long externalBatchNumber;
    @XmlElement(required = true, nillable = true)
    protected String externalReferenceNo;
    protected long externalSystemAuditTrailNumber;
    @XmlElement(required = true, nillable = true)
    protected String localDateTimeText;
    @XmlElement(required = true, nillable = true)
    protected String originalReferenceNo;
    @XmlElement(required = true, nillable = true)
    protected String overridenWarnings;
    @XmlElement(required = true, nillable = true)
    protected String postingDateText;
    @XmlElement(required = true, nillable = true)
    protected AuthorizationReason reason;
    @XmlElement(required = true, nillable = true)
    protected String serviceCode;
    @XmlElement(required = true, nillable = true)
    protected String sessionTicket;
    @XmlElement(required = true, nillable = true)
    protected UserContext supervisorContext;
    protected int transactionBranch;
    @XmlElement(required = true, nillable = true)
    protected String userId;
    @XmlElement(required = true, nillable = true)
    protected String userReferenceNumber;
    @XmlElement(required = true, nillable = true)
    protected String valueDateText;

    /**
     * Gets the value of the bankCode property.
     * 
     */
    public int getBankCode() {
        return bankCode;
    }

    /**
     * Sets the value of the bankCode property.
     * 
     */
    public void setBankCode(int value) {
        this.bankCode = value;
    }

    /**
     * Gets the value of the channel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getChannel() {
        return channel;
    }

    /**
     * Sets the value of the channel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setChannel(String value) {
        this.channel = value;
    }

    /**
     * Gets the value of the externalBatchNumber property.
     * 
     */
    public long getExternalBatchNumber() {
        return externalBatchNumber;
    }

    /**
     * Sets the value of the externalBatchNumber property.
     * 
     */
    public void setExternalBatchNumber(long value) {
        this.externalBatchNumber = value;
    }

    /**
     * Gets the value of the externalReferenceNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExternalReferenceNo() {
        return externalReferenceNo;
    }

    /**
     * Sets the value of the externalReferenceNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExternalReferenceNo(String value) {
        this.externalReferenceNo = value;
    }

    /**
     * Gets the value of the externalSystemAuditTrailNumber property.
     * 
     */
    public long getExternalSystemAuditTrailNumber() {
        return externalSystemAuditTrailNumber;
    }

    /**
     * Sets the value of the externalSystemAuditTrailNumber property.
     * 
     */
    public void setExternalSystemAuditTrailNumber(long value) {
        this.externalSystemAuditTrailNumber = value;
    }

    /**
     * Gets the value of the localDateTimeText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocalDateTimeText() {
        return localDateTimeText;
    }

    /**
     * Sets the value of the localDateTimeText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocalDateTimeText(String value) {
        this.localDateTimeText = value;
    }

    /**
     * Gets the value of the originalReferenceNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginalReferenceNo() {
        return originalReferenceNo;
    }

    /**
     * Sets the value of the originalReferenceNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginalReferenceNo(String value) {
        this.originalReferenceNo = value;
    }

    /**
     * Gets the value of the overridenWarnings property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOverridenWarnings() {
        return overridenWarnings;
    }

    /**
     * Sets the value of the overridenWarnings property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOverridenWarnings(String value) {
        this.overridenWarnings = value;
    }

    /**
     * Gets the value of the postingDateText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPostingDateText() {
        return postingDateText;
    }

    /**
     * Sets the value of the postingDateText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPostingDateText(String value) {
        this.postingDateText = value;
    }

    /**
     * Gets the value of the reason property.
     * 
     * @return
     *     possible object is
     *     {@link AuthorizationReason }
     *     
     */
    public AuthorizationReason getReason() {
        return reason;
    }

    /**
     * Sets the value of the reason property.
     * 
     * @param value
     *     allowed object is
     *     {@link AuthorizationReason }
     *     
     */
    public void setReason(AuthorizationReason value) {
        this.reason = value;
    }

    /**
     * Gets the value of the serviceCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getServiceCode() {
        return serviceCode;
    }

    /**
     * Sets the value of the serviceCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setServiceCode(String value) {
        this.serviceCode = value;
    }

    /**
     * Gets the value of the sessionTicket property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSessionTicket() {
        return sessionTicket;
    }

    /**
     * Sets the value of the sessionTicket property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSessionTicket(String value) {
        this.sessionTicket = value;
    }

    /**
     * Gets the value of the supervisorContext property.
     * 
     * @return
     *     possible object is
     *     {@link UserContext }
     *     
     */
    public UserContext getSupervisorContext() {
        return supervisorContext;
    }

    /**
     * Sets the value of the supervisorContext property.
     * 
     * @param value
     *     allowed object is
     *     {@link UserContext }
     *     
     */
    public void setSupervisorContext(UserContext value) {
        this.supervisorContext = value;
    }

    /**
     * Gets the value of the transactionBranch property.
     * 
     */
    public int getTransactionBranch() {
        return transactionBranch;
    }

    /**
     * Sets the value of the transactionBranch property.
     * 
     */
    public void setTransactionBranch(int value) {
        this.transactionBranch = value;
    }

    /**
     * Gets the value of the userId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserId() {
        return userId;
    }

    /**
     * Sets the value of the userId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserId(String value) {
        this.userId = value;
    }

    /**
     * Gets the value of the userReferenceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserReferenceNumber() {
        return userReferenceNumber;
    }

    /**
     * Sets the value of the userReferenceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserReferenceNumber(String value) {
        this.userReferenceNumber = value;
    }

    /**
     * Gets the value of the valueDateText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValueDateText() {
        return valueDateText;
    }

    /**
     * Sets the value of the valueDateText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValueDateText(String value) {
        this.valueDateText = value;
    }

}
