
package com.iflex.fcr.entity.transaction;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.iflex.fcr.infra.exception.ExtendedReply;
import com.iflex.fcr.infra.validation.error.ArrayOfTns12ValidationError;


/**
 * <p>Java class for TransactionStatus complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TransactionStatus">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="errorCode" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="extendedReply" type="{http://exception.infra.fcr.iflex.com}ExtendedReply"/>
 *         &lt;element name="externalReferenceNo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="inputOverridenWarnings" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="isOverriden" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="isServiceChargeApplied" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="memo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="replyCode" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="replyText" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="spReturnValue" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="transactionDateTimeText" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="userReferenceNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="validationErrors" type="{http://error.validation.infra.fcr.iflex.com}ArrayOf_tns12_ValidationError"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TransactionStatus", propOrder = {
    "errorCode",
    "extendedReply",
    "externalReferenceNo",
    "inputOverridenWarnings",
    "isOverriden",
    "isServiceChargeApplied",
    "memo",
    "replyCode",
    "replyText",
    "spReturnValue",
    "transactionDateTimeText",
    "userReferenceNumber",
    "validationErrors"
})
public class TransactionStatus {

    @XmlElement(required = true, nillable = true)
    protected String errorCode;
    @XmlElement(required = true, nillable = true)
    protected ExtendedReply extendedReply;
    @XmlElement(required = true, nillable = true)
    protected String externalReferenceNo;
    @XmlElement(required = true, nillable = true)
    protected String inputOverridenWarnings;
    protected boolean isOverriden;
    protected boolean isServiceChargeApplied;
    @XmlElement(required = true, nillable = true)
    protected String memo;
    protected long replyCode;
    @XmlElement(required = true, nillable = true)
    protected String replyText;
    protected long spReturnValue;
    @XmlElement(required = true, nillable = true)
    protected String transactionDateTimeText;
    @XmlElement(required = true, nillable = true)
    protected String userReferenceNumber;
    @XmlElement(required = true, nillable = true)
    protected ArrayOfTns12ValidationError validationErrors;

    /**
     * Gets the value of the errorCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrorCode() {
        return errorCode;
    }

    /**
     * Sets the value of the errorCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrorCode(String value) {
        this.errorCode = value;
    }

    /**
     * Gets the value of the extendedReply property.
     * 
     * @return
     *     possible object is
     *     {@link ExtendedReply }
     *     
     */
    public ExtendedReply getExtendedReply() {
        return extendedReply;
    }

    /**
     * Sets the value of the extendedReply property.
     * 
     * @param value
     *     allowed object is
     *     {@link ExtendedReply }
     *     
     */
    public void setExtendedReply(ExtendedReply value) {
        this.extendedReply = value;
    }

    /**
     * Gets the value of the externalReferenceNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExternalReferenceNo() {
        return externalReferenceNo;
    }

    /**
     * Sets the value of the externalReferenceNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExternalReferenceNo(String value) {
        this.externalReferenceNo = value;
    }

    /**
     * Gets the value of the inputOverridenWarnings property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getInputOverridenWarnings() {
        return inputOverridenWarnings;
    }

    /**
     * Sets the value of the inputOverridenWarnings property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setInputOverridenWarnings(String value) {
        this.inputOverridenWarnings = value;
    }

    /**
     * Gets the value of the isOverriden property.
     * 
     */
    public boolean isIsOverriden() {
        return isOverriden;
    }

    /**
     * Sets the value of the isOverriden property.
     * 
     */
    public void setIsOverriden(boolean value) {
        this.isOverriden = value;
    }

    /**
     * Gets the value of the isServiceChargeApplied property.
     * 
     */
    public boolean isIsServiceChargeApplied() {
        return isServiceChargeApplied;
    }

    /**
     * Sets the value of the isServiceChargeApplied property.
     * 
     */
    public void setIsServiceChargeApplied(boolean value) {
        this.isServiceChargeApplied = value;
    }

    /**
     * Gets the value of the memo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMemo() {
        return memo;
    }

    /**
     * Sets the value of the memo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMemo(String value) {
        this.memo = value;
    }

    /**
     * Gets the value of the replyCode property.
     * 
     */
    public long getReplyCode() {
        return replyCode;
    }

    /**
     * Sets the value of the replyCode property.
     * 
     */
    public void setReplyCode(long value) {
        this.replyCode = value;
    }

    /**
     * Gets the value of the replyText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getReplyText() {
        return replyText;
    }

    /**
     * Sets the value of the replyText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReplyText(String value) {
        this.replyText = value;
    }

    /**
     * Gets the value of the spReturnValue property.
     * 
     */
    public long getSpReturnValue() {
        return spReturnValue;
    }

    /**
     * Sets the value of the spReturnValue property.
     * 
     */
    public void setSpReturnValue(long value) {
        this.spReturnValue = value;
    }

    /**
     * Gets the value of the transactionDateTimeText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionDateTimeText() {
        return transactionDateTimeText;
    }

    /**
     * Sets the value of the transactionDateTimeText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionDateTimeText(String value) {
        this.transactionDateTimeText = value;
    }

    /**
     * Gets the value of the userReferenceNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserReferenceNumber() {
        return userReferenceNumber;
    }

    /**
     * Sets the value of the userReferenceNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserReferenceNumber(String value) {
        this.userReferenceNumber = value;
    }

    /**
     * Gets the value of the validationErrors property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfTns12ValidationError }
     *     
     */
    public ArrayOfTns12ValidationError getValidationErrors() {
        return validationErrors;
    }

    /**
     * Sets the value of the validationErrors property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfTns12ValidationError }
     *     
     */
    public void setValidationErrors(ArrayOfTns12ValidationError value) {
        this.validationErrors = value;
    }

}
