
package com.iflex.fcr.app.bill.spi;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.iflex.fcr.app.context.SessionContext;
import com.iflex.fcr.app.loans.spi.dto.AdditionalDetailsDTO;
import com.iflex.fcr.entity.global.dto.CurrencyAmountDTO;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="sessionContext" type="{http://context.app.fcr.iflex.com}SessionContext"/>
 *         &lt;element name="forwarderID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="terminalID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="agentID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="utilityCompanyId" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="billNo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="consumerNo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="paymentDueDate" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="billAmount" type="{http://dto.global.entity.fcr.iflex.com}CurrencyAmountDTO"/>
 *         &lt;element name="serviceChargeAmount" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="exciseDutyAmount" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="commissionAmount" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="transactionCurrency" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="txnNarrative" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="uniqueReferenceNo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="transactionType" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="additionalDetailsDTO" type="{http://dto.spi.loans.app.fcr.iflex.com}AdditionalDetailsDTO"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "sessionContext",
    "forwarderID",
    "terminalID",
    "agentID",
    "utilityCompanyId",
    "billNo",
    "consumerNo",
    "paymentDueDate",
    "billAmount",
    "serviceChargeAmount",
    "exciseDutyAmount",
    "commissionAmount",
    "transactionCurrency",
    "txnNarrative",
    "uniqueReferenceNo",
    "transactionType",
    "additionalDetailsDTO"
})
@XmlRootElement(name = "cardlessBillPayment")
public class CardlessBillPayment {

    @XmlElement(required = true)
    protected SessionContext sessionContext;
    @XmlElement(required = true)
    protected String forwarderID;
    @XmlElement(required = true)
    protected String terminalID;
    @XmlElement(required = true)
    protected String agentID;
    protected int utilityCompanyId;
    @XmlElement(required = true)
    protected String billNo;
    @XmlElement(required = true)
    protected String consumerNo;
    @XmlElement(required = true)
    protected String paymentDueDate;
    @XmlElement(required = true)
    protected CurrencyAmountDTO billAmount;
    @XmlElement(required = true)
    protected BigDecimal serviceChargeAmount;
    @XmlElement(required = true)
    protected BigDecimal exciseDutyAmount;
    @XmlElement(required = true)
    protected BigDecimal commissionAmount;
    @XmlElement(required = true)
    protected String transactionCurrency;
    @XmlElement(required = true)
    protected String txnNarrative;
    @XmlElement(required = true)
    protected String uniqueReferenceNo;
    protected int transactionType;
    @XmlElement(required = true)
    protected AdditionalDetailsDTO additionalDetailsDTO;

    /**
     * Gets the value of the sessionContext property.
     * 
     * @return
     *     possible object is
     *     {@link SessionContext }
     *     
     */
    public SessionContext getSessionContext() {
        return sessionContext;
    }

    /**
     * Sets the value of the sessionContext property.
     * 
     * @param value
     *     allowed object is
     *     {@link SessionContext }
     *     
     */
    public void setSessionContext(SessionContext value) {
        this.sessionContext = value;
    }

    /**
     * Gets the value of the forwarderID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getForwarderID() {
        return forwarderID;
    }

    /**
     * Sets the value of the forwarderID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setForwarderID(String value) {
        this.forwarderID = value;
    }

    /**
     * Gets the value of the terminalID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTerminalID() {
        return terminalID;
    }

    /**
     * Sets the value of the terminalID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTerminalID(String value) {
        this.terminalID = value;
    }

    /**
     * Gets the value of the agentID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAgentID() {
        return agentID;
    }

    /**
     * Sets the value of the agentID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAgentID(String value) {
        this.agentID = value;
    }

    /**
     * Gets the value of the utilityCompanyId property.
     * 
     */
    public int getUtilityCompanyId() {
        return utilityCompanyId;
    }

    /**
     * Sets the value of the utilityCompanyId property.
     * 
     */
    public void setUtilityCompanyId(int value) {
        this.utilityCompanyId = value;
    }

    /**
     * Gets the value of the billNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillNo() {
        return billNo;
    }

    /**
     * Sets the value of the billNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillNo(String value) {
        this.billNo = value;
    }

    /**
     * Gets the value of the consumerNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getConsumerNo() {
        return consumerNo;
    }

    /**
     * Sets the value of the consumerNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setConsumerNo(String value) {
        this.consumerNo = value;
    }

    /**
     * Gets the value of the paymentDueDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaymentDueDate() {
        return paymentDueDate;
    }

    /**
     * Sets the value of the paymentDueDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaymentDueDate(String value) {
        this.paymentDueDate = value;
    }

    /**
     * Gets the value of the billAmount property.
     * 
     * @return
     *     possible object is
     *     {@link CurrencyAmountDTO }
     *     
     */
    public CurrencyAmountDTO getBillAmount() {
        return billAmount;
    }

    /**
     * Sets the value of the billAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link CurrencyAmountDTO }
     *     
     */
    public void setBillAmount(CurrencyAmountDTO value) {
        this.billAmount = value;
    }

    /**
     * Gets the value of the serviceChargeAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getServiceChargeAmount() {
        return serviceChargeAmount;
    }

    /**
     * Sets the value of the serviceChargeAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setServiceChargeAmount(BigDecimal value) {
        this.serviceChargeAmount = value;
    }

    /**
     * Gets the value of the exciseDutyAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getExciseDutyAmount() {
        return exciseDutyAmount;
    }

    /**
     * Sets the value of the exciseDutyAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setExciseDutyAmount(BigDecimal value) {
        this.exciseDutyAmount = value;
    }

    /**
     * Gets the value of the commissionAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCommissionAmount() {
        return commissionAmount;
    }

    /**
     * Sets the value of the commissionAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCommissionAmount(BigDecimal value) {
        this.commissionAmount = value;
    }

    /**
     * Gets the value of the transactionCurrency property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionCurrency() {
        return transactionCurrency;
    }

    /**
     * Sets the value of the transactionCurrency property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionCurrency(String value) {
        this.transactionCurrency = value;
    }

    /**
     * Gets the value of the txnNarrative property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTxnNarrative() {
        return txnNarrative;
    }

    /**
     * Sets the value of the txnNarrative property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTxnNarrative(String value) {
        this.txnNarrative = value;
    }

    /**
     * Gets the value of the uniqueReferenceNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUniqueReferenceNo() {
        return uniqueReferenceNo;
    }

    /**
     * Sets the value of the uniqueReferenceNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUniqueReferenceNo(String value) {
        this.uniqueReferenceNo = value;
    }

    /**
     * Gets the value of the transactionType property.
     * 
     */
    public int getTransactionType() {
        return transactionType;
    }

    /**
     * Sets the value of the transactionType property.
     * 
     */
    public void setTransactionType(int value) {
        this.transactionType = value;
    }

    /**
     * Gets the value of the additionalDetailsDTO property.
     * 
     * @return
     *     possible object is
     *     {@link AdditionalDetailsDTO }
     *     
     */
    public AdditionalDetailsDTO getAdditionalDetailsDTO() {
        return additionalDetailsDTO;
    }

    /**
     * Sets the value of the additionalDetailsDTO property.
     * 
     * @param value
     *     allowed object is
     *     {@link AdditionalDetailsDTO }
     *     
     */
    public void setAdditionalDetailsDTO(AdditionalDetailsDTO value) {
        this.additionalDetailsDTO = value;
    }

}
