@javax.xml.bind.annotation.XmlSchema(namespace = "http://spi.bill.app.fcr.iflex.com", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.iflex.fcr.app.bill.spi;
