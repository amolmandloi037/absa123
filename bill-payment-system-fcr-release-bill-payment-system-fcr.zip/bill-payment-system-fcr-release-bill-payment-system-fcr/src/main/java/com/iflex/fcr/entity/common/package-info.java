@javax.xml.bind.annotation.XmlSchema(namespace = "http://common.entity.fcr.iflex.com")
package com.iflex.fcr.entity.common;
