@javax.xml.bind.annotation.XmlSchema(namespace = "http://error.validation.infra.fcr.iflex.com", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.iflex.fcr.infra.validation.error;
