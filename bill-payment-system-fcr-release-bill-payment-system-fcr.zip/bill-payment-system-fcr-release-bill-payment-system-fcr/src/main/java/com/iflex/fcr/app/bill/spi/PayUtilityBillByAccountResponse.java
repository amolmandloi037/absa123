
package com.iflex.fcr.app.bill.spi;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="payUtilityBillByAccountReturn" type="{http://dto.spi.bill.app.fcr.iflex.com}PayUtilityBillByAccountResponse"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "payUtilityBillByAccountReturn"
})
@XmlRootElement(name = "payUtilityBillByAccountResponse")
public class PayUtilityBillByAccountResponse {

    @XmlElement(required = true)
    protected com.iflex.fcr.app.bill.spi.dto.PayUtilityBillByAccountResponse payUtilityBillByAccountReturn;

    /**
     * Gets the value of the payUtilityBillByAccountReturn property.
     * 
     * @return
     *     possible object is
     *     {@link com.iflex.fcr.app.bill.spi.dto.PayUtilityBillByAccountResponse }
     *     
     */
    public com.iflex.fcr.app.bill.spi.dto.PayUtilityBillByAccountResponse getPayUtilityBillByAccountReturn() {
        return payUtilityBillByAccountReturn;
    }

    /**
     * Sets the value of the payUtilityBillByAccountReturn property.
     * 
     * @param value
     *     allowed object is
     *     {@link com.iflex.fcr.app.bill.spi.dto.PayUtilityBillByAccountResponse }
     *     
     */
    public void setPayUtilityBillByAccountReturn(com.iflex.fcr.app.bill.spi.dto.PayUtilityBillByAccountResponse value) {
        this.payUtilityBillByAccountReturn = value;
    }

}
