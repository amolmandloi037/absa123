
package com.iflex.fcr.app.charge;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.iflex.fcr.entity.charge.dto.ArrayOfTns4ServiceChargeDTO;


/**
 * <p>Java class for ServiceChargeRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ServiceChargeRequest">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="isServiceChargeApplicable" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="serviceChargeDetails" type="{http://dto.charge.entity.fcr.iflex.com}ArrayOf_tns4_ServiceChargeDTO"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ServiceChargeRequest", propOrder = {
    "isServiceChargeApplicable",
    "serviceChargeDetails"
})
public class ServiceChargeRequest {

    protected boolean isServiceChargeApplicable;
    @XmlElement(required = true, nillable = true)
    protected ArrayOfTns4ServiceChargeDTO serviceChargeDetails;

    /**
     * Gets the value of the isServiceChargeApplicable property.
     * 
     */
    public boolean isIsServiceChargeApplicable() {
        return isServiceChargeApplicable;
    }

    /**
     * Sets the value of the isServiceChargeApplicable property.
     * 
     */
    public void setIsServiceChargeApplicable(boolean value) {
        this.isServiceChargeApplicable = value;
    }

    /**
     * Gets the value of the serviceChargeDetails property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfTns4ServiceChargeDTO }
     *     
     */
    public ArrayOfTns4ServiceChargeDTO getServiceChargeDetails() {
        return serviceChargeDetails;
    }

    /**
     * Sets the value of the serviceChargeDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfTns4ServiceChargeDTO }
     *     
     */
    public void setServiceChargeDetails(ArrayOfTns4ServiceChargeDTO value) {
        this.serviceChargeDetails = value;
    }

}
