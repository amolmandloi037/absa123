
package com.iflex.fcr.app.loans.spi.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AdditionalDetailsDTO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AdditionalDetailsDTO">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="additionalDetail1" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="additionalDetail2" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="additionalDetail3" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="additionalDetail4" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AdditionalDetailsDTO", propOrder = {
    "additionalDetail1",
    "additionalDetail2",
    "additionalDetail3",
    "additionalDetail4"
})
public class AdditionalDetailsDTO {

    @XmlElement(required = true, nillable = true)
    protected String additionalDetail1;
    @XmlElement(required = true, nillable = true)
    protected String additionalDetail2;
    @XmlElement(required = true, nillable = true)
    protected String additionalDetail3;
    @XmlElement(required = true, nillable = true)
    protected String additionalDetail4;

    /**
     * Gets the value of the additionalDetail1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdditionalDetail1() {
        return additionalDetail1;
    }

    /**
     * Sets the value of the additionalDetail1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdditionalDetail1(String value) {
        this.additionalDetail1 = value;
    }

    /**
     * Gets the value of the additionalDetail2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdditionalDetail2() {
        return additionalDetail2;
    }

    /**
     * Sets the value of the additionalDetail2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdditionalDetail2(String value) {
        this.additionalDetail2 = value;
    }

    /**
     * Gets the value of the additionalDetail3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdditionalDetail3() {
        return additionalDetail3;
    }

    /**
     * Sets the value of the additionalDetail3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdditionalDetail3(String value) {
        this.additionalDetail3 = value;
    }

    /**
     * Gets the value of the additionalDetail4 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdditionalDetail4() {
        return additionalDetail4;
    }

    /**
     * Sets the value of the additionalDetail4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdditionalDetail4(String value) {
        this.additionalDetail4 = value;
    }

}
