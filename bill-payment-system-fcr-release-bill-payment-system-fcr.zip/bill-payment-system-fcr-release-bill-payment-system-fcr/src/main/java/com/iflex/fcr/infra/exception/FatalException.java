
package com.iflex.fcr.infra.exception;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FatalException complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FatalException">
 *   &lt;complexContent>
 *     &lt;extension base="{http://exception.infra.fcr.iflex.com}OLTPException">
 *       &lt;sequence>
 *         &lt;element name="reason" type="{http://exception.infra.fcr.iflex.com}ReplyMessage"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FatalException", propOrder = {
    "reason"
})
public class FatalException
    extends OLTPException
{

    @XmlElement(required = true, nillable = true)
    protected ReplyMessage reason;

    /**
     * Gets the value of the reason property.
     * 
     * @return
     *     possible object is
     *     {@link ReplyMessage }
     *     
     */
    public ReplyMessage getReason() {
        return reason;
    }

    /**
     * Sets the value of the reason property.
     * 
     * @param value
     *     allowed object is
     *     {@link ReplyMessage }
     *     
     */
    public void setReason(ReplyMessage value) {
        this.reason = value;
    }

}
