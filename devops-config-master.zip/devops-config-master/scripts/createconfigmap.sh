#!/bin/sh
#script to create and label configmap with app name 
APP_NAME=$1
NAME=`ls src/main/resources/properties/dev/ | cut -d'.' -f1`
echo "creating configmap for amol-api-dev env"
oc create configmap $NAME --from-file=src/main/resources/properties/dev/$NAME.properties -n amol-api-dev
oc label configmap $NAME app=$APP_NAME -n amol-api-dev
#NAME=`ls src/main/resources/properties/cit/ | cut -d'.' -f1`
#echo "creating configmap for amol-api-cit env"
#oc create configmap $NAME --from-file=src/main/resources/properties/cit/$NAME.properties -n amol-api-cit
#oc label configmap $NAME app=$APP_NAME -n amol-api-cit
#NAME=`ls src/main/resources/properties/sit/ | cut -d'.' -f1`
#echo "creating configmap for amol-api-sit env"
#oc create configmap $NAME --from-file=src/main/resources/properties/sit/$NAME.properties -n amol-api-sit
#oc label configmap $NAME app=$APP_NAME -n amol-api-sit
#NAME=`ls src/main/resources/properties/uat/ | cut -d'.' -f1`
#echo "creating configmap for amol-api-uat env"
#oc create configmap $NAME --from-file=src/main/resources/properties/uat/$NAME.properties -n amol-api-uat
#oc label configmap $NAME app=$APP_NAME -n amol-api-uat
