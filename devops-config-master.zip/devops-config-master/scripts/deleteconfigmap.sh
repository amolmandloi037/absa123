#!/bin/sh
echo "defining variable"
APP_NAME=$1
echo $APP_NAME
echo "app name initialised removing eisting configs"
oc delete configmap -l app=$APP_NAME -n amol-api-dev
#oc delete configmap -l app=$APP_NAME -n amol-api-cit
#oc delete configmap -l app=$APP_NAME -n amol-api-sit
#oc delete configmap -l app=$APP_NAME -n amol-api-uat
