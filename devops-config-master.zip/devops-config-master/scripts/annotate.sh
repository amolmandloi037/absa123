#!/bin/sh
APP_NAME=$1
NAMESPACE=$2
oc get secret ${APP_NAME} -n ${NAMESPACE} > out 2> test
[ -s test ] && echo error || echo exist
