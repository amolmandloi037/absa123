package com.absa.amol.saving.service.purchasemv;

import com.absa.amol.saving.model.purchasemv.PurchaseMvReqWrapper;
import com.absa.amol.saving.model.purchasemv.PurchaseMvRes;
import com.absa.amol.util.model.ResponseEntity;

public interface PurchaseMvService {
	public ResponseEntity<PurchaseMvRes> moneyVoucherPurchase(PurchaseMvReqWrapper requestWrapper);
}
