package com.absa.amol.saving.service.unclearedfund;

import com.absa.amol.saving.model.unclearedfund.UnclearFundDetailsRequest;

public interface UnclearedfundReqValidator {

	void validateRetrieveUnclearedFund(UnclearFundDetailsRequest unclearFundDetailsRequest);

}
