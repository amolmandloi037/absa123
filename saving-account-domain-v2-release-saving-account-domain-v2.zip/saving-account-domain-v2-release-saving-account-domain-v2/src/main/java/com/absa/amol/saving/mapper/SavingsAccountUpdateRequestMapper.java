package com.absa.amol.saving.mapper;

import com.absa.amol.saving.model.AccountArrangementRequest;
import com.absa.amol.saving.model.AccountStoppedCheque;
import com.absa.amol.saving.model.CustomerReferenceDTO;
import com.absa.amol.saving.model.InterestRate;
import com.absa.amol.saving.model.InterestTransaction;
import com.absa.amol.saving.model.MailingAddress;
import com.absa.amol.saving.model.PositionLimitValue;
import com.absa.amol.saving.model.ProductAndServicePreference;
import com.absa.amol.saving.model.SavingAccountArrangementRequest;
import com.absa.amol.util.utility.CommonUtil;

public class SavingsAccountUpdateRequestMapper {

  public AccountArrangementRequest accountUpdateReqMapper(
      SavingAccountArrangementRequest domainRequest) {
    AccountArrangementRequest request = new AccountArrangementRequest();
    MailingAddress mailingAddress = new MailingAddress();
    MailingAddress mailingAddressDomain = null;
    mailingAddressDomain = domainRequest.getMailingAddress();
    CustomerReferenceDTO customerReference = null;
    customerReference = domainRequest.getCustomerReference();
    ProductAndServicePreference productAndServicePreferenceDomain = null;
    productAndServicePreferenceDomain = domainRequest.getProductAndServicePreference();
    InterestRate interestRate = null;
    interestRate = domainRequest.getInterestRate();
    PositionLimitValue positionLimitValue = null;
    positionLimitValue = domainRequest.getPositionLimitValue();
    InterestTransaction interestTransaction = null;
    interestTransaction = domainRequest.getInterestTransaction();
    request.setApiRequestHeader(domainRequest.getApiRequestHeader());
    request.setAccountClassification(domainRequest.getAccountClassification());
    request.setAccountCurrency(domainRequest.getAccountCurrency());
    request.setProductInstanceReference(domainRequest.getSavingsAccountNumber());
    request.setAccountStatus(domainRequest.getAccountStatus());
    request.setAccountType(domainRequest.getAccountType());
    request.setBankBranch(domainRequest.getBankBranch());
    request.setBicCode(domainRequest.getBicCode());
    request.setMarketSegment(domainRequest.getMarketSegment());
    request.setReferStream(domainRequest.getReferStream());
    request.setSequenceNumber(domainRequest.getSequenceNumber());
    request.setTerminalNumber(domainRequest.getTerminalNumber());
    if (CommonUtil.isNotNull(productAndServicePreferenceDomain)) {
      request.setAtmIndicator(productAndServicePreferenceDomain.getAtmIndicator());
      request.setKycInd(productAndServicePreferenceDomain.getKycIndicator());
      request.setDebitRateIndicator1(productAndServicePreferenceDomain.getDebitRateIndicator1());
      request.setDebitRateIndicator2(productAndServicePreferenceDomain.getDebitRateIndicator2());
      request.setCreditRateIndicator1(productAndServicePreferenceDomain.getCreditRateIndicator1());
      request.setCreditRateIndicator2(productAndServicePreferenceDomain.getCreditRateIndicator2());
    }
    if (CommonUtil.isNotNull(mailingAddressDomain)) {
      mailingAddress.setContactName(mailingAddressDomain.getContactName());
      mailingAddress.setLine1(mailingAddressDomain.getLine1());
      mailingAddress.setLine2(mailingAddressDomain.getLine2());
      mailingAddress.setLine3(mailingAddressDomain.getLine3());
      mailingAddress.setAddressIdentifier(mailingAddressDomain.getAddressIdentifier());
      request.setMailingAddress(mailingAddress);
    }

    // adding for notes
    if (domainRequest.getAccountNotes() != null)
      request.setAccountNotes(domainRequest.getAccountNotes());
    request.setHostname(domainRequest.getHostname());
    request.setUserid(domainRequest.getUserid());
    request.setNotesActionCode(domainRequest.getNotesActionCode());

    // stopped cheque
    AccountStoppedCheque stoppedCheque = new AccountStoppedCheque();
    if (domainRequest.getIssuedInventoryPropertyType() != null) {
      stoppedCheque.setFirstChequeNumber(
          domainRequest.getIssuedInventoryPropertyType().getFirstChequeNumber());
      stoppedCheque.setLastChequeNumber(
          domainRequest.getIssuedInventoryPropertyType().getLastChequeNumber());
    }
    if (domainRequest.getIssuedInventoryPropertyValue() != null) {
      stoppedCheque.setStoppedChequeAction(
          domainRequest.getIssuedInventoryPropertyValue().getStoppedChequeAction());
      stoppedCheque
          .setChequeAmount(domainRequest.getIssuedInventoryPropertyValue().getChequeAmount());
    }
    if (domainRequest.getIssuedInventoryOptionDefinition() != null)
      stoppedCheque.setStopType(domainRequest.getIssuedInventoryOptionDefinition().getStopType());
    if (domainRequest.getIssuedInventoryOptionSetting() != null)
      stoppedCheque.setOriginalStopDate(
          domainRequest.getIssuedInventoryOptionSetting().getOriginalStopDate());
    request.setStoppedChequeActionCode(domainRequest.getStoppedChequeAction());
    request.setAccountStoppedCheque(stoppedCheque);

    // adding for modification, loan, amendments
    request.setAccountModificationIndicator(domainRequest.getAccountModificationIndicator());
    request.setShortName(domainRequest.getAccountShortName());
    request.setLongName(domainRequest.getAccountLongName());
    if (domainRequest.getCustomerReference() != null) {
      request.setDesignationCode(customerReference.getDesignationCode());
      request.setCustomerIdentification(customerReference.getCustomerIdentification());
    }

    if (domainRequest.getDate() != null) {
      request.setKycDate(domainRequest.getDate().getKycDate());
      request.setDebitLimitExpiry(domainRequest.getDate().getDebitLimitExpiry());
      request.setSystemDayNumber(domainRequest.getDate().getSystemDayNumber());
    }

    if (domainRequest.getInterestRate() != null) {
      request.setInterestSinceDormant(interestRate.getInterestAmountSinceDormant());
      request.setDebitRate1(interestRate.getDebitRate1());
      request.setDebitRate2(interestRate.getDebitRate2());
      request.setCreditRate1(interestRate.getCreditRate1());
      request.setCreditRate2(interestRate.getCreditRate2());
    }

    if (domainRequest.getLocationReference() != null) {
      request.setLocationCode(domainRequest.getLocationReference().getLocationCode());
      request.setSalesLocation(domainRequest.getLocationReference().getSalesLocation());
    }
    if (domainRequest.getPositionLimitSetting() != null) {
      request.setCreditLimit(domainRequest.getPositionLimitSetting().getCreditLimit());
      request
          .setEffectiveDebitLimit(domainRequest.getPositionLimitSetting().getEffectiveDebitLimit());
    }
    if (domainRequest.getPositionLimitValue() != null) {
      request.setDrLimitReductionAmt(
          domainRequest.getPositionLimitValue().getDebitLimitReductionAmount());
      request.setAmountToClear(positionLimitValue.getAmountToClear());
      request.setDrBalanceEffective(positionLimitValue.getDrBalanceEffective());
      request.setCrBalanceEffective(positionLimitValue.getCrBalanceEffective());
    }

    request.setGscaDrCode(domainRequest.getSalesCode());
    request.setCrediatorClassification(domainRequest.getCreditorClassification());

    request.setFrequencyData(domainRequest.getFrequencyData());
    request.setFrequencyInd(domainRequest.getFrequencyIndicator());
    request.setAmendmtCnclOfDebit(domainRequest.isAmendmtCnclOfDebit());

    // adding auto-transfer fields
    if (null != domainRequest.getAutoTransferActionCode()
        && !domainRequest.getAutoTransferActionCode().isEmpty()) {
      request.setProductInstanceReference(domainRequest.getSavingsAccountNumber());
      request.setBankBranch(domainRequest.getBankBranch());
      request.setSerialNumber(domainRequest.getSerialNumber());
      // paymenttransaction
      if (null != domainRequest.getPaymentTransaction()) {
        com.absa.amol.saving.model.autotransfer.PaymentTransaction paymentTransaction =
            new com.absa.amol.saving.model.autotransfer.PaymentTransaction();
        paymentTransaction.setPayeeAccountReference(
            domainRequest.getPaymentTransaction().getPayeeAccountReference());
        paymentTransaction
            .setPayeeBankReference(domainRequest.getPaymentTransaction().getPayeeBankReference());
        paymentTransaction.setAmount(domainRequest.getPaymentTransaction().getAmount());

        request.setPaymentTransaction(paymentTransaction);
      }

      request.setPositionLimitType(domainRequest.getPositionLimitType());
      request.setTransfersOutAllowed(domainRequest.getTransfersOutAllowed());
      request.setTransfersInAllowed(domainRequest.getTransfersInAllowed());
      request.setAutoTransferActionCode(domainRequest.getAutoTransferActionCode());

      com.absa.amol.saving.model.autotransfer.PaymentTransactionType paymentTransactionType =
          new com.absa.amol.saving.model.autotransfer.PaymentTransactionType();

      if (domainRequest.getPaymentTransactionType() != null) {

        paymentTransactionType
            .setTransferType(domainRequest.getPaymentTransactionType().getTransferType());
        request.setPaymentTransactionType(paymentTransactionType);

      }

      com.absa.amol.saving.model.autotransfer.PaymentSchedule paymentSchedule =
          new com.absa.amol.saving.model.autotransfer.PaymentSchedule();
      com.absa.amol.saving.model.autotransfer.PaymentSchedule paymentScheduleDomain =
          new com.absa.amol.saving.model.autotransfer.PaymentSchedule();

      paymentScheduleDomain = domainRequest.getPaymentSchedule();
      if (null != domainRequest.getPaymentSchedule()) {
        paymentSchedule.setFrequency(paymentScheduleDomain.getFrequency());
        paymentSchedule.setFrequencyData(paymentScheduleDomain.getFrequencyData());
        paymentSchedule.setNextDueDate(paymentScheduleDomain.getNextDueDate());
        request.setPaymentSchedule(paymentSchedule);

      }
    }
    if (CommonUtil.isNotNull(interestTransaction)) {
      request.setDebitInterestContra(interestTransaction.getDebitInterestContra());
      request.setCreditInterestContra(interestTransaction.getCreditInterestContra());
    }

    // uncleared_Effects
    if (domainRequest.getPaymentType() != null)
      request.setUnclearedEffectType(domainRequest.getPaymentType().getUnclearedEffectType());
    request.setInterestRateIndicator(domainRequest.isInterestRateIndicator());
    return request;
  }

}
