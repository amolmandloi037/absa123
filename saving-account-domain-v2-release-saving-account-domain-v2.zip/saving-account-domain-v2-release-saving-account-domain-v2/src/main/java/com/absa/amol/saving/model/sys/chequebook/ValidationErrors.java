package com.absa.amol.saving.model.sys.chequebook;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ValidationErrors 
{
	 protected String applicableAttributes;

	 

	  protected String attributeName;

	 

	  protected String attributeValue;

	 

	  protected String errorCode;

	 

	  protected String errorMessage;

	 

	  protected String methodName;

	 

	  protected String objectName;
}
