package com.absa.amol.saving.service.checkstatus;

import com.absa.amol.saving.model.checkstatus.CheckStatusRequest;

public interface CheckStatusValidatorService {

		  public void validateCheckStatus(CheckStatusRequest req);
		
}
