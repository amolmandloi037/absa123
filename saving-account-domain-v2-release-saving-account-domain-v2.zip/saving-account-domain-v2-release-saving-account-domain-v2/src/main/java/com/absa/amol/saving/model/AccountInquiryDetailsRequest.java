package com.absa.amol.saving.model;

import javax.ws.rs.BeanParam;
import javax.ws.rs.QueryParam;
import com.absa.amol.util.model.ApiRequestHeader;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AccountInquiryDetailsRequest {
  @BeanParam
  ApiRequestHeader apiRequestHeader;

  @QueryParam(value = "customerNumber")
  private String customerNumber;
}
