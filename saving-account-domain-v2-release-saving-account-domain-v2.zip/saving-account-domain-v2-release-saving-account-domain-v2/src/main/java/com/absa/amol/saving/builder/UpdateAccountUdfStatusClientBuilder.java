package com.absa.amol.saving.builder;

import javax.ws.rs.BeanParam;
import javax.ws.rs.POST;

import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import com.absa.amol.saving.model.sys.updaccudf.AccountUdfUpdateReq;
import com.absa.amol.saving.model.sys.updaccudf.AccountUdfUpdateRes;
import com.absa.amol.saving.util.ServerSideExceptionMapper;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.model.ResponseEntity;

@RegisterRestClient(configKey = "uas.update.udfstatus")
@RegisterProvider(value = ServerSideExceptionMapper.class)
public interface UpdateAccountUdfStatusClientBuilder {

	@POST
	ResponseEntity<AccountUdfUpdateRes> accountUpdateUdf(@BeanParam ApiRequestHeader requestHeader, @RequestBody AccountUdfUpdateReq accountUdfUpdateReq);

}
