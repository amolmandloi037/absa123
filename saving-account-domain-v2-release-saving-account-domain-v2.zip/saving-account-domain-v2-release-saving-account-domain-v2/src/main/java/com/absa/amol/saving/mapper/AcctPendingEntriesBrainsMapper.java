package com.absa.amol.saving.mapper;

import java.util.ArrayList;

import com.absa.amol.saving.model.acctearmarkpendingentries.AccountDetails;
import com.absa.amol.saving.model.acctearmarkpendingentries.AcctEarmarkPendingEntriesDomainRequest;
import com.absa.amol.saving.model.acctearmarkpendingentries.AcctEarmarkPendingEntriesDomainResponse;
import com.absa.amol.saving.model.acctearmarkpendingentries.AcctEarmarkPendingEntriesListResponse;
import com.absa.amol.saving.model.acctearmarkpendingentries.PositionLimitType;
import com.absa.amol.saving.model.acctearmarkpendingentries.PositionLimitValue;
import com.absa.amol.saving.model.sys.pendingentries.AcctPendingEntriesSystemList;
import com.absa.amol.saving.model.sys.pendingentries.AcctPendingEntriesSystemReq;
import com.absa.amol.saving.model.sys.pendingentries.AcctPendingEntriesSystemRes;
import com.absa.amol.util.model.ResponseEntity;
import com.absa.amol.util.utility.CommonUtil;
import com.absa.amol.util.utility.StringUtil;

public class AcctPendingEntriesBrainsMapper {

	public AcctPendingEntriesSystemReq acctPendingEntrReqMapping(AcctEarmarkPendingEntriesDomainRequest domainReq) {

		AcctPendingEntriesSystemReq pendingEntriesSystemReq = new AcctPendingEntriesSystemReq();
		pendingEntriesSystemReq.setAccountNumber(domainReq.getAccountNumber());
		pendingEntriesSystemReq.setBranchNumber(domainReq.getBankBranchReference());
		pendingEntriesSystemReq.setRequestHeader(domainReq.getApiRequestHeader());
		return pendingEntriesSystemReq;
	}


	public ResponseEntity<AcctEarmarkPendingEntriesListResponse>  acctPendingEntrResMapping(ResponseEntity<AcctPendingEntriesSystemList> systemRespEntity){
		ResponseEntity<AcctEarmarkPendingEntriesListResponse>  respEntity = null;
		AcctEarmarkPendingEntriesListResponse acctPendingEntriesDomainRes= new AcctEarmarkPendingEntriesListResponse();
		ArrayList<AcctEarmarkPendingEntriesDomainResponse> earmarkingPendingEntriesList = new ArrayList<>();
		AcctEarmarkPendingEntriesDomainResponse pendingEntriesDomainRes = new AcctEarmarkPendingEntriesDomainResponse();
		AcctPendingEntriesSystemList acctPendingEntriesSystemList = null;

		String respCode = systemRespEntity.getCode();
		String respMsg = systemRespEntity.getMessage();
		String respStatus = systemRespEntity.getStatus();
		if(CommonUtil.isNotNull(systemRespEntity)) {
			acctPendingEntriesSystemList =systemRespEntity.getData();
			mapPendingEntriesResp(acctPendingEntriesDomainRes, earmarkingPendingEntriesList, pendingEntriesDomainRes,
					acctPendingEntriesSystemList);
			respEntity = new ResponseEntity<>(respCode, respMsg, respStatus, acctPendingEntriesDomainRes);
		}

		return respEntity;
	}


	public void mapPendingEntriesResp(AcctEarmarkPendingEntriesListResponse acctPendingEntriesDomainRes,
			ArrayList<AcctEarmarkPendingEntriesDomainResponse> earmarkingPendingEntriesList,
			AcctEarmarkPendingEntriesDomainResponse pendingEntriesDomainRes,
			AcctPendingEntriesSystemList acctPendingEntriesSystemList) {
		ArrayList<AcctPendingEntriesSystemRes> pendingEntriesSystemList;
		if(CommonUtil.isNotNull(acctPendingEntriesSystemList)) {
			pendingEntriesSystemList = acctPendingEntriesSystemList.getPendingEntriesList();
			for (AcctPendingEntriesSystemRes systemResObj:pendingEntriesSystemList) {

				if(StringUtil.isStringNotNullAndNotEmpty(systemResObj.getAmount())){
					PositionLimitValue positionLimitValue= new PositionLimitValue(systemResObj.getAmount());
					pendingEntriesDomainRes.setPositionLimitValue(positionLimitValue);
				}
				if(StringUtil.isStringNotNullAndNotEmpty(systemResObj.getDrCrMultiplier())){
					PositionLimitType positionLimitType = new PositionLimitType(systemResObj.getDrCrMultiplier());
					pendingEntriesDomainRes.setPositionLimitType(positionLimitType);
				}
				if(StringUtil.isStringNotNullAndNotEmpty(systemResObj.getNarrative())){
					AccountDetails accountDetails = new AccountDetails(systemResObj.getNarrative());
					pendingEntriesDomainRes.setAccountDetails(accountDetails);
				}
				pendingEntriesDomainRes.setTransactionCode(systemResObj.getTransactionCode());
				earmarkingPendingEntriesList.add(pendingEntriesDomainRes);
				acctPendingEntriesDomainRes.setEarmarkingPendingEntriesList(earmarkingPendingEntriesList);
			}

		}
	}

}
