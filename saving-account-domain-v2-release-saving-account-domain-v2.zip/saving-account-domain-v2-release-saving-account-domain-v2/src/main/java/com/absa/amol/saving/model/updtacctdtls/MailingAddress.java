package com.absa.amol.saving.model.updtacctdtls;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class MailingAddress {
	
	@Pattern(regexp = "[01234]{0,1}?|", message = "addressSequenceNumber.pattern.message")
    private String addressSequenceNumber;
	@Size(min=1, max=35, message="addressName.size.error.message")
    private String addressName;
	@Size(min=1, max=35, message="addressLine1.size.error.message")
    private String addressLine1;
	@Size(min=1, max=35, message="addressLine2.size.error.message")
    private String addressLine2;
	@Size(min=1, max=35, message="addressLine3.size.error.message")
    private String addressLine3;

}
