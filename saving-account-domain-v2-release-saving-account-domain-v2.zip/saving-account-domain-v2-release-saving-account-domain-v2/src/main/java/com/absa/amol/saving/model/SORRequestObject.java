package com.absa.amol.saving.model;

import javax.ws.rs.BeanParam;
import javax.ws.rs.QueryParam;
import com.absa.amol.util.model.ApiRequestHeader;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class SORRequestObject {

  @BeanParam
  private ApiRequestHeader apiRequestHeader;

  @QueryParam(value = "accountNumber")
  private String accountNumber;

  @QueryParam(value = "branchCode")
  private String branchCode;

}
