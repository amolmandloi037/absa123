package com.absa.amol.saving.service.updtacctdtls;

import com.absa.amol.saving.model.updtacctdtls.UpdateAcctDtlsReqWrapper;
import com.absa.amol.saving.model.updtacctdtls.UpdateAcctDtlsRes;
import com.absa.amol.util.model.ResponseEntity;

public interface UpdateAcctDtlsService {
	
	public ResponseEntity<UpdateAcctDtlsRes> updateAcctDetails(UpdateAcctDtlsReqWrapper updateAcctDtlsReqWrapper);

}
