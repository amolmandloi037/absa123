package com.absa.amol.saving.service.impl.demanddraft;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.eclipse.microprofile.config.Config;

import com.absa.amol.saving.model.demanddraft.DemandDraftDomainReq;
import com.absa.amol.saving.service.demandraft.IDemandDraftValidatorService;
import com.absa.amol.saving.service.impl.chequebook.ChequeBookValidatorServiceImpl;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.exception.ApiRequestException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.utility.StringUtil;

public class DemandDraftValidatorServiceImpl implements IDemandDraftValidatorService {
	
	@Inject
	private Validator validator;

	@Inject
	Config config;

	private static final Logger LOGGER = LoggerFactory.getLogger(ChequeBookValidatorServiceImpl.class);

	public <T>void validateInputRequest(T demandDraftDomainReq,ApiRequestHeader apiRequestHeader) {
		Set<String> demandDraftErrorSet = demandDraftValidateReqHeader(apiRequestHeader);
		demandDraftErrorSet.addAll(validatedAnnotedBeans(demandDraftDomainReq));
		demandDraftErrorSet.addAll(customvalidatedBeans((DemandDraftDomainReq) demandDraftDomainReq));
		if (!demandDraftErrorSet.isEmpty()) {
			String validationErrorMessage = String.join(",", demandDraftErrorSet);
			LOGGER.error("validateInputRequest", apiRequestHeader.getConsumerUniqueReferenceId(), "Validation failed:", validationErrorMessage);
			throw new ApiRequestException(Constant.BAD_REQUEST_CODE, validationErrorMessage);
		}
	}
	private Set<String> demandDraftValidateReqHeader(ApiRequestHeader demandDraftApiRequestHeader) {
		Set<ConstraintViolation<Object>> violations = validator.validate(demandDraftApiRequestHeader);
		return violations.stream().map(constraint -> {
			String demandDraftCustomErroMessage = getPropertyValue(constraint.getMessageTemplate());
			return StringUtil.isStringNullOrEmpty(demandDraftCustomErroMessage) ? constraint.getMessage() : demandDraftCustomErroMessage;
		}).collect(Collectors.toSet());
	}

	private <T>Set<String> validatedAnnotedBeans(T demandDraftRequest) {
		Set<ConstraintViolation<Object>> violations = validator.validate(demandDraftRequest);
		return violations.stream().map(constraint -> {
			String demandDraftCustomErroMessage = getPropertyValue(constraint.getMessageTemplate());
			return StringUtil.isStringNullOrEmpty(demandDraftCustomErroMessage) ? constraint.getMessage() : demandDraftCustomErroMessage;
		}).collect(Collectors.toSet());
	}
	
	private Set<String> customvalidatedBeans(DemandDraftDomainReq chequeBookDomainReq) {

		LOGGER.info(Constant.VALIDATE_INPUT_REQUEST, Constant.EMPTY,Constant.CUSTOMVALIDATED_BEANS, Constant.EMPTY);
		Set<String> customValErrSet = new HashSet<>();
			if (StringUtil.isStringNotNullAndNotEmpty(chequeBookDomainReq.getCustomerReference())
					&& (chequeBookDomainReq.getCustomerReference().split(Constant.ZERO_STRING, -1).length
							- 1 == chequeBookDomainReq.getCustomerReference().length())) {
				customValErrSet.add(
						getPropertyValue(Constant.DD_CUSTOMER_REFERENCE_PATTERN_ERROR_MESSAGE));
			}
			if (StringUtil.isStringNotNullAndNotEmpty(chequeBookDomainReq.getSavingsAccountNumber())
					&& (chequeBookDomainReq.getSavingsAccountNumber().split(Constant.ZERO_STRING, -1).length
							- 1 == chequeBookDomainReq.getSavingsAccountNumber().length())) {
				customValErrSet.add(
						getPropertyValue(Constant.SAVINGS_ACCOUNT_NUMBER_PATTERN_ERROR_MESSAGE));
			}
			if (StringUtil.isStringNotNullAndNotEmpty(chequeBookDomainReq.getBankBranchReference())
					&& (chequeBookDomainReq.getBankBranchReference().split(Constant.ZERO_STRING, -1).length
							- 1 == chequeBookDomainReq.getBankBranchReference().length())) {
				customValErrSet.add(
						getPropertyValue(Constant.BANK_BRANCH_REFERENCE_PATTERN_ERROR_MESSAGE));
			}
			
		
		return customValErrSet;
	}

	private String getPropertyValue(String confkey) {
		String msg=null;
		try {
			msg =  config.getValue(confkey, String.class);
		} catch (Exception e) {
			LOGGER.error("getPropertyValue", "", "Exception while reading property for the key ::" + confkey, e.getMessage());
		}
		return msg;
	}


}
