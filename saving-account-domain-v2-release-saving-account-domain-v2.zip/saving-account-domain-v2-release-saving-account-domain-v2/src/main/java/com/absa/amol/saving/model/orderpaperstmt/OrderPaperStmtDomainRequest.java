package com.absa.amol.saving.model.orderpaperstmt;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.ws.rs.BeanParam;
import javax.ws.rs.QueryParam;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import com.absa.amol.util.model.ApiRequestHeader;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Schema(name = "OrderPaperStmtDomainRequest",
    description = "Request Schema For Order Paper Statement")
public class OrderPaperStmtDomainRequest {

  @Valid
  @BeanParam
  private ApiRequestHeader apiRequestHeader;

  @Schema(description = "Field is mandatory for all flows.", pattern = "Only numeric",
      minLength = 1, maxLength = 12, required = true)
  @NotNull(message = "order.paper.stmt.customerNumber.noempty.error.message")
  @NotEmpty(message = "order.paper.stmt.customerNumber.noempty.error.message")
  @Size(min = 0, max = 12, message = "order.paper.stmt.customerNumber.length.error.message")
  @Pattern(regexp = "(^$)|^[0-9]*", message = "order.paper.stmt.customerNumber.digit.error.message")
  @QueryParam("customerNumber")
  private String customerNumber;

  @Schema(description = "Field is mandatory for all flows.", pattern = "Only numeric",
      minLength = 1, maxLength = 16, required = true)
  @NotNull(message = "order.paper.stmt.accountId.noempty.error.message")
  @NotEmpty(message = "order.paper.stmt.accountId.noempty.error.message")
  @Pattern(regexp = "^[0-9]*", message = "order.paper.stmt.accountId.digit.error.message")
  @Size(min = 1, max = 16, message = "order.paper.stmt.accountId.length.error.message")
  @QueryParam("accountId")
  private String accountId;

  @Schema(description = "Field is conditional mandatory for Ebox flow.", maxLength = 5)
  @Size(min = 0, max = 5, message = "order.paper.stmt.branchCode.length.error.message")
  @Pattern(regexp = "(^$)|^[0-9]*", message = "order.paper.stmt.branchCode.digit.error.message")
  @QueryParam("branchCode")
  private String branchCode;

  @Schema(description = "Field is conditional mandatory and format is YYYYMMDD.")
  @com.absa.amol.saving.util.Date(message = "order.paper.stmt.fromDate.invalid.error.message",
      format = "yyyyMMdd")
  @Pattern(regexp = "^[0-9]*", message = "order.paper.stmt.fromDate.digit.error.message")
  @QueryParam("fromDate")
  private String fromDate;

  @Schema(description = "Field is conditional mandatory and format is YYYYMMDD.")
  @com.absa.amol.saving.util.Date(message = "order.paper.stmt.toDate.invalid.error.message",
      format = "yyyyMMdd")
  @Pattern(regexp = "^[0-9]*", message = "order.paper.stmt.toDate.digit.error.message")
  @QueryParam("toDate")
  private String toDate;

  @Override
  public String toString() {
    return "OrderPaperStmtDomainRequest [requestHeader=" + apiRequestHeader + ", branchCode="
        + branchCode + ", fromDate=" + fromDate + ", toDate=" + toDate + "]";
  }
}
