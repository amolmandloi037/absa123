package com.absa.amol.saving.service.demandraft;

import com.absa.amol.saving.model.demanddraft.DemandDraftDomainReqWrapper;
import com.absa.amol.saving.model.demanddraft.DemandDraftDomainRes;
import com.absa.amol.util.model.ResponseEntity;

public interface IDemandDraftService {
	public ResponseEntity<DemandDraftDomainRes> demandDraftRequest(DemandDraftDomainReqWrapper demandDraftDomainReqWrapper);

}
