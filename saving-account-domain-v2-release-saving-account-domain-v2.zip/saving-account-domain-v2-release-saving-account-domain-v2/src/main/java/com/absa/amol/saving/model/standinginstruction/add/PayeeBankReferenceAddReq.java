package com.absa.amol.saving.model.standinginstruction.add;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PayeeBankReferenceAddReq {

	@Schema(description = "Field is conditional mandatory.For EBOX maxlength=3 and FCR maxlength=5", pattern = "[0-9]*",required = true)
	private Integer beneficiaryBranchCode;
	
	private String beneficiaryBankCode;
	private String beneficiaryBranchName;	
	private String beneficiaryBankName;
	private String routingNumber;

}
