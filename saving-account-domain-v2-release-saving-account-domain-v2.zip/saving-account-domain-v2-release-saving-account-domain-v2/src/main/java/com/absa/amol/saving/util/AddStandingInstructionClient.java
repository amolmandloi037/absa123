package com.absa.amol.saving.util;

import javax.ws.rs.BeanParam;
import javax.ws.rs.POST;

import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import com.absa.amol.saving.model.standinginstruction.add.StandingOrderAddReq;
import com.absa.amol.saving.model.standinginstruction.add.StandingOrderAddRes;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.model.ResponseEntity;

@RegisterRestClient(configKey = Constant.ADD_STANDING_INSTRUCTION_URL)
@RegisterProvider(value = ServerSideExceptionMapper.class)
public interface AddStandingInstructionClient {

	@POST
	public ResponseEntity<StandingOrderAddRes> addStandingInstruction(@BeanParam ApiRequestHeader apiRequestHeader,
			@RequestBody StandingOrderAddReq standingOrderAddReq);
}

