package com.absa.amol.saving.model.standinginstruction.retrieve;

import java.math.BigDecimal;

import javax.json.bind.annotation.JsonbProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FeeChargeRetRes {
	@JsonbProperty(nillable = true) private String chargeAmount;
	@JsonbProperty(nillable = true) private BigDecimal sucessServiceChargeAmount;
	@JsonbProperty(nillable = true) private BigDecimal failureServiceChargeAmount;
}