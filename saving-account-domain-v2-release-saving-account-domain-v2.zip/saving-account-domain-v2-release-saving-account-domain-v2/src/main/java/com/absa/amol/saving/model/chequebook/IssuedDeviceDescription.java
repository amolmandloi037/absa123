package com.absa.amol.saving.model.chequebook;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import com.absa.amol.saving.util.Constant;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class IssuedDeviceDescription {

	@Schema(description = "Field is mandatory for all flows.", minLength = 1, maxLength = 3,required = true)
	@Digits(integer = 3, fraction = 0, message = Constant.CHEQUE_BOOK_LEAF_SIZE_LENGTH_ERROR_MESSAGE)
	@NotNull(message = Constant.CHEQUE_BOOK_LEAF_SIZE_NOTNULLEMPTY_ERROR_MESSAGE)
	
	private Integer chequeBookleafSize;
}
