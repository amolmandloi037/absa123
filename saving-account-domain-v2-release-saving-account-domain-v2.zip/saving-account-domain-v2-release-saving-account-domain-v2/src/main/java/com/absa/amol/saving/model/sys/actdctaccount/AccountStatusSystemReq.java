package com.absa.amol.saving.model.sys.actdctaccount;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountStatusSystemReq {
	
	@NotNull(message = "accountId.null.empty.message")
	@NotEmpty(message = "accountId.null.empty.message")
	@Size(min = 1, max = 10, message = "accountId.length.message")
	private String accountId;
	
	@NotNull(message = "accounStatusIndicator.null.empty.message")
	@NotEmpty(message = "accounStatusIndicator.null.empty.message")
	private String accounStatusIndicator;
	
	@NotNull(message = "accountTitle.null.empty.message")
	@NotEmpty(message = "accountTitle.null.empty.message")
	private String accountTitle;
	
	private String branchCode;
	private String premierMembershipCentreCode;
	private String premierMembershipFeeIndicator;
	private String verification;



}
