package com.absa.amol.saving.service.impl;

import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import com.absa.amol.saving.model.AccountInquiryDetailsRequest;
import com.absa.amol.saving.model.AccountInquiryDetailsResponse;
import com.absa.amol.saving.model.AccountMasterMaintenance;
import com.absa.amol.saving.model.CustProdEligibilityRes;
import com.absa.amol.saving.model.CustomerSearchRequest;
import com.absa.amol.saving.model.SavingAccountDetailsRequest;
import com.absa.amol.saving.model.SavingAccountDetailsResponse;
import com.absa.amol.saving.model.SavingAccountSummaryResp;
import com.absa.amol.saving.model.retrievecasa.status.Status;
import com.absa.amol.saving.model.retrievecasa.status.SystemReplyMessage;
import com.absa.amol.saving.service.SavingAcctDetailsService;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.saving.util.CustomerAccountInquiryBrainsClient;
import com.absa.amol.saving.util.DomainMappingforBrains;
import com.absa.amol.saving.util.DomainMappingforFcr;
import com.absa.amol.saving.util.SavingAcctDetailsClient;
import com.absa.amol.saving.util.SearchCustomerSystemBrainsClient;
import com.absa.amol.util.exception.ApiException;
import com.absa.amol.util.exception.ApiResponseException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ResponseEntity;
import com.absa.amol.util.utility.CollectionUtil;
import com.absa.amol.util.utility.CommonUtil;
import com.absa.amol.util.utility.StringUtil;

@ApplicationScoped
public class SavingAcctDetailsServiceImpl implements SavingAcctDetailsService {

  @Inject
  @RestClient
  private SavingAcctDetailsClient savingAcctDetailsClient;

  @Inject
  @RestClient
  private SearchCustomerSystemBrainsClient customerSearch;

  @Inject
  @RestClient
  private CustomerAccountInquiryBrainsClient customerInq;

  @Inject
  private DomainMappingforBrains brainsMapping;

  @Inject
  private DomainMappingforFcr fcrMapping;

  private static final Logger logger = LoggerFactory.getLogger(SavingAcctDetailsServiceImpl.class);

  public Response getSavingAcctDetails(SavingAccountDetailsRequest casaAcctDetailsRequest) {

    String consUniqId = casaAcctDetailsRequest.getApiRequestHeader().getConsumerUniqueReferenceId();

    Response response = null;
    ResponseEntity<SavingAccountSummaryResp> entitySummary = null;
    ResponseEntity<SavingAccountDetailsResponse> casaEntity = null;

    logger.info(Constant.GET_SAVING_ACCOUNT_DETAILS, consUniqId,
        "inside Service : invoking system service client", "");
    try {
      response = savingAcctDetailsClient.getSavingAcctDetailsResponse(casaAcctDetailsRequest);

      logger.info(Constant.GET_SAVING_ACCOUNT_DETAILS, consUniqId,
          "Response Recieved from System Adapter", "");

      SavingAccountDetailsResponse casaDetailsResp = null;

      if (response.getStatus() == Constant.SUCCESS) {
        entitySummary =
            response.readEntity(new GenericType<ResponseEntity<SavingAccountSummaryResp>>() {});

        if (CommonUtil.isNotNull(entitySummary) && CommonUtil.isNotNull(entitySummary.getData())) {
          if (CommonUtil.isNotNull(entitySummary.getData().getAccount())) {

            AccountMasterMaintenance accResponse = entitySummary.getData().getAccount();
            // FCR success response
            if (CommonUtil.isNotNull(accResponse.getStatus())
                && accResponse.getStatus().getReplyCode().equals(Constant.REPLY_CODE_0)) {
              logger.info(Constant.GET_SAVING_ACCOUNT_DETAILS, consUniqId,
                  "Got Success Response from FCR",
                  accResponse.getStatus().getReplyCode().toString());
              casaDetailsResp = fcrMapping.getDomainMappingofAccDetailsFromFcr(
                  entitySummary.getData(), casaAcctDetailsRequest);
              logger.info(Constant.GET_SAVING_ACCOUNT_DETAILS, consUniqId,
                  "Mapping completed in fcr", "");
              casaEntity = new ResponseEntity<SavingAccountDetailsResponse>(entitySummary.getCode(),
                  entitySummary.getMessage(), entitySummary.getStatus(), casaDetailsResp);
            }
            // FCR FAILURES
            else if (CommonUtil.isNotNull(accResponse.getStatus())
                && (accResponse.getStatus().getReplyCode().equals(Constant.REPLY_CODE_30)
                    || accResponse.getStatus().getReplyCode() >= (Constant.REPLY_CODE_80))) {
              logger.info(Constant.GET_SAVING_ACCOUNT_DETAILS, consUniqId,
                  Constant.LOG_BUSINESS_MSG, accResponse.getStatus().getReplyCode().toString());
              casaEntity = new ResponseEntity<SavingAccountDetailsResponse>(
                  Constant.BAD_REQUEST_CODE, Constant.FAILURE_MSG,
                  getBusinessFailureMessage(accResponse.getStatus()), null);
            } else if (CommonUtil.isNotNull(accResponse.getStatus())
                && accResponse.getStatus().getReplyCode().equals(Constant.REPLY_CODE_40)) {
              logger.info(Constant.GET_SAVING_ACCOUNT_DETAILS, consUniqId,
                  Constant.LOG_BUSINESS_MSG, accResponse.getStatus().getReplyCode().toString());
              casaEntity = new ResponseEntity<SavingAccountDetailsResponse>(Constant.SUCCESS_CODE,
                  Constant.FAILURE_MSG, getBusinessFailureMessage(accResponse.getStatus()), null);
            }
          }
          // Brains success response
          else if (CommonUtil.isNotNull(entitySummary.getData().getAccountNumber())) {
            logger.info(Constant.GET_SAVING_ACCOUNT_DETAILS, consUniqId,
                "Got Success Response from Brains", "");
            casaDetailsResp = brainsMapping.getDomainMappingofAccDetailsFromBrains(
                entitySummary.getData(), casaAcctDetailsRequest);
            // *** Fetching Additional Account Info for BRAINS using CUS-I and ACC-LC Token ***//
            getAdditionalBrainsAccountDetails(casaAcctDetailsRequest, casaDetailsResp);
            logger.info(Constant.GET_SAVING_ACCOUNT_DETAILS, consUniqId,
                "Mapping completed in brains", "");
            casaEntity = new ResponseEntity<SavingAccountDetailsResponse>(entitySummary.getCode(),
                entitySummary.getMessage(), entitySummary.getStatus(), casaDetailsResp);
          }
        }
        // success but data null
        else {
          casaEntity = new ResponseEntity<SavingAccountDetailsResponse>(entitySummary.getCode(),
              entitySummary.getMessage(), entitySummary.getStatus(), null);
        }
        response = Response.ok(casaEntity).build();
      }
      return response;

    } catch (ApiException exception) {
      logger.error(Constant.GET_SAVING_ACCOUNT_DETAILS, consUniqId,
          Constant.EXCEPTION_OCCURED_FROM_SERVER, exception.getErrorMessage());
      logger.debug(Constant.GET_SAVING_ACCOUNT_DETAILS, consUniqId,
          Constant.EXCEPTION_OCCURED_FROM_SERVER, exception);
      throw exception;
    } catch (Exception exception) {
      logger.error(Constant.GET_SAVING_ACCOUNT_DETAILS, consUniqId,
          Constant.EXCEPTION_OCCURED_FROM_SERVER, exception.getMessage());
      logger.debug(Constant.GET_SAVING_ACCOUNT_DETAILS, consUniqId,
          Constant.EXCEPTION_OCCURED_FROM_SERVER, exception);
      throw new ApiResponseException("500", "Internal  Server Error");
    }
  }

  public String getBusinessFailureMessage(Status status) {
    logger.info("getBusinessFailureMessage", null, "Concatinating Business Error Messages", "");
    String message = "";

    if (CollectionUtil.isNotNullAndNotEmpty(status.getExtendedReply().getMessages().getItem())) {
      List<SystemReplyMessage> itemList = status.getExtendedReply().getMessages().getItem();
      for (SystemReplyMessage item : itemList) {
        message.concat(item.getMessage()).concat("\n");
      }
    }
    if (status.getReplyText() != null) {
      message.concat(status.getReplyText());
    }
    return message;
  }

  public void getAdditionalBrainsAccountDetails(SavingAccountDetailsRequest domainReq,
      SavingAccountDetailsResponse casaDetailsResp) {
    String consUniqId = "";
    final String method = "getAdditionalBrainsAccountDetails";
    ResponseEntity<CustProdEligibilityRes> searchEntity = null;
    ResponseEntity<AccountInquiryDetailsResponse> custInqEntity = null;
    try {
      consUniqId = domainReq.getApiRequestHeader().getConsumerUniqueReferenceId();
      logger.info(method, consUniqId, "Getting Additional Account Info", "START");

      CustomerSearchRequest req = new CustomerSearchRequest();
      req.setProductInstanceReference(domainReq.getAccountNumber());
      req.setBranchCode(domainReq.getBranchCode());
      req.setApiRequestHeader(domainReq.getApiRequestHeader());

      Response responseOne = customerSearch.getSearchCustomer(req);
      logger.info(method, consUniqId, "Account Search Response Status",
          "" + responseOne.getStatus());
      if (responseOne.getStatus() == Constant.SUCCESS) {
        searchEntity =
            responseOne.readEntity(new GenericType<ResponseEntity<CustProdEligibilityRes>>() {});
        if (searchEntity.getData() != null
            && searchEntity.getData().getProductServiceDetails() != null
            && searchEntity.getData().getProductServiceDetails().size() > 0
            && StringUtil.isStringNotNullAndNotEmpty(
                searchEntity.getData().getProductServiceDetails().get(0).getProductServiceId())) {
          logger.info(method, consUniqId, "Account Search Response", "Customer Number found");
          String custNo =
              searchEntity.getData().getProductServiceDetails().get(0).getProductServiceId();
          AccountInquiryDetailsRequest acctReq =
              new AccountInquiryDetailsRequest(domainReq.getApiRequestHeader(), custNo);
          Response responseTwo = customerInq.getCustomerAccountInquiry(acctReq);
          logger.info(method, consUniqId, "Customer Inquiry Response Status",
              "" + responseTwo.getStatus());
          if (responseTwo.getStatus() == Constant.SUCCESS) {
            custInqEntity = responseTwo
                .readEntity(new GenericType<ResponseEntity<AccountInquiryDetailsResponse>>() {});
            if (custInqEntity.getData() != null) {
              logger.info(method, consUniqId, "Customer Inquiry Response::Market Segment",
                  custInqEntity.getData().getMarketSegment());
              if (null == casaDetailsResp) {
                casaDetailsResp = new SavingAccountDetailsResponse();
              }
              casaDetailsResp.setMarketSegment(custInqEntity.getData().getMarketSegment());
              casaDetailsResp.setReferCode(custInqEntity.getData().getReferCode());
              casaDetailsResp.setPropositionTypeCode(custInqEntity.getData().getProposition());
              logger.info(method, consUniqId, "Customer Inquiry Response Mapping", "DONE");
            }
          }
        }
      }
    } catch (Exception ex) {
      logger.error(method, consUniqId, Constant.EXCEPTION_OCCURED_FROM_SERVER, ex.getMessage());
      logger.debug(method, consUniqId, Constant.EXCEPTION_OCCURED_FROM_SERVER, ex);
      throw new ApiResponseException("500", "Internal  Server Error");
    }
    logger.info(method, consUniqId, "Getting Additional Account Info", "END");
  }
}
