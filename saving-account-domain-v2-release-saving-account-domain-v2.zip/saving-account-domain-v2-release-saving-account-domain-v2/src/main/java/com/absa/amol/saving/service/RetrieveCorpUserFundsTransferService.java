package com.absa.amol.saving.service;

import javax.ws.rs.core.Response;
import com.absa.amol.saving.model.TransactionHistoryDomainRequest;

public interface RetrieveCorpUserFundsTransferService {

  public Response getRetrieveCorpUserFundsTransferServiceList(
      TransactionHistoryDomainRequest domainRequest);

  public Response getRetrieveCorpUserFundsTransferServiceDetails(
      TransactionHistoryDomainRequest domainRequest);

}
