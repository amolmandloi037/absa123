package com.absa.amol.saving.model.demanddraft;

import java.math.BigDecimal;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import com.absa.amol.saving.util.Constant;
import com.absa.amol.saving.util.Date;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class PaymentTransaction {

	@Valid
	private PayeeReference payeeReference;

	@Pattern(regexp = Constant.ONLY_CHARACTERS_REGEX, message = Constant.CURRENCY_CODE_PATTERN_ERROR_MESSAGE)
	@Size(min = 1, max = 3, message = Constant.CURRENCY_CODE_LENGTH_ERROR_MESSAGE)
	@NotNull(message = Constant.CURRENCY_CODE_NOTNULLEMPTY_ERROR_MESSAGE)
	@NotEmpty(message = Constant.CURRENCY_CODE_NOTNULLEMPTY_ERROR_MESSAGE)
	@Schema(description = "Field is mandatory", pattern = "only characters",minLength = 1, maxLength = 3, required = true)
	private String currencyCode;
	
	@Digits(integer = 5, fraction = 7, message = Constant.AMOUNT_LENGTH_ERROR_MESSAGE)
	@Schema(description = "Field is optional", pattern = "Numeric values (upto Integer = 5 and Decimal = 7)", maxLength = 12)
	private BigDecimal amount;
	
	@Valid
	private PaymentPurpose paymentPurpose;
	
	@Date(format = "ddMMyy", message =Constant.DATE_PATTERN_ERROR_MESSAGE)
	private String date;
	
	@Valid
	private PaymentMechanism paymentMechanism;
	
	@Valid
	private PayeeBankReference payeeBankReference;
	
	private String transactionDate;

}
