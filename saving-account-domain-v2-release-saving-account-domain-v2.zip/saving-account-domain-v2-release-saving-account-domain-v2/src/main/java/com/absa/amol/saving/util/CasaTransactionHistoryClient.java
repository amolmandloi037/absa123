package com.absa.amol.saving.util;

import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;
import com.absa.amol.saving.model.TransactionHistoryRequest;

@RegisterRestClient(configKey = "casaTransactionHistorySys")
@RegisterProvider(ServerSideExceptionMapper.class)
public interface CasaTransactionHistoryClient {

  @GET
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  public Response getCasaAcctTransactionHistoryResponse(
      @BeanParam TransactionHistoryRequest transactionHistoryRequest);

}
