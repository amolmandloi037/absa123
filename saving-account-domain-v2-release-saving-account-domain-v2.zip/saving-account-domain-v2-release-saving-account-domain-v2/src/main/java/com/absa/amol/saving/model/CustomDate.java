package com.absa.amol.saving.model;

import javax.xml.datatype.XMLGregorianCalendar;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class CustomDate {
  private Integer monthDate;
  private Long monthDateTime;
  private boolean mutable;
  private Long time;
  private XMLGregorianCalendar timestamp;
  private Integer year;
  private Long yearMonthDate;
}
