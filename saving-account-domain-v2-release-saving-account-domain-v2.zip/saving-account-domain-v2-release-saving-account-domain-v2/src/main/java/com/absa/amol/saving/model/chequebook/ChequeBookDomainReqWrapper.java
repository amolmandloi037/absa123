package com.absa.amol.saving.model.chequebook;

import javax.validation.Valid;
import javax.ws.rs.BeanParam;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import com.absa.amol.util.model.ApiRequestHeader;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ChequeBookDomainReqWrapper {

	@BeanParam
	@Schema(hidden = true)
	@Valid
	private ApiRequestHeader apiRequestHeader;
	
	@Valid
	private ChequeBookDomainReq chequeBookDomainReq;
}
