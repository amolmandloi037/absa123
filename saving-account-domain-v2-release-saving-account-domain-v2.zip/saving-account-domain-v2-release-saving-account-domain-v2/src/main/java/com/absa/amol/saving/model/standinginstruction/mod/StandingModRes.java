package com.absa.amol.saving.model.standinginstruction.mod;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StandingModRes {

	private PaymentTransactionModRes paymentTransaction;
	private StandingOrderReferenceModRes standingOrderReference;
}
