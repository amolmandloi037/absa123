
package com.absa.amol.saving.mapper;

import java.util.ArrayList;
import java.util.List;
import com.absa.amol.saving.model.AccountDTO;
import com.absa.amol.saving.model.CorpUserAuthDetailsDTO;
import com.absa.amol.saving.model.CorpUserFundsTransferInfoDTO;
import com.absa.amol.saving.model.DepositTransactionSourceReference;
import com.absa.amol.saving.model.FundTransferDetailsResponse;
import com.absa.amol.saving.model.MceDetailsResponse;
import com.absa.amol.saving.model.PayeeAccountReference;
import com.absa.amol.saving.model.PaymentMechanism;
import com.absa.amol.saving.model.PaymentPurpose;
import com.absa.amol.saving.model.PaymentTransaction;
import com.absa.amol.saving.model.PositionLimitType;
import com.absa.amol.saving.model.TransactionDescription;
import com.absa.amol.saving.model.TransactionHistoryDomainResponse;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.utility.CollectionUtil;
import com.absa.amol.util.utility.CommonUtil;
import com.absa.amol.util.utility.StringUtil;

public class TransactionHistoryMceDetailsResponseMapper {


  private static final Logger LOGGER =
      LoggerFactory.getLogger(TransactionHistoryMceDetailsResponseMapper.class);

  public TransactionHistoryDomainResponse fundsTransferDetailsResMapper(
      ApiRequestHeader apiRequestHeader, FundTransferDetailsResponse fundTransferDetailsResponse) {

    LOGGER.info("TransactionHistoryMceDetailsResponseMapper",
        Constant.getConsumerUniqueReferenceId(apiRequestHeader),
        "start of Mce response mapper Method", "");


    TransactionHistoryDomainResponse transactionDataDomain = new TransactionHistoryDomainResponse();
    // ****************************mapping start
    if (CommonUtil.isNotNull(fundTransferDetailsResponse) && CollectionUtil
        .isNotNullAndNotEmpty(fundTransferDetailsResponse.getCorpUserFundsTransferInfoList())) {
      List<MceDetailsResponse> mceDetailsResponseList = new ArrayList<>();

      List<CorpUserFundsTransferInfoDTO> corpUserFundsTransferInfoDTOList =
          fundTransferDetailsResponse.getCorpUserFundsTransferInfoList();


      for (CorpUserFundsTransferInfoDTO corpUserFundsTransferInfo : corpUserFundsTransferInfoDTOList) {
        MceDetailsResponse mceDetailsResponse = new MceDetailsResponse();
        PaymentTransaction transaction = new PaymentTransaction();
        PaymentMechanism mechanism = new PaymentMechanism();
        PayeeAccountReference payeeAccountReference = new PayeeAccountReference();
        DepositTransactionSourceReference depositTransactionSourceReference =
            new DepositTransactionSourceReference();

        AccountDTO accountCredit = corpUserFundsTransferInfo.getCreditAccount();
        AccountDTO accountDebit = corpUserFundsTransferInfo.getDebitAccount();

        PositionLimitType debitAmt = new PositionLimitType();
        debitAmt.setType("DebitAmount");
        debitAmt.setValue(corpUserFundsTransferInfo.getDebitAmount());
        PositionLimitType creditAmt = new PositionLimitType();
        creditAmt.setType("CreditAmount");
        creditAmt.setValue(corpUserFundsTransferInfo.getCreditAmount());

        mechanism.setFundsTransferType(corpUserFundsTransferInfo.getFundsTransferType());

        payeeAccountReference.setDebitAccountType(accountDebit.getAcctType());// confusion
        payeeAccountReference.setBeneficiaryName(corpUserFundsTransferInfo.getTxnBeneficiaryName());
        payeeAccountReference.setBenAccountNumber(accountCredit.getAccountNumber());
        payeeAccountReference.setBenAccountTypeCode(accountCredit.getAccountType());
        payeeAccountReference.setBenAccountCurrencyCode(accountCredit.getAccountCurrency());


        mceDetailsResponse.setEventByUserId(corpUserFundsTransferInfo.getInitiatedBy());
        mceDetailsResponse.setAuditType(corpUserFundsTransferInfo.getAuthLevel());
        mceDetailsResponse.setNameOnProbative(corpUserFundsTransferInfo.getCustomerFullName());
        mceDetailsResponse.setDebitAmount(debitAmt);
        mceDetailsResponse.setCreditAmount(creditAmt);

        depositTransactionSourceReference.setDebitAccountNumber(accountDebit.getAccountNumber());

        transaction.setCreateDateTime(corpUserFundsTransferInfo.getInitiatedDateTime());
        transaction.setTransactionCurrencyCode(accountDebit.getAccountCurrency());// confusion
        transaction.setTransactionLiteral(corpUserFundsTransferInfo.getTransactionStatus());

        transaction.setPayeeAccountReference(payeeAccountReference);
        transaction.setPaymentMechanism(mechanism);
        mceDetailsResponse.setDepositTransactionSourceReference(depositTransactionSourceReference);
        if (StringUtil.isStringNotNullAndNotEmpty(corpUserFundsTransferInfo.getTrxReferenceNumber())
            || StringUtil
                .isStringNotNullAndNotEmpty(corpUserFundsTransferInfo.getTrxSequenceNumber())) {
          PaymentPurpose paymentPurpose = new PaymentPurpose();
          paymentPurpose
              .setTransactionReferenceNumber(corpUserFundsTransferInfo.getTrxReferenceNumber());
          paymentPurpose
              .setTransactionSequenceNumber(corpUserFundsTransferInfo.getTrxSequenceNumber());
          transaction.setPaymentPurpose(paymentPurpose);
        }
        mceDetailsResponse.setPaymentTransaction(transaction);

        // if TransactionDescription respective isnot null auth values
        if (CollectionUtil
            .isNotNullAndNotEmpty(corpUserFundsTransferInfo.getCorpUserAuthDetailsList())) {
          List<TransactionDescription> transactionDescriptionList = new ArrayList<>();
          List<CorpUserAuthDetailsDTO> corpUserAuthDetailsDTOList =
              corpUserFundsTransferInfo.getCorpUserAuthDetailsList();
          for (CorpUserAuthDetailsDTO corpUserAuthDetailsDTO : corpUserAuthDetailsDTOList) {
            TransactionDescription transactionDescription = new TransactionDescription();
            transactionDescription.setAuthorisedBy(corpUserAuthDetailsDTO.getAuthorizedBy());
            transactionDescription
                .setAuthorisedDateTime(corpUserAuthDetailsDTO.getAuthorizedDateTime());
            transactionDescription.setAuthorizerName(corpUserAuthDetailsDTO.getAuthorizerName());
            transactionDescription.setDecision(corpUserAuthDetailsDTO.getDecision());
            transactionDescription.setRemarks(corpUserAuthDetailsDTO.getRemarks());
            transactionDescriptionList.add(transactionDescription);
          }
          mceDetailsResponse.setTransactionDescription(transactionDescriptionList);
        }
        /*
         * Fix for additional transaction details
         */
        if (CollectionUtil
            .isNotNullAndNotEmpty(corpUserFundsTransferInfo.getCorpUserOtherTxnDetails())) {
          mceDetailsResponse.setAdditionalTransactionDetails(
              corpUserFundsTransferInfo.getCorpUserOtherTxnDetails());
        }
        mceDetailsResponse.setRemarks(corpUserFundsTransferInfo.getRemarks());
        // set list or add values in list
        mceDetailsResponseList.add(mceDetailsResponse);
      }
      transactionDataDomain.setMceDetailsResponse(mceDetailsResponseList);
    }

    LOGGER.info("TransactionHistoryMceDetailsResponseMapper",
        Constant.getConsumerUniqueReferenceId(apiRequestHeader), "Mce response mapper Method",
        transactionDataDomain.toString());
    return transactionDataDomain;
  }

}

