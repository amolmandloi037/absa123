package com.absa.amol.saving.model.demanddraft;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import com.absa.amol.saving.util.Constant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Schema(name="DemandDraftDomainReq", description=" Domain Request Schema for requesting a Demand Draft by using given Customer Number or Account Number")
public class DemandDraftDomainReq {

	@Size(min=9,max = 12, message = Constant.DD_CUSTOMER_REFERENCE_LENGTH_ERROR_MESSAGE)
	@Pattern(regexp = Constant.BRANCH_ID_REGX, message = Constant.DD_CUSTOMER_REFERENCE_PATTERN_ERROR_MESSAGE)
	@Schema(description = "Field is optional", pattern = "only numeric", minLength=9,maxLength = 12)
	private String customerReference;

	@NotNull(message = Constant.BANK_BRANCH_REFERENCE_NOTNULLEMPTY_ERROR_MESSAGE)
	@Pattern(regexp = Constant.BRANCH_ID_REGX, message = Constant.BANK_BRANCH_REFERENCE_PATTERN_ERROR_MESSAGE)
	@NotEmpty(message = Constant.BANK_BRANCH_REFERENCE_NOTNULLEMPTY_ERROR_MESSAGE)
	@Size(min = 1, max = 5, message = Constant.BANK_BRANCH_REFERENCE_LENGTH_ERROR_MESSAGE)
	@Schema(description = "Field is mandatory", pattern = "only numeric",minLength = 1, maxLength = 5, required = true)
	private String bankBranchReference;

	@Pattern(regexp = Constant.BRANCH_ID_REGX, message = Constant.SAVINGS_ACCOUNT_NUMBER_PATTERN_ERROR_MESSAGE)
	@Size(min = 1, max = 16, message = Constant.SAVINGS_ACCOUNT_NUMBER_LENGTH_ERROR_MESSAGE)
	@NotNull(message = Constant.SAVINGS_ACCOUNT_NUMBER_NOTNULLEMPTY_ERROR_MESSAGE)
	@NotEmpty(message = Constant.SAVINGS_ACCOUNT_NUMBER_NOTNULLEMPTY_ERROR_MESSAGE)
	@Schema(description = "Field is mandatory", pattern = "only numeric",minLength = 1, maxLength = 16, required = true)
	private String savingsAccountNumber;

	@Valid
	private PaymentTransaction paymentTransaction;

	@Schema(description = "Field is optional", pattern = "only true or false")
	private Boolean isServiceChargeApplicable;

	@Schema(description = "Field is optional", pattern = "only numeric")
	private Integer transactionType;

}
