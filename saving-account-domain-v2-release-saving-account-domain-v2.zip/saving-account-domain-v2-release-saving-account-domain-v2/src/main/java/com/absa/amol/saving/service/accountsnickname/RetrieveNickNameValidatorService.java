package com.absa.amol.saving.service.accountsnickname;

import com.absa.amol.saving.model.accountsnickname.retrieve.RetrieveAccountsNickNameReq;

public interface RetrieveNickNameValidatorService {

	public void validateRequest(RetrieveAccountsNickNameReq retrieveAccountsNickNameReq);
}
