package com.absa.amol.saving.model.sys.demanddraft;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class SystemAddress {

	private String city;

	private String country;

	private String line1;

	private String line2;

	private String line3;

	private String state;

	private String zip;

}
