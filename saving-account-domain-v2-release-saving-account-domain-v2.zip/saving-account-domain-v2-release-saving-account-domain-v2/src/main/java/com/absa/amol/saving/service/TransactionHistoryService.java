package com.absa.amol.saving.service;

import javax.ws.rs.core.Response;
import com.absa.amol.saving.model.TransactionHistoryDomainRequest;

public interface TransactionHistoryService {

  public Response getTransactionHistoryResponse(
      TransactionHistoryDomainRequest transactionHistoryRequest);


}
