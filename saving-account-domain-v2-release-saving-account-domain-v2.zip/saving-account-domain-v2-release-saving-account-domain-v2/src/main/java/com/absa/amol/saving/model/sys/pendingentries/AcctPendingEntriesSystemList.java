package com.absa.amol.saving.model.sys.pendingentries;

import java.util.ArrayList;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class AcctPendingEntriesSystemList {
	private ArrayList<AcctPendingEntriesSystemRes> pendingEntriesList;
}
