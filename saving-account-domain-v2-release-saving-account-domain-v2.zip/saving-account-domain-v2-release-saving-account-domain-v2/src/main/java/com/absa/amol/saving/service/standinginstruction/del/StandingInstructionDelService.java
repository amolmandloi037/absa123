package com.absa.amol.saving.service.standinginstruction.del;

import com.absa.amol.saving.model.standinginstruction.del.StandingDelReq;
import com.absa.amol.saving.model.standinginstruction.del.StandingDelRes;
import com.absa.amol.util.model.ResponseEntity;

public interface StandingInstructionDelService {
	ResponseEntity<StandingDelRes> delStandingInstruction(StandingDelReq standingDelReq);
}
