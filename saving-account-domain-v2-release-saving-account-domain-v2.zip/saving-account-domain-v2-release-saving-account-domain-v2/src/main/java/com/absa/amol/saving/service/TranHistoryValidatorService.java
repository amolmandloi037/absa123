package com.absa.amol.saving.service;

import com.absa.amol.saving.model.TransactionHistoryDomainRequest;

public interface TranHistoryValidatorService {

  public void validateCasaRequest(TransactionHistoryDomainRequest accountRequest);
}
