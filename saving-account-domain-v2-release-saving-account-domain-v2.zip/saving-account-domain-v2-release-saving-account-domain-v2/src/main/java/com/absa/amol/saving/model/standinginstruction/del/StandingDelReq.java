package com.absa.amol.saving.model.standinginstruction.del;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.ws.rs.BeanParam;
import javax.ws.rs.QueryParam;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import com.absa.amol.util.model.ApiRequestHeader;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(name = "Delete Standing Instruction Request", description = "Request Schema for Delete Standing Instruction")
public class StandingDelReq {

	@Valid
    @BeanParam
    private ApiRequestHeader apiRequestHeader;
	
	@QueryParam("bankBranch")
	@Size(max = 5, message = "bank.branch.pattern.message")
	private String bankBranch;

    @QueryParam("accountNumber")
    @NotNull(message = "account.number.null.empty.message")
    @NotEmpty(message = "account.number.null.empty.message")
    @Size(max = 16, message = "account.number.pattern.message")
    private String accountNumber;
    
    @Valid
    @BeanParam
    private StandingOrderReferenceDelReq standingOrderReference;
}
