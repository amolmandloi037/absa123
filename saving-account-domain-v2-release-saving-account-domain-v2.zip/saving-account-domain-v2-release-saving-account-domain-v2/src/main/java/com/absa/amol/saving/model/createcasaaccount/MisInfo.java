package com.absa.amol.saving.model.createcasaaccount;

import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class MisInfo {

	@Size(min = 1, max = 9, message = "misInfo.code.length.error.message")
	private String code;

	@Size(min = 1, max = 15, message = "misInfo.type.length.error.message")
	private String type;

}
