package com.absa.amol.saving.service.impl.demanddraft;

import javax.inject.Inject;

import org.eclipse.microprofile.config.Config;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import com.absa.amol.saving.builder.DemandDraftRequestClientBuilder;
import com.absa.amol.saving.mapper.demanddraft.DemandDraftMapper;
import com.absa.amol.saving.model.demanddraft.DemandDraftDomainReqWrapper;
import com.absa.amol.saving.model.demanddraft.DemandDraftDomainRes;
import com.absa.amol.saving.model.sys.demanddraft.DemandDraftReq;
import com.absa.amol.saving.model.sys.demanddraft.DemandDraftRes;
import com.absa.amol.saving.service.demandraft.IDemandDraftService;
import com.absa.amol.saving.service.demandraft.IDemandDraftValidatorService;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.exception.ApiException;
import com.absa.amol.util.exception.ApiResponseException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ResponseEntity;

public class DemandDraftServiceImpl implements IDemandDraftService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DemandDraftServiceImpl.class);

	@Inject
	@RestClient
	DemandDraftRequestClientBuilder clientBuilder;

	@Inject
	DemandDraftMapper demandDraftMapper;

	@Inject 
	IDemandDraftValidatorService validatorService;

	@Inject
	Config config;
	
	@Override
	public ResponseEntity<DemandDraftDomainRes> demandDraftRequest(DemandDraftDomainReqWrapper reqWrapper) {
	
		LOGGER.info(Constant.DEMAND_DRAFT_SERVICE,reqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(),Constant.EMPTY,Constant.EMPTY);

		try {
			validatorService.validateInputRequest(reqWrapper.getDemandDraftDomainReq(), reqWrapper.getApiRequestHeader());
			DemandDraftReq demandDraftReq= demandDraftMapper.demandDraftReqmapping(reqWrapper);
			ResponseEntity<DemandDraftRes> response = clientBuilder.demandDraftSystemRequest(demandDraftReq, reqWrapper.getApiRequestHeader());
			ResponseEntity<DemandDraftDomainRes> responseEntity = demandDraftMapper.demandDraftResmapping(response);

			return responseEntity;
		}
		catch (ApiException apiException) {
			LOGGER.error(Constant.DEMAND_DRAFT_SERVICE, reqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(), Constant.API_EXCEPTION, apiException.getMessage());
			LOGGER.debug(Constant.DEMAND_DRAFT_SERVICE, reqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(), Constant.API_EXCEPTION, apiException);
			throw apiException;
		} catch (Exception exception) {
			LOGGER.error(Constant.DEMAND_DRAFT_SERVICE, reqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(), Constant.EXCEPTION, exception.getMessage());
			LOGGER.debug(Constant.DEMAND_DRAFT_SERVICE, reqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(), Constant.EXCEPTION, exception);
			throw new ApiResponseException(Constant.INTERNAL_ERROR_CODE, Constant.INTERNAL_ERROR_MSG);
		}
	}


}
