package com.absa.amol.saving.model.standinginstruction.add;

import java.math.BigDecimal;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentTransactionAddReq {

	@Schema(description = "Field is mandatory for all flows.", required = true)
	private BigDecimal amount;
	
	@Schema(description = "Field is mandatory for all flows.", required = true)
	private String currency;
	
	private PayeeAccountReferenceAddReq payeeAccountReference;
	private PayeeBankReferenceAddReq payeeBankReference;
	private PayeeReferenceAddReq payeeReference;
	private PaymentPurposeAddReq paymentPurpose;

}
