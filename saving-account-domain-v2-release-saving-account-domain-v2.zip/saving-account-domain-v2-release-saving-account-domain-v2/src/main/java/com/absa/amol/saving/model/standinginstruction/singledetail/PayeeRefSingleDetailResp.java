package com.absa.amol.saving.model.standinginstruction.singledetail;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PayeeRefSingleDetailResp 
{
	private String beneficiaryName;
	
	private String beneficiaryAddressLine1; //fcr
	
	private String beneficiaryAddressLine2; //fcr
	
	private String beneficiaryAddressLine3; //fcr
	
	private String beneficiaryAddressCity; //fcr
	
	private String beneficiaryAddressState; //fcr
	
	private String beneficiaryAddressZip; //fcr
	
	private String beneficiaryAddressCountry; //fcr
}
