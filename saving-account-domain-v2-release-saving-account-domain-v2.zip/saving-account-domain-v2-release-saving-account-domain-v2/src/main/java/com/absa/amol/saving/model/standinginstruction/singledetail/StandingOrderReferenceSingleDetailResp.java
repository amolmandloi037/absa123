package com.absa.amol.saving.model.standinginstruction.singledetail;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StandingOrderReferenceSingleDetailResp 
{
  private Integer terminationMethod; //ebox
  
  private String eofPeriodInd; //ebox
  
  private String noOfPayments; //ebox //earlier Integer
  
  private BigDecimal terminationAmount; //ebox
  
  private Integer standingOrderNumber; //FCR instruction number
  
  private String priority; //FCR
}
