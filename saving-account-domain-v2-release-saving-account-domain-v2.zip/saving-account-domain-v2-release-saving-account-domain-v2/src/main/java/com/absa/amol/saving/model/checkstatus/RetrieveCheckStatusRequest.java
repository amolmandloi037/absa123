package com.absa.amol.saving.model.checkstatus;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.ws.rs.BeanParam;
import javax.ws.rs.QueryParam;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import com.absa.amol.util.model.ApiRequestHeader;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor

public class RetrieveCheckStatusRequest {
	@Valid
	@BeanParam
	private ApiRequestHeader apiRequestHeader;

	@QueryParam("accountId")
	private String accountId;


	
	@QueryParam("chequeNumber")
	private String chequeNumber;

	

	@QueryParam("branchCode") private String branchCode;



	/*
	 * @Schema(hidden = true) private String configuredChannelId;
	 */


}
