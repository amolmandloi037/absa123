package com.absa.amol.saving.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class AccountCommonInformation {

  private Long customerNumber;
  private String accountNumber;
  private String currencyShortName;
  private String accountTitle;
  private Integer productCode;
  private String productName;
  private String accountLifecycleStatusCode;
  private Integer branchCode;
  private String branchName;
  private String branchShortName;
  private CustomDate accountOpeningDate;
  private String languageCode;
  private String fullName;
  private boolean restrictedAccountFlag;
  private boolean staffFlag;

}
