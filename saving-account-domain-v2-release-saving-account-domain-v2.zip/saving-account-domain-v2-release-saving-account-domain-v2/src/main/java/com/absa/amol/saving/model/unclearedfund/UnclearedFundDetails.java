package com.absa.amol.saving.model.unclearedfund;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class UnclearedFundDetails {

	private BigDecimal unclearAmount;
	private String unclearDate;
	private Integer unclearClearingDays;
	private String earDate;
	private String eARClearDate;
	private String eARNarration;
	private String eARDebitCreditIndicator;
	private BigDecimal earAmount;
}
