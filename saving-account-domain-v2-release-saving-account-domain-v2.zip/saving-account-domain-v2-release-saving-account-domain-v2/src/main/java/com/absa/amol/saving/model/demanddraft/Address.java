package com.absa.amol.saving.model.demanddraft;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import com.absa.amol.saving.util.Constant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Address {
	
	@Pattern(regexp = Constant.ONLY_SPACE_CHARACTERS_REGEX, message = Constant.CITY_NAME_PATTERN_ERROR_MESSAGE)
	@Size(max = 35, message = Constant.CITY_NAME_LENGTH_ERROR_MESSAGE)
	@Schema(description = "Field is optional", pattern = "only characters and space", maxLength = 35)
	private String cityName;

	@Pattern(regexp = Constant.ONLY_SPACE_CHARACTERS_REGEX, message = Constant.COUNTRY_NAME_PATTERN_ERROR_MESSAGE)
	@Size(max = 35, message = Constant.COUNTRY_NAME_LENGTH_ERROR_MESSAGE)
	@Schema(description = "Field is optional", pattern = "only characters and space", maxLength = 35)
	private String countryName;

	@Pattern(regexp = Constant.ONLY_SPACE_ALPHANUMERIC_REGEX, message = Constant.ADDRESS_LINE1_PATTERN_ERROR_MESSAGE)
	@Size(max = 35, message = Constant.ADDRESS_LINE1_LENGTH_ERROR_MESSAGE)
	@Schema(description = "Field is optional", pattern = "only alphanumeric and space", maxLength = 35)
	private String addressline1;

	@Pattern(regexp = Constant.ONLY_SPACE_ALPHANUMERIC_REGEX, message = Constant.ADDRESS_LINE2_PATTERN_ERROR_MESSAGE)
	@Size(max = 35, message = Constant.ADDRESS_LINE2_LENGTH_ERROR_MESSAGE)
	@Schema(description = "Field is optional", pattern = "only alphanumeric and space", maxLength = 35)
	private String addressline2;

	@Pattern(regexp = Constant.ONLY_SPACE_ALPHANUMERIC_REGEX, message = Constant.ADDRESS_LINE3_PATTERN_ERROR_MESSAGE)
	@Size(max = 35, message = Constant.ADDRESS_LINE3_LENGTH_ERROR_MESSAGE)
	@Schema(description = "Field is optional", pattern = "only alphanumeric and space", maxLength = 35)
	private String addressline3;
	
	@Pattern(regexp = Constant.ONLY_SPACE_CHARACTERS_REGEX, message = Constant.STATE_PATTERN_ERROR_MESSAGE)
	@Size(max = 35, message = Constant.STATE_LENGTH_ERROR_MESSAGE)
	@Schema(description = "Field is optional", pattern = "only characters and space", maxLength = 35)
	private String state;
	
	@Pattern(regexp = Constant.ONLY_SPACE_ALPHANUMERIC_REGEX, message = Constant.ZIP_CODE_PATTERN_ERROR_MESSAGE)
	@Size(max = 35, message = Constant.ZIP_CODE_LENGTH_ERROR_MESSAGE)
	@Schema(description = "Field is optional", pattern = "only alphanumeric and space", maxLength = 35)
	private String zipCode;
}
