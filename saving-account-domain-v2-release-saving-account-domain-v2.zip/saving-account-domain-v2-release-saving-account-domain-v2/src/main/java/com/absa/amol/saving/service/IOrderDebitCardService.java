package com.absa.amol.saving.service;

import com.absa.amol.saving.model.orderdebitcard.OrderDebitCardDomainReq;
import com.absa.amol.saving.model.orderdebitcard.OrderDebitCardDomainRes;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.model.ResponseEntity;

public interface IOrderDebitCardService {
	
	public ResponseEntity<OrderDebitCardDomainRes> orderDebitCard(ApiRequestHeader apiRequestHeader, OrderDebitCardDomainReq orderDebitCardDomainReq);

}
