package com.absa.amol.saving.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class AccountStatus {
  private String accountLifecycleStatusCode;
  private String accrualStatusCode;
  private String minorAccountStatusCode;
}
