package com.absa.amol.saving.model.chequebook;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BankBranch {
	
	@Schema(description = "Conditional mandatory", pattern = "[0-9]*",required = true)
	private Integer homeBranch;
	
	@Schema(description = "Conditional mandatory", required = true)
	private String collectionBranch;
}
