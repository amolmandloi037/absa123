package com.absa.amol.saving.model.sys.actdctaccount;

import javax.json.bind.annotation.JsonbProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class MessagesSys {
	
	@JsonbProperty(nillable= true)
	private String code;
	@JsonbProperty(nillable= true)
	private String message;

}
