package com.absa.amol.saving.service.impl.chequebook;

import javax.inject.Inject;

import org.eclipse.microprofile.rest.client.inject.RestClient;

import com.absa.amol.saving.builder.CustContactHistoryClientBuilder;
import com.absa.amol.saving.mapper.chequebook.CustContactHistorySysMapper;
import com.absa.amol.saving.model.chequebook.ChequeBookDomainReqWrapper;
import com.absa.amol.saving.model.sys.addcontacthistory.AddContactHistoryRequest;
import com.absa.amol.saving.service.chequebook.ICustContactHistoryService;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;

public class CustContactHistoryServiceImpl implements ICustContactHistoryService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CustContactHistoryServiceImpl.class);
	
	@Inject
	CustContactHistorySysMapper contactHistorySysMapper;

	@Inject
	@RestClient
	private CustContactHistoryClientBuilder addCustContactHistoryClientBuilder;

	public void addCustContactHistory(ChequeBookDomainReqWrapper chequeBookDomainReqWrapper) {
		LOGGER.info(Constant.ADD_CUST_CONTACT_HISTORY, chequeBookDomainReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(),Constant.EMPTY,Constant.EMPTY);
		try {
			AddContactHistoryRequest addContactHistoryRequest = contactHistorySysMapper.addContactHistorySysReqMapping(chequeBookDomainReqWrapper);
			addCustContactHistoryClientBuilder.addContactHistory(chequeBookDomainReqWrapper.getApiRequestHeader(), addContactHistoryRequest);
			LOGGER.info(Constant.ADD_CUST_CONTACT_HISTORY, chequeBookDomainReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(),"", "Successfully inserted in MCE");
		} catch (Exception ex) {
			LOGGER.error(Constant.ADD_CUST_CONTACT_HISTORY, chequeBookDomainReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(),"Exception", ex.getMessage());
			LOGGER.debug(Constant.ADD_CUST_CONTACT_HISTORY, chequeBookDomainReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(),"Exception", ex);
		}

	}

}
