package com.absa.amol.saving.service.impl.updtacctamendstatus;

import javax.inject.Inject;

import org.eclipse.microprofile.rest.client.inject.RestClient;

import com.absa.amol.saving.builder.UpdateAcctStatusClientBuilder;
import com.absa.amol.saving.mapper.updtacctamendstatus.UpdateAcctStatusReqMapper;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.saving.model.sys.updtacctamendstatus.AcctMngmtAmendReq;
import com.absa.amol.saving.model.sys.updtacctamendstatus.AcctMngmtAmendRes;
import com.absa.amol.saving.model.updtacctstatus.UpdateAcctStatusReqWrapper;
import com.absa.amol.saving.model.updtacctstatus.UpdateAcctStatusRes;
import com.absa.amol.saving.service.updtacctamendstatus.UpdateAcctStatusService;
import com.absa.amol.saving.service.updtacctamendstatus.UpdateAcctStatusValidatorService;
import com.absa.amol.util.exception.ApiException;
import com.absa.amol.util.exception.ApiRequestException;
import com.absa.amol.util.exception.ApiResponseException;
import com.absa.amol.util.exception.SORSystemServiceUnavailableException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ResponseEntity;
import com.absa.amol.util.utility.CommonUtil;

public class UpdateAcctStatusServiceImpl implements UpdateAcctStatusService {


	private static final Logger LOGGER = LoggerFactory.getLogger(UpdateAcctStatusServiceImpl.class);

	@Inject
	@RestClient
	private UpdateAcctStatusClientBuilder updateAcctStatusClientBuilder;

	@Inject 
	private UpdateAcctStatusReqMapper requestMapper;

	@Inject
	private UpdateAcctStatusValidatorService validatorService;

	@Override
	public ResponseEntity<UpdateAcctStatusRes> amendCustomerAccount(UpdateAcctStatusReqWrapper requestWrapper) {
		final String METHOD_NAME = "amendCustomerAccount";
		String consumerUniqRefId = requestWrapper.getApiRequestHeader().getConsumerUniqueReferenceId();
		LOGGER.info(METHOD_NAME, consumerUniqRefId, "Inside Method", Constant.BLANK);
		ResponseEntity<UpdateAcctStatusRes> updateAccountStatusRes = null;
		UpdateAcctStatusRes updateAccountStatusResponse = null;

		try {
			validatorService.validateInputRequest(requestWrapper);
			AcctMngmtAmendReq acctMngmtAmendReq = requestMapper.acctMngmtAmendSysReqMapping(requestWrapper);		
			ResponseEntity<AcctMngmtAmendRes> acctMngmtAmendSysRes = updateAcctStatusClientBuilder.amendCustomerAccount(requestWrapper.getApiRequestHeader(), acctMngmtAmendReq);

			if (CommonUtil.isNotNull(acctMngmtAmendSysRes.getData()) && Constant.SUCCESS_CODE.equals(acctMngmtAmendSysRes.getCode())) {
				AcctMngmtAmendRes acctMngmtAmendRes = acctMngmtAmendSysRes.getData();

				if(0 == (acctMngmtAmendRes.getResponseStatusAmend().getStatusCode()) &&
						"Success".equalsIgnoreCase(acctMngmtAmendRes.getResponseStatusAmend().getStatusDesc())) {
					LOGGER.info(METHOD_NAME, consumerUniqRefId, "System adapter call is successful", "Going to map domain response");
					updateAccountStatusResponse = new UpdateAcctStatusRes();
					updateAccountStatusResponse.setReferenceNumber(consumerUniqRefId);
					updateAccountStatusRes = new ResponseEntity<>(acctMngmtAmendSysRes.getCode(),
							acctMngmtAmendSysRes.getMessage(), acctMngmtAmendSysRes.getStatus(), updateAccountStatusResponse);

				} else {
					LOGGER.info(METHOD_NAME, consumerUniqRefId, "Got failed response from system adapter.", Constant.BLANK);
					updateAccountStatusRes = new ResponseEntity<>(acctMngmtAmendSysRes.getCode(),
							acctMngmtAmendSysRes.getMessage(), acctMngmtAmendSysRes.getStatus(), updateAccountStatusResponse);
				}
			} else {
				LOGGER.info(METHOD_NAME, consumerUniqRefId, "Data come as null.", Constant.BLANK);
				updateAccountStatusRes = new ResponseEntity<>(acctMngmtAmendSysRes.getCode(),
						acctMngmtAmendSysRes.getMessage(), acctMngmtAmendSysRes.getStatus(), updateAccountStatusResponse);
			}
		} catch (SORSystemServiceUnavailableException ex) {
			LOGGER.error(METHOD_NAME, consumerUniqRefId, "System adapter is unavailable",ex.getErrorMessage());
			LOGGER.debug(METHOD_NAME, consumerUniqRefId, "System adapter is unavailable - Debug", ex);
			throw new SORSystemServiceUnavailableException(Constant.FIVE_O_THREE, ex.getErrorMessage());
		} catch (ApiRequestException ex) {
			LOGGER.error(METHOD_NAME, consumerUniqRefId, "ApiRequestException occured for account status update", ex.getErrorMessage());
			LOGGER.debug(METHOD_NAME, consumerUniqRefId, "ApiRequestException occured for account status update - Debug", ex);
			throw new ApiRequestException(ex.getErrorCode(), ex.getErrorMessage());
		} catch (ApiException ex) {
			LOGGER.error(METHOD_NAME, consumerUniqRefId, "ApiException occured for account status update", ex.getMessage());
			LOGGER.debug(METHOD_NAME, consumerUniqRefId, "ApiException occured for account status update - Debug", ex);
			throw new ApiResponseException(ex.getErrorCode(), ex.getErrorMessage());
		} catch (Exception ex) {
			LOGGER.error(METHOD_NAME, consumerUniqRefId, "Exception occured for account status update", ex.getMessage());
			LOGGER.debug(METHOD_NAME, consumerUniqRefId, "Exception occured for account status update - Debug", ex);
			throw new ApiResponseException(Constant.INTERNAL_ERROR_CODE, Constant.INTERNAL_ERROR_MSG);
		}
		return updateAccountStatusRes;

	}	
}
