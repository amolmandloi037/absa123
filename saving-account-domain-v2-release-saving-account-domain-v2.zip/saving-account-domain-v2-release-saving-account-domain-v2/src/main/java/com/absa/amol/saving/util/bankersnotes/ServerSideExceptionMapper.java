package com.absa.amol.saving.util.bankersnotes;

import java.util.Arrays;
import java.util.List;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import org.eclipse.microprofile.rest.client.ext.ResponseExceptionMapper;

import com.absa.amol.util.exception.ApiException;
import com.absa.amol.util.exception.ApiRequestException;
import com.absa.amol.util.exception.ApiResponseException;
import com.absa.amol.util.exception.DownStreamSystemUnavailableException;
import com.absa.amol.util.exception.GlobalException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ResponseEntity;


public class ServerSideExceptionMapper implements ResponseExceptionMapper<Exception> {
  private static final Logger logger = LoggerFactory.getLogger(ServerSideExceptionMapper.class);
  private static final List<Integer> errorStatus = Arrays.asList(404, 500, 400);

  private static final String TOTHRWOWABLE = "toThrowable";

  @Override
  public boolean handles(int status, MultivaluedMap<String, Object> headers) {
    return errorStatus.contains(status);
  }

  @Override
  public ApiException toThrowable(Response response) {
    try {
      if (response.hasEntity() && !MediaType.TEXT_HTML_TYPE.equals(response.getMediaType())
          && response.getStatus() != 400) {
        ResponseEntity<?> responseEntity = response.readEntity(ResponseEntity.class);
        ApiResponseException exception =
            new ApiResponseException(responseEntity.getCode(), responseEntity.getMessage());
        logger.info(TOTHRWOWABLE, "", responseEntity.getMessage(), exception);
        return exception;

      } else if (response.getStatus() == 400) {
        ResponseEntity<?> responseEntity = response.readEntity(ResponseEntity.class);
        ApiRequestException exception =
            new ApiRequestException(responseEntity.getCode(), responseEntity.getMessage());
        logger.info(TOTHRWOWABLE, "", responseEntity.getMessage(), exception);
        return exception;
      } else {
        DownStreamSystemUnavailableException exception = new DownStreamSystemUnavailableException(
            "503", "System Adapter Service is unavailable");
        logger.info(TOTHRWOWABLE, "", "Raising DownStreamSystemUnavailableException exception",
            exception);
        return exception;
      }
    } catch (Exception ex) {
      return new GlobalException(CreditCardTransactionConstant.ERROR_CODE, "Internal Server Error..");
    }
  }
}
