package com.absa.amol.saving.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class InterestRate {

  private Float interestAmountSinceDormant;

  private Float debitRate1;

  private Float debitRate2;

  private Float creditRate1;

  private Float creditRate2;

}
