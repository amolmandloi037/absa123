package com.absa.amol.saving.service.impl.standinginstruction.del;

import javax.inject.Inject;

import org.eclipse.microprofile.rest.client.inject.RestClient;

import com.absa.amol.saving.builder.StandingInstructionDelClientBuilder;
import com.absa.amol.saving.model.standinginstruction.del.StandingDelReq;
import com.absa.amol.saving.model.standinginstruction.del.StandingDelRes;
import com.absa.amol.saving.service.standinginstruction.del.StandingInstructionDelService;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.exception.ApiException;
import com.absa.amol.util.exception.ApiResponseException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ResponseEntity;

public class StandingInstructionDelServiceImpl implements StandingInstructionDelService{
private static final Logger LOGGER = LoggerFactory.getLogger(StandingInstructionDelServiceImpl.class);
	
	@Inject
	@RestClient
	StandingInstructionDelClientBuilder clientBuilder;
	
	@Override
	public ResponseEntity<StandingDelRes> delStandingInstruction(StandingDelReq standingDelReq)  {
		LOGGER.info(Constant.DEL_STANDING_INSTRUCTION,standingDelReq.getApiRequestHeader().getConsumerUniqueReferenceId(), "", "");
		
		try {
		return clientBuilder.deleteStandingInstructionDetails(standingDelReq);
		}
		catch (ApiException apiException) {
			LOGGER.error(Constant.DEL_STANDING_INSTRUCTION, Constant.API_EXCEPTION, Constant.API_EXCEPTION, apiException.getMessage());
			LOGGER.debug(Constant.DEL_STANDING_INSTRUCTION, Constant.API_EXCEPTION, Constant.API_EXCEPTION, apiException);
			throw apiException;
		} catch (Exception exception) {
			LOGGER.error(Constant.DEL_STANDING_INSTRUCTION, Constant.EXCEPTION, Constant.EXCEPTION, exception.getMessage());
			LOGGER.debug(Constant.DEL_STANDING_INSTRUCTION, Constant.EXCEPTION, Constant.EXCEPTION, exception);
			throw new ApiResponseException(Constant.INTERNAL_ERROR_CODE, Constant.INTERNAL_ERROR_MSG);
		}
	}
}
	

