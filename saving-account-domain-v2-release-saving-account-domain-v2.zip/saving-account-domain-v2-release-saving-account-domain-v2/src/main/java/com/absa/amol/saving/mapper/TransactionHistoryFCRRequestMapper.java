package com.absa.amol.saving.mapper;

import com.absa.amol.saving.model.TransactionHistoryDomainRequest;
import com.absa.amol.saving.model.TransactionHistoryRequest;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.utility.StringUtil;

public class TransactionHistoryFCRRequestMapper {
  private static final Logger LOGGER =
      LoggerFactory.getLogger(TransactionHistoryFCRRequestMapper.class);

  public TransactionHistoryRequest fundsTransferDetailsReqMapper(ApiRequestHeader apiRequestHeader,
      TransactionHistoryDomainRequest transactionHistoryRequest) {
    LOGGER.info("SavingAccountDomainFCRRequestMapper",
        Constant.getConsumerUniqueReferenceId(apiRequestHeader),
        "start of  FCR request mapper Method", "");
    TransactionHistoryRequest request = new TransactionHistoryRequest();

    request.setApiRequestHeader(apiRequestHeader);
    request.setAccountId(transactionHistoryRequest.getSavingsAccountNumber());
    request.setBranchCode(transactionHistoryRequest.getBranchCode());
    request.setStartDate(transactionHistoryRequest.getStartDate());
    request.setEndDate(transactionHistoryRequest.getEndDate());
    request.setAmountStart(transactionHistoryRequest.getAmountStart());
    request.setAmountEnd(transactionHistoryRequest.getAmountEnd());
    if (StringUtil.isStringNotNullAndNotEmpty(transactionHistoryRequest.getPageNumber())) {
      request.setPageNo(transactionHistoryRequest.getPageNumber());
    } else {
      request.setPageNo("1");
    }
    if (StringUtil
        .isStringNotNullAndNotEmpty(transactionHistoryRequest.getNumberOfRecordsPerPage())) {
      request.setPageSize(transactionHistoryRequest.getNumberOfRecordsPerPage());
    }
    request.setDrCrInd(transactionHistoryRequest.getDebitCreditIndicator());

    LOGGER.info("SavingAccountDomainFCRRequestMapper",
        Constant.getConsumerUniqueReferenceId(apiRequestHeader), "FCR request mapper Method",
        request.toString());
    return request;
  }

}
