package com.absa.amol.saving.util;

import java.util.ArrayList;
import java.util.List;
import com.absa.amol.saving.model.AccountStatus;
import com.absa.amol.saving.model.ArrangementOption;
import com.absa.amol.saving.model.InterestAccrualType;
import com.absa.amol.saving.model.SavingAccountDetailsRequest;
import com.absa.amol.saving.model.SavingAccountDetailsResponse;
import com.absa.amol.saving.model.SavingAccountSummaryResp;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;

public class DomainMappingforBrains {

  private static final Logger logger = LoggerFactory.getLogger(DomainMappingforBrains.class);


  public SavingAccountDetailsResponse getDomainMappingofAccDetailsFromBrains(
      SavingAccountSummaryResp accIAResponse, SavingAccountDetailsRequest casaRequest) {

    logger.info("getDomainMappingofAccDetailsFromBrains",
        casaRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
        "Domain Mapping for Brains Started", "");

    SavingAccountDetailsResponse casaResp = new SavingAccountDetailsResponse();

    casaResp.setAccountNumber(accIAResponse.getAccountNumber());
    casaResp.setAccountCurrency(accIAResponse.getAccountCur());
    casaResp.setAccountTitle(accIAResponse.getLongName());
    casaResp.setProductCode(accIAResponse.getAccountType());
    casaResp.setProductTypeCode(accIAResponse.getTypeNarrative()); // product type code
    String accountLifecycleStatusCode =
        accIAResponse.getAccountStatus() != null ? accIAResponse.getAccountStatus().toString()
            : null;

    AccountStatus accStat = new AccountStatus();
    accStat.setAccountLifecycleStatusCode(accountLifecycleStatusCode);
    casaResp.setAccountStatus(accStat);

    if (null != accIAResponse.getCurAvailBal()) {
      casaResp.setAvailableBalance(accIAResponse.getCurAvailBal());
    }
    if (null != accIAResponse.getCurActBal()) {
      casaResp.setCurrentBalance(accIAResponse.getCurActBal());
    }

    casaResp.setBranchCode(accIAResponse.getBranchCode());

    if (null != accIAResponse.getCurUnclBal()) {
      casaResp.setTotalUnclearFundAmount(accIAResponse.getCurUnclBal());
    }
    if (null != accIAResponse.getCurEarBal()) {
      casaResp.setTotalCASAHoldAmount(accIAResponse.getCurEarBal().doubleValue());
    }
    if (accIAResponse.getDebitLimit().toString().indexOf("-") < 0) {
      if (null != accIAResponse.getDebitLimit()) {
        casaResp.setMinimumRequiredBalanceAmount(accIAResponse.getDebitLimit());
      }
    }
    if (null != accIAResponse.getCurAvailBal()) {
      casaResp.setNetAvailableBalanceForWithdrawal(accIAResponse.getCurAvailBal());
    }
    if (accIAResponse.getDebitLimit().toString().indexOf("-") >= 0) {

      Double creditInterestAccruedAmount = accIAResponse.getAccruuedCreditInterest() != null
          ? accIAResponse.getAccruuedCreditInterest().doubleValue()
          : null;

      Double debitInterestAccruedAmount = accIAResponse.getAccruedDebitInterest() != null
          ? accIAResponse.getAccruedDebitInterest().doubleValue()
          : null;

      Double overdraftLimitAmount =
          accIAResponse.getDebitLimit() != null ? accIAResponse.getDebitLimit().doubleValue()
              : null;

      List<InterestAccrualType> intereAccrList = new ArrayList<>();
      InterestAccrualType interestAccrualType =
          new InterestAccrualType("CreditInterestAccruedAmount", creditInterestAccruedAmount);
      intereAccrList.add(interestAccrualType);

      InterestAccrualType interestAccrualType2 =
          new InterestAccrualType("DebitInterestAccruedAmount", debitInterestAccruedAmount);
      intereAccrList.add(interestAccrualType2);
      casaResp.setInterestAccrualType(intereAccrList);

      ArrangementOption arrangeOpt = new ArrangementOption();
      arrangeOpt.setOverdraftLimitAmount(overdraftLimitAmount);
      casaResp.setArrangementOption(arrangeOpt);
    }
    if (casaRequest.getApiRequestHeader().getSystemId().equalsIgnoreCase("BRU")
        || casaRequest.getApiRequestHeader().getSystemId().equalsIgnoreCase("BKO")
        || casaRequest.getApiRequestHeader().getSystemId().equalsIgnoreCase("CCU")
        || casaRequest.getApiRequestHeader().getSystemId().equalsIgnoreCase("TLE")) {
      casaResp.setAddress1(accIAResponse.getAddress1());
      casaResp.setAddress2(accIAResponse.getAddress2());
      casaResp.setAddress3(accIAResponse.getAddress3());
    }
    casaResp.setMarketSegmentDesc(accIAResponse.getMarketSegmentNarrative());
    logger.info("getDomainMappingofAccDetailsFromBrains",
        casaRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
        "Domain mapping for brains completed", "");
    return casaResp;
  }
}
