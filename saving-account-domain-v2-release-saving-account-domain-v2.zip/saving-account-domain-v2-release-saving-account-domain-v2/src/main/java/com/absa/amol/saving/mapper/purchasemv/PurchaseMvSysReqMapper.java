package com.absa.amol.saving.mapper.purchasemv;

import com.absa.amol.saving.model.purchasemv.PaymentPurposeReq;
import com.absa.amol.saving.model.purchasemv.PaymentTransactionAmount;
import com.absa.amol.saving.model.purchasemv.PaymentTransactionReq;
import com.absa.amol.saving.model.purchasemv.PurchaseMvReq;
import com.absa.amol.saving.model.purchasemv.PurchaseMvReqWrapper;
import com.absa.amol.saving.model.sys.purchasemv.CashServiceMvPurchaseReq;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.utility.CommonUtil;

public class PurchaseMvSysReqMapper {

	private static final Logger LOGGER = LoggerFactory.getLogger(PurchaseMvSysReqMapper.class);

	public CashServiceMvPurchaseReq purchaseSysReqMapping(PurchaseMvReqWrapper requestWrapper) {
		final String METHOD_NAME = "purchaseSysReqMapping";
		String consumerUniqRefId = requestWrapper.getApiRequestHeader().getConsumerUniqueReferenceId();
		LOGGER.info(METHOD_NAME, consumerUniqRefId, "Going to map domain request to system adapter", "Inside Method");
		CashServiceMvPurchaseReq cashServiceMvPurchaseReq= new CashServiceMvPurchaseReq();
		PurchaseMvReq purchaseMvReq = requestWrapper.getPurchaseMvReq();
		cashServiceMvPurchaseReq.setCreatorAccount(purchaseMvReq.getSavingsAccountNumber());
		cashServiceMvPurchaseReq.setOperationId(requestWrapper.getOperationId());
		if(CommonUtil.isNotNull(purchaseMvReq.getPaymentTransaction())) {
			PaymentTransactionReq paymentTransactionReq= purchaseMvReq.getPaymentTransaction();
			if(CommonUtil.isNotNull(paymentTransactionReq.getPaymentPurpose())) {
				PaymentPurposeReq paymentPurposeReq = paymentTransactionReq.getPaymentPurpose();
				cashServiceMvPurchaseReq.setCreatorMobile(paymentPurposeReq.getSenderMobileNumber());
				cashServiceMvPurchaseReq.setRecipientMobile(paymentPurposeReq.getRecipientMobileNumber());
				cashServiceMvPurchaseReq.setVoucherPinblock(paymentPurposeReq.getVoucherPinBlock());
				cashServiceMvPurchaseReq.setVoucherPin(paymentPurposeReq.getVoucherPin());
			}
		}
		if(CommonUtil.isNotNull(purchaseMvReq.getPaymentTransactionAmount())) {
			PaymentTransactionAmount paymentTransactionAmount = purchaseMvReq.getPaymentTransactionAmount();
			cashServiceMvPurchaseReq.setVoucherValue(paymentTransactionAmount.getVoucherAmount());
			cashServiceMvPurchaseReq.setVoucherValueCurrency(paymentTransactionAmount.getVoucherCurrency());
		}
		return cashServiceMvPurchaseReq;
	}

}
