package com.absa.amol.saving.mapper.accountsnickname.add;

import java.util.ArrayList;
import java.util.List;

import com.absa.amol.saving.model.accountsnickname.add.AddAccountsNickNameReq;
import com.absa.amol.saving.model.sys.accountsnickname.add.AddAccountsNickNameSystemMceRequest;
import com.absa.amol.saving.model.sys.accountsnickname.add.CustomerAccountDet;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ApiRequestHeader;

public class AddAccountsNicknameMapper {

	private static final Logger LOGGER = LoggerFactory.getLogger(AddAccountsNicknameMapper.class);

	public AddAccountsNickNameSystemMceRequest getAddAccountsNicknameReqMapping(ApiRequestHeader requestHeader, AddAccountsNickNameReq addAccountsNickNameReq) {
		LOGGER.info(Constant.M_ADD_UPDATE_ACCOUNTS_NICKNAME_REQ_MAPPING, requestHeader.getConsumerUniqueReferenceId(), Constant.BLANK, "Inside Method");
		
		List<CustomerAccountDet> accountList = new ArrayList<>();
		
		AddAccountsNickNameSystemMceRequest addAccountsNickNameSystemMceRequest = new AddAccountsNickNameSystemMceRequest();
		addAccountsNickNameSystemMceRequest.setScvID(addAccountsNickNameReq.getCustomerReference());
		
		CustomerAccountDet accountDetails = new CustomerAccountDet();
		accountDetails.setAccountNickName(addAccountsNickNameReq.getAccountNickName());
		accountDetails.setAccountNumber(addAccountsNickNameReq.getAccountNumber());
		accountDetails.setBranchCode(addAccountsNickNameReq.getBankBranchCode().toString());
		accountList.add(accountDetails);
		
		addAccountsNickNameSystemMceRequest.setCustomerAccountList(accountList);
		
		LOGGER.info(Constant.M_ADD_UPDATE_ACCOUNTS_NICKNAME_REQ_MAPPING, requestHeader.getConsumerUniqueReferenceId(), Constant.BLANK, "Request constructed successfully");
		return addAccountsNickNameSystemMceRequest;
	}

}
