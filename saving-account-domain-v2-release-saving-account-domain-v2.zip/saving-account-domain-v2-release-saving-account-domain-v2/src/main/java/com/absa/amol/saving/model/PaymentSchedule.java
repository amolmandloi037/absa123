package com.absa.amol.saving.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class PaymentSchedule {

  private String frequency;
  private String frequencyData;
  private String nextDueDate;
}
