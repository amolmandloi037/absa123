package com.absa.amol.saving.model;

import java.util.List;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
@Schema(name = "CorpuserFTListResponse",
    description = "POJO for Corpuser FT List Response Response.")
public class CorpuserFTListResponse {


  private Integer totalNumberOfRecords;
  private List<TrxnDetails> trxnDetails;
  private String serviceResponseCode;
  private String errorMessage;



}
