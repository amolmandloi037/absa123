package com.absa.amol.saving.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class TrxnDetails {
  private String transactionDateTime;
  private String transactionTypeCode;
  private String transactionCurrencyAmount;
  private String transactionReferenceNumber;
  private String benAccountNumber;
  private String beneficiaryName;
  private String transactionSeqNumber;
}
