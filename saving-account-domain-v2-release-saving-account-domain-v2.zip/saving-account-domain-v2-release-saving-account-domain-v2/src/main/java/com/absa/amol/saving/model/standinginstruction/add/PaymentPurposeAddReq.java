package com.absa.amol.saving.model.standinginstruction.add;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentPurposeAddReq {
	
	private String narrative;

	private String benAddNarrative;
	private String benNarrative;	
	
	private String benRegionCode;
	private String remAddNarrative;
	private String remNarrative;

}
