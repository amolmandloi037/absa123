package com.absa.amol.saving.service.impl;

import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import com.absa.amol.saving.model.FcrTransactionStatus;
import com.absa.amol.saving.model.SystemReplyMessage;
import com.absa.amol.saving.mapper.TransactionHistoryFCRRequestMapper;
import com.absa.amol.saving.mapper.TransactionHistoryFCRResponseMapper;
import com.absa.amol.saving.model.TransactionHistoryDomainRequest;
import com.absa.amol.saving.model.TransactionHistoryDomainResponse;
import com.absa.amol.saving.model.TransactionHistoryRequest;
import com.absa.amol.saving.model.TransactionHistoryResponse;
import com.absa.amol.saving.service.RetrieveCorpUserFundsTransferService;
import com.absa.amol.saving.service.TransactionHistoryService;
import com.absa.amol.saving.util.CasaTransactionHistoryClient;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.exception.ApiException;
import com.absa.amol.util.exception.ApiResponseException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ResponseEntity;
import com.absa.amol.util.utility.CollectionUtil;
import com.absa.amol.util.utility.CommonUtil;
import com.absa.amol.util.utility.StringUtil;

@ApplicationScoped
public class TransactionHistoryServiceImpl implements TransactionHistoryService {



  @Inject
  @RestClient
  private CasaTransactionHistoryClient transactionHistoryClient;

  @Inject
  private RetrieveCorpUserFundsTransferService corpUserFTService;

  @Inject
  private TransactionHistoryFCRRequestMapper tranHistoryFCRRequestMapper;

  @Inject
  private TransactionHistoryFCRResponseMapper tranHistoryFCRResponseMapper;

  private static final Logger logger = LoggerFactory.getLogger(TransactionHistoryServiceImpl.class);

  @Override
  public Response getTransactionHistoryResponse(
      TransactionHistoryDomainRequest transactionHistoryRequest) {



    ResponseEntity<TransactionHistoryResponse> entitySummary = null;
    ResponseEntity<TransactionHistoryResponse> responseEntityFailure = null;
    Response domainResponse = null;
    ResponseEntity<TransactionHistoryDomainResponse> casaEntity = null;

    logger.info(Constant.GET_TRANSACTION_HISTORY_RESPONSE,
        transactionHistoryRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
        "inside Service : start of fetching transaction history reponse", "");
    try {
      if (StringUtil.isStringNotNullAndNotEmpty(transactionHistoryRequest.getActionCode())) {

        logger.info(Constant.GET_TRANSACTION_HISTORY_RESPONSE,
            transactionHistoryRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
            "# # # inside getTransactionHistoryService ACTIONCODE  ",
            transactionHistoryRequest.getActionCode());
        if (transactionHistoryRequest.getActionCode().equals("DETAILS")) {

          logger.info(Constant.GET_TRANSACTION_HISTORY_RESPONSE,
              transactionHistoryRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
              " DETAILS inside getTransactionHistoryService ACTIONCODE  ",
              transactionHistoryRequest.getActionCode());

          logger.info(Constant.GET_TRANSACTION_HISTORY_RESPONSE,
              transactionHistoryRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
              "LIST inside getTransactionHistoryService ACTIONCODE  ",
              transactionHistoryRequest.getActionCode());
          return corpUserFTService
              .getRetrieveCorpUserFundsTransferServiceDetails(transactionHistoryRequest);

        } else if (transactionHistoryRequest.getActionCode().equals("LIST")) {
          return corpUserFTService
              .getRetrieveCorpUserFundsTransferServiceList(transactionHistoryRequest);
        }
      } else {

        logger.info(Constant.GET_TRANSACTION_HISTORY_RESPONSE,
            transactionHistoryRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
            "inside getTransactionHistoryResponse : invoking system service client", "");

        Response casaAcctResponse = null;

        TransactionHistoryRequest historyRequest =
            tranHistoryFCRRequestMapper.fundsTransferDetailsReqMapper(
                transactionHistoryRequest.getApiRequestHeader(), transactionHistoryRequest);

        casaAcctResponse =
            transactionHistoryClient.getCasaAcctTransactionHistoryResponse(historyRequest);

        TransactionHistoryResponse tranHistoryResponse = null;

        logger.info(Constant.GET_TRANSACTION_HISTORY_RESPONSE,
            transactionHistoryRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
            "inside RetrieveCorpUserFundsTransferServiceList : Response recived ",
            "Status Code : " + casaAcctResponse.getStatus());

        if (casaAcctResponse.getStatus() == Constant.SUCCESS) {
          entitySummary = casaAcctResponse
              .readEntity(new GenericType<ResponseEntity<TransactionHistoryResponse>>() {});
          if (CommonUtil.isNotNull(entitySummary)
              && CommonUtil.isNotNull(entitySummary.getData())) {
            tranHistoryResponse = entitySummary.getData();

            if (CommonUtil.isNotNull(tranHistoryResponse.getStatus())
                && tranHistoryResponse.getStatus().getReplyCode().equals(Constant.REPLY_CODE_30)) {
              logger.info(Constant.GET_TRANSACTION_HISTORY_LIST,
                  Constant.getConsumerUniqueReferenceId(
                      transactionHistoryRequest.getApiRequestHeader()),
                  Constant.LOG_BUSINESS_MSG,
                  tranHistoryResponse.getStatus().getReplyCode().toString());
              return getBusinessFailureResponse(entitySummary);
            } else if (CommonUtil.isNotNull(tranHistoryResponse.getStatus())
                && tranHistoryResponse.getStatus().getReplyCode().equals(Constant.REPLY_CODE_40)) {
              logger.info(Constant.GET_TRANSACTION_HISTORY_LIST,
                  Constant.getConsumerUniqueReferenceId(
                      transactionHistoryRequest.getApiRequestHeader()),
                  Constant.LOG_BUSINESS_MSG,
                  tranHistoryResponse.getStatus().getReplyCode().toString());
              return getBusinessFailureResponse(entitySummary);
            } else if (CommonUtil.isNotNull(tranHistoryResponse.getStatus())
                && tranHistoryResponse.getStatus().getReplyCode().equals(Constant.REPLY_CODE_80)) {
              logger.info(Constant.GET_TRANSACTION_HISTORY_LIST,
                  Constant.getConsumerUniqueReferenceId(
                      transactionHistoryRequest.getApiRequestHeader()),
                  Constant.LOG_BUSINESS_MSG,
                  tranHistoryResponse.getStatus().getReplyCode().toString());
              return getBusinessFailureResponse(entitySummary);
            } else {


              TransactionHistoryDomainResponse domainReponseData = tranHistoryFCRResponseMapper
                  .transactionHistoryResMapper(transactionHistoryRequest.getApiRequestHeader(),
                      entitySummary.getData(), transactionHistoryRequest.getDebitCreditIndicator());
              casaEntity =
                  new ResponseEntity<TransactionHistoryDomainResponse>(entitySummary.getCode(),
                      entitySummary.getMessage(), entitySummary.getStatus(), domainReponseData);
              domainResponse = Response.ok(casaEntity).build();

              logger.info(Constant.GET_TRANSACTION_HISTORY_RESPONSE,
                  transactionHistoryRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
                  "Received success response from system service",
                  "Status Code : " + casaAcctResponse.getStatus());
              return domainResponse;
            }
          } else {

            logger.info(Constant.GET_TRANSACTION_HISTORY_LIST,
                transactionHistoryRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
                "Received success response from system service; but data not found ", "");

            responseEntityFailure = new ResponseEntity<>(entitySummary.getCode(), null,
                entitySummary.getStatus(), null);
            responseEntityFailure.setCode(Constant.SUCCESS_CODE);
            responseEntityFailure.setMessage(Constant.NO_RECORD_FOUND);
            responseEntityFailure.setStatus(Constant.SUCCESS_MSG);

            return Response.ok(responseEntityFailure).build();
          }

        }
      }
    } catch (ApiException exception) {
      logger.error(Constant.GET_TRANSACTION_HISTORY_RESPONSE,
          transactionHistoryRequest.getApiRequestHeader().getCorrelationId(),
          Constant.EXCEPTION_OCCURED_FROM_SERVER, exception.getErrorMessage());
      logger.debug(Constant.GET_TRANSACTION_HISTORY_RESPONSE,
          transactionHistoryRequest.getApiRequestHeader().getCorrelationId(),
          Constant.EXCEPTION_OCCURED_FROM_SERVER, exception);
      throw exception;
    } catch (Exception exception) {

      logger.error(Constant.GET_TRANSACTION_HISTORY_RESPONSE,
          transactionHistoryRequest.getApiRequestHeader().getCorrelationId(),
          Constant.EXCEPTION_OCCURED_FROM_SERVER, exception.getMessage());
      logger.debug(Constant.GET_TRANSACTION_HISTORY_RESPONSE,
          transactionHistoryRequest.getApiRequestHeader().getCorrelationId(),
          Constant.EXCEPTION_OCCURED_FROM_SERVER, exception);
      throw new ApiResponseException("500", "Internal  Server Error");
    }
    return null;


  }

  public Response getBusinessFailureResponse(
      ResponseEntity<TransactionHistoryResponse> responseEntity) {
    ResponseEntity<TransactionHistoryDomainResponse> responseEntityFailure =
        new ResponseEntity<>(responseEntity.getCode(), null, responseEntity.getStatus(), null);

    responseEntityFailure.setCode(Constant.BAD_REQUEST_CODE);
    responseEntityFailure.setStatus(Constant.FAILURE_MSG);
    responseEntityFailure
        .setMessage(getBusinessFailureMessage(responseEntity.getData().getStatus()));
    // create response
    return Response.status(Integer.parseInt(responseEntityFailure.getCode()))
        .entity(responseEntityFailure).build();

  }

  public Response getBusinessFailureResponseSuccess(
      ResponseEntity<TransactionHistoryResponse> responseEntity) {
    ResponseEntity<TransactionHistoryDomainResponse> responseEntityFailure =
        new ResponseEntity<>(responseEntity.getCode(), null, responseEntity.getStatus(), null);
    responseEntityFailure.setCode(Constant.SUCCESS_CODE);
    responseEntityFailure.setStatus(Constant.FAILURE_MSG);
    responseEntityFailure
        .setMessage(getBusinessFailureMessage(responseEntity.getData().getStatus()));
    return Response.status(Integer.parseInt(responseEntityFailure.getCode()))
        .entity(responseEntityFailure).build();
  }

  public String getBusinessFailureMessage(FcrTransactionStatus status) {
    logger.info(Constant.GET_TRANSACTION_HISTORY_RESPONSE, null,
        "Concatinating Business Error Messages", "");
    String message = "";

    if (CollectionUtil.isNotNullAndNotEmpty(status.getExtendedReply().getMessages().getItem())) {
      List<SystemReplyMessage> itemList = status.getExtendedReply().getMessages().getItem();
      for (SystemReplyMessage item : itemList) {
        message.concat(item.getMessage()).concat("\n");
      }
    }
    if (status.getReplyText() != null) {
      message.concat(status.getReplyText());
    }
    return message;
  }

}
