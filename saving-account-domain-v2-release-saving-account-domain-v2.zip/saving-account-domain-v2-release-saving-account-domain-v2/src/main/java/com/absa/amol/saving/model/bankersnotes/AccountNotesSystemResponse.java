package com.absa.amol.saving.model.bankersnotes;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class AccountNotesSystemResponse {
	private String  memoType;
	private String  memoText;
	private String  lastMaintanenceDate;
	private String  severity ;
	private String  savingsAccountNumber;
	private String notesLine1;
	private String notesLine2;
	private String notesLine3;

}
