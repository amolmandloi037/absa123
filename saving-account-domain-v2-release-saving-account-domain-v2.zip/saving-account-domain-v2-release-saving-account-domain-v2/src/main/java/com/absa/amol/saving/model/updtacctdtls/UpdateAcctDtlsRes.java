package com.absa.amol.saving.model.updtacctdtls;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UpdateAcctDtlsRes {
	
	private String referenceNumber;

}
