package com.absa.amol.saving.service;

import com.absa.amol.saving.model.acctearmarkpendingentries.AcctEarmarkPendingEntriesDomainRequest;

public interface AccountEarmarkPendingEntriesValidatorService {
	public void validateEarmarkRequest(AcctEarmarkPendingEntriesDomainRequest req);
}
