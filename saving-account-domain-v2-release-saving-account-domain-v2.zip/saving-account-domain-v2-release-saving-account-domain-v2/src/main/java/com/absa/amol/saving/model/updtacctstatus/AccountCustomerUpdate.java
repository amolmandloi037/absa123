package com.absa.amol.saving.model.updtacctstatus;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountCustomerUpdate {

	@Schema(description = "Mandatory field", pattern = "Numeric", maxLength = 9, required = true)
	@NotNull(message = "customerReference.notnullempty.error.message")
	@NotEmpty(message = "customerReference.notnullempty.error.message")
	@Pattern(regexp="[0-9]{1,9}", message="customerReference.regex.error.message")
	private String customerReference;
	
	@Schema(description = "Optional field", pattern = "Alpha-Numeric", maxLength = 9, required = false)
	@Pattern(regexp="[a-zA-Z0-9]{1,9}?|", message="accountStatus.regex.error.message")
	private String accountStatus;
	
	@Valid
	private Date date;
	
	@Schema(description = "Optional field", pattern = "Free Field", maxLength = 60, required = false)
	@Pattern(regexp=".{1,60}?|", message="comments.regex.error.message")
	private String comments;
	
	@Valid
	private AccountDetails accountDetails;
	
	@Schema(description = "Optional field", pattern = "Alpha-Numeric", maxLength = 1, required = false)
	@Pattern(regexp="[sSjJoOmMtT]{1}?|", message="associationType.regex.error.message")
	private String associationType;
	
}
