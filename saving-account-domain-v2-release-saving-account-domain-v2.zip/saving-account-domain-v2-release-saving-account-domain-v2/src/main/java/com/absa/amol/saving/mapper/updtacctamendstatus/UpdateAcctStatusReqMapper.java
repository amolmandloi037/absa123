package com.absa.amol.saving.mapper.updtacctamendstatus;

import java.util.ArrayList;
import java.util.List;

import com.absa.amol.saving.model.sys.updtacctamendstatus.AccountCustomerUpdateAmend;
import com.absa.amol.saving.model.sys.updtacctamendstatus.AcctMngmtAmendReq;
import com.absa.amol.saving.model.updtacctstatus.AccountCustomerUpdate;
import com.absa.amol.saving.model.updtacctstatus.AccountDetails;
import com.absa.amol.saving.model.updtacctstatus.BankBranch;
import com.absa.amol.saving.model.updtacctstatus.Date;
import com.absa.amol.saving.model.updtacctstatus.ProductInstanceReference;
import com.absa.amol.saving.model.updtacctstatus.UpdateAcctStatusReq;
import com.absa.amol.saving.model.updtacctstatus.UpdateAcctStatusReqWrapper;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.utility.CommonUtil;

public class UpdateAcctStatusReqMapper {

	private static final Logger LOGGER = LoggerFactory.getLogger(UpdateAcctStatusReqMapper.class);

	public AcctMngmtAmendReq acctMngmtAmendSysReqMapping(UpdateAcctStatusReqWrapper requestWrapper) {
		final String METHOD_NAME = "acctMngmtAmendSysReqMapping";
		String consumerUniqRefId = requestWrapper.getApiRequestHeader().getConsumerUniqueReferenceId();
		LOGGER.info(METHOD_NAME, consumerUniqRefId, "Going to map domain request to system adapter", "Inside Method");
		AcctMngmtAmendReq acctMngmtAmendSysReq= new AcctMngmtAmendReq();
		UpdateAcctStatusReq updateAcctStatusReq = requestWrapper.getUpdateAcctStatusReq();
		
		ProductInstanceReference productInstanceReference = updateAcctStatusReq.getProductInstanceReference();
		if(CommonUtil.isNotNull(productInstanceReference)) {
			acctMngmtAmendSysReq.setAccountId(productInstanceReference.getAccountNumber());
		}
		
		BankBranch bankBranch = updateAcctStatusReq.getBankBranch();
		if(CommonUtil.isNotNull(bankBranch)) {
			acctMngmtAmendSysReq.setBranchCode(bankBranch.getBranchNumber());
		}
		
		List<AccountCustomerUpdate> accountCustomerUpdateList = updateAcctStatusReq.getAccountCustomerUpdates();
		if(CommonUtil.isNotNull(accountCustomerUpdateList)) {
			List<AccountCustomerUpdateAmend> accountCustomerUpdateSysList = new ArrayList<>();
			for(AccountCustomerUpdate data : accountCustomerUpdateList) {
				AccountCustomerUpdateAmend accountCustomerUpdateAmend = new AccountCustomerUpdateAmend();
				accountCustomerUpdateAmend.setCustomerNumber(data.getCustomerReference());
				accountCustomerUpdateAmend.setContactStatus(data.getAccountStatus());
				
				Date date = data.getDate();
				if(CommonUtil.isNotNull(date)) {
					accountCustomerUpdateAmend.setContactStatusDate(date.getContactStatusDate());
				}				
				if(CommonUtil.isNotNull(bankBranch)) {
					accountCustomerUpdateAmend.setContactBranch(bankBranch.getContactBranch());
				}
				accountCustomerUpdateAmend.setComments(data.getComments());				
				AccountDetails accountDetails = data.getAccountDetails();
				if(CommonUtil.isNotNull(accountDetails)) {
					accountCustomerUpdateAmend.setPrimaryAccountIndicator(accountDetails.getPrimaryAccountIndicator());
					accountCustomerUpdateAmend.setCashbackAccountIndicator(accountDetails.getCashbackAccountNumber());
				}
				accountCustomerUpdateAmend.setAccountAssociation(data.getAssociationType());
				accountCustomerUpdateSysList.add(accountCustomerUpdateAmend);
			}
			acctMngmtAmendSysReq.setAccountCustomerUpdateAmend(accountCustomerUpdateSysList);
		}
		
		return acctMngmtAmendSysReq;
	}
}
