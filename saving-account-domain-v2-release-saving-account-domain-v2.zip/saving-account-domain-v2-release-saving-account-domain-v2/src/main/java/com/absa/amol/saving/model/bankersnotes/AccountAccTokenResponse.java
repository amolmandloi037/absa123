package com.absa.amol.saving.model.bankersnotes;

import java.math.BigDecimal;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Schema(name = "AccountAccTokenResponse",
    description = "Response Schema for account management system adapter")
public class AccountAccTokenResponse {
  private Integer availInd;
  private String branchCode;
  private String accountNumber;
  private String shortName;
  private String longName;
  private Integer accountStatus;
  private Integer accountType;
  private Integer externalInd;
  private String accountCur;
  private Integer referDebits;
  private Integer referCredits;
  private Integer referNonChequeDebits;
  private Integer earmarksInd;
  private Integer stoppedChequesInd;
  private Integer signaturesInd;
  private Integer notesInd;
  private Integer pendingItemsInd;
  private Integer addressInd;
  private Integer designationId;
  private String stmtFreq;
  private String lastStmtDate;
  private String stmtFreqData;
  private String atmClass;
  private BigDecimal openActLocBal;
  private BigDecimal openActBal;
  private BigDecimal openEarBal;
  private BigDecimal openUnclBal;
  private BigDecimal openAvailBal;
  private BigDecimal curActLocBal;
  private BigDecimal curActBal;
  private BigDecimal curEarBal;
  private BigDecimal curUnclBal;
  private BigDecimal curAvailBal;
  private BigDecimal debitLimit;
  private String expiryDate;
  private BigDecimal accruuedCreditInterest;
  private BigDecimal accruedDebitInterest;
  private String lastEntrypostDate;
  private String lastCreditPostDate;
  private String creditIntDate;
  private String debitIntDate;
  private String typeNarrative;
  private String groupNarrative;
  private String statusNarrative;
  private String designationNarrative;
  private String customerInd;
  private Integer marketSegmentNarrative;
  private Integer referCode;
  private BigDecimal marketSegmentCode;
  private Integer riskLevelBBG;
  private Integer riskLevelEwl;
  private String riskLevel3;
  // private String 51
  // private String 52
  private String addressSeqNumber;
  private String addressContactName;
  private String address1;
  private String address2;
  private String address3;
  private String iban;
  // private String 59
  private String notesLine1;
  private String notesLine2;
  private String notesLine3;
  private String kycInd;
  private String kycDate;
  private String acctOpenDate;
  // private String End;
  private String originalLoanAmount;
  private String statementType;
  // private String stmtFreq;
  // private String stmtFreqData;
  private String nextDueDate;
  private String facilityCode;


}
