package com.absa.amol.saving.model.createcasaaccount;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class BankBranch {

	// M 5
	@NotNull(message = "bankBranch.branchNumber.nullOrEmpty.error.message")
	@Digits(integer = 5, fraction = 0, message = "bankBranch.branchNumber.length.error.message")
	private Integer branchNumber;

	private Integer transactionBranch;

	 @Digits(integer = 3, fraction = 0, message = "contactBranch.size.error.message")
	private Integer contactBranch;

}
