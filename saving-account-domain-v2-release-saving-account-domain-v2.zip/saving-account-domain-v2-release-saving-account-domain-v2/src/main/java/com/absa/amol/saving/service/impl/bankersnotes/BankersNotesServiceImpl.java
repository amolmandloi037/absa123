package com.absa.amol.saving.service.impl.bankersnotes;

import javax.inject.Inject;

import org.eclipse.microprofile.rest.client.inject.RestClient;

import com.absa.amol.saving.mapper.bankersnotes.BankersNotesMapper;
import com.absa.amol.saving.model.bankersnotes.AccountNotes;
import com.absa.amol.saving.model.bankersnotes.AccountNotesSystemResponse;
import com.absa.amol.saving.model.bankersnotes.BankersNotesDomainRequest;
import com.absa.amol.saving.model.bankersnotes.BankersNotesSystemRequest;
import com.absa.amol.saving.service.bankersnotes.BankersNotesService;
import com.absa.amol.saving.util.bankersnotes.BankesrNotesServiceClient;
import com.absa.amol.saving.util.bankersnotes.CreditCardTransactionConstant;
import com.absa.amol.util.exception.ApiException;
import com.absa.amol.util.exception.ApiResponseException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ResponseEntity;
import com.absa.amol.util.utility.CommonUtil;

public class BankersNotesServiceImpl implements BankersNotesService{

	private static final Logger logger = LoggerFactory.getLogger(BankersNotesServiceImpl.class);

	@Inject
	@RestClient
	private BankesrNotesServiceClient brainsClient;

	@Inject
	BankersNotesMapper mapper;

	@Override
	public ResponseEntity<AccountNotes> retrieveBankersNotesDetails(
			BankersNotesDomainRequest bankersNotesDomainRequest) {

		//ResponseEntity<AccountNotes> domainResEntity = null;

		AccountNotes accountNotes = null;

		logger.info("getPostedTransactionResponse",
				bankersNotesDomainRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
				"inside Service : invoking system service client", "");

		try {
			BankersNotesSystemRequest bankersNotesSystemRequest = mapper.mapBankersNotesRequestDomainToSystem(bankersNotesDomainRequest);

			ResponseEntity<AccountNotesSystemResponse> sysBrainsRes = brainsClient.getBankersNotesResponse(bankersNotesSystemRequest);

			if(CommonUtil.isNotNull(sysBrainsRes.getData()) && sysBrainsRes.getCode().equals("200")){

				logger.info(CreditCardTransactionConstant.GET_TRANSACTION_HISTORY_RESPONSE,
						bankersNotesDomainRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
						"Received success response from system service",
						"Status Code : " + sysBrainsRes.getStatus());

				accountNotes = mapper.mapBrainsResToDomainRes(sysBrainsRes.getData());

				
				
				if(CommonUtil.isNull(sysBrainsRes.getMessage())){
					sysBrainsRes.setMessage(CreditCardTransactionConstant.SUCCESS_MESSAGE);
				}

				return new ResponseEntity<AccountNotes>(sysBrainsRes.getCode(),

						sysBrainsRes.getMessage(), sysBrainsRes.getStatus(), accountNotes);
			}
			else {
				logger.info(CreditCardTransactionConstant.GET_TRANSACTION_HISTORY_RESPONSE, "", "data field is null or empty",

						"");
				//accountNotes.setMemoText("");
				return new ResponseEntity<AccountNotes>(sysBrainsRes.getCode(),

						sysBrainsRes.getMessage(), sysBrainsRes.getStatus(), accountNotes);
			}

		} catch (ApiException exception) {
			logger.error(CreditCardTransactionConstant.GET_TRANSACTION_HISTORY_RESPONSE,
					bankersNotesDomainRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
					CreditCardTransactionConstant.EXCEPTION_OCCURED_FROM_SERVER, exception.getErrorMessage());
			logger.debug(CreditCardTransactionConstant.GET_TRANSACTION_HISTORY_RESPONSE,
					bankersNotesDomainRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
					CreditCardTransactionConstant.EXCEPTION_OCCURED_FROM_SERVER, exception);
			throw exception;
		} catch (Exception exception) {

			logger.error(CreditCardTransactionConstant.GET_TRANSACTION_HISTORY_RESPONSE,
					bankersNotesDomainRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
					CreditCardTransactionConstant.EXCEPTION_OCCURED_FROM_SERVER, exception.getMessage());
			logger.debug(CreditCardTransactionConstant.GET_TRANSACTION_HISTORY_RESPONSE,
					bankersNotesDomainRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
					CreditCardTransactionConstant.EXCEPTION_OCCURED_FROM_SERVER, exception);
			throw new ApiResponseException("500", "Internal  Server Error");
		}
	}
}
