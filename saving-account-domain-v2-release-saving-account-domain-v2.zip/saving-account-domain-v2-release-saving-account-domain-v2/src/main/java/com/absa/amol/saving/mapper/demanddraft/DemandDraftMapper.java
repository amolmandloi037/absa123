package com.absa.amol.saving.mapper.demanddraft;

import com.absa.amol.saving.model.demanddraft.Address;
import com.absa.amol.saving.model.demanddraft.DemandDraftDomainReq;
import com.absa.amol.saving.model.demanddraft.DemandDraftDomainReqWrapper;
import com.absa.amol.saving.model.demanddraft.DemandDraftDomainRes;
import com.absa.amol.saving.model.demanddraft.PaymentPurpose;
import com.absa.amol.saving.model.demanddraft.PaymentTransaction;
import com.absa.amol.saving.model.sys.demanddraft.DemandDraftReq;
import com.absa.amol.saving.model.sys.demanddraft.DemandDraftRes;
import com.absa.amol.saving.model.sys.demanddraft.SystemAddress;
import com.absa.amol.saving.model.sys.demanddraft.SystemReplyMessage;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.exception.ApiRequestException;
import com.absa.amol.util.model.ResponseEntity;
import com.absa.amol.util.utility.CommonUtil;
import com.absa.amol.util.utility.StringUtil;

public class DemandDraftMapper {

	public DemandDraftReq demandDraftReqmapping(DemandDraftDomainReqWrapper reqWrapper) {

		DemandDraftDomainReq demandDraftDomainReq = reqWrapper.getDemandDraftDomainReq();
		DemandDraftReq demandDraftReq = new DemandDraftReq();

		demandDraftReq.setAccountId(demandDraftDomainReq.getSavingsAccountNumber());
		demandDraftReq.setIsServiceChargeApplicable(false);
		demandDraftReq.setTransactionType(0);
		demandDraftReq.setCustomerNumber(demandDraftDomainReq.getCustomerReference());
		demandDraftReq.setTransactionBranch(demandDraftDomainReq.getBankBranchReference());

		if (CommonUtil.isNotNull(demandDraftDomainReq.getPaymentTransaction())) {

			if (CommonUtil.isNotNull(demandDraftDomainReq.getPaymentTransaction().getPayeeBankReference())) {
				demandDraftReq.setPayableAtCountry(
						demandDraftDomainReq.getPaymentTransaction().getPayeeBankReference().getCountryCode());
				demandDraftReq.setCollectionBranchId(
						demandDraftDomainReq.getPaymentTransaction().getPayeeBankReference().getCollectionBranchId());
				demandDraftReq.setCollectionBranchName(
						demandDraftDomainReq.getPaymentTransaction().getPayeeBankReference().getCollectionBranchName());
			}

			if (CommonUtil.isNotNull(demandDraftDomainReq.getPaymentTransaction().getPayeeReference())) {
				demandDraftReq.setBeneficiaryAddress(
						mapAddress(demandDraftDomainReq.getPaymentTransaction().getPayeeReference().getAddress()));
				demandDraftReq.setBeneficiaryName(
						demandDraftDomainReq.getPaymentTransaction().getPayeeReference().getBeneficiaryName());
				demandDraftReq.setBeneficiaryPhone(
						demandDraftDomainReq.getPaymentTransaction().getPayeeReference().getPhoneNumber());
			}

			if (CommonUtil.isNotNull(demandDraftDomainReq.getPaymentTransaction().getPaymentPurpose())) {
				demandDraftReq.setAdditionalInfo(
						demandDraftDomainReq.getPaymentTransaction().getPaymentPurpose().getAdditionalInfo());
				demandDraftReq.setPaymentRemarks(
						demandDraftDomainReq.getPaymentTransaction().getPaymentPurpose().getPaymentRemarks());
			}

			demandDraftReq.setMonetaryValue(demandDraftDomainReq.getPaymentTransaction().getAmount());
			demandDraftReq.setCurrencyCode(demandDraftDomainReq.getPaymentTransaction().getCurrencyCode());
			demandDraftReq.setDateRequired(demandDraftDomainReq.getPaymentTransaction().getDate());
			demandDraftReq.setDeliveryType(demandDraftDomainReq.getPaymentTransaction().getPaymentMechanism() != null
					? demandDraftDomainReq.getPaymentTransaction().getPaymentMechanism().getDeliveryType()
					: "");
		}

		return demandDraftReq;

	}

	private SystemAddress mapAddress(Address addressDomain) {
		SystemAddress addressSystem = new SystemAddress();
		if (CommonUtil.isNotNull(addressDomain)) {
			addressSystem.setCity(addressDomain.getCityName());
			addressSystem.setCountry(addressDomain.getCountryName());
			addressSystem.setLine1(addressDomain.getAddressline1());
			addressSystem.setLine2(addressDomain.getAddressline2());
			addressSystem.setLine3(addressDomain.getAddressline3());
			addressSystem.setState(addressDomain.getState());
			addressSystem.setZip(addressDomain.getZipCode());
		}
		return addressSystem;
	}

	public ResponseEntity<DemandDraftDomainRes> demandDraftResmapping(
			ResponseEntity<DemandDraftRes> demandDraftResEntity) {

		ResponseEntity<DemandDraftDomainRes> respEntity = null;
		DemandDraftDomainRes demandDraftDomainRes = new DemandDraftDomainRes();
		PaymentPurpose paymentPurpose = new PaymentPurpose();
		PaymentTransaction paymentTransaction = new PaymentTransaction();
		DemandDraftRes demandDraftRes = null;
		if (CommonUtil.isNotNull(demandDraftResEntity)) {
			demandDraftRes = demandDraftResEntity.getData();
			if (CommonUtil.isNotNull(demandDraftRes) && CommonUtil.isNotNull(demandDraftRes.getStatus())) {
				if (StringUtil.isStringNotNullAndNotEmpty(demandDraftRes.getStatus().getStatusCode())
						&& StringUtil.isStringNotNullAndNotEmpty(demandDraftRes.getStatus().getStatusDesc())) {
					if (Constant.EBOX_SUCCESS_STATUS_CODE.equals(demandDraftRes.getStatus().getStatusCode())) {

						paymentPurpose.setExternalReferenceNumber(demandDraftRes.getStatus().getExternalReferenceNo());
						paymentTransaction.setPaymentPurpose(paymentPurpose);
						paymentTransaction.setTransactionDate(demandDraftRes.getStatus().getTransactionDateTimeText());

						demandDraftDomainRes.setPaymentTransaction(paymentTransaction);
						respEntity = new ResponseEntity<>(Constant.SUCCESS_CODE, Constant.DATA_ADDED_SUCCESS,
								Constant.SUCCESS_MESSAGE, demandDraftDomainRes);
					} else {
						throw new ApiRequestException(Constant.BAD_REQUEST_CODE,
								demandDraftRes.getStatus().getStatusDesc());
					}
				} else {
					respEntity = mapFcrResponse(demandDraftRes);
				}
			} else {
				respEntity = new ResponseEntity<>(Constant.SUCCESS_CODE, "NO_DATA_FOUND", Constant.SUCCESS_MESSAGE,
						null);
			}
		}

		return respEntity;
	}

	private ResponseEntity<DemandDraftDomainRes> mapFcrResponse(DemandDraftRes demandDraftRes) {
		String msg = null;
		String statusMsg = Constant.SUCCESS_MESSAGE;
		String statusCode = Constant.SUCCESS_CODE;
		StringBuilder sb = new StringBuilder();
		if (demandDraftRes.getStatus().getReplyCode().equals(Constant.REPLY_CODE_0)) {
			msg = Constant.DATA_ADDED_SUCCESS;
		} else if (demandDraftRes.getStatus().getReplyCode().equals(Constant.REPLY_CODE_40)) {
			if (null != demandDraftRes.getStatus() && null != demandDraftRes.getStatus().getReplyText()
					&& !demandDraftRes.getStatus().getReplyText().trim().isEmpty()) {
				sb.append(demandDraftRes.getStatus().getReplyText());
			} else {

				mapSystemMessage(demandDraftRes,sb);
			}
			msg = sb.toString();
		} else {
			statusMsg = Constant.FAILURE_MSG;
			statusCode = Constant.BAD_REQUEST_CODE;
			if (null != demandDraftRes.getStatus() && null != demandDraftRes.getStatus().getReplyText()
					&& !demandDraftRes.getStatus().getReplyText().trim().isEmpty()) {
				sb.append(demandDraftRes.getStatus().getReplyText());
			} else {

				mapSystemMessage(demandDraftRes,sb);
			}
			msg = sb.toString();

		}
		DemandDraftDomainRes demandDraftDomainRes = new DemandDraftDomainRes();
		PaymentPurpose paymentPurpose = new PaymentPurpose();
		PaymentTransaction paymentTransaction = new PaymentTransaction();

		paymentPurpose.setExternalReferenceNumber(demandDraftRes.getStatus().getExternalReferenceNo());
		paymentTransaction.setPaymentPurpose(paymentPurpose);
		paymentTransaction.setTransactionDate(demandDraftRes.getStatus().getTransactionDateTimeText());

		demandDraftDomainRes.setPaymentTransaction(paymentTransaction);

		return new ResponseEntity<>(statusCode, msg, statusMsg, demandDraftDomainRes);

	}

	private void mapSystemMessage(DemandDraftRes demandDraftRes, StringBuilder sb) {
		if (CommonUtil.isNotNull(demandDraftRes.getStatus().getExtendedReply())
				&& CommonUtil.isNotNull(demandDraftRes.getStatus().getExtendedReply().getMessages())
				&& CommonUtil.isNotNull(demandDraftRes.getStatus().getExtendedReply().getMessages().getItem()))
			sb.append(!demandDraftRes.getStatus().getExtendedReply().getMessages().getItem().isEmpty() ? demandDraftRes
					.getStatus().getExtendedReply().getMessages().getItem().stream().map(SystemReplyMessage::getMsg)
					: "");
	}
}
