package com.absa.amol.saving.model.updtacctdtls;

import javax.validation.Valid;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountDetails {
	
	@Valid
	private PricingPlan pricingPlan;

}
