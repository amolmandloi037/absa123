package com.absa.amol.saving.model.updtacctdtls;

import javax.validation.constraints.Pattern;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductAndServicePreference {
	
	@Pattern(regexp = "[123456789]{0,1}?|", message = "noOfStatementCopies.pattern.message")
	@Schema(description = "Optional field", pattern = "Numeric",minLength=0, maxLength = 1 )
	private String noOfStatementCopies;
	private String chequesRequiredIndicator;
	private String branchStatementIndicator;
	private String statementAddressIndicator;
	private String miniStatementAddressIndicator;
	private String fixedDepositAddressIndicator;

}
