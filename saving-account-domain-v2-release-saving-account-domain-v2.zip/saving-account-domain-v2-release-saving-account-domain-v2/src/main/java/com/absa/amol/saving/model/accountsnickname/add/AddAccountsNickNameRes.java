package com.absa.amol.saving.model.accountsnickname.add;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Schema(name = "AddAccountsNickNameRes", description = "Response Schema for Add Account NickName API")
public class AddAccountsNickNameRes {
	
	private String transactionReferenceId;

}
