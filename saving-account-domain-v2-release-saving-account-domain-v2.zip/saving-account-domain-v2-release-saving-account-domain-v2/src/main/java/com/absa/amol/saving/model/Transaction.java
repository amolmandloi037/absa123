package com.absa.amol.saving.model;

import java.math.BigDecimal;
import javax.json.bind.annotation.JsonbNillable;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonbNillable
public class Transaction {
  private BigDecimal amountInAccountCurrency;
  private BigDecimal amountInLocalCurrency;
  private BigDecimal amount;
  private Long auditTrailSequence;
  private String authoriserId;
  private Long batchNumber;
  private String chequeNumber;
  private String creditDebitFlag;
  private String description;
  private Integer mnemonic;
  private Integer originatingBranch;
  private String postDate;
  private BigDecimal transactionAmount;
  private String currencyCode;
  private String transactionDate;
  private Integer transactionOrder;
  private String userId;
  private String valueDate;
  private String cardNumber;
  private Integer chequeCount;
  private String clearingType;
  private BigDecimal runningTotal;
  private Integer serviceChargeCode;
  private String taskLiteral;
  private String transactionId;
  private String transactionTime;
  private String userReferenceNumber;
  private String subCodeNarrative;
  private String narrative;
  private String counterPartyName;
  private String remitterInformation;
  private String stmntDateTime;
}
