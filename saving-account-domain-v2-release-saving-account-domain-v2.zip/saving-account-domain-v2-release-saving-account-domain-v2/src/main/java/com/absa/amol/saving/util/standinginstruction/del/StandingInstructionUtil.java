package com.absa.amol.saving.util.standinginstruction.del;

import javax.inject.Inject;

import org.eclipse.microprofile.config.Config;

import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;



public class StandingInstructionUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(StandingInstructionUtil.class);

	@Inject 
	Config config;

	public String getConfigStringValue(String key){

		try {
			return config.getValue(key, String.class);
		} catch (Exception e) {
			LOGGER.error("getPropertyValue", Constant.BLANK,
					"Exception while reading property for the key ::" + key, e.getMessage());
		}
		return Constant.BLANK;
	}

	public Integer getConfigIntValue(String key){

		try {
			return config.getValue(key, Integer.class);


		} catch (Exception e) {
			LOGGER.error("getPropertyValue", Constant.BLANK,
					"Exception while reading property for the key ::" + key, e.getMessage());

		}
		return 0;
	}

}
