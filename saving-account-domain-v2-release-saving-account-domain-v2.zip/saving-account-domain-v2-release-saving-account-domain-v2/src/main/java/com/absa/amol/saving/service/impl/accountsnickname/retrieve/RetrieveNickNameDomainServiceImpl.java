package com.absa.amol.saving.service.impl.accountsnickname.retrieve;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.Response;

import org.eclipse.microprofile.rest.client.inject.RestClient;

import com.absa.amol.saving.builder.RetrieveNickNameDomainClientBuilder;
import com.absa.amol.saving.model.accountsnickname.retrieve.CustomerAccount;
import com.absa.amol.saving.model.accountsnickname.retrieve.RetrieveAccountsNickNameReq;
import com.absa.amol.saving.model.accountsnickname.retrieve.RetrieveAccountsNickNameRes;
import com.absa.amol.saving.model.sys.accountsnickname.retrieve.RetrieveAccountsNickNameSystemRes;
import com.absa.amol.saving.model.sys.accountsnickname.retrieve.RetrieveNickNameSystemRequest;
import com.absa.amol.saving.service.accountsnickname.RetrieveNickNameDomainService;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.exception.ApiException;
import com.absa.amol.util.exception.ApiResponseException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ResponseEntity;

public class RetrieveNickNameDomainServiceImpl implements RetrieveNickNameDomainService {

	@Inject
	@RestClient
	RetrieveNickNameDomainClientBuilder retrieveNickNameDomainClientBuilder;

	private static final Logger LOGGER = LoggerFactory.getLogger(RetrieveNickNameDomainServiceImpl.class);

	@Override
	public ResponseEntity<RetrieveAccountsNickNameRes> retrieveNickNameDomain(
			RetrieveAccountsNickNameReq retrieveAccountsNickNameReq) {
		LOGGER.info(Constant.RETRIEVE_NICK_NAME,
				retrieveAccountsNickNameReq.getApiRequestheader().getConsumerUniqueReferenceId(), Constant.BLANK,
				Constant.BLANK);
		RetrieveNickNameSystemRequest retrieveNickNameSystemRequest = new RetrieveNickNameSystemRequest();
		retrieveNickNameSystemRequest.setApiRequestheader(retrieveAccountsNickNameReq.getApiRequestheader());
		retrieveNickNameSystemRequest.setScvId(retrieveAccountsNickNameReq.getCustomerReference());
		try {
			Response response = retrieveNickNameDomainClientBuilder.retrieveNickName(retrieveNickNameSystemRequest);
			ResponseEntity<List<RetrieveAccountsNickNameSystemRes>> entity = response
					.readEntity(new GenericType<ResponseEntity<List<RetrieveAccountsNickNameSystemRes>>>() {
					});
			
			LOGGER.info(Constant.RETRIEVE_NICK_NAME, retrieveAccountsNickNameReq.getApiRequestheader().getConsumerUniqueReferenceId(), "response status code", entity.getCode());
			return responseMappingMce(entity);
		} catch (ApiException apiException) {
			LOGGER.error(Constant.RETRIEVE_NICK_NAME, Constant.API_EXCEPTION, Constant.API_EXCEPTION,
					apiException.getMessage());
			LOGGER.debug(Constant.RETRIEVE_NICK_NAME, Constant.API_EXCEPTION, Constant.API_EXCEPTION, apiException);
			throw apiException;
		} catch (Exception exception) {
			LOGGER.error(Constant.RETRIEVE_NICK_NAME, Constant.EXCEPTION, Constant.EXCEPTION, exception.getMessage());
			LOGGER.debug(Constant.RETRIEVE_NICK_NAME, Constant.EXCEPTION, Constant.EXCEPTION, exception);
			throw new ApiResponseException(Constant.INTERNAL_ERROR_CODE, Constant.INTERNAL_ERROR_MSG);
		}
	}

	private static ResponseEntity<RetrieveAccountsNickNameRes> responseMappingMce(
			ResponseEntity<List<RetrieveAccountsNickNameSystemRes>> entity) {
	
		if (entity.getData() != null && entity.getCode().equals(Constant.SUCCESS_CODE)) {
			List<CustomerAccount> list = new ArrayList<>();
			RetrieveAccountsNickNameRes retrieveAccountsNickNameRes = new RetrieveAccountsNickNameRes();
			entity.getData().forEach(account -> {
				CustomerAccount customerAccount = new CustomerAccount();
				customerAccount.setAccountNickName(account.getAccountNickName());
				customerAccount.setAccountNumber(account.getAccountNumber());
				customerAccount.setBankBranchCode(account.getBranchCode());
				list.add(customerAccount);
			}

			);
			retrieveAccountsNickNameRes.setCustomerAccountList(list);
			String message = Constant.DATA_RECEIVED;
			if (entity.getMessage() != null) {
				message = entity.getMessage();
			}
			return new ResponseEntity<>(Constant.SUCCESS_CODE, message,
					Constant.SUCCESS_MESSAGE, retrieveAccountsNickNameRes);
		} else if (entity.getData() == null && entity.getStatus().equals(Constant.BAD_REQUEST_CODE)) {

			String message = Constant.BAD_REQ;
			if (entity.getMessage() != null) {
				message = entity.getMessage();
			}
			return new ResponseEntity<>(Constant.BAD_REQUEST_CODE, message, Constant.FAILURE_MSG, null);

		} else {
			return new ResponseEntity<>(Constant.INTERNAL_ERROR_CODE, Constant.INTERNAL_ERROR_MSG, Constant.FAILURE_MSG,
					null);
		}

	}
}
