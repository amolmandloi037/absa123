package com.absa.amol.saving.model.sys.updaccudf;

import javax.json.bind.annotation.JsonbProperty;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(name = "AccountUdfUpdateRes", description = "Response Schema for Updating Customer Udf")
public class AccountUdfUpdateRes {
	
	@JsonbProperty(nillable= true)
	private String statusCode;  
	@JsonbProperty(nillable= true)
	private ExtendedReply extendedReply;        
	@JsonbProperty(nillable= true)
	private String externalReferenceNo;
	@JsonbProperty(nillable= true)
	private String InputOverridenWarnings;
	@JsonbProperty(nillable= true)
	private Boolean IsOverriden;
	@JsonbProperty(nillable= true)
	private Boolean IsServiceChargeApplied;
	@JsonbProperty(nillable= true)
	private String Memo;
	@JsonbProperty(nillable= true)
	private Long replyCode;
	@JsonbProperty(nillable= true)
	private String StatusDesc;
	@JsonbProperty(nillable= true)
	private Long spReturnValue;
	@JsonbProperty(nillable= true)
	private String transactionDateTimeText;
	@JsonbProperty(nillable= true)
	private String userReferenceNumber;
	@JsonbProperty(nillable= true)
	private ValidationErrors validationErrors;

}
