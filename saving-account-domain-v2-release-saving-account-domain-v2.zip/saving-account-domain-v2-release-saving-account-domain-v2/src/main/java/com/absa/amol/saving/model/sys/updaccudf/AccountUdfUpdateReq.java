package com.absa.amol.saving.model.sys.updaccudf;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(name = "AccountUdfUpdateReq", description = "Request Schema for Updating Customer Udf")
public class AccountUdfUpdateReq {
	
	@Schema(description = "Field is optional", pattern = "Only Numeric",minLength = 1, maxLength = 5 )
	@Pattern(regexp = "[0-9]{0,5}", message = "branchCode.pattern.message")
	private String branchCode;
	
	@Schema(description = "Field is optional", pattern = "AlphaNumeric")
	private String VATRegNo;
	
	@NotNull(message = "accountId.null.empty.message")
	@NotEmpty(message = "accountId.null.empty.message")
	@Size(min = 1, max = 20, message = "accountId.length.message")
	@Pattern(regexp = "[0-9]{1,20}", message = "accountId.pattern.message")
	@Schema(description = "Field is mandatory", pattern = "Only Numeric",minLength = 1, maxLength = 20 , required = true)
	private String accountId;
	
	@Schema(description = "Field is optional", pattern = "AlphaNumeric")
	private String acctDesgn;
	
	@Schema(description = "Field is optional", pattern = "AlphaNumeric")
	private String creditors;
	
	@Schema(description = "Field is optional", pattern = "Characterstic")
	private String delarueChqbkDesc;
	
	@Schema(description = "Field is optional", pattern = "AlphaNumeric")
	private String delarueSubBranch;
	
	@Schema(description = "Field is optional", pattern = "Only Numeric")
	private String ewlStatus;
	
	@Size(min = 0, max = 10, message = "nuitNo.length.message")
	@Schema(description = "Field is optional", pattern = "AlphaNumeric", minLength = 0, maxLength = 10 )
	private String nuitNo;
	
	@Schema(description = "Field is optional", pattern = "AlphaNumeric")
	private String origRefNo;
	
	@Schema(description = "Field is optional", pattern = "AlphaNumeric")
	private String prestigeMember;
	
	@Schema(description = "Field is optional", pattern = "AlphaNumeric")
	private String riskLevel;
	
	@Schema(description = "Field is optional", pattern = "AlphaNumeric")
	private String riskLevelBBG;
	
	@Schema(description = "Field is optional", pattern = "AlphaNumeric")
	private String riskLevelEWL;
	
	@Schema(description = "Field is optional", pattern = "AlphaNumeric")
	private String shortName;
}
