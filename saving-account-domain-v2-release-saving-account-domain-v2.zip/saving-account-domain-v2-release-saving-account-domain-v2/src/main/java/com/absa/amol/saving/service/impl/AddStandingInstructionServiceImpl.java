package com.absa.amol.saving.service.impl;

import javax.inject.Inject;

import com.absa.amol.saving.model.standinginstruction.add.StandingOrderAddReq;
import com.absa.amol.saving.model.standinginstruction.add.StandingOrderAddRes;
import com.absa.amol.saving.service.AddStandingInstructionService;
import com.absa.amol.saving.util.AddStandingInstructionClient;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.exception.ApiException;
import com.absa.amol.util.exception.ApiResponseException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ResponseEntity;

public class AddStandingInstructionServiceImpl implements AddStandingInstructionService {

	public static final String ADD_STANDING_INSTRUC = "addStandingInstruc";

	@Inject
	AddStandingInstructionClient addSIClient;

	private static final Logger logger = LoggerFactory.getLogger(AddStandingInstructionServiceImpl.class);

	@Override
	public ResponseEntity<StandingOrderAddRes> addStandingInstruc(StandingOrderAddReq standingOrderAddReq) {
		ResponseEntity<StandingOrderAddRes> siAddResEntity = null;

		try {
			siAddResEntity = addSIClient.addStandingInstruction(standingOrderAddReq.getApiRequestHeader(),
					standingOrderAddReq);
		} catch (ApiException exception) {
			logger.error(ADD_STANDING_INSTRUC, standingOrderAddReq.getApiRequestHeader().getCorrelationId(),
					Constant.EXCEPTION_OCCURED_FROM_SERVER, exception.getErrorMessage());
			logger.debug(ADD_STANDING_INSTRUC, standingOrderAddReq.getApiRequestHeader().getCorrelationId(),
					Constant.EXCEPTION_OCCURED_FROM_SERVER, exception);
			throw exception;
		} catch (Exception exception) {

			logger.error(ADD_STANDING_INSTRUC, standingOrderAddReq.getApiRequestHeader().getCorrelationId(),
					Constant.EXCEPTION_OCCURED_FROM_SERVER, exception.getMessage());
			logger.debug(ADD_STANDING_INSTRUC, standingOrderAddReq.getApiRequestHeader().getCorrelationId(),
					Constant.EXCEPTION_OCCURED_FROM_SERVER, exception);
			throw new ApiResponseException("500", "Internal  Server Error");
		}
		return siAddResEntity;
	}

}
