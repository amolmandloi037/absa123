package com.absa.amol.saving.model.updateaccountstatus;

import javax.validation.constraints.Size;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class UdfDetails {

	@Schema(description = "Field is Optional")
	private String udfType;
	
	@Schema(description = "Field is Optional", pattern = "[0-9]*", minLength = 1, maxLength = 10)
	@Size(min = 0, max = 10, message = "udfCode.length.message")
	private String udfCode;
}
