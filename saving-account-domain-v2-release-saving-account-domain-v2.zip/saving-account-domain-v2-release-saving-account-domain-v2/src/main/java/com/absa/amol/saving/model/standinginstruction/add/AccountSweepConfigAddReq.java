package com.absa.amol.saving.model.standinginstruction.add;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountSweepConfigAddReq {
	
	private String compoundingFreq;
	private Boolean sweepInProviderFlag;	
	private Integer productCode;
	private Integer termDays;
	private Integer termMonths;
	private Float accountVariance;

}
