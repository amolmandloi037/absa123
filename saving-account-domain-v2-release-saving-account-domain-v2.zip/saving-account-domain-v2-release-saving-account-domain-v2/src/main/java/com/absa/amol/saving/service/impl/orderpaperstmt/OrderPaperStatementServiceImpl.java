package com.absa.amol.saving.service.impl.orderpaperstmt;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import javax.inject.Inject;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import com.absa.amol.saving.builder.CustContactHistoryClientBuilder;
import com.absa.amol.saving.mapper.CustContactHistoryMapper;
import com.absa.amol.saving.model.orderpaperstmt.OrderPaperStmtDomainRequest;
import com.absa.amol.saving.model.orderpaperstmt.OrderPaperStmtDomainResponse;
import com.absa.amol.saving.model.orderpaperstmt.OrderPaperStmtResponse;
import com.absa.amol.saving.model.orderpaperstmt.OrderPaperStmtSystemRequest;
import com.absa.amol.saving.model.orderpaperstmt.Status;
import com.absa.amol.saving.model.orderpaperstmt.SystemReplyMessage;
import com.absa.amol.saving.model.sys.addcontacthistory.AddContactHistoryRequest;
import com.absa.amol.saving.service.orderpaperstmt.OrderPaperStatementService;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.saving.util.OrderPaperStatementClient;
import com.absa.amol.util.exception.ApiException;
import com.absa.amol.util.exception.ApiResponseException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.model.ResponseEntity;
import com.absa.amol.util.utility.CollectionUtil;
import com.absa.amol.util.utility.CommonUtil;

public class OrderPaperStatementServiceImpl implements OrderPaperStatementService {

  private static final Logger logger =
      LoggerFactory.getLogger(OrderPaperStatementServiceImpl.class);

  @Inject
  @RestClient
  private OrderPaperStatementClient orderPaperStatementClient;

  @Inject
  @RestClient
  private CustContactHistoryClientBuilder addCustContactHistoryClientBuilder;

  @Inject
  CustContactHistoryMapper contactHistoryMapper;

  @Override
  public Response getOrderPaperStatement(OrderPaperStmtDomainRequest req) {
    final String method_name = "getOrderPaperStatement";
    Response response = null;
    String consUniqId = "";
    ResponseEntity<OrderPaperStmtResponse> systemEntity = null;
    ResponseEntity<OrderPaperStmtDomainResponse> domainEntity = null;
    try {
      consUniqId = req.getApiRequestHeader().getConsumerUniqueReferenceId();
      logger.info(method_name, consUniqId, "inside Service : invoking system service client", "");
      OrderPaperStmtSystemRequest systemReq = new OrderPaperStmtSystemRequest(req);
      response = orderPaperStatementClient.getOrderPaperStatement(systemReq);
      logger.info(method_name, consUniqId, "Response Recieved from System Adapter",
          response.toString());

      if (response.getStatus() == Constant.SUCCESS) {
        systemEntity =
            response.readEntity(new GenericType<ResponseEntity<OrderPaperStmtResponse>>() {});
        OrderPaperStmtDomainResponse domainRes = new OrderPaperStmtDomainResponse();

        OrderPaperStmtResponse systemRes = systemEntity.getData();
        if (CommonUtil.isNotNull(systemRes) && CommonUtil.isNotNull(systemRes.getStatus())) {
          Status status = systemRes.getStatus();
          
          logger.info(method_name, consUniqId, "Status object recieved from System Adapter",
                  status.toString());
          
          domainRes.setTransactionReferenceNumber(status.getReferenceNumber());
      domainEntity = new ResponseEntity<OrderPaperStmtDomainResponse>(systemEntity.getCode(),
          systemEntity.getMessage(), systemEntity.getStatus(), domainRes);

          if (Constant.REPLY_CODE_0.equals(status.getReplyCode())) {

            /******* FCR Success Mapping for Success code 0 *******/
            logger.info(method_name, consUniqId, "Got Success Response from FCR",
                status.getReplyCode().toString());

            domainRes.setTransactionReferenceNumber(status.getReferenceNumber());
            domainEntity = new ResponseEntity<OrderPaperStmtDomainResponse>(systemEntity.getCode(),
                systemEntity.getMessage(), systemEntity.getStatus(), domainRes);
            logger.info(method_name, consUniqId, "Mapping completed in FCR", "");
          } else if (status.getReplyCode()!=null && (Constant.REPLY_CODE_30.equals(status.getReplyCode())
              || status.getReplyCode() >= (Constant.REPLY_CODE_80))) {

            /******* FCR FAILURES Mapping for 30 and 80 *******/
            logger.info(method_name, consUniqId, Constant.LOG_BUSINESS_MSG,
                status.getReplyCode().toString());

            domainEntity = new ResponseEntity<OrderPaperStmtDomainResponse>(
                Constant.BAD_REQUEST_CODE, Constant.FAILURE_MSG,
                getBusinessFailureMessage(status, req.getApiRequestHeader()), null);
          } else if (Constant.REPLY_CODE_40.equals(status.getReplyCode())) {

            /******* FCR FAILURES Mapping for 40 *******/
            logger.info(method_name, consUniqId, Constant.LOG_BUSINESS_MSG,
                status.getReplyCode().toString());

            domainEntity = new ResponseEntity<OrderPaperStmtDomainResponse>(Constant.SUCCESS_CODE,
                Constant.FAILURE_MSG, getBusinessFailureMessage(status, req.getApiRequestHeader()),
                null);
          } else if (Constant.ZERO_STRING.equals(status.getStatusCode())) {
        	  /******* EBOX Success scenario *******/
              domainRes.setTransactionReferenceNumber(status.getReferenceNumber());
              domainEntity = new ResponseEntity<OrderPaperStmtDomainResponse>(systemEntity.getCode(),
                  systemEntity.getMessage(), systemEntity.getStatus(), domainRes);
          }else if (!Constant.ZERO_STRING.equals(status.getStatusCode())) {
        	  /******* EBOX failure scenario *******/
              domainEntity = new ResponseEntity<OrderPaperStmtDomainResponse>(
                      Constant.BAD_REQUEST_CODE, Constant.FAILURE_MSG,
                      status.getStatusDesc(), null);
          }
        }

        if (Constant.SUCCESS_CODE.equalsIgnoreCase(domainEntity.getCode())) {
          callAddContactHistoryMce(req);
        }

        response =
            Response.status(Integer.parseInt(domainEntity.getCode())).entity(domainEntity).build();
      }
      return response;
    } catch (ApiException exception) {
      logger.error(method_name, consUniqId, Constant.EXCEPTION_OCCURED_FROM_SERVER,
          exception.getErrorMessage());
      logger.debug(method_name, consUniqId, Constant.EXCEPTION_OCCURED_FROM_SERVER, exception);
      throw exception;
    } catch (Exception exception) {
      logger.error(method_name, consUniqId, Constant.EXCEPTION_OCCURED_FROM_SERVER,
          exception.getMessage());
      logger.debug(method_name, consUniqId, Constant.EXCEPTION_OCCURED_FROM_SERVER, exception);
      throw new ApiResponseException("500", "Internal  Server Error");
    }
  }

  private void callAddContactHistoryMce(OrderPaperStmtDomainRequest req) {
    final String method_Name = "callAddContactHistoryMce";
    String conUniqRefId = "";
    try {
      conUniqRefId = req.getApiRequestHeader().getConsumerUniqueReferenceId();
      logger.info(method_Name, conUniqRefId, Constant.CALL_ADD_CONTACT_HIST, "Start");
      AddContactHistoryRequest contactHistoryReq =
          contactHistoryMapper.addContactHistorySysReqMapping(req);
      CompletableFuture.runAsync(() -> addCustContactHistoryClientBuilder
          .addContactHistory(req.getApiRequestHeader(), contactHistoryReq));
      logger.info(method_Name, conUniqRefId, Constant.CALL_ADD_CONTACT_HIST, "End");
    } catch (Exception ex) {
      logger.error(method_Name, conUniqRefId, Constant.EXCEPTION, ex.getMessage());
      logger.debug(method_Name, conUniqRefId, Constant.EXCEPTION, ex);
    }
  }

  public String getBusinessFailureMessage(Status status, ApiRequestHeader header) {
    logger.info("getBusinessFailureMessage", header.getConsumerUniqueReferenceId(),
        "Concatinating Business Error Messages", "Start");
    String message = "";

    if (CommonUtil.isNotNull(status.getExtendedReply())
        && CommonUtil.isNotNull(status.getExtendedReply().getMessages())
        && CollectionUtil.isNotNullAndNotEmpty(status.getExtendedReply().getMessages().getItem())) {
      List<SystemReplyMessage> itemList = status.getExtendedReply().getMessages().getItem();
      for (SystemReplyMessage item : itemList) {
        message = message.concat(item.getMessage()).concat("\n");
      }
    }
    if (status.getReplyText() != null) {
      message = message.concat(status.getReplyText());
    }
    logger.info("getBusinessFailureMessage", header.getConsumerUniqueReferenceId(),
        "Concatinating Business Error Messages", "End");
    return message;
  }
}
