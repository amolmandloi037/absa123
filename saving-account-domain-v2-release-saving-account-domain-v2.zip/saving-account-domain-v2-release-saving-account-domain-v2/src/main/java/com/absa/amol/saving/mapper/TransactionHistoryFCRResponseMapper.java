package com.absa.amol.saving.mapper;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import com.absa.amol.saving.model.PaymentMechanism;
import com.absa.amol.saving.model.PaymentPurpose;
import com.absa.amol.saving.model.PaymentTransaction;
import com.absa.amol.saving.model.Response;
import com.absa.amol.saving.model.Transaction;
import com.absa.amol.saving.model.TransactionDescription;
import com.absa.amol.saving.model.TransactionHistoryDomainResponse;
import com.absa.amol.saving.model.TransactionHistoryResponse;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.exception.ApiRequestException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.utility.AmolDateUtils;
import com.absa.amol.util.utility.CollectionUtil;
import com.absa.amol.util.utility.CommonUtil;
import com.absa.amol.util.utility.StringUtil;

public class TransactionHistoryFCRResponseMapper {
  private static final String TRANSACTION_HISTORY_RESPONSE_FCR_RESPONSE_MAPPER =
      "TransactionHistoryResponseFcrResponseMapper";
  private static final Logger LOGGER = LoggerFactory.getLogger(TransactionHistoryFCRResponseMapper.class);

  String outDateFormat = "yyyy-MM-dd";
  String inputDateFormat;

  public TransactionHistoryDomainResponse transactionHistoryResMapper(ApiRequestHeader apiRequestHeader,
      TransactionHistoryResponse responseFcr, String debitCreditIndicator) {

    try {
      if (CommonUtil.isNotNull(responseFcr.getStatus())) {
        inputDateFormat = "yyyyMMdd";
      } else {
        inputDateFormat = "ddMMyy";
      }

      LOGGER.info(TRANSACTION_HISTORY_RESPONSE_FCR_RESPONSE_MAPPER,
          Constant.getConsumerUniqueReferenceId(apiRequestHeader), "input inputDateFormat", inputDateFormat);

      LOGGER.info(TRANSACTION_HISTORY_RESPONSE_FCR_RESPONSE_MAPPER,
          Constant.getConsumerUniqueReferenceId(apiRequestHeader), "start of FCR response mapper Method",
          responseFcr.toString());
      TransactionHistoryDomainResponse responseFcrAndEbox = new TransactionHistoryDomainResponse();
      Response response = new Response();
      response.setAccountNumber(responseFcr.getAccountNumber());
      if (CommonUtil.isNull(responseFcr.getOpeningBalance())) {
        response.setOpeningBalanceAmount(Constant.ZERO_BALANCE);
      } else {
        response.setOpeningBalanceAmount(responseFcr.getOpeningBalance());
      }
      if (CommonUtil.isNull(responseFcr.getClosingBalance())) {
        response.setClosingBalanceAmount(Constant.ZERO_BALANCE);
      } else {
        response.setClosingBalanceAmount(responseFcr.getClosingBalance());
      }
      response.setTotalNumberOfRecords((int) responseFcr.getNumberOfRecords());

      List<PaymentTransaction> transactionList = new ArrayList<>();
      List<TransactionDescription> description = new ArrayList<>();
      // create a list of account
      List<Transaction> accountList = responseFcr.getTransactions();

      if (StringUtil.isStringNotNullAndNotEmpty(debitCreditIndicator)) {
        accountList =
            accountList.stream().filter(account -> debitCreditIndicator.equals(account.getCreditDebitFlag()))
                .collect(Collectors.toList());
      }

      if (CollectionUtil.isNotNullAndNotEmpty(accountList)) {

        for (Transaction account : accountList) {

          LOGGER.info(TRANSACTION_HISTORY_RESPONSE_FCR_RESPONSE_MAPPER,
              Constant.getConsumerUniqueReferenceId(apiRequestHeader), "# # # # # Inside Mapper Loop ", "");
          PaymentTransaction paymentTransaction = new PaymentTransaction();
          PaymentPurpose pamentPurpose = new PaymentPurpose();
          PaymentMechanism mechanism = new PaymentMechanism();
          TransactionDescription transactionDescription = new TransactionDescription();
          paymentTransaction.setSourceAccountCurrencyAmount(account.getAmountInAccountCurrency());
          if (StringUtil.isStringNotNullAndNotEmpty(account.getTransactionDate())) {
            String date = "";
            if (account.getTransactionDate().length() >= 8) {
              date = account.getTransactionDate().substring(0, 8);
            } else {
              date = account.getTransactionDate();
            }
            paymentTransaction
                .setPaymentTransactionDate(AmolDateUtils.dateConversion(inputDateFormat, outDateFormat, date));
          }
          pamentPurpose.setStatementTxnDesc1(account.getDescription());
          pamentPurpose.setStatementTxnDesc2(account.getSubCodeNarrative());
          pamentPurpose.setStatementTxnDesc3(account.getNarrative());
          pamentPurpose.setStatementTxnDesc4(account.getCounterPartyName());
          paymentTransaction.setCreditDebitTypeCode(account.getCreditDebitFlag());
          pamentPurpose.setTransactionReferenceNumber(account.getTransactionId());
          paymentTransaction.setPaymentTransactionTypeCode(String.valueOf(account.getMnemonic()));
          if (StringUtil.isStringNotNullAndNotEmpty(account.getValueDate())) {
            String date = "";
            if (account.getValueDate().length() >= 8) {
              date = account.getValueDate().substring(0, 8);
            } else {
              date = account.getValueDate();
            }
            paymentTransaction.setValueDate(AmolDateUtils.dateConversion(inputDateFormat, outDateFormat, date));
          }
          if (StringUtil.isStringNotNullAndNotEmpty(account.getPostDate())) {
            String date = "";
            if (account.getPostDate().length() >= 8) {
              date = account.getPostDate().substring(0, 8);
            } else {
              date = account.getPostDate();
            }
            paymentTransaction.setPostingDate(AmolDateUtils.dateConversion(inputDateFormat, outDateFormat, date));
          }
          paymentTransaction.setLcyAmount(account.getAmountInLocalCurrency());
          paymentTransaction.setTransactionCurrencyAmount(account.getAmount());
          paymentTransaction.setFeeType(String.valueOf(account.getServiceChargeCode()));
          paymentTransaction.setRunningBalanceAmount(account.getRunningTotal());
          pamentPurpose.setCheckNumber(account.getChequeNumber());
          paymentTransaction.setChannelReferenceNumber(account.getUserReferenceNumber());
          paymentTransaction.setCreatedBy(account.getUserId());

          paymentTransaction.setBatchNumber(account.getBatchNumber());

          if (StringUtil.isStringNotNullAndNotEmpty(account.getClearingType())) {
            mechanism.setClearingTypeCode(account.getClearingType());
            paymentTransaction.setPaymentMechanism(mechanism);
          }
          paymentTransaction.setTransactionLiteral(account.getTaskLiteral());
          paymentTransaction.setPaymentPurpose(pamentPurpose);
          if (StringUtil.isStringNotNullAndNotEmpty(account.getPostDate())) {
            String date = "";
            if (account.getPostDate().length() >= 8) {
              date = account.getPostDate().substring(0, 8);
            } else {
              date = account.getPostDate();
            }
            paymentTransaction.setPostingDate(AmolDateUtils.dateConversion(inputDateFormat, outDateFormat, date));
          }
          transactionList.add(paymentTransaction);

          if (StringUtil.isStringNotNullAndNotEmpty(account.getAuthoriserId())) {
            transactionDescription.setAuthorisedBy(account.getAuthoriserId());
            description.add(transactionDescription);
            response.setTransactionDescription(description);
          }

          response.setPaymentTransaction(transactionList);

          responseFcrAndEbox.setResponse(response);
        }
      }
      LOGGER.info(TRANSACTION_HISTORY_RESPONSE_FCR_RESPONSE_MAPPER,
          Constant.getConsumerUniqueReferenceId(apiRequestHeader), "FCR response mapped ",
          responseFcrAndEbox.toString());
      return responseFcrAndEbox;
    } catch (Exception exception) {
      LOGGER.error("getDomainMappingofAccDetailsFromFcr", Constant.getConsumerUniqueReferenceId(apiRequestHeader),
          "Exception in request mapping", exception.getMessage());
      LOGGER.error("getDomainMappingofAccDetailsFromFcr", Constant.getConsumerUniqueReferenceId(apiRequestHeader),
          "Exception in request mapping", exception);
      throw new ApiRequestException(Constant.BAD_REQUEST_CODE, exception.getMessage());
    }
  }
}


