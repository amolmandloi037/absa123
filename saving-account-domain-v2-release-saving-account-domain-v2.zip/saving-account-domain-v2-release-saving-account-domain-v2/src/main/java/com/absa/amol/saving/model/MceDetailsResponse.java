package com.absa.amol.saving.model;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Schema(name = "MceDetailsResponse",
    description = "POJO that represents Mce Details Response details")


public class MceDetailsResponse {

  private String eventByUserId;
  private String auditType;
  private String nameOnProbative;
  private PositionLimitType debitAmount;
  private PositionLimitType creditAmount;
  private Integer totalNumberOfRecords;
  private String accountNumber;
  private BigDecimal openingBalanceAmount;
  private BigDecimal closingBalanceAmount;
  private PaymentTransaction paymentTransaction;
  private DepositTransactionSourceReference depositTransactionSourceReference;
  List<TransactionDescription> transactionDescription;
  // List<IdPKDetails> idPkDetails;

  private Map<String, Object> additionalTransactionDetails;
  private String remarks;

}
