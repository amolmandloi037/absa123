package com.absa.amol.saving.model.standinginstruction.mod;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PayeeBankReferenceModReq {

	
	private String beneficiaryBranchCode;	
	private String beneficiaryBankCode;
	private String beneficiaryBranchName;	
	private String beneficiaryBankName;
	private String routingNumber;

}
