package com.absa.amol.saving.model.chequebook;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import com.absa.amol.saving.util.Constant;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(name = "ChequeBookDomainReq", description = Constant.REQUEST_SCHEMA_FOR_ADD_CHEQUE_BOOK)
public class ChequeBookDomainReq {

	@Schema(description = "Field is mandatory for all flows.", pattern = "[0-9]*", minLength = 1, maxLength = 12,required = true)
	@NotNull(message = Constant.CUSTOMER_REFERENCE_NOTNULLEMPTY_ERROR_MESSAGE)
	@NotEmpty(message = Constant.CUSTOMER_REFERENCE_NOTNULLEMPTY_ERROR_MESSAGE)
	@Size(min = 1, max = 12, message = Constant.CUSTOMER_REFERENCE_LENGTH_ERROR_MESSAGE)
	@Pattern(regexp = Constant.BRANCH_ID_REGX, message = Constant.CUSTOMER_REFERENCE_PATTERN_ERROR_MESSAGE)
	private String customerReference;
	
	private BankBranch bankBranch;
	
	@Pattern(regexp = Constant.BRANCH_ID_REGX, message = Constant.PRODUCT_INST_REFERENCE_PATTERN_ERROR_MESSAGE)
	@NotNull(message = Constant.PRODUCT_INST_REFERENCE_NOTNULLEMPTY_ERROR_MESSAGE)
	@NotEmpty(message = Constant.PRODUCT_INST_REFERENCE_NOTNULLEMPTY_ERROR_MESSAGE)
	@Schema(description = "Field is mandatory. For EBOX maxlength=7 and FCR maxlength=16", pattern = "[0-9]*",required = true)
	private String productInstanceReference;
	
	@NotNull(message = Constant.ISSUED_DEVICE_DESCRIPTION_NULLOR_EMPTY_ERROR_MESSAGE)
	@Valid
	private IssuedDeviceDescription issuedDeviceDescription;
	
	

}
