package com.absa.amol.saving.model;

import javax.json.bind.annotation.JsonbNillable;
import com.absa.amol.saving.model.retrievecasa.status.Status;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonbNillable
public class AccountMasterMaintenance {

  private Status status;
  private AccountCommonInformation accountCommonInformation;
  private CustomDate statementPeriodBeginDate;
  private CustomDate statementPeriodEndDate;
  private CurrentAndSavingsAccount currentAndSavingsAccount;
  private CASAControlAttribute CASAControlAttribute;
  private CASAInterestCapitalization CASAInterestCapitalization;
  private CASAValue CASAValue;
  private AccountBalance accountBalance;
  private UnclearedFundsAdvanceFacility unclearedFundsAdvanceFacility;
  private StatementFacility statementFacility;
  private MailFacility mailFacility;
  private OverdraftFacility overdraftFacility;
  private ExternalBankingFacilityAttributes externalBankingFacilityAttributes;
  private ChequeBookFacility chequeBookFacility;
  private BasicInformation basicInformation;
}
