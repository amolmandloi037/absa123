package com.absa.amol.saving.service.standinginstruction.del;

import com.absa.amol.util.model.ApiRequestHeader;

public interface StandingInstructionValidatorService {

	public <T>void validateInputRequest(T request,ApiRequestHeader apiRequestHeader);
	}
