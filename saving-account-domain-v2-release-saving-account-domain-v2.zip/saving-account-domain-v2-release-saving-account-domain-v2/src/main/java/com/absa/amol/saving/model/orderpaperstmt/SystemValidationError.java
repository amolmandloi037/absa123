package com.absa.amol.saving.model.orderpaperstmt;

import javax.json.bind.annotation.JsonbNillable;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonbNillable
public class SystemValidationError {
  private String applicableAttributes;
  private String attributeName;
  private String attributeValue;
  private String errorCode;
  private String errorMessage;
  private String methodName;
  private String objectName;
}
