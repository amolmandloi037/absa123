package com.absa.amol.saving.util;

import javax.ws.rs.BeanParam;
import javax.ws.rs.GET;

import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import com.absa.amol.saving.model.standinginstruction.retrieve.StandingInstructionsRetReq;
import com.absa.amol.saving.model.standinginstruction.retrieve.StandingInstructionsRetRes;
import com.absa.amol.util.model.ResponseEntity;

@RegisterRestClient(configKey = "retrieve.standing.instructions.process")
@RegisterProvider(value = ServerSideExceptionMapper.class)
public interface RetrieveStandingInstructionsClientBuilder {

	@GET
	ResponseEntity<StandingInstructionsRetRes> retrieveStandingInstructions(@BeanParam StandingInstructionsRetReq standingInstructionsRetReq);
}