package com.absa.amol.saving.model.standinginstruction.add;

import javax.json.bind.annotation.JsonbProperty;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
@Schema(name="StandingOrderAddRes", description="Response Schema For Add Standing Instruction Domain API")
public class StandingOrderAddRes {
	
	@JsonbProperty(nillable = true)
	private PaymentTransactionAddRes paymentTransaction;
	@JsonbProperty(nillable = true)
	private StandingOrderReferenceAddRes standingOrderReference;
}
