package com.absa.amol.saving.service.impl.chequebook;

import java.util.concurrent.CompletableFuture;

import javax.inject.Inject;

import org.eclipse.microprofile.config.Config;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import com.absa.amol.saving.builder.ChequeBookRequestClientBuilder;
import com.absa.amol.saving.mapper.chequebook.ChequeBookRequestMapper;
import com.absa.amol.saving.model.chequebook.ChequeBookDomainReqWrapper;
import com.absa.amol.saving.model.chequebook.ChequeBookDomainRes;
import com.absa.amol.saving.model.sys.chequebook.ChequeBookReq;
import com.absa.amol.saving.model.sys.chequebook.ChequeBookRes;
import com.absa.amol.saving.service.chequebook.IChequeBookService;
import com.absa.amol.saving.service.chequebook.IChequeBookValidatorService;
import com.absa.amol.saving.service.chequebook.ICustContactHistoryService;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.exception.ApiException;
import com.absa.amol.util.exception.ApiResponseException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ResponseEntity;

public class ChequeBookServiceImpl implements IChequeBookService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ChequeBookServiceImpl.class);

	@Inject
	@RestClient
	ChequeBookRequestClientBuilder clientBuilder;

	@Inject
	ChequeBookRequestMapper chequeBookRequestMapper;

	@Inject 
	ICustContactHistoryService custContactHistoryService;
	
	@Inject 
	IChequeBookValidatorService validatorService;

	@Inject
	Config config;
	
	@Override
	public ResponseEntity<ChequeBookDomainRes> addrequestChequeBook(ChequeBookDomainReqWrapper reqWrapper) {
		LOGGER.info(Constant.ADD_CHEQUE_BOOK_REQUEST,reqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(),Constant.EMPTY,Constant.EMPTY);

		try {
			validatorService.validateInputRequest(reqWrapper.getChequeBookDomainReq(), reqWrapper.getApiRequestHeader());
			ChequeBookReq chequeBookReq= chequeBookRequestMapper.chequeBookReqmapping(reqWrapper);
			ResponseEntity<ChequeBookRes> response = clientBuilder.addChequeBookRequest(chequeBookReq, reqWrapper.getApiRequestHeader());
			ResponseEntity<ChequeBookDomainRes> responseEntity = chequeBookRequestMapper.chequeBookResmapping(response);
			
			if(Constant.SUCCESS_CODE.equalsIgnoreCase(responseEntity.getCode())) {
				invokeMce(reqWrapper);
			}
			return responseEntity;
		}
		catch (ApiException apiException) {
			LOGGER.error(Constant.ADD_CHEQUE_BOOK_REQUEST, reqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(), Constant.API_EXCEPTION, apiException.getMessage());
			LOGGER.debug(Constant.ADD_CHEQUE_BOOK_REQUEST, reqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(), Constant.API_EXCEPTION, apiException);
			throw apiException;
		} catch (Exception exception) {
			LOGGER.error(Constant.ADD_CHEQUE_BOOK_REQUEST, reqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(), Constant.EXCEPTION, exception.getMessage());
			LOGGER.debug(Constant.ADD_CHEQUE_BOOK_REQUEST, reqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(), Constant.EXCEPTION, exception);
			throw new ApiResponseException(Constant.INTERNAL_ERROR_CODE, Constant.INTERNAL_ERROR_MSG);
		}
	}

	private void invokeMce(ChequeBookDomainReqWrapper chequeBookDomainReqWrapper) {

		try {
			LOGGER.info(Constant.INVOKE_MCE,chequeBookDomainReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(),Constant.EMPTY,Constant.EMPTY
					);
			CompletableFuture.runAsync(() -> 
			custContactHistoryService.addCustContactHistory(chequeBookDomainReqWrapper)
					);
		}catch(Exception ex) {
			LOGGER.error(Constant.INVOKE_MCE,chequeBookDomainReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(), Constant.EXCEPTION,ex.getMessage());
			LOGGER.debug(Constant.INVOKE_MCE,chequeBookDomainReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(), Constant.EXCEPTION, ex);
		}
	}

}
