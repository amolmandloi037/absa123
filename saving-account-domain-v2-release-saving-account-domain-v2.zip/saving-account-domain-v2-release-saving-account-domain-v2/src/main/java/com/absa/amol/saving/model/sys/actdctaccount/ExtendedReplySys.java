package com.absa.amol.saving.model.sys.actdctaccount;

import java.util.List;

import javax.json.bind.annotation.JsonbProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ExtendedReplySys {
	@JsonbProperty(nillable= true)
	private List<MessagesSys> messages;

}
