package com.absa.amol.saving.service.impl.updateaccountstatus;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.eclipse.microprofile.config.Config;

import com.absa.amol.saving.model.updateaccountstatus.UpdateAccountStatusDomainReq;
import com.absa.amol.saving.service.updateaccountstatus.UpdateAccountStatusValidationService;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.exception.ApiRequestException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.utility.StringUtil;

public class UpdateAccountStatusValidationServiceImpl implements UpdateAccountStatusValidationService {

	@Inject
	private Validator validator;

	@Inject
	Config config;

	private static final Logger LOGGER = LoggerFactory.getLogger(UpdateAccountStatusValidationServiceImpl.class);
	
	public <T>void validateInputRequest(T updateAccStatusReq,ApiRequestHeader apiRequestHeader) {
		Set<String> errorSet = validateReqHeader(apiRequestHeader);
		errorSet.addAll(validatedAnnotedBeans(updateAccStatusReq));
		errorSet.addAll(customvalidatedBeans((UpdateAccountStatusDomainReq) updateAccStatusReq));
		if (!errorSet.isEmpty()) {
			String validationErrorMessage = String.join(",", errorSet);
			LOGGER.error("validateInputRequest", apiRequestHeader.getConsumerUniqueReferenceId(), "Validation failed:", validationErrorMessage);
			throw new ApiRequestException(Constant.BAD_REQUEST_CODE, validationErrorMessage);
		}
	}
	private Set<String> validateReqHeader(ApiRequestHeader apiRequestHeader) {
		Set<ConstraintViolation<Object>> violations = validator.validate(apiRequestHeader);
		return violations.stream().map(constraint -> {
			String customErroMessage = getPropertyValue(constraint.getMessageTemplate());
			return StringUtil.isStringNullOrEmpty(customErroMessage) ? constraint.getMessage() : customErroMessage;
		}).collect(Collectors.toSet());
	}

	private <T>Set<String> validatedAnnotedBeans(T request) {
		Set<ConstraintViolation<Object>> violations = validator.validate(request);
		return violations.stream().map(constraint -> {
			String customErroMessage = getPropertyValue(constraint.getMessageTemplate());
			return StringUtil.isStringNullOrEmpty(customErroMessage) ? constraint.getMessage() : customErroMessage;
		}).collect(Collectors.toSet());
	}
	
	private Set<String> customvalidatedBeans(UpdateAccountStatusDomainReq updateAccountStatusDomainReq) {

		LOGGER.info(Constant.VALIDATE_INPUT_REQUEST, Constant.EMPTY,Constant.CUSTOMVALIDATED_BEANS, Constant.EMPTY);
		Set<String> customValErrSet = new HashSet<>();
			if (StringUtil.isStringNotNullAndNotEmpty(updateAccountStatusDomainReq.getSavingAccountNumber())
					&& (updateAccountStatusDomainReq.getSavingAccountNumber().split(Constant.ZERO_STRING, -1).length
							- 1 == updateAccountStatusDomainReq.getSavingAccountNumber().length())) {
				customValErrSet.add(
						getPropertyValue("savingAccountNumber.pattern.message"));
			}
		return customValErrSet;
	}

	
	private String getPropertyValue(String confkey) {
		String msg=null;
		try {
			msg =  config.getValue(confkey, String.class);
		} catch (Exception e) {
			LOGGER.error("getPropertyValue", "", "Exception while reading property for the key ::" + confkey, e.getMessage());
		}
		return msg;
	}


}
