package com.absa.amol.saving.model.sys.accountsnickname.add;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CustomerAccountDet {
	
    private String branchCode;
	
    private String accountNumber;

    private String creditCardFlag;
    
    private String accountNickName;
   
}
