package com.absa.amol.saving.model.orderdebitcard;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ProductInstanceReference {

	@Schema(description = "Field is mandatory.", pattern = "Only numeric", maxLength = 13, required = true)
	@NotEmpty(message = "orderdebitcard.accountNumber.nullorempty.error.message")
	@NotNull(message = "orderdebitcard.accountNumber.nullorempty.error.message")
	@Size(max = 13, message = "orderdebitcard.accountNumber.length.error.message")
	@Pattern(regexp="[0-9]*", message="orderdebitcard.accountNumber.regex.error.message")
	private String accountNumber;
	
	@Schema(description = "Field is mandatory.", pattern = "Only numeric", maxLength = 3, required = true)
	@NotEmpty(message = "orderdebitcard.productCode.nullorempty.error.message")
	@NotNull(message = "orderdebitcard.productCode.nullorempty.error.message")
	@Size(max = 3, message = "orderdebitcard.productCode.length.error.message")
	@Pattern(regexp="[0-9]*", message="orderdebitcard.productCode.regex.error.message")
	private String productCode;
}
