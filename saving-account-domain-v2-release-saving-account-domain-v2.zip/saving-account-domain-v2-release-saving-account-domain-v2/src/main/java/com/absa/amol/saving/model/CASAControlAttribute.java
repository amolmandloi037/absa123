package com.absa.amol.saving.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class CASAControlAttribute {
	private boolean jointAccountFlag;
	private boolean adHocStatementFlag;
	private String isGroupBonusInterestApplicable;
	private boolean inwardDirectDebitAuthorizationFlag;
	private boolean standingInstructionFlag;
	private boolean sweepoutInstructionFlag;
	private boolean interestWaiverFlag;
}
