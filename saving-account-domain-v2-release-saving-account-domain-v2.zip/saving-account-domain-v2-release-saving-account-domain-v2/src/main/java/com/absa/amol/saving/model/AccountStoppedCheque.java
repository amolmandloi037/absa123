package com.absa.amol.saving.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AccountStoppedCheque {

	private Integer firstChequeNumber;
	private Float chequeAmount;
	private Integer lastChequeNumber;
	private Integer stopType;
	private String originalStopDate;
	private String stoppedChequeAction;

}
