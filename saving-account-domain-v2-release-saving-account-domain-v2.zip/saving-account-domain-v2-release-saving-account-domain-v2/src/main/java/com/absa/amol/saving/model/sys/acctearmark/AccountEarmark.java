package com.absa.amol.saving.model.sys.acctearmark;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class AccountEarmark {
	private String postDate;
	private String amount;
	private String drCrMultiplier;
	private String matDate;
	private String authCode;	
	private String narrative;
	private String deviceId;
	private String dateAndTime;	
}
