package com.absa.amol.saving.mapper;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.eclipse.microprofile.config.Config;

import com.absa.amol.saving.model.acctearmarkpendingentries.AccountDetails;
import com.absa.amol.saving.model.acctearmarkpendingentries.AcctEarmarkPendingEntriesDomainRequest;
import com.absa.amol.saving.model.acctearmarkpendingentries.AcctEarmarkPendingEntriesDomainResponse;
import com.absa.amol.saving.model.acctearmarkpendingentries.AcctEarmarkPendingEntriesListResponse;
import com.absa.amol.saving.model.acctearmarkpendingentries.Date;
import com.absa.amol.saving.model.acctearmarkpendingentries.IssuedDevicePropertyValue;
import com.absa.amol.saving.model.acctearmarkpendingentries.PositionLimitType;
import com.absa.amol.saving.model.acctearmarkpendingentries.PositionLimitValue;
import com.absa.amol.saving.model.sys.acctearmark.AccountEarmark;
import com.absa.amol.saving.model.sys.acctearmark.AcctEarmarkSystemAdapterReq;
import com.absa.amol.saving.model.sys.acctearmark.AcctEarmarkSystemAdapterRes;
import com.absa.amol.util.model.ResponseEntity;

public class EarmarkRequestMapper {

	@Inject
	Config config;

	public  AcctEarmarkSystemAdapterReq mapRequest(AcctEarmarkPendingEntriesDomainRequest acctEarmarkDomainRequest) {
		AcctEarmarkSystemAdapterReq acctEarmarkSystemAdapterReq = new AcctEarmarkSystemAdapterReq();
		acctEarmarkSystemAdapterReq.setRequestHeader(acctEarmarkDomainRequest.getApiRequestHeader());
		acctEarmarkSystemAdapterReq.setAccountNumber(acctEarmarkDomainRequest.getAccountNumber());
		acctEarmarkSystemAdapterReq.setBranchNumber(acctEarmarkDomainRequest.getBankBranchReference());
		return acctEarmarkSystemAdapterReq;
	}

	public  ResponseEntity<AcctEarmarkPendingEntriesListResponse> mapResponse( ResponseEntity<AcctEarmarkSystemAdapterRes> responseEntity) {
		{
			ResponseEntity<AcctEarmarkPendingEntriesListResponse> response = null;			
			AcctEarmarkPendingEntriesListResponse acctEarmarkListResponse = new AcctEarmarkPendingEntriesListResponse();
			ArrayList<AcctEarmarkPendingEntriesDomainResponse> earmarkingList = new ArrayList<>();
			List<AccountEarmark> earmarkList = null;	
			if(responseEntity.getData()!=null)
			{
				earmarkList = responseEntity.getData().getEarmarkingList();
				for(AccountEarmark earmark : earmarkList)
				{
					AcctEarmarkPendingEntriesDomainResponse acctEarmarkDomainResponse = new AcctEarmarkPendingEntriesDomainResponse();
					Date date = new Date();
					PositionLimitValue positionLimitValue = new PositionLimitValue();
					IssuedDevicePropertyValue issuedDevicePropertyValue = new IssuedDevicePropertyValue();
					AccountDetails accountDetails = new AccountDetails();
					PositionLimitType positionLimitType = new PositionLimitType();
					date.setPostDate(earmark.getPostDate());
					date.setMaturityDate(earmark.getMatDate());
					date.setDateAndTime(earmark.getDateAndTime());
					acctEarmarkDomainResponse.setDate(date);
					acctEarmarkDomainResponse.setAuthCode(Integer.valueOf(earmark.getAuthCode()));
					if(earmark.getAmount()!= null && !earmark.getAmount().isEmpty())
					{
						positionLimitValue.setAmount(earmark.getAmount());
					}
					acctEarmarkDomainResponse.setPositionLimitValue(positionLimitValue);
					accountDetails.setNarrative(earmark.getNarrative());
					acctEarmarkDomainResponse.setAccountDetails(accountDetails);
					positionLimitType.setDrCrMultiplier(earmark.getDrCrMultiplier());
					acctEarmarkDomainResponse.setPositionLimitType(positionLimitType);
					issuedDevicePropertyValue.setDeviceId(Integer.valueOf(earmark.getDeviceId()));
					acctEarmarkDomainResponse.setIssuedDevicePropertyValue(issuedDevicePropertyValue);
					earmarkingList.add(acctEarmarkDomainResponse);
				}
			}
			acctEarmarkListResponse.setEarmarkingPendingEntriesList(earmarkingList);
			response = new ResponseEntity<>(responseEntity.getCode(),
					responseEntity.getMessage(), responseEntity.getStatus(), acctEarmarkListResponse);
			return response;
		}
	}
}