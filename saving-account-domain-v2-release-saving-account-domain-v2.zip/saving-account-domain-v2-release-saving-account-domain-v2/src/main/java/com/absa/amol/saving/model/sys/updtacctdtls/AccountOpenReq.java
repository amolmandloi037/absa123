package com.absa.amol.saving.model.sys.updtacctdtls;

import java.util.List;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(name = "AccountOpenReq", description = "Request Schema for Retrieve Account Open - EBOX")
public class AccountOpenReq {
	
	private String branchCode;
	private String accountId;
	private String locationCode;
	private String productId;
	private String accountShortName;
	private String accountLongName;
	private String currency;
	private String primaryCustomerNumber;
	private String accountStatus;
	private AcctAddress acctAddress;
	private List<AccountParameters> accountParameter;
	private PricingParametersSys pricingParameters;

}
