package com.absa.amol.saving.model.createcasaaccount;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CreateCasaAccountResponse {
  private String productInstanceReference;
  private Long accountCreationStatusCode;
  private String accountCreationStatusDescription;
  private String transactionReferenceNumber;
  private String transactionDateTime;

}
