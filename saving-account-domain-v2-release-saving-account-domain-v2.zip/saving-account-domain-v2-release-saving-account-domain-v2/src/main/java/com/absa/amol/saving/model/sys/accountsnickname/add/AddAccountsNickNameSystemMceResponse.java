package com.absa.amol.saving.model.sys.accountsnickname.add;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class AddAccountsNickNameSystemMceResponse {

	private String serviceRespDateTime;
	private String serviceResponseCode;
	private String serviceResponseDesc;
	private String serviceUniqueRefNo;
}
