package com.absa.amol.saving.model.standinginstruction.singledetail;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentPurposeSingleDetailResp 
{
	private String narrative; //FCR
}
