package com.absa.amol.saving.model.sys.addcontacthistory;

import java.util.List;

import javax.json.bind.annotation.JsonbProperty;
import javax.validation.Valid;
import javax.ws.rs.BeanParam;

import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.model.ApiRequestHeader;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AddContactHistoryRequest {
	
	@BeanParam
	@Valid
	private ApiRequestHeader apiRequestHeader;

	@JsonbProperty(Constant.CONTACT_LIST)
	@Valid
	private List<ContactHistoryDetails> contactHistoryDetails;

}
