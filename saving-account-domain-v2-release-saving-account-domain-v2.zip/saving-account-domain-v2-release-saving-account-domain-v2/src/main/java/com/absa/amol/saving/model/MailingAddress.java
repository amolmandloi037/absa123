package com.absa.amol.saving.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MailingAddress {

  private String contactName;
  private String line1;
  private String line2;
  private String line3;
  private Integer addressIdentifier;
}
