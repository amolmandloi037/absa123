package com.absa.amol.saving.model.standinginstruction.mod;

import javax.validation.Valid;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PayeeReferenceModReq {

	private String beneficiaryAddressCity;

	private String beneficiaryAddressCountry;

	private String beneficiaryAddressline1;

	private String beneficiaryAddressline2;

	private String beneficiaryAddressline3;

	private String beneficiaryAddressState;

	private String beneficiaryAddressZip;

	private String beneficiaryName;

	@Valid
	private PhoneModReq phone;

	private String beneficiaryId;
}
