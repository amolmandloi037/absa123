package com.absa.amol.saving.model.standinginstruction.add;

import java.math.BigDecimal;

import javax.json.bind.annotation.JsonbProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentTransactionAddRes {

	@JsonbProperty(nillable = true)
	private PaymentPurposeAddRes paymentPurpose;
	
	@JsonbProperty(nillable = true)
	private String date;
	
	@JsonbProperty(nillable = true)
	private String feeType;
	
	@JsonbProperty(nillable = true)
	private BigDecimal feeCharge; 

}
