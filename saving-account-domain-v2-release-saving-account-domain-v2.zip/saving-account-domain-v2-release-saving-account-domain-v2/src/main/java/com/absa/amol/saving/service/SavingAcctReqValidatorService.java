package com.absa.amol.saving.service;

import com.absa.amol.saving.model.SavingAccountArrangementRequest;
import com.absa.amol.saving.model.SavingAccountDetailsRequest;

public interface SavingAcctReqValidatorService {
  public void validateSavingAcctRequest(SavingAccountDetailsRequest accountRequest);
  public void validateUpdateRequest(SavingAccountArrangementRequest request);
}
