package com.absa.amol.saving.service.checkstatus;

import javax.ws.rs.core.Response;

import com.absa.amol.saving.model.checkstatus.CheckStatusRequest;

public interface CheckStatusService {
	public Response getCheckStatus(CheckStatusRequest req);
}
