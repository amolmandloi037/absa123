package com.absa.amol.saving.service.purchasemv;

import com.absa.amol.saving.model.purchasemv.PurchaseMvReqWrapper;

public interface PurchaseMvValidatorService {
	public void validateInputRequest(PurchaseMvReqWrapper requestWrapper);
}
