package com.absa.amol.saving.service.orderpaperstmt;

import com.absa.amol.saving.model.orderpaperstmt.OrderPaperStmtDomainRequest;

public interface OrderPaperStatementValidatorService {
  public void validateOrderPaperStmtRequest(OrderPaperStmtDomainRequest req);
}
