package com.absa.amol.saving.model.standinginstruction.mod;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PayeeAccountReferenceModReq {

	private String beneficiaryAccountTypes;

	private String accountNumber;
}
