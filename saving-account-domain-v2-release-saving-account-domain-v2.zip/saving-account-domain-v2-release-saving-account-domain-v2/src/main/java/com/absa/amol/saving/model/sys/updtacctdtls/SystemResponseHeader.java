package com.absa.amol.saving.model.sys.updtacctdtls;

import javax.json.bind.annotation.JsonbProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SystemResponseHeader {
	
	@JsonbProperty(nillable = true)
	private String msgId;
	@JsonbProperty(nillable = true)
	private String transactionId;
	@JsonbProperty(nillable = true)
	private String correlId;

}
