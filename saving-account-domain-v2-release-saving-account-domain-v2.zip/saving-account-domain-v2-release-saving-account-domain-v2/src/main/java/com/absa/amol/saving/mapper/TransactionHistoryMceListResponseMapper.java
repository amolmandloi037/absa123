package com.absa.amol.saving.mapper;

import java.util.ArrayList;
import java.util.List;
import com.absa.amol.saving.model.CorpuserFTListResponse;
import com.absa.amol.saving.model.PayeeAccountReference;
import com.absa.amol.saving.model.PaymentPurpose;
import com.absa.amol.saving.model.PaymentTransaction;
import com.absa.amol.saving.model.Response;
import com.absa.amol.saving.model.TransactionHistoryDomainResponse;
import com.absa.amol.saving.model.TrxnDetails;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.utility.CollectionUtil;
import com.absa.amol.util.utility.CommonUtil;

public class TransactionHistoryMceListResponseMapper {
  private static final Logger LOGGER =
      LoggerFactory.getLogger(TransactionHistoryMceListResponseMapper.class);

  public TransactionHistoryDomainResponse fundTransferListResMapper(
      ApiRequestHeader apiRequestHeader, CorpuserFTListResponse corpuserFTListResponse) {

    LOGGER.info("TransactionHistoryMceListResponseMapper",
        Constant.getConsumerUniqueReferenceId(apiRequestHeader),
        "start of mce response mapper Method", "");
    TransactionHistoryDomainResponse transhistResponse = new TransactionHistoryDomainResponse();
    Response response = new Response();
    if (CommonUtil.isNotNull(corpuserFTListResponse)) {
      response.setTotalNumberOfRecords(corpuserFTListResponse.getTotalNumberOfRecords());

      List<PaymentTransaction> transactionMceList = new ArrayList<>();

      // for loop to set list
      if (CollectionUtil.isNotNullAndNotEmpty(corpuserFTListResponse.getTrxnDetails())) {
        List<TrxnDetails> trxnDetails = corpuserFTListResponse.getTrxnDetails();
        for (TrxnDetails trxnDetailsList : trxnDetails) {
          PaymentTransaction transactionMce = new PaymentTransaction();
          PaymentPurpose paymentPurpose = new PaymentPurpose();
          PayeeAccountReference payeeAccountReference = new PayeeAccountReference();
          transactionMce.setPaymentTransactionTypeCode(trxnDetailsList.getTransactionTypeCode());
          transactionMce.setPaymentTransactionDate(trxnDetailsList.getTransactionDateTime());
          transactionMce.setPaymentTransactionAmount(
              Double.parseDouble(trxnDetailsList.getTransactionCurrencyAmount()));
          paymentPurpose
              .setTransactionReferenceNumber(trxnDetailsList.getTransactionReferenceNumber());
          payeeAccountReference.setBenAccountNumber(trxnDetailsList.getBenAccountNumber());
          payeeAccountReference.setBeneficiaryName(trxnDetailsList.getBeneficiaryName());
          transactionMceList.add(transactionMce);
          transactionMce.setPaymentPurpose(paymentPurpose);
          transactionMce.setPayeeAccountReference(payeeAccountReference);
          response.setPaymentTransaction(transactionMceList);
        }
      }
      transhistResponse.setResponse(response);



    }

    LOGGER.info("TransactionHistoryMceListResponseMapper",
        Constant.getConsumerUniqueReferenceId(apiRequestHeader), "mce response mapper Method",
        transhistResponse.toString());

    return transhistResponse;
  }
}

