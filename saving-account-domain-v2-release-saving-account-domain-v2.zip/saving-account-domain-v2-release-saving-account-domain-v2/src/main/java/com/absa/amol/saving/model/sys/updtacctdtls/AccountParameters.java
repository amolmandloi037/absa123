package com.absa.amol.saving.model.sys.updtacctdtls;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountParameters {
	
	private String parameterId;
	private String parameterValue;

}
