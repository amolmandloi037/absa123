package com.absa.amol.saving.builder;

import javax.ws.rs.BeanParam;
import javax.ws.rs.GET;
import javax.ws.rs.core.Response;

import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import com.absa.amol.saving.model.sys.accountsnickname.retrieve.RetrieveNickNameSystemRequest;
import com.absa.amol.saving.util.ServerSideExceptionMapper;

@RegisterRestClient(configKey = "accountsnickname.retrieve.sys.url")
@RegisterProvider(value = ServerSideExceptionMapper.class)
public interface RetrieveNickNameDomainClientBuilder {
	
	@GET
	Response retrieveNickName(@BeanParam RetrieveNickNameSystemRequest retrieveNickNameSystemRequest);
	
}
