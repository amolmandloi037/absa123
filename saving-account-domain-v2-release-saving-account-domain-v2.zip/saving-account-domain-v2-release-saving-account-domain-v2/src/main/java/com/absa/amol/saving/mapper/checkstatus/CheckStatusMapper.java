package com.absa.amol.saving.mapper.checkstatus;

import java.util.ArrayList;
import java.util.List;

import com.absa.amol.saving.model.checkstatus.CheckStatusRequest;
import com.absa.amol.saving.model.checkstatus.CheckStatusResponse;
import com.absa.amol.saving.model.checkstatus.ChequeStatusModel;
import com.absa.amol.saving.model.checkstatus.RetrieveCheckStatusRequest;
import com.absa.amol.saving.model.checkstatus.RetrieveCheckStatusResponse;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.utility.CommonUtil;

public class CheckStatusMapper {
	private static final Logger LOGGER = LoggerFactory.getLogger(CheckStatusMapper.class);

	public RetrieveCheckStatusRequest checkStatusReqMapping(CheckStatusRequest req) {
		LOGGER.info("checkStatusReqMapping",
				req.getApiRequestHeader().getConsumerUniqueReferenceId(), Constant.EMPTY, " Start");

		RetrieveCheckStatusRequest sysRequest = new RetrieveCheckStatusRequest();
		sysRequest.setApiRequestHeader(req.getApiRequestHeader());

		sysRequest.setAccountId(req.getSavingsAccountNumber());
		if( CommonUtil.isNotNull(req.getIssuedDevicePropertyValue())) {
			sysRequest.setChequeNumber(req.getIssuedDevicePropertyValue());
		}

		LOGGER.info("checkStatusReqMapping",
				req.getApiRequestHeader().getConsumerUniqueReferenceId(), Constant.EMPTY, " End");
		return sysRequest;
	}



	public CheckStatusResponse checkStatusResMapping(RetrieveCheckStatusResponse sysResponse ) {
		CheckStatusResponse domainRes = new CheckStatusResponse();
		List<ChequeStatusModel> lst = new ArrayList<ChequeStatusModel>();
		
		if(CommonUtil.isNotNull(sysResponse)) {
			if(CommonUtil.isNotNull(sysResponse.getItems())) {

				for (ChequeStatusModel var : sysResponse.getItems()) {
					ChequeStatusModel statusModel = new ChequeStatusModel();
					statusModel.setAccountId(var.getAccountId());
					statusModel.setChequeAmount(var.getChequeAmount());
					statusModel.setChequeStatus(var.getChequeStatus());
					statusModel.setCustomerShortName(var.getCustomerShortName());
					lst.add(statusModel);
				}
				domainRes.setItems(lst);
			}
		}
		return domainRes;

	}

}
