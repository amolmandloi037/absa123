package com.absa.amol.saving.model.purchasemv;

import javax.validation.Valid;

import com.absa.amol.util.model.ApiRequestHeader;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class PurchaseMvReqWrapper {
	
	@Valid
	private ApiRequestHeader apiRequestHeader;
	@Valid
	private PurchaseMvReq purchaseMvReq;
	private String operationId;
	
}
