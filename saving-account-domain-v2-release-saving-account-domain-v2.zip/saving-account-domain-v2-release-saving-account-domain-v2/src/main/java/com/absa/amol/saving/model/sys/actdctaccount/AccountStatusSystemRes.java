package com.absa.amol.saving.model.sys.actdctaccount;

import java.util.List;

import javax.json.bind.annotation.JsonbProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountStatusSystemRes {
	@JsonbProperty(nillable= true)
	private ExtendedReplySys extendedReply;
	@JsonbProperty(nillable= true)
	private String statusCode;
	@JsonbProperty(nillable= true)
	private String externalReferenceNo;
	@JsonbProperty(nillable= true)
	private String inputOverridenWarnings;
	@JsonbProperty(nillable= true)
	private Boolean isOverriden;
	@JsonbProperty(nillable= true)
	private Boolean isServiceChargeApplied;
	@JsonbProperty(nillable= true)
	private String memo;
	@JsonbProperty(nillable= true)
	private Long replyCode;
	@JsonbProperty(nillable= true)
	private String statusDesc;
	@JsonbProperty(nillable= true)
	private Long spReturnValue;
	@JsonbProperty(nillable= true)
	private String transactionDateTimeText;
	@JsonbProperty(nillable= true)
	private String userReferenceNumber;
	@JsonbProperty(nillable= true)
	private List<ValidationErrorsSys> validationErrors;

}
