package com.absa.amol.saving.controller;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.eclipse.microprofile.config.Config;
import org.eclipse.microprofile.faulttolerance.Fallback;
import org.eclipse.microprofile.faulttolerance.Timeout;
import org.eclipse.microprofile.faulttolerance.exceptions.TimeoutException;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponses;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

import com.absa.amol.saving.model.SavingAccountArrangementRequest;
import com.absa.amol.saving.model.SavingAccountDetailsRequest;
import com.absa.amol.saving.model.SavingAccountDetailsResponse;
import com.absa.amol.saving.model.TransactionHistoryDomainRequest;
import com.absa.amol.saving.model.TransactionHistoryResponse;
import com.absa.amol.saving.model.accountsnickname.add.AddAccountsNickNameReq;
import com.absa.amol.saving.model.accountsnickname.add.AddAccountsNickNameRes;
import com.absa.amol.saving.model.accountsnickname.retrieve.RetrieveAccountsNickNameReq;
import com.absa.amol.saving.model.accountsnickname.retrieve.RetrieveAccountsNickNameRes;
import com.absa.amol.saving.model.acctearmarkpendingentries.AcctEarmarkPendingEntriesDomainRequest;
import com.absa.amol.saving.model.acctearmarkpendingentries.AcctEarmarkPendingEntriesDomainResponse;
import com.absa.amol.saving.model.bankersnotes.AccountNotes;
import com.absa.amol.saving.model.bankersnotes.BankersNotesDomainRequest;
import com.absa.amol.saving.model.checkstatus.CheckStatusRequest;
import com.absa.amol.saving.model.checkstatus.CheckStatusResponse;
import com.absa.amol.saving.model.chequebook.ChequeBookDomainReq;
import com.absa.amol.saving.model.chequebook.ChequeBookDomainReqWrapper;
import com.absa.amol.saving.model.chequebook.ChequeBookDomainRes;
import com.absa.amol.saving.model.createcasaaccount.CreateCasaAccountRequest;
import com.absa.amol.saving.model.createcasaaccount.CreateCasaAccountResponse;
import com.absa.amol.saving.model.demanddraft.DemandDraftDomainReq;
import com.absa.amol.saving.model.demanddraft.DemandDraftDomainReqWrapper;
import com.absa.amol.saving.model.orderdebitcard.OrderDebitCardDomainReq;
import com.absa.amol.saving.model.orderdebitcard.OrderDebitCardDomainRes;
import com.absa.amol.saving.model.orderpaperstmt.OrderPaperStmtDomainRequest;
import com.absa.amol.saving.model.orderpaperstmt.OrderPaperStmtDomainResponse;
import com.absa.amol.saving.model.purchasemv.PurchaseMvReq;
import com.absa.amol.saving.model.purchasemv.PurchaseMvReqWrapper;
import com.absa.amol.saving.model.purchasemv.PurchaseMvRes;
import com.absa.amol.saving.model.standinginstruction.add.StandingOrderAddReq;
import com.absa.amol.saving.model.standinginstruction.add.StandingOrderAddRes;
import com.absa.amol.saving.model.standinginstruction.del.StandingDelReq;
import com.absa.amol.saving.model.standinginstruction.del.StandingDelRes;
import com.absa.amol.saving.model.standinginstruction.mod.StandingModReq;
import com.absa.amol.saving.model.standinginstruction.mod.StandingModRes;
import com.absa.amol.saving.model.standinginstruction.retrieve.StandingInstructionsRetReq;
import com.absa.amol.saving.model.standinginstruction.retrieve.StandingInstructionsRetRes;
import com.absa.amol.saving.model.standinginstruction.singledetail.StandingInstructionSingleDetailRequest;
import com.absa.amol.saving.model.standinginstruction.singledetail.StandingInstructionSingleDetailResponse;
import com.absa.amol.saving.model.unclearedfund.UnclearFundDetailsRequest;
import com.absa.amol.saving.model.unclearedfund.UnclearFundDetailsResponse;
import com.absa.amol.saving.model.updateaccountstatus.UpdateAccountStatusDomainReq;
import com.absa.amol.saving.model.updateaccountstatus.UpdateAccountStatusDomainReqWrapper;
import com.absa.amol.saving.model.updateaccountstatus.UpdateAccountStatusDomainRes;
import com.absa.amol.saving.model.updtacctdtls.UpdateAcctDtlsReq;
import com.absa.amol.saving.model.updtacctdtls.UpdateAcctDtlsReqWrapper;
import com.absa.amol.saving.model.updtacctdtls.UpdateAcctDtlsRes;
import com.absa.amol.saving.model.updtacctstatus.UpdateAcctStatusReq;
import com.absa.amol.saving.model.updtacctstatus.UpdateAcctStatusReqWrapper;
import com.absa.amol.saving.model.updtacctstatus.UpdateAcctStatusRes;
import com.absa.amol.saving.service.AccountEarmarkPendingEntriesService;
import com.absa.amol.saving.service.AccountEarmarkPendingEntriesValidatorService;
import com.absa.amol.saving.service.AddStandingInstructionService;
import com.absa.amol.saving.service.IOrderDebitCardService;
import com.absa.amol.saving.service.IStandingInstructionSingleDetailService;
import com.absa.amol.saving.service.RetrieveStandingInstructionsService;
import com.absa.amol.saving.service.SavingAcctDetailsService;
import com.absa.amol.saving.service.SavingAcctReqValidatorService;
import com.absa.amol.saving.service.SavingsAccountUpdateService;
import com.absa.amol.saving.service.TranHistoryValidatorService;
import com.absa.amol.saving.service.TransactionHistoryService;
import com.absa.amol.saving.service.accountsnickname.RetrieveNickNameDomainService;
import com.absa.amol.saving.service.accountsnickname.RetrieveNickNameValidatorService;
import com.absa.amol.saving.service.accountsnickname.add.IAddAccountsNicknameService;
import com.absa.amol.saving.service.bankersnotes.BankersNotesService;
import com.absa.amol.saving.service.checkstatus.CheckStatusService;
import com.absa.amol.saving.service.checkstatus.CheckStatusValidatorService;
import com.absa.amol.saving.service.chequebook.IChequeBookService;
import com.absa.amol.saving.service.createcasaaccount.CreateCasaAccountService;
import com.absa.amol.saving.service.createcasaaccount.CreateCasaAccountValidatorService;
import com.absa.amol.saving.service.demandraft.IDemandDraftService;
import com.absa.amol.saving.service.orderpaperstmt.OrderPaperStatementService;
import com.absa.amol.saving.service.orderpaperstmt.OrderPaperStatementValidatorService;
import com.absa.amol.saving.service.purchasemv.PurchaseMvService;
import com.absa.amol.saving.service.standinginstruction.del.StandingInstructionDelService;
import com.absa.amol.saving.service.standinginstruction.mod.StandingInstructionModService;
import com.absa.amol.saving.service.unclearedfund.UnclearedFundService;
import com.absa.amol.saving.service.unclearedfund.UnclearedfundReqValidator;
import com.absa.amol.saving.service.updateaccountstatus.UpdateAccountStatusService;
import com.absa.amol.saving.service.updtacctamendstatus.UpdateAcctStatusService;
import com.absa.amol.saving.service.updtacctdtls.UpdateAcctDtlsService;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.saving.util.bankersnotes.ValidatorUtil;
import com.absa.amol.saving.util.unclearedfund.UnclearedFundConstant;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.model.ResponseEntity;

@RequestScoped
@Path("savings-account")
public class SavingAccountDomainController {



	private static final Logger LOGGER = LoggerFactory.getLogger(SavingAccountDomainController.class);

	@Inject
	Config config;

	@Inject
	private SavingAcctDetailsService savingDetailsService;

	@Inject
	private SavingAcctReqValidatorService savingReqValidatorService;

	@Inject
	private TranHistoryValidatorService tranHistoryValidatorService;

	@Inject
	private TransactionHistoryService transactionHistoryService;

	@Inject
	private UnclearedFundService unclearedFundService;

	@Inject 
	private IAddAccountsNicknameService addAccountsNicknameService;

	@Inject
	private SavingsAccountUpdateService updateService;

	@Inject
	private UnclearedfundReqValidator unclearedfundReqValidator;

	@Inject
	private AddStandingInstructionService addStandingInstructionService;

	@Inject
	private RetrieveStandingInstructionsService retrieveStandingInstructionsService;

	@Inject
	private StandingInstructionDelService standingInstructionDelService;

	@Inject 
	private IStandingInstructionSingleDetailService standingInstructionSingleDetailService;

	@Inject
	private StandingInstructionModService standingInstructionModService;

	@Inject
	private IChequeBookService chequeBookService;

	@Inject
	private IDemandDraftService demandDraftService;

	@Inject
	private RetrieveNickNameDomainService retrieveNickNameDomainService;

	@Inject
	private RetrieveNickNameValidatorService retrieveNickNameValidatorService;

	@Inject
	private OrderPaperStatementService orderPaperStatementService;

	@Inject
	private OrderPaperStatementValidatorService orderPaperStatementValidatorService;

	@Inject
	private AccountEarmarkPendingEntriesValidatorService accountEarmarkPendingEntriesValidatorService;

	@Inject
	private CheckStatusValidatorService checkStatusValidatorService;

	@Inject
	private CheckStatusService checkStatusService;

	@Inject
	private BankersNotesService bankersNotesService;
	@Inject
	private ValidatorUtil validatorUtil;

	@Inject
	private IOrderDebitCardService orderDebitCardService;

	@Inject
	private AccountEarmarkPendingEntriesService accountEarmarkPendingEntriesService;


	@Inject
	private CreateCasaAccountService createCasaAccountService;

	@Inject
	private CreateCasaAccountValidatorService createCasaAccountValidatorService;

	@Inject
	private PurchaseMvService purchaseMvService;

	@Inject
	private UpdateAcctDtlsService updateAcctDtlsService;

	@Inject
	UpdateAcctStatusService updateAcctStatusService;

	@Inject
	private UpdateAccountStatusService updateAccountStatusService;

	@GET
	@Path("/savings-account-fulfillment/account-information/retrieval")
	@Timeout
	@Fallback(fallbackMethod = Constant.FALLBACK_METHOD_FOR_TIMEOUT,
	applyOn = {TimeoutException.class})
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Tag(name = Constant.SAVINGS_ACCOUNT_FULFILLMENT)
	@APIResponses(value = {
			@APIResponse(responseCode = Constant.BAD_REQUEST_CODE, description = Constant.BAD_REQ,
					content = @Content(mediaType = Constant.APPL_JSON,
					schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.INTERNAL_ERROR_CODE,
			description = Constant.INTERNAL_ERROR_MSG,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.DOWNSTREAM_UNAVAILABLE,
			description = Constant.SERVICE_UNAVAILABLE,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.TIMEOUT_CODE, description = Constant.GATEWAY_TIMEOUT,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.SUCCESS_CODE, description = Constant.SUCCESS_MSG,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = SavingAccountDetailsResponse.class)))})
	@Operation(summary = "Get saving account details",
	description = "Get saving account details using account number and branch code")
	public Response getSavingAccountDetails(
			@BeanParam SavingAccountDetailsRequest casaAccountDetailsRequest) {

		savingReqValidatorService.validateSavingAcctRequest(casaAccountDetailsRequest);
		LOGGER.info("getSavingAccountDetails",
				casaAccountDetailsRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
				"start of getSavingAccountDetails Method", "");

		return savingDetailsService.getSavingAcctDetails(casaAccountDetailsRequest);
	}

	public Response fallbackForTimeout(SavingAccountDetailsRequest casaAccountDetailsRequest) {
		LOGGER.info(Constant.FALLBACK_METHOD_FOR_TIMEOUT,
				casaAccountDetailsRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
				"Fallback method after waiting milliseconds!=",
				config.getValue(Constant.FALLBACK_TIMEOUT_KEY_AM, String.class));
		ResponseEntity<String> responseEntity = new ResponseEntity<>(Constant.TIMEOUT_CODE,
				"No response from downstream service", Constant.FAILURE_MSG, null);
		return Response.status(504).entity(responseEntity).build();
	}

	/**
	 * retrieve Transaction History *
	 */

	@GET
	@Path("/savings-account-fulfillment/transaction-history/retrieval")
	@Timeout
	@Fallback(fallbackMethod = Constant.FALLBACK_METHOD_FOR_TIMEOUT,
	applyOn = {TimeoutException.class})
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Tag(name = Constant.SAVINGS_ACCOUNT_FULFILLMENT)
	@APIResponses(value = {
			@APIResponse(responseCode = Constant.BAD_REQUEST_CODE, description = Constant.BAD_REQ,
					content = @Content(mediaType = Constant.APPL_JSON,
					schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.INTERNAL_ERROR_CODE,
			description = Constant.INTERNAL_ERROR_MSG,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.DOWNSTREAM_UNAVAILABLE,
			description = Constant.SERVICE_UNAVAILABLE,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.TIMEOUT_CODE, description = Constant.GATEWAY_TIMEOUT,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.SUCCESS_CODE, description = Constant.SUCCESS_MSG,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = TransactionHistoryResponse.class)))})
	@Operation(summary = "Get saving account transaction history details",
	description = "Fetch saving account transaction history details")
	public Response getTransactionHistoryDetails(
			@BeanParam TransactionHistoryDomainRequest historyDomainRequest) {
		tranHistoryValidatorService.validateCasaRequest(historyDomainRequest);

		LOGGER.info("getTransactionHistoryDetails",
				historyDomainRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
				"start of getTransactionHistoryDetails Method", "");

		return transactionHistoryService.getTransactionHistoryResponse(historyDomainRequest);
	}

	public Response fallbackForTimeout(TransactionHistoryDomainRequest historyDomainRequest) {
		LOGGER.info(Constant.FALLBACK_METHOD_FOR_TIMEOUT,
				historyDomainRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
				"# Fallback method after waiting milliseconds!=",
				config.getValue(Constant.FALLBACK_TIMEOUT_KEY_TH, String.class));
		ResponseEntity<String> responseEntity = new ResponseEntity<>(Constant.TIMEOUT_CODE,
				"No response from downstream service. ", Constant.FAILURE_MSG, null);
		return Response.status(504).entity(responseEntity).build();
	}

	/**
	 * retrieve UnclearedFund
	 * 
	 */

	@GET
	@Path("/savings-account-fulfillment/account-information/unclear-fund/retrieval")
	@Timeout
	@Fallback(fallbackMethod = UnclearedFundConstant.FALLBACK_METHOD_FOR_TIMEOUT,
	applyOn = {TimeoutException.class})
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Tag(name = Constant.SAVINGS_ACCOUNT_FULFILLMENT)
	@APIResponses(value = {
			@APIResponse(responseCode = Constant.BAD_REQUEST_CODE, description = Constant.BAD_REQ,
					content = @Content(mediaType = Constant.APPL_JSON,
					schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.INTERNAL_ERROR_CODE,
			description = Constant.INTERNAL_ERROR_MSG,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.DOWNSTREAM_UNAVAILABLE,
			description = Constant.SERVICE_UNAVAILABLE,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.TIMEOUT_CODE, description = Constant.GATEWAY_TIMEOUT,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.SUCCESS_CODE, description = Constant.SUCCESS_MSG,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = UnclearFundDetailsResponse.class)))})
	@Operation(summary = "Get the details of Uncleared Fund",
	description = "Get the details of Uncleared Fund")
	public Response retrieveUnclearedFund(
			@BeanParam UnclearFundDetailsRequest unclearFundDetailsRequest) {

		unclearedfundReqValidator.validateRetrieveUnclearedFund(unclearFundDetailsRequest);
		LOGGER.info("retrieveUnclearedFund",
				unclearFundDetailsRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
				"start of retrieveUnclearedFund Method", "");
		return unclearedFundService.retrieveUnclearedFund(unclearFundDetailsRequest);
	}

	public Response fallbackTimeoutForUnclearedFund(UnclearFundDetailsRequest unclearFundDetailsRequest) {
		LOGGER.info(UnclearedFundConstant.FALLBACK_METHOD_FOR_TIMEOUT,
				unclearFundDetailsRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
				"Fallback method fallbackTimeoutForUnclearedFund after waiting milliseconds!=",
				config.getValue(UnclearedFundConstant.FALLBACK_TIMEOUT, String.class));
		ResponseEntity<String> responseEntity = new ResponseEntity<>(UnclearedFundConstant.TIMEOUT_CODE,
				"Gateway Timeout", UnclearedFundConstant.FAILURE_MSG, null);
		return Response.status(Integer.parseInt(UnclearedFundConstant.TIMEOUT_CODE))
				.entity(responseEntity).build();
	}

	/**
	 * Add Standing Instruction starts
	 */
	@POST
	@Path("/savings-account-fulfillment/payments/standing-instruction/initiation")
	@Timeout
	@Fallback(fallbackMethod = Constant.FALLBACK_TIMEOUT_FOR_ADD_STANDING_INSTRUCTION,
	applyOn = {TimeoutException.class})
	@Tag(name = Constant.STANDING_INSTRUCTION)
	@Operation(summary = "Add Standing Instruction",
	description = "Add Standing Instruction")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@APIResponses(value = {
			@APIResponse(responseCode = Constant.BAD_REQUEST_CODE, description = Constant.BAD_REQ,
					content = @Content(mediaType = Constant.APPL_JSON,
					schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.INTERNAL_ERROR_CODE,
			description = Constant.INTERNAL_ERROR_MSG,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.DOWNSTREAM_UNAVAILABLE,
			description = Constant.SERVICE_UNAVAILABLE,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.TIMEOUT_CODE, description = Constant.GATEWAY_TIMEOUT,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.SUCCESS_CODE, description = Constant.SUCCESS_MESSAGE,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = StandingOrderAddRes.class)))})
	public Response addStandingInstruction(@BeanParam ApiRequestHeader apiRequestHeader,
			@RequestBody StandingOrderAddReq standingOrderAddReq) {

		LOGGER.info(Constant.ADD_STANDING_INSTRUCTION, apiRequestHeader.getConsumerUniqueReferenceId(),
				Constant.EXECUTED, Constant.EMPTY);
		standingOrderAddReq.setApiRequestHeader(apiRequestHeader);
		ResponseEntity<StandingOrderAddRes> addStandingOrderResEntity =
				addStandingInstructionService.addStandingInstruc(standingOrderAddReq);
		return Response.ok(addStandingOrderResEntity).build();
	}

	public Response fallbackTimeoutForAddStandingInstruction(ApiRequestHeader apiRequestHeader,StandingOrderAddReq standingOrderAddReq) {
		LOGGER.info(Constant.FALLBACK_TIMEOUT_FOR_ADD_STANDING_INSTRUCTION,
				standingOrderAddReq.getApiRequestHeader().getConsumerUniqueReferenceId(),
				Constant.FALLBACK_METHOD_AFTER_WAITING_15_MILLISECONDS,
				apiRequestHeader.getConsumerUniqueReferenceId());
		ResponseEntity<String> responseEntity = new ResponseEntity<>(Constant.TIMEOUT_CODE,
				"No response from downstream service", Constant.FAILURE_MSG, null);
		return Response.status(504).entity(responseEntity).build();
	}

	/**
	 * Add Standing Instruction ends
	 */

	/**
	 * Retrieve Standing Instructions implementation starts
	 **/
	@GET
	@Path("/savings-account-fulfillment/payments/standing-instruction/list/retrieval")
	@Tag(name = Constant.STANDING_INSTRUCTION)
	@Operation(summary = "Retrieve Standing Instructions List", description = "Standing Instructions - List Retrieval")
	@APIResponses(value = {
			@APIResponse(responseCode = Constant.BAD_REQUEST_CODE, description = Constant.BAD_REQ,
					content = @Content(mediaType = Constant.APPL_JSON,
					schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.INTERNAL_ERROR_CODE,
			description = Constant.INTERNAL_ERROR_MSG,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.DOWNSTREAM_UNAVAILABLE,
			description = Constant.SERVICE_UNAVAILABLE,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.TIMEOUT_CODE, description = Constant.GATEWAY_TIMEOUT,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.SUCCESS_CODE, description = Constant.SUCCESS_MESSAGE,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = StandingInstructionsRetRes.class)))})
	@Timeout
	@Fallback(fallbackMethod = Constant.FALLBACK_RET_SI, applyOn = {TimeoutException.class})
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response retrieveStandingInstructions(
			@BeanParam StandingInstructionsRetReq standingInstructionsRetReq) {
		return Response.ok(retrieveStandingInstructionsService
				.retrieveStandingInstructions(standingInstructionsRetReq)).build();
	}

	public Response fallbackForRetrieveStandingInstructions(StandingInstructionsRetReq standingInstructionsRetReq) {
		LOGGER.info(Constant.FALLBACK_RET_SI,
				standingInstructionsRetReq.getApiRequestHeader().getConsumerUniqueReferenceId(),
				"Timeout after ms", config.getValue(Constant.RET_SI_TIMEOUT, String.class));
		return Response.status(Constant.TIMEOUT_INT)
				.entity(new ResponseEntity<>(Constant.TIMEOUT_CODE, Constant.GATEWAY_TIMEOUT,
						Constant.FAILURE_MSG, null))
				.build();
	}

	/**
	 * Retrieve Standing Instructions implementation ends
	 **/

	/**
	 * update Account arrangement *
	 */
	@POST
	@Path("/savings-account-fulfillment/savings-account-fulfillment-arrangement/update")
	@Timeout(Constant.FALLBACK_TIMEOUT)
	@Fallback(fallbackMethod = Constant.FALLBACK_METHOD_FOR_ACCOUNT_UPDATE,
	applyOn = {TimeoutException.class})
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@APIResponses(value = {
			@APIResponse(name = "ok", responseCode = "200", description = "Update Account Arrangement",
					content = @Content(mediaType = "application/json")),
			@APIResponse(responseCode = "500", description = "Internal server error."),
			@APIResponse(responseCode = "400", description = "Bad request"),
			@APIResponse(responseCode = "503", description = "System adapter service unavailable")})
	@Operation(summary = "Update Account Arrangement", description = "Update Account Arrangement")
	public Response updateAccountArrangement(@BeanParam ApiRequestHeader requestHeader,
			@RequestBody SavingAccountArrangementRequest request) {
		request.setApiRequestHeader(requestHeader);
		savingReqValidatorService.validateUpdateRequest(request);
		LOGGER.info("updateAccountArrangement",
				request.getApiRequestHeader().getConsumerUniqueReferenceId(),
				"start of updateAccountArrangement Method", "");
		return updateService.updateAccountArrangement(request);
	}

	public Response fallbackForAccountUpdate(ApiRequestHeader requestHeader,SavingAccountArrangementRequest request) {
		LOGGER.info(Constant.FALLBACK_METHOD_FOR_TIMEOUT,
				request.getApiRequestHeader().getConsumerUniqueReferenceId(),
				"Fallback method after waiting milliseconds!=", String.valueOf(Constant.FALLBACK_TIMEOUT));
		ResponseEntity<String> responseEntity = new ResponseEntity<>(Constant.TIMEOUT_CODE,
				"No response from downstream service", Constant.FAILURE_MSG, null);
		return Response.status(504).entity(responseEntity).build();
	}

	/**
	 * delete Standing Instruction implementation starts
	 * 
	 */

	@DELETE
	@Path("/savings-account-fulfillment/payments/standing-instruction/status-change/update")
	@Timeout
	@Fallback(fallbackMethod = Constant.FALLBACK_METHOD_DEL, applyOn = {TimeoutException.class})
	@Operation(summary = "Delete Standing Instruction", description = "delete details for a particular Standing Instruction")
	@Tag(name = Constant.SAVINGS_ACCOUNT_FULFILLMENT)
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@APIResponses(value = {
			@APIResponse(responseCode = Constant.BAD_REQUEST_CODE, description = Constant.BAD_REQ,
					content = @Content(mediaType = Constant.APPL_JSON, schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.INTERNAL_ERROR_CODE, description = Constant.INTERNAL_ERROR_MSG,
			content = @Content(mediaType = Constant.APPL_JSON, schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.DOWNSTREAM_UNAVAILABLE, description = Constant.SERVICE_UNAVAILABLE,
			content = @Content(mediaType = Constant.APPL_JSON, schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.TIMEOUT_CODE, description = Constant.GATEWAY_TIMEOUT,
			content = @Content(mediaType = Constant.APPL_JSON, schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.SUCCESS_CODE, description = Constant.SUCCESS_MSG,
			content = @Content(mediaType = Constant.APPL_JSON, schema = @Schema(implementation = StandingDelRes.class)))})
	public Response deleteSI(@BeanParam StandingDelReq standingDelReq) {
		LOGGER.info("deleteStandingInstruction", Constant.INSIDE_CONTROLLER, Constant.BLANK, Constant.BLANK);
		return Response.ok(standingInstructionDelService.delStandingInstruction(standingDelReq))
				.build();
	}

	public Response delFallbackTimeout(StandingDelReq standingDelReq) {
		LOGGER.info(Constant.FALLBACK_METHOD_DEL,
				standingDelReq.getApiRequestHeader().getConsumerUniqueReferenceId(), Constant.WAITING_TIME,
				config.getValue(Constant.SI_TIMEOUT_DEL, String.class));
		return Response.status(Constant.TIMEOUT_INT).entity(new ResponseEntity<>(Constant.TIMEOUT_CODE,
				Constant.GATEWAY_TIMEOUT, Constant.FAILURE_MSG, null)).build();
	}
	/**
	 * delete Standing Instruction implementation ends
	 * 
	 */


	/**
	 * Modify Standing Instruction implementation starts
	 * 
	 */

	@PUT
	@Path("/savings-account-fulfillment/payments/standing-instruction/details/update")
	@Timeout
	@Fallback(fallbackMethod = Constant.FALLBACK_METHOD_MOD, applyOn = { TimeoutException.class })
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@APIResponses(value = {
			@APIResponse(name = "ok", responseCode = "200", description = "Modify Standing Instruction.", content = @Content(mediaType = "application/json")),
			@APIResponse(responseCode = "500", description = "Internal server error."),
			@APIResponse(responseCode = "400", description = "Bad request"),
			@APIResponse(responseCode = "503", description = "System adapter service unavailable") })
	@Operation(summary = "Modify Standing Instruction in Saving Account", description = "Modify Standing Instruction")
	public Response modifySI(@BeanParam ApiRequestHeader apiRequestHeader, @RequestBody StandingModReq standingModReq) {
		{

			LOGGER.info("modifyStandingInstruction", Constant.INSIDE_CONTROLLER, Constant.BLANK, Constant.BLANK);

			standingModReq.setApiRequestHeader(apiRequestHeader);
			ResponseEntity<StandingModRes> modStandingOrderResEntity = standingInstructionModService
					.modStandingInstruction(standingModReq);
			return Response.ok(modStandingOrderResEntity).build();
		}

	}

	public Response modFallbackTimeout(ApiRequestHeader apiRequestHeader, StandingModReq standingModReq) {
		LOGGER.info(Constant.FALLBACK_METHOD_MOD, standingModReq.getApiRequestHeader().getConsumerUniqueReferenceId(),
				Constant.WAITING_TIME, config.getValue(Constant.SI_TIMEOUT_MOD, String.class));
		ResponseEntity<String> responseEntity = new ResponseEntity<>(Constant.TIMEOUT_CODE,
				Constant.NO_RESP_FROM_DOWNSTREAM_SERVICE, Constant.FAILURE_MSG, null);
		return Response.status(504).entity(responseEntity).build();
	}

	/**
	 * Modify Standing Instruction implementation ends
	 * 
	 */


	/**
	 * Retrieve Standing Instructions (Single Record) implementation starts
	 **/
	@GET
	@Path("/savings-account-fulfillment/payments/standing-instruction/detail/retrieval")
	@Operation(summary = "Retrieve Standing Instruction Detail", description = "retrieves details for a particular Standing Instruction")
	@Tag(name = Constant.STANDING_INSTRUCTION)
	@APIResponses(value = {
			@APIResponse(responseCode = Constant.BAD_REQUEST_CODE, description = Constant.BAD_REQ,
					content = @Content(mediaType = Constant.APPL_JSON, schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.INTERNAL_ERROR_CODE, description = Constant.INTERNAL_ERROR_MSG,
			content = @Content(mediaType = Constant.APPL_JSON, schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.DOWNSTREAM_UNAVAILABLE, description = Constant.SERVICE_UNAVAILABLE,
			content = @Content(mediaType = Constant.APPL_JSON, schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.TIMEOUT_CODE, description = Constant.GATEWAY_TIMEOUT,
			content = @Content(mediaType = Constant.APPL_JSON, schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.SUCCESS_CODE, description = Constant.SUCCESS_MSG,
			content = @Content(mediaType = Constant.APPL_JSON, schema = @Schema(implementation = StandingInstructionSingleDetailResponse.class)))})
	@Timeout
	@Fallback(fallbackMethod = Constant.FALLBACK_RET_SINGLE_SI, applyOn = {TimeoutException.class})
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response singleStandingInstructions(@BeanParam StandingInstructionSingleDetailRequest standingInstructionSingleDetailRequest) {
		return Response.ok(standingInstructionSingleDetailService.singleStandingInstruction(standingInstructionSingleDetailRequest)).build();
	}

	public Response fallbackForSingleStandingInstructions(StandingInstructionSingleDetailRequest standingInstructionSingleDetailRequest) {
		LOGGER.info(Constant.FALLBACK_RET_SINGLE_SI, standingInstructionSingleDetailRequest.getApiRequestHeader().getConsumerUniqueReferenceId(), "Timeout after ms", config.getValue(Constant.RET_SI_TIMEOUT, String.class));
		return Response.status(Constant.TIMEOUT_INT).entity(new ResponseEntity<>(Constant.TIMEOUT_CODE, Constant.GATEWAY_TIMEOUT, Constant.FAILURE_MSG, null)).build();
	}

	@POST
	@Path("savings-account-fulfillment/issueddevice/chequebook-request/requisition")
	@Timeout
	@Fallback(fallbackMethod = Constant.FALLBACK_METHOD_FOR_CHEQUE_BOOK,applyOn = {TimeoutException.class})
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Tag(name = Constant.SAVINGS_ACCOUNT_FULFILLMENT)
	@Operation(summary = "Add Cheque Book", description = "Request for Cheque Book")
	@APIResponses(value = {
			@APIResponse(responseCode = Constant.BAD_REQUEST_CODE, description = Constant.BAD_REQUEST_MSG,
					content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.INTERNAL_ERROR_CODE, description = Constant.INTERNAL_ERROR_MSG,
			content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.DOWNSTREAM_UNAVAILABLE, description = Constant.SERVICE_UNAVAILABLE,
			content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.TIMEOUT_CODE, description = Constant.GATEWAY_TIMEOUT,
			content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.SUCCESS_CODE, description = Constant.SUCCESS_MSG,
			content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ChequeBookDomainRes.class)))})
	public Response addChequeBookRequest(@BeanParam ApiRequestHeader requestHeader,
			@RequestBody ChequeBookDomainReq chequeBookDomainReq) {
		LOGGER.info("addChequeBookRequest",requestHeader.getConsumerUniqueReferenceId(),"start of addChequeBookRequest Method", "");
		ChequeBookDomainReqWrapper chequeBookDomainReqWrapper = new ChequeBookDomainReqWrapper();
		chequeBookDomainReqWrapper.setApiRequestHeader(requestHeader);
		chequeBookDomainReqWrapper.setChequeBookDomainReq(chequeBookDomainReq);
		return Response.ok(chequeBookService.addrequestChequeBook(chequeBookDomainReqWrapper)).build();
	}

	public Response fallbackForAddChequeBookReq(ApiRequestHeader requestHeader,ChequeBookDomainReq chequeBookDomainReq) {

		LOGGER.info(Constant.FALLBACK_METHOD_FOR_TIMEOUT,
				requestHeader.getConsumerUniqueReferenceId(), "Timeout after ms", 
				config.getValue(Constant.CHEQUE_BOOK_TIMEOUT, String.class));
		ResponseEntity<String> responseEntity = new ResponseEntity<>(Constant.TIMEOUT_CODE,
				Constant.GATEWAY_TIMEOUT, Constant.FAILURE_MSG, null);
		return Response.status(504).entity(responseEntity).build();
	}

	@POST
	@Path("savings-account-fulfillment/payments/demand-draft/initiation")
	@Timeout
	@Fallback(fallbackMethod = Constant.FALLBACK_METHOD_FOR_DEMAND_DRAFT,applyOn = {TimeoutException.class})
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Tag(name = "Demand Draft")
	@APIResponses(value = {
			@APIResponse(name = "ok", responseCode = "200", description = "Request for Demand Draft",content = @Content(mediaType = "application/json")),
			@APIResponse(responseCode = "500", description = "Internal server error."),
			@APIResponse(responseCode = "400", description = "Bad request"),
			@APIResponse(responseCode = "503", description = "System adapter service unavailable")})
	@Operation(summary = "Demand Draft Request", description = "Request for Demand Draft")
	public Response demandDraftRequest(@BeanParam ApiRequestHeader requestHeader,
			@RequestBody DemandDraftDomainReq demandDraftDomainReq) {
		LOGGER.info("demandDraftRequest",requestHeader.getConsumerUniqueReferenceId(),"start of demandDraftRequest Method in Controller", "");
		DemandDraftDomainReqWrapper demandDraftDomainReqWrapper = new DemandDraftDomainReqWrapper();
		demandDraftDomainReqWrapper.setApiRequestHeader(requestHeader);
		demandDraftDomainReqWrapper.setDemandDraftDomainReq(demandDraftDomainReq);
		return Response.ok(demandDraftService.demandDraftRequest(demandDraftDomainReqWrapper)).build();
	}

	public Response fallbackFordemandDraftRequest(ApiRequestHeader requestHeader,DemandDraftDomainReq demandDraftDomainReq) {
		demandDraftDomainReq.getIsServiceChargeApplicable();
		LOGGER.info(Constant.FALLBACK_METHOD_FOR_DEMAND_DRAFT,
				requestHeader.getConsumerUniqueReferenceId(),Constant.TIME_OUT_AFTER_MS , 
				config.getValue(Constant.DEMAND_DRAFT_TIMEOUT, String.class));
		ResponseEntity<String> responseEntity = new ResponseEntity<>(Constant.TIMEOUT_CODE,
				Constant.GATEWAY_TIMEOUT, Constant.FAILURE_MSG, null);
		return Response.status(504).entity(responseEntity).build();
	}

	@GET
	@Path("savings-account-arrangement/account-nickname/retrieval")
	@Timeout
	@Fallback(fallbackMethod = Constant.FALLBACK_METHOD_FOR_RETRIEVE_NICK_NAME,applyOn = {TimeoutException.class})
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Tag(name = Constant.ACCOUNTS_NICKNAME)
	@APIResponses(value = {
			@APIResponse(responseCode = Constant.BAD_REQUEST_CODE, description = Constant.BAD_REQ,
					content = @Content(mediaType = Constant.APPL_JSON, schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.INTERNAL_ERROR_CODE, description = Constant.INTERNAL_ERROR_MSG,
			content = @Content(mediaType = Constant.APPL_JSON, schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.DOWNSTREAM_UNAVAILABLE, description = Constant.SERVICE_UNAVAILABLE,
			content = @Content(mediaType = Constant.APPL_JSON, schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.TIMEOUT_CODE, description = Constant.GATEWAY_TIMEOUT,
			content = @Content(mediaType = Constant.APPL_JSON, schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.SUCCESS_CODE, description = Constant.SUCCESS_MSG,
			content = @Content(mediaType = Constant.APPL_JSON, schema = @Schema(implementation = RetrieveAccountsNickNameRes.class)))})
	@Operation(summary = "Retrieve Nick Name Details", description = "Request to Retrieve Nick Name details for the given Customer Reference Number")
	public Response retrieveNickName(@BeanParam RetrieveAccountsNickNameReq retrieveAccountsNickNameReq) {
		LOGGER.info("retrieveNickName",retrieveAccountsNickNameReq.getApiRequestheader().getConsumerUniqueReferenceId(),"Inside Controller of RetrieveNickName ",Constant.BLANK);
		retrieveNickNameValidatorService.validateRequest(retrieveAccountsNickNameReq);
		ResponseEntity<RetrieveAccountsNickNameRes> response = retrieveNickNameDomainService.retrieveNickNameDomain(retrieveAccountsNickNameReq);
		Integer status = Integer.parseInt(response.getCode());
		return Response.status(status).entity(response).build();
	}

	public Response fallbackForRetrieveNickName(RetrieveAccountsNickNameReq retrieveAccountsNickNameReq) {
		LOGGER.info(Constant.FALLBACK_METHOD_FOR_TIMEOUT,
				retrieveAccountsNickNameReq.getApiRequestheader().getConsumerUniqueReferenceId(), Constant.TIME_OUT_AFTER_MS, 
				config.getValue(Constant.RETRIEVE_NICK_NAME_TIMEOUT, String.class));
		ResponseEntity<String> responseEntity = new ResponseEntity<>(Constant.TIMEOUT_CODE,
				Constant.GATEWAY_TIMEOUT, Constant.FAILURE_MSG, null);
		return Response.status(504).entity(responseEntity).build();
	}	

	@PUT
	@Path("/savings-account-arrangement/account-nickname/update")
	@Timeout
	@Fallback(fallbackMethod = Constant.M_ADD_ACCOUNTS_NICKNAME_FALLBACK,applyOn = {TimeoutException.class})
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Tag(name = Constant.ACCOUNTS_NICKNAME)
	@APIResponses(value = {
			@APIResponse(responseCode = Constant.BAD_REQUEST_CODE, description = Constant.BAD_REQ,
					content = @Content(mediaType = Constant.APPL_JSON, schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.INTERNAL_ERROR_CODE, description = Constant.INTERNAL_ERROR_MSG,
			content = @Content(mediaType = Constant.APPL_JSON, schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.DOWNSTREAM_UNAVAILABLE, description = Constant.SERVICE_UNAVAILABLE,
			content = @Content(mediaType = Constant.APPL_JSON, schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.TIMEOUT_CODE, description = Constant.GATEWAY_TIMEOUT,
			content = @Content(mediaType = Constant.APPL_JSON, schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.SUCCESS_CODE, description = Constant.SUCCESS_MSG,
			content = @Content(mediaType = Constant.APPL_JSON, schema = @Schema(implementation = AddAccountsNickNameRes.class)))})
	@Operation(summary = "Add-Update Customer Nickname", description = "Update Customer Accounts Nickname if already present or Add new record if not")
	public Response addUpdateAccountNickname(@BeanParam ApiRequestHeader requestHeader, @RequestBody AddAccountsNickNameReq addAccountsNickNameReq ) {
		LOGGER.info(Constant.M_ADD_UPDATE_ACCOUNTS_NICKNAME,requestHeader.getConsumerUniqueReferenceId(),"", "Inside Method");
		return Response.ok(addAccountsNicknameService.addUpdateAccountNickname(requestHeader,addAccountsNickNameReq)).build();
	}

	public Response fallbackForAddUpdateAccountNickname(ApiRequestHeader requestHeader, AddAccountsNickNameReq addAccountsNickNameReq) {
		LOGGER.info(Constant.M_ADD_ACCOUNTS_NICKNAME_FALLBACK,requestHeader.getConsumerUniqueReferenceId(), Constant.TIMEOUT_AFTER,config.getValue(Constant.ACCOUNTS_NICKNAME_TIMEOUT, String.class)+" milliseconds");
		addAccountsNickNameReq.getBankBranchCode();
		ResponseEntity<String> responseEntity = new ResponseEntity<>(Constant.TIMEOUT_CODE,Constant.GATEWAY_TIMEOUT, Constant.FAILURE_MSG, null);
		return Response.status(Constant.TIMEOUT_CODE_INT).entity(responseEntity).build();
	}

	/**
	 * Order Paper Statement Endpoint
	 * 
	 */

	@GET
	@Path("/savings-account-arrangement/paper-statement/initiation")
	@Operation(summary = "Order paper statement for saving account",
	description = "Order paper statement for saving using account number and branch code")
	@Tag(name = Constant.SAVINGS_ACCOUNT_ARRANGEMENT)
	@APIResponses(value = {
			@APIResponse(responseCode = Constant.BAD_REQUEST_CODE, description = Constant.BAD_REQ,
					content = @Content(mediaType = Constant.APPL_JSON,
					schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.INTERNAL_ERROR_CODE,
			description = Constant.INTERNAL_ERROR_MSG,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.DOWNSTREAM_UNAVAILABLE,
			description = Constant.SERVICE_UNAVAILABLE,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.TIMEOUT_CODE, description = Constant.GATEWAY_TIMEOUT,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.SUCCESS_CODE, description = Constant.SUCCESS_MSG,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = OrderPaperStmtDomainResponse.class)))})
	@Timeout
	@Fallback(fallbackMethod = Constant.ORDER_PAPER_STMT_FALLBACK, applyOn = {TimeoutException.class})
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getOrderPaperStatement(@BeanParam OrderPaperStmtDomainRequest req) {
		LOGGER.info(Constant.GET_ORDER_PAPER_STMT, "", Constant.INSIDE_CONTROLLER, "Validation Start");
		orderPaperStatementValidatorService.validateOrderPaperStmtRequest(req);
		LOGGER.info(Constant.GET_ORDER_PAPER_STMT,
				req.getApiRequestHeader().getConsumerUniqueReferenceId(), Constant.INSIDE_CONTROLLER,
				"Request Start");
		Response response = orderPaperStatementService.getOrderPaperStatement(req);
		LOGGER.info(Constant.GET_ORDER_PAPER_STMT,
				req.getApiRequestHeader().getConsumerUniqueReferenceId(), "Exiting Controller", "");
		return response;
	}

	/**
	 * Order Paper Statement Fallback
	 * 
	 */
	public Response fallbackForOrderPaperStatement(OrderPaperStmtDomainRequest req) {
		LOGGER.info(Constant.ORDER_PAPER_STMT_FALLBACK,
				req.getApiRequestHeader().getConsumerUniqueReferenceId(), Constant.TIME_OUT_AFTER_MS,
				config.getValue(Constant.ORDER_PAPER_STMT_TIMEOUT, String.class));
		ResponseEntity<String> responseEntity = new ResponseEntity<>(Constant.TIMEOUT_CODE,
				Constant.GATEWAY_TIMEOUT, Constant.FAILURE_MSG, null);
		return Response.status(Constant.TIMEOUT_CODE_INT).entity(responseEntity).build();
	}

	@GET
	@Path("savings-account-arrangement/earmarking-pendingentries/retrieval")
	@Tag(name = "Savings Account Arrangement")
	@Operation(description = "Service Domain - Account Earmark Pending Entries")
	@APIResponses(value = {
			@APIResponse(responseCode = Constant.BAD_REQUEST_CODE, description = Constant.BAD_REQUEST_MSG,
					content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.INTERNAL_ERROR_CODE, description = Constant.INTERNAL_ERROR_MSG,
			content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.DOWNSTREAM_UNAVAILABLE, description = Constant.SERVICE_UNAVAILABLE,
			content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.TIMEOUT_CODE, description = Constant.GATEWAY_TIMEOUT,
			content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.SUCCESS_CODE, description = Constant.SUCCESS_MSG,
			content = @Content(mediaType = MediaType.APPLICATION_JSON, schema = @Schema(implementation = AcctEarmarkPendingEntriesDomainResponse.class)))})


	@Timeout
	@Fallback(fallbackMethod = Constant.EARMARK_FALLBAK, applyOn = {TimeoutException.class})
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getEarmarkPendingEntriesList(@BeanParam AcctEarmarkPendingEntriesDomainRequest req) {
		LOGGER.info(Constant.GET_EARMARK_PENINDENTRIES, "", Constant.INSIDE_CONTROLLER, "Validation Start");
		accountEarmarkPendingEntriesValidatorService.validateEarmarkRequest(req);
		LOGGER.info(Constant.GET_EARMARK_PENINDENTRIES,
				req.getApiRequestHeader().getConsumerUniqueReferenceId(), Constant.INSIDE_CONTROLLER,
				"Request Start");
		Response response = accountEarmarkPendingEntriesService.getEarmarkPendingEntriesList(req);
		LOGGER.info(Constant.GET_EARMARK_PENINDENTRIES,
				req.getApiRequestHeader().getConsumerUniqueReferenceId(), "Exiting Controller", "");
		return response;
	}
	public Response fallbackForEarmarkPendingEntries(AcctEarmarkPendingEntriesDomainRequest req) {
		LOGGER.info(Constant.EARMARK_FALLBAK, req.getApiRequestHeader().getConsumerUniqueReferenceId(), Constant.TIME_OUT_AFTER_MS,
				config.getValue(Constant.EARMARK_TIMEOUT, String.class));
		ResponseEntity<String> responseEntity = new ResponseEntity<>(Constant.TIMEOUT_CODE,
				Constant.GATEWAY_TIMEOUT, Constant.FAILURE_MSG, null);
		return Response.status(Constant.TIMEOUT_CODE_INT).entity(responseEntity).build();
	}
	
/**
	 * Check Status Endpoint
	 * 
	 */
	@GET
	@Path("/savings-account-arrangement/check-status/retrieval")
	@Operation(summary = "Service Domain - Check Status",
	description = "Retrieve status details by saving account Number and issuedDevicePropertyValue")
	@Tag(name = Constant.SAVINGS_ACCOUNT_ARRANGEMENT)
	@APIResponses(value = {
			@APIResponse(responseCode = Constant.BAD_REQUEST_CODE, description = Constant.BAD_REQ,
					content = @Content(mediaType = Constant.APPL_JSON,
					schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.INTERNAL_ERROR_CODE,
			description = Constant.INTERNAL_ERROR_MSG,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.DOWNSTREAM_UNAVAILABLE,
			description = Constant.SERVICE_UNAVAILABLE,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.TIMEOUT_CODE, description = Constant.GATEWAY_TIMEOUT,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.SUCCESS_CODE, description = Constant.SUCCESS_MSG,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = CheckStatusResponse.class)))})
	@Timeout
	@Fallback(fallbackMethod = Constant.CHECK_STATUS_FALLBACK_METHOD,	applyOn = {TimeoutException.class})
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getCheckStatus(@BeanParam CheckStatusRequest req) {
		checkStatusValidatorService.validateCheckStatus(req);  
		LOGGER.info(Constant.CHECK_STATUS_METHOD_NAME,
				req.getApiRequestHeader().getConsumerUniqueReferenceId(),Constant.INSIDE_CONTROLLER, "");

		Response response = checkStatusService.getCheckStatus(req);
		LOGGER.info(Constant.CHECK_STATUS_METHOD_NAME,
				req.getApiRequestHeader().getConsumerUniqueReferenceId(),"Exiting Controller", "");
		return response;
	}

	/**
	 * Check Status Fallback
	 * 
	 */
	public Response fallbackForCheckStatus(CheckStatusRequest req) {
		LOGGER.info(Constant.CHECK_STATUS_FALLBACK_METHOD,
				req.getApiRequestHeader().getConsumerUniqueReferenceId(), Constant.TIME_OUT_AFTER_MS,
				config.getValue(Constant.CHECK_STATUS_TIMEOUT, String.class));
		ResponseEntity<String> responseEntity = new ResponseEntity<>(Constant.TIMEOUT_CODE,
				Constant.GATEWAY_TIMEOUT, Constant.FAILURE_MSG, null);
		return Response.status(Constant.TIMEOUT_CODE_INT).entity(responseEntity).build();
	}


	/*
	 * Bankers Notes domain added
	 */

	@GET
	@Path("/savings-account-arrangement/bankers-notes/nonpersonal/retrieval")
	@Operation(summary = "Retrieve bankers notes details by saving account Number.",
	description = "Retrieve bankers notes details by saving account Number.")
	@Tag(name = Constant.SAVINGS_ACCOUNT_ARRANGEMENT)
	@APIResponses(value = {
			@APIResponse(responseCode = Constant.BAD_REQUEST_CODE, description = Constant.BAD_REQ,
					content = @Content(mediaType = Constant.APPL_JSON,
					schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.INTERNAL_ERROR_CODE,
			description = Constant.INTERNAL_ERROR_MSG,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.DOWNSTREAM_UNAVAILABLE,
			description = Constant.SERVICE_UNAVAILABLE,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.TIMEOUT_CODE, description = Constant.GATEWAY_TIMEOUT,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = Constant.SUCCESS_CODE, description = Constant.SUCCESS_MSG,
			content = @Content(mediaType = Constant.APPL_JSON,
			schema = @Schema(implementation = AccountNotes.class)))})
	@Timeout
	@Fallback(fallbackMethod = Constant.BANKERS_NOTES_FALLBACK_METHOD,	applyOn = {TimeoutException.class})
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response getBankersNotesDetails(@BeanParam BankersNotesDomainRequest bankersNotesDomainRequest) {

		validatorUtil.validateInputRequest(bankersNotesDomainRequest);

		LOGGER.info(Constant.BANKERS_METHOD_NAME,
				bankersNotesDomainRequest.
				getApiRequestHeader().getConsumerUniqueReferenceId(), "start of "+ Constant.BANKERS_METHOD_NAME, "");

		ResponseEntity<AccountNotes> responseEntity = bankersNotesService.retrieveBankersNotesDetails(bankersNotesDomainRequest);
		Integer status = Integer.parseInt(responseEntity.getCode());
		
		LOGGER.info(Constant.BANKERS_METHOD_NAME,
				bankersNotesDomainRequest.
				getApiRequestHeader().getConsumerUniqueReferenceId(), "end of "+ Constant.BANKERS_METHOD_NAME, responseEntity.getCode());
		
		
		return Response.status(status).entity(responseEntity).build();
	}


	/*
	 * Bankers Notes fallback added
	 */

	public Response fallbackForBankersNotesTimeout(BankersNotesDomainRequest bankersNotesDomainRequest) {
		LOGGER.info(Constant.BANKERS_NOTES_FALLBACK_METHOD,bankersNotesDomainRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),Constant.TIME_OUT_AFTER_MS, config.getValue(Constant.BANKERS_NOTES_TIMEOUT, String.class));
		ResponseEntity<String> responseEntity =
				new ResponseEntity<>(Constant.TIMEOUT_CODE,
						Constant.GATEWAY_TIMEOUT, Constant.FAILURE_MSG, null);
		return Response.status(Constant.TIMEOUT_CODE_INT).entity(responseEntity).build();
	}


	//CreateCasaAccount
	@POST
	@Path("/savings-account-arrangement/initiation")
	@Timeout
	@Fallback(fallbackMethod = Constant.FALLBACK_METHOD_FOR_CREATE_CASA_ACCOUNT,applyOn = {TimeoutException.class})
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@APIResponses(value = {
			@APIResponse(name = "ok", responseCode = "200", description = "Create CASA account",content = @Content(mediaType = "application/json")),
			@APIResponse(responseCode = "500", description = "Internal server error."),
			@APIResponse(responseCode = "400", description = "Bad request"),
			@APIResponse(responseCode = "503", description = "System adapter service unavailable")})
	@Operation(summary = "Create CASA account", description = "Request to create CASA account")
	public Response createCasaAccount(@BeanParam ApiRequestHeader apiHeader, @RequestBody CreateCasaAccountRequest createCasaAccountRequest) {
		LOGGER.info("createCasaAccount",apiHeader.getConsumerUniqueReferenceId(),"Inside Controller of CreateCasaAccount ",Constant.BLANK);
		createCasaAccountRequest.setApiRequestHeader(apiHeader);
		createCasaAccountValidatorService.validateCreateCasaAccountRequest(createCasaAccountRequest);
		ResponseEntity<CreateCasaAccountResponse> response = createCasaAccountService.createCasaAccount(createCasaAccountRequest);
		Integer status = Integer.parseInt(response.getCode());
		return Response.status(status).entity(response).build();
	}

	public Response fallbackForCreateCasaAccount(ApiRequestHeader apiHeader, CreateCasaAccountRequest createCasaAccountRequest) {
		LOGGER.info(Constant.FALLBACK_METHOD_FOR_TIMEOUT,
				createCasaAccountRequest.getApiRequestHeader().getConsumerUniqueReferenceId(), Constant.TIME_OUT_AFTER_MS, 
				config.getValue(Constant.RETRIEVE_NICK_NAME_TIMEOUT, String.class));
		ResponseEntity<String> responseEntity = new ResponseEntity<>(Constant.TIMEOUT_CODE,
				Constant.GATEWAY_TIMEOUT, Constant.FAILURE_MSG, null);
		return Response.status(504).entity(responseEntity).build();
	}



	@POST
	@Path("savings-account-fulfillment/payments/cashservice/initiation")
	@Operation(summary = "Purchase money voucher", description = "Purchase money voucher")
	@Tag(name = "Savings Account Fulfillment")
	@APIResponses(value = {
			@APIResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType = "application/json",
					schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType = "application/json",
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = "503", description = "System adapter service unavailable", content = @Content(mediaType = "application/json",
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = "200", description = "Success", content = @Content(mediaType = "application/json",
			schema = @Schema(implementation = PurchaseMvRes.class)))})
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Timeout
	@Fallback(fallbackMethod = Constant.FALLBACK_METHOD_FOR_PURCHASE_MV, applyOn = {TimeoutException.class})
	public Response purchaseMoneyVoucher(@BeanParam ApiRequestHeader apiRequestHeader, @RequestBody PurchaseMvReq purchaseMvReq){
		final String METHOD_NAME = "purchaseMoneyVoucher";
		LOGGER.info(METHOD_NAME, apiRequestHeader.getConsumerUniqueReferenceId(), Constant.INSIDE_CONTROLLER, "Request Start");
		PurchaseMvReqWrapper purchaseMvReqWrapper = new PurchaseMvReqWrapper();
		purchaseMvReqWrapper.setApiRequestHeader(apiRequestHeader);
		purchaseMvReqWrapper.setPurchaseMvReq(purchaseMvReq);
		ResponseEntity<PurchaseMvRes> voucherPurchaseRes = purchaseMvService.moneyVoucherPurchase(purchaseMvReqWrapper);
		return Response.ok(voucherPurchaseRes).build();
	}

	public Response fallbackForPurchaseMoneyVoucher(ApiRequestHeader apiRequestHeader, PurchaseMvReq purchaseMvReq) {
		final String METHOD_NAME = Constant.FALLBACK_METHOD_FOR_PURCHASE_MV;
		LOGGER.info(METHOD_NAME, apiRequestHeader.getConsumerUniqueReferenceId(), "Waiting time in ms ", config.getValue(Constant.TIME_OUT_PURCHASE_MV, String.class));
		ResponseEntity<String> responseEntity = new ResponseEntity<>(Constant.TIMEOUT_CODE, Constant.GATEWAY_TIMEOUT, Constant.FAILURE_MSG, null);
		return Response.status(504).entity(responseEntity).build();
	}

	@POST
	@Path("/savings-account-arrangement/account-opening/update")
	@Operation(summary = "Update Account Details", description = "Update Account Details to activate account")
	@Tag(name = Constant.SAVINGS_ACCOUNT_ARRANGEMENT)
	@APIResponses(value = {
			@APIResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType = "application/json",
					schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType = "application/json",
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = "503", description = "System adapter service unavailable", content = @Content(mediaType = "application/json",
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = "200", description = "Success", content = @Content(mediaType = "application/json",
			schema = @Schema(implementation = UpdateAcctDtlsRes.class)))})
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Timeout
	@Fallback(fallbackMethod = Constant.FALLBACK_METHOD_FOR_UPDATE_ACCT_DTLS, applyOn = {TimeoutException.class})
	public Response updateAcctDetails(@BeanParam ApiRequestHeader apiRequestHeader, @RequestBody UpdateAcctDtlsReq updateAcctDtlsReq){
		final String METHOD_NAME = "updateAcctDetails";
		LOGGER.info(METHOD_NAME, apiRequestHeader.getConsumerUniqueReferenceId(), Constant.INSIDE_CONTROLLER, "Request Start");
		UpdateAcctDtlsReqWrapper updateAcctDtlsReqWrapper = new UpdateAcctDtlsReqWrapper();
		updateAcctDtlsReqWrapper.setApiRequestHeader(apiRequestHeader);
		updateAcctDtlsReqWrapper.setUpdateAcctDtlsReq(updateAcctDtlsReq);
		ResponseEntity<UpdateAcctDtlsRes> updateAcctDtlsResEntity = updateAcctDtlsService.updateAcctDetails(updateAcctDtlsReqWrapper);
		return Response.ok(updateAcctDtlsResEntity).build();
	}

	public Response fallbackForUpdateAcctDetails(ApiRequestHeader apiRequestHeader, UpdateAcctDtlsReq updateAcctDtlsReq) {
		final String METHOD_NAME = Constant.FALLBACK_METHOD_FOR_UPDATE_ACCT_DTLS;
		LOGGER.info(METHOD_NAME, apiRequestHeader.getConsumerUniqueReferenceId(), "Waiting time in ms ", config.getValue(Constant.TIME_OUT_UPDATE_ACCT_DTLS, String.class));
		LOGGER.debug(METHOD_NAME, apiRequestHeader.getConsumerUniqueReferenceId(),"", updateAcctDtlsReq+"");
		ResponseEntity<String> responseEntity = new ResponseEntity<>(Constant.TIMEOUT_CODE, Constant.GATEWAY_TIMEOUT, Constant.FAILURE_MSG, null);
		return Response.status(504).entity(responseEntity).build();

	}

	@POST
	@Path("savings-account-arrangement/amendment/update")
	@Operation(summary = "Amend Customer Account Status Update", description = "Amend Customer Account Status Update")
	@Tag(name = "Savings Account Arrangement")
	@APIResponses(value = {
			@APIResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = "503", description = "System adapter service unavailable", content = @Content(mediaType = "application/json", schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = "200", description = "Success", content = @Content(mediaType = "application/json", schema = @Schema(implementation = UpdateAcctStatusRes.class))) })
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Timeout
	@Fallback(fallbackMethod = Constant.FALLBACK_METHOD_FOR_ACCOUNT_STATUS_UPDATE, applyOn = { TimeoutException.class })
	public Response amendCustomerAccount(@BeanParam ApiRequestHeader apiRequestHeader,
			@RequestBody UpdateAcctStatusReq updateAccountStatusReq) {
		final String METHOD_NAME = "amendCustomerAccount";
		LOGGER.info(METHOD_NAME, apiRequestHeader.getConsumerUniqueReferenceId(), Constant.INSIDE_CONTROLLER, "Request Start");
		UpdateAcctStatusReqWrapper updateAccountStatusReqWrapper = new UpdateAcctStatusReqWrapper();
		updateAccountStatusReqWrapper.setApiRequestHeader(apiRequestHeader);
		updateAccountStatusReqWrapper.setUpdateAcctStatusReq(updateAccountStatusReq);
		ResponseEntity<UpdateAcctStatusRes> updateAcctStatusResEnt = updateAcctStatusService.amendCustomerAccount(updateAccountStatusReqWrapper);
		return Response.ok(updateAcctStatusResEnt).build();
	}

	public Response fallbackForAccountStatusUpdate(ApiRequestHeader apiRequestHeader, UpdateAcctStatusReq updateAccountStatusReq) {
		final String METHOD_NAME = Constant.FALLBACK_METHOD_FOR_ACCOUNT_STATUS_UPDATE;
		LOGGER.info(METHOD_NAME, apiRequestHeader.getConsumerUniqueReferenceId(), "Waiting time in ms ",
				config.getValue(Constant.TIME_OUT_ACCOUNT_STATUS_UPDATE, String.class));
		LOGGER.debug(METHOD_NAME, apiRequestHeader.getConsumerUniqueReferenceId(), "",updateAccountStatusReq+"");
		ResponseEntity<String> responseEntity = new ResponseEntity<>(Constant.TIMEOUT_CODE, Constant.GATEWAY_TIMEOUT,
				Constant.FAILURE_MSG, null);
		return Response.status(504).entity(responseEntity).build();
	}

	@POST
	@Path("savings-account-fulfillment-arrangement/account-details/update")
	@Operation(summary = "Update Account Status", description = "Update Account Status with UDF post Activate/Deactivate Status ")
	@Tag(name = "Savings Account Fulfillment Arrangement")
	@APIResponses(value = {
			@APIResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType = "application/json",
					schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType = "application/json",
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = "503", description = "System adapter service unavailable", content = @Content(mediaType = "application/json",
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = "200", description = "Success", content = @Content(mediaType = "application/json",
			schema = @Schema(implementation = UpdateAccountStatusDomainRes.class)))})
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Timeout
	@Fallback(fallbackMethod = Constant.FALLBACK_METHOD_FOR_UPDATE_ACCOUNT_STATUS, applyOn = {TimeoutException.class})
	public Response getUpdatedAccountStatus(@BeanParam ApiRequestHeader apiRequestHeader, @RequestBody UpdateAccountStatusDomainReq updateAccountStatusDomainReq){
		final String METHOD_NAME = "getUpdatedAccountStatus";
		LOGGER.info(METHOD_NAME, apiRequestHeader.getConsumerUniqueReferenceId(), Constant.INSIDE_CONTROLLER, "Request Start");
		UpdateAccountStatusDomainReqWrapper updateAccStsDomainReqWrapper = new UpdateAccountStatusDomainReqWrapper();
		updateAccStsDomainReqWrapper.setApiRequestHeader(apiRequestHeader);
		updateAccStsDomainReqWrapper.setUpdateAccountStatusDomainReq(updateAccountStatusDomainReq);;
		ResponseEntity<UpdateAccountStatusDomainRes> updateAccStsDomainRes = updateAccountStatusService.getUpdateAccStsResponse(updateAccStsDomainReqWrapper);
		return Response.ok(updateAccStsDomainRes).build();
	}

	public Response fallbackForUpdateAccountStatus(ApiRequestHeader apiRequestHeader, UpdateAccountStatusDomainReq updateAccountStatusDomainReq) {
		final String METHOD_NAME = Constant.FALLBACK_METHOD_FOR_UPDATE_ACCOUNT_STATUS;
		LOGGER.info(METHOD_NAME, apiRequestHeader.getConsumerUniqueReferenceId(), updateAccountStatusDomainReq+" Waiting time in ms ", config.getValue(Constant.TIME_OUT_UPD_ACCOUNT_STATUS, String.class));
		LOGGER.debug(METHOD_NAME, apiRequestHeader.getConsumerUniqueReferenceId(), "", updateAccountStatusDomainReq+"");
		ResponseEntity<String> responseEntity = new ResponseEntity<>(Constant.TIMEOUT_CODE, Constant.GATEWAY_TIMEOUT, Constant.FAILURE_MSG, null);
		return Response.status(504).entity(responseEntity).build();
	}
	
	@POST
	@Path("savings-account-fulfillment/order-debit-card/requisition")
	@Operation(summary = "Order Debit Card", description = "Place order for debit card for the given account number, card number and postal address details.")
	@Tag(name = "Order Debit Card")
	@APIResponses(value = {
			@APIResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType = "application/json",
					schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = "504", description = "Gateway Timeout", content = @Content(mediaType = "application/json",
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = "500", description = "Internal server error", content = @Content(mediaType = "application/json",
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = "503", description = "System adapter service unavailable", content = @Content(mediaType = "application/json",
			schema = @Schema(implementation = ResponseEntity.class))),
			@APIResponse(responseCode = "200", description = "Success", content = @Content(mediaType = "application/json",
			schema = @Schema(implementation = OrderDebitCardDomainRes.class)))})
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Timeout
	@Fallback(fallbackMethod = Constant.FALLBACK_METHOD_FOR_ORDER_DEBIT_CARD, applyOn = {TimeoutException.class})
	public Response orderDebitCard(@BeanParam ApiRequestHeader apiRequestHeader, @RequestBody OrderDebitCardDomainReq orderDebitCardDomainReq){
		LOGGER.info(Constant.M_ORDER_DEBIT_CARD, apiRequestHeader.getConsumerUniqueReferenceId(), Constant.INSIDE_CONTROLLER, Constant.BLANK );
		ResponseEntity<OrderDebitCardDomainRes> orderDebitCardDomainRes = orderDebitCardService.orderDebitCard(apiRequestHeader,orderDebitCardDomainReq);
		return Response.ok(orderDebitCardDomainRes).build();
	}

	public Response fallbackForOrderDebitCard(ApiRequestHeader apiRequestHeader, OrderDebitCardDomainReq orderDebitCardDomainReq) {
		LOGGER.info(Constant.FALLBACK_METHOD_FOR_ORDER_DEBIT_CARD, apiRequestHeader.getConsumerUniqueReferenceId(),
			" Waiting time in ms ", config.getValue(Constant.TIME_OUT_ORDER_DEBIT_CARD, String.class));
		orderDebitCardDomainReq.getLocationReference().getCardBranch();
		ResponseEntity<String> responseEntity = new ResponseEntity<>(Constant.TIMEOUT_CODE, Constant.GATEWAY_TIMEOUT, Constant.FAILURE_MSG, null);
		return Response.status(504).entity(responseEntity).build();
	}


}
