package com.absa.amol.saving.model.standinginstruction.singledetail;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PayeeBankRefSingleDetailResp 
{
	private Integer beneficiaryBranchCode; //ebox
	
	private String beneficiaryBankCode; //earlier Integer
	
	private String beneficiaryBranchName; //ebox
	
	private String beneficiaryBankName; //ebox	
}
