package com.absa.amol.saving.model.updateaccountstatus;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class UpdateAccountStatusDomainReq {
	
	@Schema(description = "Field is mandatory", pattern = "[0-9]*", minLength = 1, maxLength = 9,required = true)
	@NotNull(message = "branchCode.nullEmptyCheck.message")
	@NotEmpty(message = "branchCode.nullEmptyCheck.message")
	@Pattern(regexp = "[0-9]{1,9}", message = "branchCode.pattern.message")
	private String branchCode;
	@Schema(description = "Field is mandatory", pattern = "[0-9]*", minLength = 1, maxLength = 16,required = true)
	@NotNull(message = "savingAccountNumber.nullEmptyCheck.message")
	@NotEmpty(message = "savingAccountNumber.nullEmptyCheck.message")
	@Pattern(regexp = "[0-9]{1,16}", message = "savingAccountNumber.pattern.message")
	private String savingAccountNumber;
	
	@Schema(description = "Field is mandatory", required = true)
	@NotNull(message = "accountStatus.null.empty.message")
	@NotEmpty(message = "accountStatus.null.empty.message")
	@Pattern(regexp = "(true|false|True|False)", message = "accountStatus.pattern.message")
	private String accountStatus;
	
	@Schema(description = "Conditional mandatory")
	private String accountTitle;
	
	@Schema(description = "Conditional mandatory")
	@Valid
	private AccountDetails accountDetails;
	@Schema(description = "Conditional mandatory")
	private String verification;
	
	@Valid
	private UdfDetails udfDetails;
}
