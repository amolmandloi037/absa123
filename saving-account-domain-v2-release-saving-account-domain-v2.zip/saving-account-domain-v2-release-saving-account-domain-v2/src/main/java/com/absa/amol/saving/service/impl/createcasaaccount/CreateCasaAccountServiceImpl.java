package com.absa.amol.saving.service.impl.createcasaaccount;

import javax.inject.Inject;

import org.eclipse.microprofile.rest.client.inject.RestClient;

import com.absa.amol.saving.mapper.CustContactHistoryMapper;
import com.absa.amol.saving.model.createcasaaccount.CreateCasaAccountRequest;
import com.absa.amol.saving.model.createcasaaccount.CreateCasaAccountResponse;
import com.absa.amol.saving.service.createcasaaccount.CreateCasaAccountService;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.saving.util.CreateCasaAccountClient;
import com.absa.amol.util.exception.ApiException;
import com.absa.amol.util.exception.ApiResponseException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ResponseEntity;

public class CreateCasaAccountServiceImpl implements CreateCasaAccountService {

  private static final Logger logger =
      LoggerFactory.getLogger(CreateCasaAccountServiceImpl.class);

  @Inject
  @RestClient
  private CreateCasaAccountClient createCasaAcctClient;

  @Inject
  CustContactHistoryMapper contactHistoryMapper;

  @Override
  public ResponseEntity<CreateCasaAccountResponse> createCasaAccount(CreateCasaAccountRequest req) {
    final String method_name = "createCasaAccount";
    String consUniqId = "";
    ResponseEntity<CreateCasaAccountResponse> resEntity = null;
    try {
      consUniqId = req.getApiRequestHeader().getConsumerUniqueReferenceId();
      logger.info(method_name, consUniqId, "inside Service : invoking system service client", "");
      resEntity = createCasaAcctClient.createCasaAccount(req.getApiRequestHeader(), req);
      logger.info(method_name, consUniqId, "Response Recieved from System Adapter",
    		  resEntity.toString());

    } catch (ApiException exception) {
		logger.error(method_name, req.getApiRequestHeader().getCorrelationId(),
				Constant.EXCEPTION_OCCURED_FROM_SERVER, exception.getErrorMessage());
		logger.debug(method_name, req.getApiRequestHeader().getCorrelationId(),
				Constant.EXCEPTION_OCCURED_FROM_SERVER, exception);
		throw exception;
	} catch (Exception exception) {

		logger.error(method_name, req.getApiRequestHeader().getCorrelationId(),
				Constant.EXCEPTION_OCCURED_FROM_SERVER, exception.getMessage());
		logger.debug(method_name, req.getApiRequestHeader().getCorrelationId(),
				Constant.EXCEPTION_OCCURED_FROM_SERVER, exception);
		throw new ApiResponseException("500", "Internal  Server Error");
	}
	return resEntity;
  }
}
