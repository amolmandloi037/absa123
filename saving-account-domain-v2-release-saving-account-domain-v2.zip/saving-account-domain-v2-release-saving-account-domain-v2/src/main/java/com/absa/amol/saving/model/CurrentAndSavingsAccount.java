package com.absa.amol.saving.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class CurrentAndSavingsAccount {

  private String nib;
  private boolean tdsFlag;
  private Integer taxCode1;
  private Integer taxCode2;
  private Double tdsExemptionLimitAmount1;
  private Double tdsExemptionLimitAmount2;
  private String accountAccrualStatusCode;
  private String minorAccountStatusCode;
  private boolean generateRateChangeIntimationFlag;
  private Integer leadDaysIntimation;
  private String IBANAccountNumber;
  private Integer passbookLineNo;
  private Integer numberOfPastDueChecks;
  private String passbookLifecycleStatusCode;
  private Double minimumRequiredTradingBalanceAmount;
  private Double creditInterestAccruedAmount;
  private Double debitInterestAccruedAmount;
  private Double adjustedCreditInterestAccrued;
  private Double adjustedDebitInterestAccrued;
  private Double projectedTaxOnAccruedInterestAmount;
  private Double debitsMonthTillDateAmount;
  private CustomDate debitsLastDate;
  private Double debitsYearTillDateAmount;
  private Integer MTDDebitsCount;
  private Integer YTDDebitsCount;
  private Double YTDDebitsLastAmount;
  private Double creditsMonthTillDateAmount;
  private Integer MTDCreditsCount;
  private Integer YTDCreditsCount;
  private CustomDate creditLastDate;
  private Double YTDCreditLastAmount;
  private String nomineeName;

}
