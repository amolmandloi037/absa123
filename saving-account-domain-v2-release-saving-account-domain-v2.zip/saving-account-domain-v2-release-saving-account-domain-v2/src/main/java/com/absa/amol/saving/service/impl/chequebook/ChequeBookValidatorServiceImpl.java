package com.absa.amol.saving.service.impl.chequebook;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.eclipse.microprofile.config.Config;

import com.absa.amol.saving.model.chequebook.ChequeBookDomainReq;
import com.absa.amol.saving.service.chequebook.IChequeBookValidatorService;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.exception.ApiRequestException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.utility.CommonUtil;
import com.absa.amol.util.utility.StringUtil;

@ApplicationScoped
public class ChequeBookValidatorServiceImpl implements IChequeBookValidatorService{

	@Inject
	private Validator validator;

	@Inject
	Config config;

	private static final Logger LOGGER = LoggerFactory.getLogger(ChequeBookValidatorServiceImpl.class);

	public <T>void validateInputRequest(T request,ApiRequestHeader apiRequestHeader) {
		Set<String> errorSet = validateReqHeader(apiRequestHeader);
		errorSet.addAll(validatedAnnotedBeans(request));
		errorSet.addAll(customvalidatedBeans((ChequeBookDomainReq) request));
		if (!errorSet.isEmpty()) {
			String errorMessage = String.join(",", errorSet);
			LOGGER.error("validateInputRequest", apiRequestHeader.getConsumerUniqueReferenceId(), "Validation failed:", errorMessage);
			throw new ApiRequestException(Constant.BAD_REQUEST_CODE, errorMessage);
		}
	}
	private Set<String> validateReqHeader(ApiRequestHeader apiRequestHeader) {
		Set<ConstraintViolation<Object>> violations = validator.validate(apiRequestHeader);
		return violations.stream().map(constraint -> {
			String customErroMsg = getPropertyValue(constraint.getMessageTemplate());
			return StringUtil.isStringNullOrEmpty(customErroMsg) ? constraint.getMessage() : customErroMsg;
		}).collect(Collectors.toSet());
	}

	private <T>Set<String> validatedAnnotedBeans(T request) {
		Set<ConstraintViolation<Object>> violations = validator.validate(request);
		return violations.stream().map(constraint -> {
			String customErroMsg = getPropertyValue(constraint.getMessageTemplate());
			return StringUtil.isStringNullOrEmpty(customErroMsg) ? constraint.getMessage() : customErroMsg;
		}).collect(Collectors.toSet());
	}
	
	private Set<String> customvalidatedBeans(ChequeBookDomainReq chequeBookDomainReq) {

		LOGGER.info(Constant.VALIDATE_INPUT_REQUEST, Constant.EMPTY,Constant.CUSTOMVALIDATED_BEANS, Constant.EMPTY);
		Set<String> customValErrSet = new HashSet<>();
			if (CommonUtil.isNotNull(chequeBookDomainReq.getProductInstanceReference())
					&& (chequeBookDomainReq.getProductInstanceReference().split(Constant.ZERO_STRING, -1).length
							- 1 == chequeBookDomainReq.getProductInstanceReference().length())) {
				customValErrSet.add(
						getPropertyValue(Constant.PRODUCT_INST_REFERENCE_PATTERN_ERROR_MESSAGE));
			}
			if (CommonUtil.isNotNull(chequeBookDomainReq.getIssuedDeviceDescription()) && 
					CommonUtil.isNotNull(chequeBookDomainReq.getIssuedDeviceDescription().getChequeBookleafSize())
					&& (chequeBookDomainReq.getIssuedDeviceDescription().getChequeBookleafSize()<1)) {
				customValErrSet.add(
						getPropertyValue(Constant.CHEQUE_BOOK_LEAF_SIZE_LENGTH_ERROR_MESSAGE));
			}
		
		return customValErrSet;
	}

	private String getPropertyValue(String confkey) {
		String msg=null;
		try {
			msg =  config.getValue(confkey, String.class);
		} catch (Exception e) {
			LOGGER.error("getPropertyValue", "", "Exception while reading property for the key ::" + confkey, e.getMessage());
		}
		return msg;
	}

}
