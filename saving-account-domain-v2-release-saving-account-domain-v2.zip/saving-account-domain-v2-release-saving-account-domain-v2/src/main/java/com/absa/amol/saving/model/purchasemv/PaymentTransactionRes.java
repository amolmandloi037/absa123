package com.absa.amol.saving.model.purchasemv;

import javax.json.bind.annotation.JsonbProperty;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class PaymentTransactionRes {
	
	@JsonbProperty(value = "paymentPurpose")
	private PaymentPurposeRes paymentPurposeRes;

}
