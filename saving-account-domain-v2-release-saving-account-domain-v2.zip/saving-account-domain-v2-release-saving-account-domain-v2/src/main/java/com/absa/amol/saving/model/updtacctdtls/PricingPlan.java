package com.absa.amol.saving.model.updtacctdtls;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import com.absa.amol.saving.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PricingPlan {
	
	@NotNull( message="priceCode.null.empty.message")
	@NotEmpty( message="priceCode.null.empty.message")
	@Size( min=1, max=10 , message="priceCode.size.message")
	@Schema(description = "Mandatory field", pattern = "AlphaNumeric",minLength=1, maxLength = 10 ,required=true)
	private String priceCode;
	
	@NotNull( message="plName.null.empty.message")
	@NotEmpty( message="plName.null.empty.message")
	@Size( min=1, max=100 , message="plName.size.message")
	@Schema(description = "Mandatory field", pattern = "AlphaNumeric",minLength=1, maxLength = 100 ,required=true )
	private String plName;
	
	@NotNull( message="plDesc.null.empty.message")
	@NotEmpty( message="plDesc.null.empty.message")
	@Size( min=1, max=200 , message="plDesc.size.message")
	@Schema(description = "Mandatory field", pattern = "AlphaNumeric",minLength=1, maxLength = 200 ,required=true)
	private String plDesc;
	
	@NotNull( message="plFromDate.null.empty.message")
	@NotEmpty( message="plFromDate.null.empty.message")
	@Date(format = "yyyy-MM-dd'T'HH:mm:ss", message = "plFromDate.pattern.error.message")
	private String plFromDate;
	@Date(format = "yyyy-MM-dd'T'HH:mm:ss", message = "plEndDate.pattern.error.message")
	private String plEndDate;

}
