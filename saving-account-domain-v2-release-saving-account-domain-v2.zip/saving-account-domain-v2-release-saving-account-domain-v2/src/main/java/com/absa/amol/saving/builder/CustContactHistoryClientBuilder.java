package com.absa.amol.saving.builder;

import javax.ws.rs.BeanParam;
import javax.ws.rs.POST;
import javax.ws.rs.core.Response;

import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import com.absa.amol.saving.model.sys.addcontacthistory.AddContactHistoryRequest;
import com.absa.amol.saving.util.ServerSideExceptionMapper;
import com.absa.amol.util.model.ApiRequestHeader;

@RegisterRestClient(configKey = "cheque.book.add.custcontacthist.sys.url")
@RegisterProvider(value = ServerSideExceptionMapper.class)
public interface CustContactHistoryClientBuilder {
	
	@POST
	public Response addContactHistory(@BeanParam ApiRequestHeader apiRequestHeader,
			@RequestBody AddContactHistoryRequest addContactHistoryRequest);
}
