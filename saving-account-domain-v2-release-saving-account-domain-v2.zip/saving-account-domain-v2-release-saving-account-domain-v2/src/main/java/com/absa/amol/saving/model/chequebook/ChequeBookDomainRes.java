package com.absa.amol.saving.model.chequebook;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(name = "ChequeBookDomainRes", description = "Response Schema for cheque book domain")
public class ChequeBookDomainRes {

	private String issuedDeviceTransactionReferenceNumber;
	private String issuedDeviceTransactionDate;
	private IssuedDeviceOptionSetting issuedDeviceOptionSetting;
}
