package com.absa.amol.saving.service.standinginstruction.mod;

import com.absa.amol.saving.model.standinginstruction.mod.StandingModReq;
import com.absa.amol.saving.model.standinginstruction.mod.StandingModRes;
import com.absa.amol.util.model.ResponseEntity;

public interface StandingInstructionModService {
	ResponseEntity<StandingModRes> modStandingInstruction(StandingModReq standingModReq);
}
