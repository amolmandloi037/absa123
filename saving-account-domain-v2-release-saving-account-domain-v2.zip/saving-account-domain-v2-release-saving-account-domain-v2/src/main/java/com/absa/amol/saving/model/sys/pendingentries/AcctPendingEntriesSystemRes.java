package com.absa.amol.saving.model.sys.pendingentries;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Schema(name = "AccountPendingEntriesResponse",
description = "Response Schema for Account Pending Entries System Adapter")
public class AcctPendingEntriesSystemRes {	
	private String transactionCode;
	private String amount;
	private String drCrMultiplier;
	private String narrative;
}
