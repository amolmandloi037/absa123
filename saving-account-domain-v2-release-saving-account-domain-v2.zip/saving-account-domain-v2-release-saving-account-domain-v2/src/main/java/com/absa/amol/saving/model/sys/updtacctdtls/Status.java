package com.absa.amol.saving.model.sys.updtacctdtls;

import javax.json.bind.annotation.JsonbProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Status {
	
	@JsonbProperty(nillable = true)
	private String statusCode;
	@JsonbProperty(nillable = true)
	private String statusDesc;

}
