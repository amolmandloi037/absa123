package com.absa.amol.saving.model.sys.demanddraft;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class SystemValidationError {

	private String applicableAttributes;
	private String attributeName;
	private String attributeValue;
	private String errorCode;
	private String errorMessage;
	private String methodName;
	private String objectName;
}
