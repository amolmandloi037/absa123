package com.absa.amol.saving.model.sys.updtacctdtls;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AcctAddress {
	
	
	private String serialNumber;
	private MailAddress mailAddress;
	private String statementCopies;
	private String chequesRequiredIndicator;
	private String branchStatementIndicator;
	private String statementAddressIndicator;
	private String miniStatementAddressIndicator;
	private String fixedDepositAddressIndicator;
	private String customerId;
	private String customerContactNumber;

}

