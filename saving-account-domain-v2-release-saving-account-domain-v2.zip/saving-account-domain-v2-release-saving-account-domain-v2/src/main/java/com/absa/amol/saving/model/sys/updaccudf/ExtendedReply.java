package com.absa.amol.saving.model.sys.updaccudf;

import javax.json.bind.annotation.JsonbProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ExtendedReply {

	@JsonbProperty(nillable= true)
	private Messages messages;
}
