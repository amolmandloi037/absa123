package com.absa.amol.saving.util;

import java.util.Arrays;
import java.util.List;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import org.eclipse.microprofile.rest.client.ext.ResponseExceptionMapper;

import com.absa.amol.util.exception.ApiException;
import com.absa.amol.util.exception.ApiRequestException;
import com.absa.amol.util.exception.ApiResponseException;
import com.absa.amol.util.exception.GlobalException;
import com.absa.amol.util.exception.SORSystemServiceUnavailableException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ResponseEntity;

public class ServerSideExceptionMapper implements ResponseExceptionMapper<Exception> {
  private static final Logger logger = LoggerFactory.getLogger(ServerSideExceptionMapper.class);
  private static final List<Integer> errorStatus = Arrays.asList(404, 500, 400,504,503);

  private static final String TOTHRWOWABLE = "toThrowable";

  @Override
  public boolean handles(int status, MultivaluedMap<String, Object> headers) {
    return errorStatus.contains(status);
  }

  @Override
  public ApiException toThrowable(Response response) {
	  ApiException exception =null;
    try {
      if (response.hasEntity() && !MediaType.TEXT_HTML_TYPE.equals(response.getMediaType())
          && response.getStatus() != 400) {
    	  ResponseEntity<?> responseEntity = response.readEntity(ResponseEntity.class);
			if (response.getStatus() == 504 || response.getStatus() == 503 ) {
				exception = new SORSystemServiceUnavailableException(Constant.FIVE_O_THREE,
						Constant.SERVICE_UNAVAILABLE);
				logger.info(TOTHRWOWABLE, "", responseEntity.getMessage(), exception);
			}else {
				
				exception=new ApiResponseException(responseEntity.getCode(), responseEntity.getMessage());
				logger.info(TOTHRWOWABLE, "", responseEntity.getMessage(), exception);
			}

      } else if (response.getStatus() == 400) {
        ResponseEntity<?> responseEntity = response.readEntity(ResponseEntity.class);
         exception =
            new ApiRequestException(responseEntity.getCode(), responseEntity.getMessage());
        logger.info(TOTHRWOWABLE, "", responseEntity.getMessage(), exception);
      } else {
         exception = new SORSystemServiceUnavailableException(
        		 Constant.FIVE_O_THREE, Constant.SERVICE_UNAVAILABLE);
        logger.info(TOTHRWOWABLE, "", "Raising SORSystemServiceUnavailableException exception",
            exception);
      }
    } catch (Exception ex) {
    	exception= new GlobalException(Constant.INTERNAL_ERROR_CODE, Constant.INTERNAL_ERROR_MSG);
    }
    return exception;
  }
}