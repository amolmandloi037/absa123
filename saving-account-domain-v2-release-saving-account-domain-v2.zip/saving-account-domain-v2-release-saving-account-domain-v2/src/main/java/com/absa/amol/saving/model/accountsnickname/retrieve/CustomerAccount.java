package com.absa.amol.saving.model.accountsnickname.retrieve;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CustomerAccount {
	
	private String accountNumber;
	private String accountNickName;
	private Integer bankBranchCode;
}
