package com.absa.amol.saving.util;

import javax.inject.Inject;

import org.eclipse.microprofile.config.Config;

import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;

public class SavingAccountDomainUtil {

	public static final Logger LOGGER = LoggerFactory.getLogger(SavingAccountDomainUtil.class);

	@Inject
	Config config;

	public String getPropertyValue(String confkey) {
		String configPropVal = confkey;
		try {
			configPropVal = config.getValue(confkey, String.class);
		} catch (Exception e) {
			LOGGER.error("getPropertyValue", Constant.BLANK, "Exception while reading property for the key ::" + confkey, e.getMessage());
		}
		return configPropVal;
	}

}
