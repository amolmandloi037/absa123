package com.absa.amol.saving.model;

import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class PaymentTransaction {
	private String paymentTransactionTypeCode;
	private String transactionCurrencyCode;
	private String createDateTime;
	private String transactionLiteral;
	private String paymentTransactionDate;
	private Double paymentTransactionAmount;
	private BigDecimal sourceAccountCurrencyAmount;
    private String creditDebitTypeCode;
    private String valueDate;
    private String postingDate;
	private BigDecimal lcyAmount;
	private BigDecimal transactionCurrencyAmount;
	private String feeType;
	private BigDecimal runningBalanceAmount;
	private String channelReferenceNumber;
	private String createdBy;
	private Long batchNumber;
	private PaymentMechanism paymentMechanism;
	private PayeeAccountReference payeeAccountReference;
	private PaymentPurpose paymentPurpose;

}
