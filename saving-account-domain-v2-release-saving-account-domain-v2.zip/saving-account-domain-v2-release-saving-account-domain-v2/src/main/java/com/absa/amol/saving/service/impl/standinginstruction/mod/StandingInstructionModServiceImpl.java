package com.absa.amol.saving.service.impl.standinginstruction.mod;

import javax.inject.Inject;

import org.eclipse.microprofile.rest.client.inject.RestClient;

import com.absa.amol.saving.builder.StandingInstructionModClientBuilder;
import com.absa.amol.saving.model.standinginstruction.mod.StandingModReq;
import com.absa.amol.saving.model.standinginstruction.mod.StandingModRes;
import com.absa.amol.saving.service.standinginstruction.mod.StandingInstructionModService;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.exception.ApiException;
import com.absa.amol.util.exception.ApiResponseException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ResponseEntity;

public class StandingInstructionModServiceImpl implements StandingInstructionModService{
private static final Logger LOGGER = LoggerFactory.getLogger(StandingInstructionModServiceImpl.class);
	
	@Inject
	@RestClient
	StandingInstructionModClientBuilder clientBuilder;
	
	@Override
	public ResponseEntity<StandingModRes> modStandingInstruction(StandingModReq standingModReq)  {
		LOGGER.info(Constant.MOD_STANDING_INSTRUCTION,standingModReq.getApiRequestHeader().getConsumerUniqueReferenceId(), "", "");
		
		try {
			return clientBuilder.modifyStandingInstruction(standingModReq.getApiRequestHeader(),standingModReq);
		}
		catch (ApiException apiException) {
			LOGGER.error(Constant.MOD_STANDING_INSTRUCTION, Constant.API_EXCEPTION, Constant.API_EXCEPTION, apiException.getMessage());
			LOGGER.debug(Constant.MOD_STANDING_INSTRUCTION, Constant.API_EXCEPTION, Constant.API_EXCEPTION, apiException);
			throw apiException;
		} catch (Exception exception) {
			LOGGER.error(Constant.MOD_STANDING_INSTRUCTION, Constant.EXCEPTION, Constant.EXCEPTION, exception.getMessage());
			LOGGER.debug(Constant.MOD_STANDING_INSTRUCTION, Constant.EXCEPTION, Constant.EXCEPTION, exception);
			throw new ApiResponseException(Constant.INTERNAL_ERROR_CODE, Constant.INTERNAL_ERROR_MSG);
		}
	}
}
	

