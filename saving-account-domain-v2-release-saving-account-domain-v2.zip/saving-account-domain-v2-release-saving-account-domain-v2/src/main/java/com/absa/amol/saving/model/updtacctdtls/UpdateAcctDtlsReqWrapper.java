package com.absa.amol.saving.model.updtacctdtls;

import javax.validation.Valid;

import com.absa.amol.util.model.ApiRequestHeader;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UpdateAcctDtlsReqWrapper {
	
	@Valid
	private ApiRequestHeader apiRequestHeader;
	@Valid
	private UpdateAcctDtlsReq updateAcctDtlsReq;

}
