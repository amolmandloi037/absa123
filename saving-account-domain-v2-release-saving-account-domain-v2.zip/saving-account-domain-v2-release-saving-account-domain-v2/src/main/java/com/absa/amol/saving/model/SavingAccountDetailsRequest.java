package com.absa.amol.saving.model;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.ws.rs.BeanParam;
import javax.ws.rs.QueryParam;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import com.absa.amol.util.model.ApiRequestHeader;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Schema(name = "SavingAccountDetailsRequest",
    description = "Request Schema To Get Saving Account Details")
public class SavingAccountDetailsRequest {

  @Valid
  @BeanParam
  private ApiRequestHeader apiRequestHeader;

  @Schema(description = "Field is mandatory for all flows.", pattern = "Only numeric",
      minLength = 1, maxLength = 16, required = true)
  @NotNull(message = "accountNumber.nullOrEmpty.message")
  @NotEmpty(message = "accountNumber.nullOrEmpty.message")
  @Pattern(regexp = "[0-9]{1,16}", message = "accountNumber.pattern.message")
  @QueryParam(value = "accountNumber")
  private String accountNumber;

  @Pattern(regexp = "[0-9]{0,5}", message = "branchCode.pattern.message")
  @QueryParam(value = "branchCode")
  @Schema(
      description = "In BRAINS branchCode is associated with account number and in FCR it is associated with transaction branch",
      pattern = "[0-9]*", maxLength = 5)
  private String branchCode;


}
