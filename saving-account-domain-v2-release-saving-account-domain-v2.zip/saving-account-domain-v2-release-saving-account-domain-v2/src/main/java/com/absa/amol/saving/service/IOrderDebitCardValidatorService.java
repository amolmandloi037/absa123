package com.absa.amol.saving.service;

import com.absa.amol.saving.model.orderdebitcard.OrderDebitCardDomainReq;
import com.absa.amol.util.model.ApiRequestHeader;

public interface IOrderDebitCardValidatorService {

	public void validateOrderDebitCardReq(ApiRequestHeader apiRequestHeader, OrderDebitCardDomainReq orderDebitCardDomainReq);
}
