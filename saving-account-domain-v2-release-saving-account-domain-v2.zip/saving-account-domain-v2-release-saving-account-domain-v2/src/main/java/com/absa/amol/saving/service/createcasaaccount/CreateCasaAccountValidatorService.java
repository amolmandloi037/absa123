package com.absa.amol.saving.service.createcasaaccount;

import com.absa.amol.saving.model.createcasaaccount.CreateCasaAccountRequest;

public interface CreateCasaAccountValidatorService {
  public void validateCreateCasaAccountRequest(CreateCasaAccountRequest req);
}
