package com.absa.amol.saving.model.standinginstruction.retrieve;

import javax.json.bind.annotation.JsonbProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentScheduleRetRes {
	@JsonbProperty(nillable = true) private String startDate;
	@JsonbProperty(nillable = true) private String nextExecutionDate;
	@JsonbProperty(nillable = true) private String frequency;
	@JsonbProperty(nillable = true) private String endDate;
	@JsonbProperty(nillable = true) private Long dayOfTheMonth;
	@JsonbProperty(nillable = true) private Long transferMonth;
	@JsonbProperty(nillable = true) private Long firstPaymentAmount;
	@JsonbProperty(nillable = true) private Long lastPaymentAmount;
}
