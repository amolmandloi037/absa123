package com.absa.amol.saving.service.impl.checkstatus;

import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.Response;

import org.eclipse.microprofile.rest.client.inject.RestClient;

import com.absa.amol.saving.mapper.checkstatus.CheckStatusMapper;
import com.absa.amol.saving.model.checkstatus.CheckStatusRequest;
import com.absa.amol.saving.model.checkstatus.CheckStatusResponse;
import com.absa.amol.saving.model.checkstatus.RetrieveCheckStatusRequest;
import com.absa.amol.saving.model.checkstatus.RetrieveCheckStatusResponse;
import com.absa.amol.saving.model.checkstatus.Status;
import com.absa.amol.saving.model.checkstatus.SystemReplyMessage;
import com.absa.amol.saving.service.checkstatus.CheckStatusService;
import com.absa.amol.saving.util.CheckStatusClient;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.exception.ApiException;
import com.absa.amol.util.exception.ApiResponseException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.model.ResponseEntity;
import com.absa.amol.util.utility.CollectionUtil;
import com.absa.amol.util.utility.CommonUtil;

public class CheckStatusServiceImpl implements CheckStatusService {
	
	private static final Logger logger =
		      LoggerFactory.getLogger(CheckStatusServiceImpl.class);
	


	  @Inject
	  @RestClient
	  private CheckStatusClient checkStatusClient;
	  
	  @Inject
	  private CheckStatusMapper checkStatusMapper;

	@Override
	public Response getCheckStatus(CheckStatusRequest req) {
		final String method_name = "getCheckStatus";
		Response response = null;
	    String consUniqId = "";
	    ResponseEntity<RetrieveCheckStatusResponse> systemEntity = null;
	    ResponseEntity<CheckStatusResponse> domainEntity = null;
	    try {
	      consUniqId = req.getApiRequestHeader().getConsumerUniqueReferenceId();
	      logger.info(method_name, consUniqId, "inside Service : invoking system service client", "");
	      RetrieveCheckStatusRequest systemReq = checkStatusMapper.checkStatusReqMapping(req);
	      response = checkStatusClient.getCheckStatus(systemReq);
	      logger.info(method_name, consUniqId, "Response Recieved from System Adapter",
	          response.toString());

	      if (response.getStatus() == Constant.SUCCESS) {
	        systemEntity =
	            response.readEntity(new GenericType<ResponseEntity<RetrieveCheckStatusResponse>>(){});
	        CheckStatusResponse domainRes = null;

	        RetrieveCheckStatusResponse systemRes = systemEntity.getData();
	        if (CommonUtil.isNotNull(systemRes) && CommonUtil.isNotNull(systemRes.getStatus())) {
	      Status status = systemRes.getStatus();
	          
	          logger.info(method_name, consUniqId, "Status object recieved from System Adapter",
	                  status.toString());
	          
				/*
				 * domainEntity = new
				 * ResponseEntity<CheckStatusResponse>(systemEntity.getCode(),
				 * systemEntity.getMessage(), systemEntity.getStatus(), domainRes);
				 */

	          if (Constant.REPLY_CODE_0.equals(status.getReplyCode())) {

	            /******* FCR Success Mapping for Success code 0 *******/
	            logger.info(method_name, consUniqId, "Got Success Response from FCR",
	                status.getReplyCode().toString());

	            //mapper
	            domainRes = checkStatusMapper.checkStatusResMapping(systemRes);
	            domainEntity = new ResponseEntity<CheckStatusResponse>(systemEntity.getCode(),
	                systemEntity.getMessage(), systemEntity.getStatus(), domainRes);
	            logger.info(method_name, consUniqId, "Mapping completed in FCR", "");
	          } else if (status.getReplyCode()!=null && (Constant.REPLY_CODE_30.equals(status.getReplyCode())
	              || status.getReplyCode() >= (Constant.REPLY_CODE_80))) {

	            /******* FCR FAILURES Mapping for 30 and 80 *******/
	            logger.info(method_name, consUniqId, Constant.LOG_BUSINESS_MSG,
	                status.getReplyCode().toString());

	            domainEntity = new ResponseEntity<CheckStatusResponse>(
	                Constant.BAD_REQUEST_CODE, Constant.FAILURE_MSG,
	                getBusinessFailureMessage(status, req.getApiRequestHeader()), null);
	          } else if (Constant.REPLY_CODE_40.equals(status.getReplyCode())) {

	            /******* FCR FAILURES Mapping for 40 *******/
	            logger.info(method_name, consUniqId, Constant.LOG_BUSINESS_MSG,
	                status.getReplyCode().toString());

	            domainEntity = new ResponseEntity<CheckStatusResponse>(Constant.SUCCESS_CODE,
	                Constant.FAILURE_MSG, getBusinessFailureMessage(status, req.getApiRequestHeader()),
	                null);
	         
	          }
	          
	          
	          
	        }
	        if(CommonUtil.isNotNull(domainEntity) && CommonUtil.isNotNull(domainEntity.getCode()) ) {
	        	response = Response.status( Integer.parseInt(domainEntity.getCode())).entity(domainEntity).build();
	        }
	      }
	      return response;
	    } catch (ApiException exception) {
	      logger.error(method_name, consUniqId, Constant.EXCEPTION_OCCURED_FROM_SERVER,
	          exception.getErrorMessage());
	      logger.debug(method_name, consUniqId, Constant.EXCEPTION_OCCURED_FROM_SERVER, exception);
	      throw exception;
	    } catch (Exception exception) {
	      logger.error(method_name, consUniqId, Constant.EXCEPTION_OCCURED_FROM_SERVER,
	          exception.getMessage());
	      logger.debug(method_name, consUniqId, Constant.EXCEPTION_OCCURED_FROM_SERVER, exception);
	      throw new ApiResponseException("500", "Internal  Server Error");
	    }
	  }


	  public String getBusinessFailureMessage(Status status, ApiRequestHeader header) {
	    logger.info("getBusinessFailureMessage", header.getConsumerUniqueReferenceId(),
	        "Concatinating Business Error Messages", "Start");
	    String message = "";

	    if (CommonUtil.isNotNull(status.getExtendedReply())
	        && CommonUtil.isNotNull(status.getExtendedReply().getMessages())
	        && CollectionUtil.isNotNullAndNotEmpty(status.getExtendedReply().getMessages().getItem())) {
	      List<SystemReplyMessage> itemList = status.getExtendedReply().getMessages().getItem();
	      for (SystemReplyMessage item : itemList) {
	        message = message.concat(item.getMessage()).concat("\n");
	      }
	    }
	    if (status.getReplyText() != null) {
	      message = message.concat(status.getReplyText());
	    }
	    logger.info("getBusinessFailureMessage", header.getConsumerUniqueReferenceId(),
	        "Concatinating Business Error Messages", "End");
	    return message;
	  }
	}