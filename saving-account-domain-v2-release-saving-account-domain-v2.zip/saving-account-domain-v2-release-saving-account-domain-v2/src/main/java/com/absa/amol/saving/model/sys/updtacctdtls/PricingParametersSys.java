package com.absa.amol.saving.model.sys.updtacctdtls;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PricingParametersSys {
	
	private String priceCode;
	private String plName;
	private String plDesc;
	private String plFromDate;
	private String plEndDate;

}
