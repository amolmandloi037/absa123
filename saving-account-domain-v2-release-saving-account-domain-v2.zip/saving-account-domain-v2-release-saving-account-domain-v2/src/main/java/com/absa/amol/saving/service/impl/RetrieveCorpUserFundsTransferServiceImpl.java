package com.absa.amol.saving.service.impl;

import javax.inject.Inject;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import com.absa.amol.saving.mapper.TransactionHistoryMceDetailsRequestMapper;
import com.absa.amol.saving.mapper.TransactionHistoryMceDetailsResponseMapper;
import com.absa.amol.saving.mapper.TransactionHistoryMceListRequestMapper;
import com.absa.amol.saving.mapper.TransactionHistoryMceListResponseMapper;
import com.absa.amol.saving.model.CorpuserFTListRequest;
import com.absa.amol.saving.model.CorpuserFTListResponse;
import com.absa.amol.saving.model.FundTransferDetailsResponse;
import com.absa.amol.saving.model.FundsTransferDetailsRequest;
import com.absa.amol.saving.model.TransactionHistoryDomainRequest;
import com.absa.amol.saving.model.TransactionHistoryDomainResponse;
import com.absa.amol.saving.service.RetrieveCorpUserFundsTransferService;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.saving.util.CorpUserFundsTransferDetailsMceClient;
import com.absa.amol.saving.util.CorpUserFundsTransferListMceClient;
import com.absa.amol.util.exception.ApiException;
import com.absa.amol.util.exception.ApiResponseException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ResponseEntity;
import com.absa.amol.util.utility.CommonUtil;

public class RetrieveCorpUserFundsTransferServiceImpl
    implements RetrieveCorpUserFundsTransferService {

  private static final Logger logger =
      LoggerFactory.getLogger(RetrieveCorpUserFundsTransferServiceImpl.class);

  @Inject
  private TransactionHistoryMceDetailsRequestMapper mceDetailsRequestMapper;

  @Inject
  private TransactionHistoryMceDetailsResponseMapper mceDetailsResponseMapper;

  @Inject
  private TransactionHistoryMceListRequestMapper mceListRequestMapper;

  @Inject
  private TransactionHistoryMceListResponseMapper mceListResponseMapper;

  @Inject
  @RestClient
  private CorpUserFundsTransferDetailsMceClient corpUserFundsTransferDetailsMceClient;

  @Inject
  @RestClient
  private CorpUserFundsTransferListMceClient corpUserFundsTransferListMceClient;


  @Override
  public Response getRetrieveCorpUserFundsTransferServiceList(
      TransactionHistoryDomainRequest domainRequest) {
    Response mceResponse = null;
    ResponseEntity<CorpuserFTListResponse> entitySummary = null;
    ResponseEntity<TransactionHistoryDomainResponse> casaEntity = null;
    Response domainResponse = null;
    // call a service for mce details system adapter returning response and which
    // calls mce request mapper
    logger.info(Constant.GET_TRANSACTION_HISTORY_LIST,
        domainRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
        "inside RetrieveCorpUserFundsTransferServiceList : invoking system service client", "");

    try {
      CorpuserFTListRequest corpuserFTListRequest = mceListRequestMapper
          .fundsTransferListReqMapper(domainRequest.getApiRequestHeader(), domainRequest);
      // calls mce client
      // calls mce response mapper
      if (CommonUtil.isNotNull(corpuserFTListRequest)) {
        mceResponse = corpUserFundsTransferListMceClient
            .getCorpUserFundsTransferListResponse(corpuserFTListRequest);
        logger.info(Constant.GET_TRANSACTION_HISTORY_LIST,
            domainRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
            "inside RetrieveCorpUserFundsTransferServiceList : Response recived ",
            "Status Code receieved : " + mceResponse.getStatus());
        if (mceResponse.getStatus() == Constant.SUCCESS) {
          entitySummary =
              mceResponse.readEntity(new GenericType<ResponseEntity<CorpuserFTListResponse>>() {});
          if (CommonUtil.isNotNull(entitySummary)
              && CommonUtil.isNotNull(entitySummary.getData())) {
            TransactionHistoryDomainResponse transactionHistoryDomainResponse =
                mceListResponseMapper.fundTransferListResMapper(
                    corpuserFTListRequest.getApiRequestHeader(), entitySummary.getData());
            casaEntity = new ResponseEntity<TransactionHistoryDomainResponse>(
                entitySummary.getCode(), entitySummary.getMessage(), entitySummary.getStatus(),
                transactionHistoryDomainResponse);
            domainResponse = Response.ok(casaEntity).build();
            logger.info(Constant.GET_TRANSACTION_HISTORY_LIST,
                domainRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
                "Received success response from system service",
                "Status Code" + mceResponse.getStatus());
          } else {

            logger.info(Constant.GET_TRANSACTION_HISTORY_LIST,
                domainRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
                "Received success response from system service but data not found. ", "");

            casaEntity = new ResponseEntity<>(entitySummary.getCode(), null,
                entitySummary.getStatus(), null);
            casaEntity.setCode(Constant.SUCCESS_CODE);
            casaEntity.setMessage(Constant.NO_RECORD_FOUND);
            casaEntity.setStatus(Constant.SUCCESS_MSG);

            return Response.ok(casaEntity).build();
          }
        }

      }
      return domainResponse;
    } catch (ApiException exception) {
      logger.error(Constant.GET_TRANSACTION_HISTORY_LIST,
          domainRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
          Constant.EXCEPTION_OCCURED_FROM_SERVER, exception.getErrorMessage());
      logger.debug(Constant.GET_TRANSACTION_HISTORY_LIST,
          domainRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
          Constant.EXCEPTION_OCCURED_FROM_SERVER, exception);
      throw exception;
    } catch (Exception exception) {
      logger.error(Constant.GET_TRANSACTION_HISTORY_LIST,
          domainRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
          Constant.EXCEPTION_OCCURED_FROM_SERVER, exception.getMessage());
      logger.debug(Constant.GET_TRANSACTION_HISTORY_LIST,
          domainRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
          Constant.EXCEPTION_OCCURED_FROM_SERVER, exception);
      throw new ApiResponseException("500", "Internal  Server Error");
    }
  }

  @Override
  public Response getRetrieveCorpUserFundsTransferServiceDetails(
      TransactionHistoryDomainRequest domainRequest) {
    Response mceResponse = null;
    ResponseEntity<FundTransferDetailsResponse> entitySummary = null;
    ResponseEntity<TransactionHistoryDomainResponse> casaEntity = null;
    Response domainResponse = null;
    logger.info(Constant.GET_TRANSACTION_HISTORY_DETAILS,
        domainRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
        "inside RetrieveCorpUserFundsTransferServiceDetails : invoking system service client", "");

    try {
      FundsTransferDetailsRequest fundsTransferDetailsRequest = mceDetailsRequestMapper
          .fundsTransferDetailsReqMapper(domainRequest.getApiRequestHeader(), domainRequest);
      if (CommonUtil.isNotNull(fundsTransferDetailsRequest)) {
        mceResponse = corpUserFundsTransferDetailsMceClient
            .getCorpUserFundsTransferDetailsResponse(fundsTransferDetailsRequest);
        logger.info(Constant.GET_TRANSACTION_HISTORY_DETAILS,
            domainRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
            "inside RetrieveCorpUserFundsTransferServiceList : Response recived ",
            "Status Code : " + mceResponse.getStatus());
        if (mceResponse.getStatus() == Constant.SUCCESS) {
          entitySummary = mceResponse
              .readEntity(new GenericType<ResponseEntity<FundTransferDetailsResponse>>() {});
          if (CommonUtil.isNotNull(entitySummary)
              && CommonUtil.isNotNull(entitySummary.getData())) {

            TransactionHistoryDomainResponse transactionHistoryDomainResponse =
                mceDetailsResponseMapper.fundsTransferDetailsResMapper(
                    domainRequest.getApiRequestHeader(), entitySummary.getData());

            casaEntity = new ResponseEntity<TransactionHistoryDomainResponse>(
                entitySummary.getCode(), entitySummary.getMessage(), entitySummary.getStatus(),
                transactionHistoryDomainResponse);
            domainResponse = Response.ok(casaEntity).build();

            logger.info(Constant.GET_TRANSACTION_HISTORY_DETAILS,
                domainRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
                "Received success response from system service",
                "Status Code " + mceResponse.getStatus());
          } else {

            logger.info(Constant.GET_TRANSACTION_HISTORY_LIST,
                domainRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
                "Received success response from system service but data not found. ", "");

            casaEntity = new ResponseEntity<>(entitySummary.getCode(), null,
                entitySummary.getStatus(), null);
            casaEntity.setCode(Constant.SUCCESS_CODE);
            casaEntity.setMessage(Constant.NO_RECORD_FOUND);
            casaEntity.setStatus(Constant.SUCCESS_MSG);

            return Response.ok(casaEntity).build();
          }
        }
      }

      return domainResponse;
    } catch (ApiException exception) {
      logger.error(Constant.GET_TRANSACTION_HISTORY_DETAILS,
          domainRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
          Constant.EXCEPTION_OCCURED_FROM_SERVER, exception.getErrorMessage());
      logger.debug(Constant.GET_TRANSACTION_HISTORY_LIST,
          domainRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
          Constant.EXCEPTION_OCCURED_FROM_SERVER, exception);
      throw exception;
    } catch (Exception exception) {
      logger.error(Constant.GET_TRANSACTION_HISTORY_LIST,
          domainRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
          Constant.EXCEPTION_OCCURED_FROM_SERVER, exception.getMessage());
      logger.debug(Constant.GET_TRANSACTION_HISTORY_LIST,
          domainRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
          Constant.EXCEPTION_OCCURED_FROM_SERVER, exception);
      throw new ApiResponseException("500", "Internal  Server Error");
    }
  }


}
