package com.absa.amol.saving.mapper;

import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import org.eclipse.microprofile.config.Config;
import com.absa.amol.saving.model.orderpaperstmt.OrderPaperStmtDomainRequest;
import com.absa.amol.saving.model.sys.addcontacthistory.AddContactHistoryRequest;
import com.absa.amol.saving.model.sys.addcontacthistory.ContactHistoryDetails;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;

public class CustContactHistoryMapper {
  private static final Logger LOGGER = LoggerFactory.getLogger(CustContactHistoryMapper.class);

  @Inject
  Config config;

  public AddContactHistoryRequest addContactHistorySysReqMapping(OrderPaperStmtDomainRequest req) {
    LOGGER.info("addContactHistorySysReqMapping",
        req.getApiRequestHeader().getConsumerUniqueReferenceId(), Constant.EMPTY, " Start");

    AddContactHistoryRequest addContactHistoryRequest = new AddContactHistoryRequest();
    ContactHistoryDetails contactHistoryDetails = new ContactHistoryDetails();
    List<ContactHistoryDetails> contactHistoryDetailsList = new ArrayList<>();
    contactHistoryDetails
        .setActivityId(config.getValue("order.paper.stmt.contacthist.activityId", String.class));
    contactHistoryDetails.setActivityName(
        config.getValue("order.paper.stmt.contacthist.activityName", String.class));
    contactHistoryDetails.setCustomerId(req.getCustomerNumber());
    contactHistoryDetails.setDataOne(null);
    contactHistoryDetails.setDataTwo(null);
    contactHistoryDetailsList.add(contactHistoryDetails);
    addContactHistoryRequest.setContactHistoryDetails(contactHistoryDetailsList);
    LOGGER.info("addContactHistorySysReqMapping",
        req.getApiRequestHeader().getConsumerUniqueReferenceId(), Constant.EMPTY, " End");
    return addContactHistoryRequest;
  }
}
