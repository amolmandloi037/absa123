package com.absa.amol.saving.service.impl.accountsnickname.add;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

import org.eclipse.microprofile.rest.client.inject.RestClient;

import com.absa.amol.saving.builder.AddAccountsNickNameClientBuilder;
import com.absa.amol.saving.mapper.accountsnickname.add.AddAccountsNicknameMapper;
import com.absa.amol.saving.model.accountsnickname.add.AddAccountsNickNameReq;
import com.absa.amol.saving.model.accountsnickname.add.AddAccountsNickNameRes;
import com.absa.amol.saving.model.sys.accountsnickname.add.AddAccountsNickNameSystemMceRequest;
import com.absa.amol.saving.model.sys.accountsnickname.add.AddAccountsNickNameSystemMceResponse;
import com.absa.amol.saving.service.accountsnickname.add.IAccountsNicknameValidatorService;
import com.absa.amol.saving.service.accountsnickname.add.IAddAccountsNicknameService;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.exception.ApiException;
import com.absa.amol.util.exception.ApiResponseException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.model.ResponseEntity;

@ApplicationScoped
public class AddAccountsNicknameServiceImpl implements IAddAccountsNicknameService{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(AddAccountsNicknameServiceImpl.class);
	
	@SuppressWarnings("cdi-ambiguous-dependency")
	@Inject
	@RestClient
	private AddAccountsNickNameClientBuilder addAccountsNickNameClientBuilder;
	
	@Inject 
	private AddAccountsNicknameMapper addAccountsNicknameMapper;
	
	@Inject
	private IAccountsNicknameValidatorService accountsNicknameValidatorService;
	
	@Override
	public ResponseEntity<AddAccountsNickNameRes> addUpdateAccountNickname(ApiRequestHeader requestHeader, AddAccountsNickNameReq addAccountsNickNameReq) 
	{
		
		LOGGER.info(Constant.M_ADD_UPDATE_ACCOUNTS_NICKNAME, requestHeader.getConsumerUniqueReferenceId(), Constant.BLANK, Constant.BLANK);
		ResponseEntity<AddAccountsNickNameRes> domainResEntity = null;
		try 
		{
			accountsNicknameValidatorService.validateInputRequest(addAccountsNickNameReq, requestHeader);
			AddAccountsNickNameSystemMceRequest addAccountsNickNameSystemMceRequest = addAccountsNicknameMapper.getAddAccountsNicknameReqMapping(requestHeader,addAccountsNickNameReq);
			ResponseEntity<AddAccountsNickNameSystemMceResponse> sysResEntity = addAccountsNickNameClientBuilder.addCustNickname(requestHeader,addAccountsNickNameSystemMceRequest);
			
			if(sysResEntity.getCode().equals(Constant.SUCCESS_CODE)) {
				AddAccountsNickNameRes addAccountsNickNameRes = new AddAccountsNickNameRes();
				addAccountsNickNameRes.setTransactionReferenceId(requestHeader.getConsumerUniqueReferenceId());
				domainResEntity = new ResponseEntity<>(sysResEntity.getCode(), Constant.ADD_ACCT_NICKNAME_SUCCESS_MSG, sysResEntity.getStatus(), addAccountsNickNameRes);
			}
			
		}
		catch (ApiException exception) 
		{
			LOGGER.error(Constant.M_ADD_UPDATE_ACCOUNTS_NICKNAME, requestHeader.getConsumerUniqueReferenceId(), Constant.API_EXCEPTION_OCCURRED, exception.getErrorMessage());
			LOGGER.debug(Constant.M_ADD_UPDATE_ACCOUNTS_NICKNAME, requestHeader.getConsumerUniqueReferenceId(), Constant.API_EXCEPTION_OCCURRED, exception);
			throw exception;
		} 
		catch (Exception exception) 
		{
			LOGGER.error(Constant.M_ADD_UPDATE_ACCOUNTS_NICKNAME, requestHeader.getConsumerUniqueReferenceId(), Constant.EXCEPTION_OCCURRED, exception.getMessage());
			LOGGER.debug(Constant.M_ADD_UPDATE_ACCOUNTS_NICKNAME, requestHeader.getConsumerUniqueReferenceId(), Constant.EXCEPTION_OCCURRED, exception);
			throw new ApiResponseException(Constant.INTERNAL_ERROR_CODE, Constant.INTERNAL_ERROR_MSG);
		}
		return domainResEntity;
	}
}
