package com.absa.amol.saving.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class InterestTransaction {
  private Integer debitInterestContra;
  private Integer creditInterestContra;

}
