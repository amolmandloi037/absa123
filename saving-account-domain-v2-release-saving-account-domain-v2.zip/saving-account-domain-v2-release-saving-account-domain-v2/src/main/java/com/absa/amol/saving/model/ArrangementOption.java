package com.absa.amol.saving.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ArrangementOption {
  private String holdMailFlag;
  private Boolean jointAccountFlag;
  private String mailAddressControlFlag;
  private Integer numberOfStatementCopies;
  private Boolean generateRateChangeIntimationFlag;
  private Integer leadDaysIntimation;
  private Integer numberOfPastDueChecks;
  private Integer numberOfCheckWithdrawals;
  private Integer checkReorderThresholdNumber;
  private Integer deferredStmtGenerationDayOfMonth;
  private Boolean additionalAddressFlag;
  private Boolean adHocStatementFlag;
  private Boolean atmFacilityFlag;
  private String groupBonusInteresFlag;
  private Boolean internetBankingAccessFlag;
  private Boolean inwardDirectDebitAuthorizationFlag;
  private Boolean mobileFacilityFlag;
  private Boolean pointOfSaleFacilityFlag;
  private Boolean standingInstructionFlag;
  private Boolean sweepoutInstructionFlag;
  private Double overdraftLimitAmount;
  private Boolean interestWaiverFlag;
  private String creditInterestCapitalisationBasisCode;
  private String creditInterestCapitalizationFrequency;
  private String debitInterestCapitalisationBasisCode;
  private String debitInterestCapitalisationFrequencyCode;


}
