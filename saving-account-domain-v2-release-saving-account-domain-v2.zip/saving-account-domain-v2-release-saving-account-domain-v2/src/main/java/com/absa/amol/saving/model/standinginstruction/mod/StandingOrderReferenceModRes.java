package com.absa.amol.saving.model.standinginstruction.mod;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StandingOrderReferenceModRes {

	private Integer standingOrderNumber;

}
