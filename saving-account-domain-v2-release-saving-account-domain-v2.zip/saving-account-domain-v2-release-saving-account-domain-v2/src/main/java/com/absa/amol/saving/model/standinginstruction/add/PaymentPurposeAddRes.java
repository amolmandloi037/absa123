package com.absa.amol.saving.model.standinginstruction.add;

import javax.json.bind.annotation.JsonbProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentPurposeAddRes {

	@JsonbProperty(nillable = true)
	private String transactionReferenceNumber;

}
