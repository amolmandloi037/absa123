package com.absa.amol.saving.model.purchasemv;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class PaymentTransactionAmount {

	@NotNull(message = "voucherAmount.notnullempty.error.message")
	@NotEmpty(message = "voucherAmount.notnullempty.error.message")
	@Pattern(regexp="[0-9]{1,13}(\\.[0-9]{1,2})", message="voucherAmount.regex.error.message")
	private String voucherAmount;
	
	@NotNull(message = "voucherCurrency.notnullempty.error.message")
	@NotEmpty(message = "voucherCurrency.notnullempty.error.message")
	@Pattern(regexp="[a-zA-Z]{3,3}", message="voucherCurrency.regex.error.message")
	private String voucherCurrency;
}
