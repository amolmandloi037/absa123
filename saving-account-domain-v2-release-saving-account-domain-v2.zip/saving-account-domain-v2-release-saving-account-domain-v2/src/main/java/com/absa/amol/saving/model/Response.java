package com.absa.amol.saving.model;
import java.math.BigDecimal;
import java.util.List;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

	
	

	@Getter
	@Setter
	@AllArgsConstructor
	@NoArgsConstructor
	@ToString
	@Schema(name = "TransactionHistoryDomainResponse", description = "POJO that represents Transaction History response details")


	public class Response {
		
		private String eventByUserId;
	    private String auditType;
	    private String nameOnProbative;
		private Double debitAmount;
		private Double creditAmount;
		private Integer totalNumberOfRecords;
		private String accountNumber;
		private BigDecimal openingBalanceAmount;
		private BigDecimal closingBalanceAmount;
		private List<PaymentTransaction> paymentTransaction;
		private DepositTransactionSourceReference depositTransactionSourceReference;
		List<TransactionDescription>transactionDescription;
	    List<IdPKDetails>idPkDetails;
	    

	}


