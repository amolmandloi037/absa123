package com.absa.amol.saving.model.standinginstruction.add;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PayeeReferenceAddReq {

	private String beneficiaryAddressCity;
	private String beneficiaryAddressCountry;
	private String beneficiaryAddressline1;
	private String beneficiaryAddressline2;
	private String beneficiaryAddressline3;
	private String beneficiaryAddressState;
	private String beneficiaryAddressZip;
	
	@Schema(description = "Field is mandatory for all flows.", required = true)
	private String beneficiaryName;
	private PhoneAddReq phone;
	
	private String beneficiaryId;
}
