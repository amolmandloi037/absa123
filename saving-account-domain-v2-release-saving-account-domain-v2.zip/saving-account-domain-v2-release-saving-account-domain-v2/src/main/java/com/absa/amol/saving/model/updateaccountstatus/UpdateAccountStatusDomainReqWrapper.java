package com.absa.amol.saving.model.updateaccountstatus;

import javax.validation.Valid;
import javax.ws.rs.BeanParam;

import com.absa.amol.util.model.ApiRequestHeader;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class UpdateAccountStatusDomainReqWrapper {

	@Valid
	@BeanParam
	private ApiRequestHeader apiRequestHeader;
	
	private UpdateAccountStatusDomainReq updateAccountStatusDomainReq;
	
}
