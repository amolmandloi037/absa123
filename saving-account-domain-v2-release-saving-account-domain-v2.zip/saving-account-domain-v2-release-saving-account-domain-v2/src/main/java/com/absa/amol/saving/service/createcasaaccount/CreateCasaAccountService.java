package com.absa.amol.saving.service.createcasaaccount;

import com.absa.amol.saving.model.createcasaaccount.CreateCasaAccountRequest;
import com.absa.amol.saving.model.createcasaaccount.CreateCasaAccountResponse;
import com.absa.amol.util.model.ResponseEntity;

public interface CreateCasaAccountService {
  public ResponseEntity<CreateCasaAccountResponse> createCasaAccount(CreateCasaAccountRequest req);
}
