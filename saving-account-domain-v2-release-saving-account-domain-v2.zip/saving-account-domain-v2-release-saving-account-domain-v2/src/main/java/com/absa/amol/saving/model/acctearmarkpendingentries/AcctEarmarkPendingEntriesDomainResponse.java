package com.absa.amol.saving.model.acctearmarkpendingentries;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(name = "AcctEarmarkPendingEntriesDomainResponse", description = "Response Schema for Account Earmark Pending Entries Domain")
public class AcctEarmarkPendingEntriesDomainResponse {

	private Number authCode;
	private Date date; 
	private PositionLimitValue positionLimitValue; 
	private IssuedDevicePropertyValue issuedDevicePropertyValue;
	private AccountDetails accountDetails;
	private PositionLimitType positionLimitType;
	private String transactionCode;

}
