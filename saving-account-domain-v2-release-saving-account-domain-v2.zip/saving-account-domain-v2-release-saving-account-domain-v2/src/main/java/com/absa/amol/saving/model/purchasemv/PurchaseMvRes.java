package com.absa.amol.saving.model.purchasemv;

import javax.json.bind.annotation.JsonbProperty;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Schema(name = "PurchaseMvRes", description = "Response schema for purchase money voucher")
public class PurchaseMvRes {
	
	@JsonbProperty(value = "paymentTransaction")
	private PaymentTransactionRes paymentTransactionRes;
	private String operationId;

}
