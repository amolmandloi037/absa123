package com.absa.amol.saving.model.standinginstruction.retrieve;

import java.math.BigDecimal;

import javax.json.bind.annotation.JsonbProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentTransactionRetRes {
	@JsonbProperty(nillable = true) private BigDecimal amount;
	@JsonbProperty(nillable = true) private String currency;
	@JsonbProperty(nillable = true) private String feeType;
	@JsonbProperty(nillable = true) private PaymentPurposeRetRes paymentPurpose;
	@JsonbProperty(nillable = true) private PayeeAccountReferenceRetRes payeeAccountReference;
	@JsonbProperty(nillable = true) private PayeeReferenceRetRes payeeReference;
	@JsonbProperty(nillable = true) private PayeeBankReferenceRetRes payeeBankReference;
	@JsonbProperty(nillable = true) private FeeChargeRetRes feeCharge;
}