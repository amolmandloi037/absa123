package com.absa.amol.saving.model.sys.updtacctdtls;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountOpenResWrapper {
	
	private Integer soapRecordCount;
	private String soapResponseCode;
	private Integer soapStatusCode;
	private String soapErrorMessage;
	private Boolean flagValid;
	private Boolean flagInvalid;

}
