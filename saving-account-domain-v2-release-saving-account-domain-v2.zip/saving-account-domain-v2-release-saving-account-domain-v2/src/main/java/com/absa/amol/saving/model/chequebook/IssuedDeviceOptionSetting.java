package com.absa.amol.saving.model.chequebook;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class IssuedDeviceOptionSetting {

	private Boolean isServiceChargeApplied;
}
