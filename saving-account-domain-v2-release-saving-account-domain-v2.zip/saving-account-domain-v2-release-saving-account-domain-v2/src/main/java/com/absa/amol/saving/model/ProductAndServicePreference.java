package com.absa.amol.saving.model;

import javax.validation.constraints.Pattern;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@ToString
public class ProductAndServicePreference {

  @Pattern(regexp = "^[nNyY]", message = "Only n, N, y and Y are valid values for atmIndicator")
  private String atmIndicator;

  private Integer kycIndicator;

  private Integer debitRateIndicator1;
  private Integer debitRateIndicator2;
  private Integer creditRateIndicator1;
  private Integer creditRateIndicator2;


}
