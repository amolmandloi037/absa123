package com.absa.amol.saving.mapper;

import com.absa.amol.saving.model.FundsTransferDetailsRequest;
import com.absa.amol.saving.model.TransactionHistoryDomainRequest;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ApiRequestHeader;

public class TransactionHistoryMceDetailsRequestMapper {
  private static final Logger LOGGER =
      LoggerFactory.getLogger(TransactionHistoryMceDetailsRequestMapper.class);

  public FundsTransferDetailsRequest fundsTransferDetailsReqMapper(
      ApiRequestHeader apiRequestHeader, TransactionHistoryDomainRequest request) {
    LOGGER.info("SavingAccountDomainMceRequestMapper",
        Constant.getConsumerUniqueReferenceId(apiRequestHeader),
        "start of  Mce request mapper Method", "");
    FundsTransferDetailsRequest fundsTransferDetailsRequest = new FundsTransferDetailsRequest();
    fundsTransferDetailsRequest.setApiRequestHeader(apiRequestHeader);
    fundsTransferDetailsRequest.setTrxReferenceNumber(request.getTransactionRefNumber());
    fundsTransferDetailsRequest.setLockRequired(request.getFilterCriteria());
    LOGGER.info("TransactionHistoryMceDetailsRequestMapper",
        Constant.getConsumerUniqueReferenceId(apiRequestHeader), "MCE request mapper Method",
        fundsTransferDetailsRequest.toString());
    return fundsTransferDetailsRequest;
  }

}
