package com.absa.amol.saving.service;

import com.absa.amol.saving.model.standinginstruction.retrieve.StandingInstructionsRetReq;
import com.absa.amol.saving.model.standinginstruction.retrieve.StandingInstructionsRetRes;
import com.absa.amol.util.model.ResponseEntity;

public interface RetrieveStandingInstructionsService {
	ResponseEntity<StandingInstructionsRetRes> retrieveStandingInstructions(StandingInstructionsRetReq standingInstructionsRetReq);
}