package com.absa.amol.saving.service.impl.purchasemv;

import java.util.Random;

import javax.inject.Inject;

import org.eclipse.microprofile.rest.client.inject.RestClient;

import com.absa.amol.saving.builder.PurchaseMvClientBuilder;
import com.absa.amol.saving.builder.PurchaseMvSignInClientBuilder;
import com.absa.amol.saving.mapper.purchasemv.PurchaseMvSysReqMapper;
import com.absa.amol.saving.model.purchasemv.PaymentPurposeRes;
import com.absa.amol.saving.model.purchasemv.PaymentTransactionRes;
import com.absa.amol.saving.model.purchasemv.PurchaseMvReqWrapper;
import com.absa.amol.saving.model.purchasemv.PurchaseMvRes;
import com.absa.amol.saving.model.sys.purchasemv.CashServiceMvPurchaseReq;
import com.absa.amol.saving.model.sys.purchasemv.CashServiceMvPurchaseRes;
import com.absa.amol.saving.model.sys.purchasemv.CashServiceMvSignInReq;
import com.absa.amol.saving.model.sys.purchasemv.CashServiceMvSignInRes;
import com.absa.amol.saving.service.purchasemv.PurchaseMvService;
import com.absa.amol.saving.service.purchasemv.PurchaseMvValidatorService;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.exception.ApiException;
import com.absa.amol.util.exception.ApiRequestException;
import com.absa.amol.util.exception.ApiResponseException;
import com.absa.amol.util.exception.SORSystemServiceUnavailableException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ResponseEntity;
import com.absa.amol.util.utility.CommonUtil;

public class PurchaseMvServiceImpl implements PurchaseMvService {


	private static final Logger LOGGER = LoggerFactory.getLogger(PurchaseMvServiceImpl.class);

	@Inject
	@RestClient
	private PurchaseMvSignInClientBuilder signInClientBuilder;

	@Inject
	@RestClient
	private PurchaseMvClientBuilder purchaseMvClientBuilder;

	@Inject 
	private PurchaseMvSysReqMapper requestMapper;

	@Inject
	private PurchaseMvValidatorService validatorService;

	@Override
	public ResponseEntity<PurchaseMvRes> moneyVoucherPurchase(PurchaseMvReqWrapper requestWrapper) {
		final String METHOD_NAME = "moneyVoucherPurchase";
		String consumerUniqRefId = requestWrapper.getApiRequestHeader().getConsumerUniqueReferenceId();
		LOGGER.info(METHOD_NAME, consumerUniqRefId, "Inside Method", Constant.BLANK);
		ResponseEntity<PurchaseMvRes> purchaseRes = null;
		PurchaseMvRes purchaseMvRes = null;

		try {
			validatorService.validateInputRequest(requestWrapper);
			CashServiceMvSignInReq cashServiceMvSignInReq = new CashServiceMvSignInReq();
			String operationId = randomOperationIdGen();
			cashServiceMvSignInReq.setOperationId(operationId);
			requestWrapper.setOperationId(operationId);
			LOGGER.info(METHOD_NAME, consumerUniqRefId, "Operation Id generated ", operationId);
			ResponseEntity<CashServiceMvSignInRes> signInSysAdptrRes = signInClientBuilder.signInStatus(requestWrapper.getApiRequestHeader(), cashServiceMvSignInReq);

			if (CommonUtil.isNotNull(signInSysAdptrRes.getData()) && Constant.SUCCESS_CODE.equals(signInSysAdptrRes.getCode())) {
				CashServiceMvSignInRes cashServiceMvSignInRes = signInSysAdptrRes.getData();

				if("00".equalsIgnoreCase(cashServiceMvSignInRes.getServiceResCode()) &&
						"Success".equalsIgnoreCase(cashServiceMvSignInRes.getServiceResDesc())) {
					LOGGER.info(METHOD_NAME, consumerUniqRefId, "Sign in successfull", "Going to call purchase system adapter");
					CashServiceMvPurchaseReq cashServiceMvPurchaseReq = requestMapper.purchaseSysReqMapping(requestWrapper);
					ResponseEntity<CashServiceMvPurchaseRes> purchaseSysAdptrRes = purchaseMvClientBuilder.purchaseMoneyVoucher(
							requestWrapper.getApiRequestHeader(), cashServiceMvPurchaseReq);

					if (CommonUtil.isNotNull(purchaseSysAdptrRes.getData()) && Constant.SUCCESS_CODE.equals(purchaseSysAdptrRes.getCode())) {
						LOGGER.info(METHOD_NAME, consumerUniqRefId, "Purchase successfull", "Going to map the response");
						CashServiceMvPurchaseRes cashServiceMvPurchaseRes = purchaseSysAdptrRes.getData();
						purchaseMvRes = new PurchaseMvRes();
						PaymentTransactionRes paymentTransactionRes = new PaymentTransactionRes();
						PaymentPurposeRes paymentPurposeRes = new PaymentPurposeRes();
						paymentPurposeRes.setVoucherId(cashServiceMvPurchaseRes.getVoucherId());
						paymentTransactionRes.setPaymentPurposeRes(paymentPurposeRes);
						purchaseMvRes.setPaymentTransactionRes(paymentTransactionRes);
						purchaseMvRes.setOperationId(requestWrapper.getOperationId());
						purchaseRes = new ResponseEntity<>(purchaseSysAdptrRes.getCode(),
								purchaseSysAdptrRes.getMessage(), purchaseSysAdptrRes.getStatus(), purchaseMvRes);
						LOGGER.info(METHOD_NAME, consumerUniqRefId, "Response mapping success", Constant.BLANK);
					} else {
						LOGGER.info(METHOD_NAME, consumerUniqRefId, "data field is null or empty for purchase system adapter", Constant.BLANK);
						purchaseRes = new ResponseEntity<>(purchaseSysAdptrRes.getCode(),
								purchaseSysAdptrRes.getMessage(), purchaseSysAdptrRes.getStatus(), purchaseMvRes);
					}
				} else {
					LOGGER.info(METHOD_NAME, consumerUniqRefId, "Sign in failed", Constant.BLANK);
					LOGGER.info(METHOD_NAME, consumerUniqRefId, "Purchase system adapter not called.", Constant.BLANK);
					purchaseRes = new ResponseEntity<>(signInSysAdptrRes.getCode(),
							"Sign in failed for purchase money voucher", signInSysAdptrRes.getStatus(), purchaseMvRes);
				}
			} else {
				LOGGER.info(METHOD_NAME, consumerUniqRefId, "data field is null or empty for sign in system adapter", Constant.BLANK);
				LOGGER.info(METHOD_NAME, consumerUniqRefId, "Purchase system adapter not called.", Constant.BLANK);
				purchaseRes = new ResponseEntity<>(signInSysAdptrRes.getCode(),
						signInSysAdptrRes.getMessage(), signInSysAdptrRes.getStatus(), purchaseMvRes);
			}
		} catch (SORSystemServiceUnavailableException ex) {
			LOGGER.error(METHOD_NAME, consumerUniqRefId, "System adapter is unavailable",ex.getErrorMessage());
			LOGGER.debug(METHOD_NAME, consumerUniqRefId, "System adapter is unavailable - Debug", ex);
			throw new SORSystemServiceUnavailableException(Constant.FIVE_O_THREE, ex.getErrorMessage());
		} catch (ApiRequestException ex) {
			LOGGER.error(METHOD_NAME, consumerUniqRefId, "ApiRequestException occured for money voucher purchase", ex.getErrorMessage());
			LOGGER.debug(METHOD_NAME, consumerUniqRefId, "ApiRequestException occured for money voucher purchase- Debug", ex);
			throw new ApiRequestException(ex.getErrorCode(), ex.getErrorMessage());
		} catch (ApiException ex) {
			LOGGER.error(METHOD_NAME, consumerUniqRefId, "ApiException occured for money voucher purchase", ex.getMessage());
			LOGGER.debug(METHOD_NAME, consumerUniqRefId, "ApiException occured for money voucher purchase- Debug", ex);
			throw new ApiResponseException(ex.getErrorCode(), ex.getErrorMessage());
		} catch (Exception ex) {
			LOGGER.error(METHOD_NAME, consumerUniqRefId, "Exception occured for money voucher purchase", ex.getMessage());
			LOGGER.debug(METHOD_NAME, consumerUniqRefId, "Exception occured for money voucher purchase- Debug", ex);
			throw new ApiResponseException(Constant.INTERNAL_ERROR_CODE, Constant.INTERNAL_ERROR_MSG);
		}
		return purchaseRes;

	}
	
	private String randomOperationIdGen() {
		String salt = "12345678901234567890";
		StringBuilder op_id = new StringBuilder();
		Random rnd = new Random();
		while (op_id.length() < 10) {
			int index = (int) (rnd.nextFloat() * salt.length());
			op_id.append(salt.charAt(index));
		}
		return op_id.toString();
	}

}
