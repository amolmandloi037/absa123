package com.absa.amol.saving.model.orderpaperstmt;

import javax.json.bind.annotation.JsonbNillable;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonbNillable
public class OrderPaperStmtResponse {
  private Status status;
}
