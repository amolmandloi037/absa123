package com.absa.amol.saving.model.sys.accountsnickname.add;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AddAccountsNickNameSystemMceRequest {
	
	private String scvID;
	
	private List<CustomerAccountDet> customerAccountList;
	
}
