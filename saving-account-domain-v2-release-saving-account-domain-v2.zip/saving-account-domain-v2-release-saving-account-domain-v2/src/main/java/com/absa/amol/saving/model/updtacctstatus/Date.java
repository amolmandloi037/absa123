package com.absa.amol.saving.model.updtacctstatus;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Date {

	private String contactStatusDate;
	
}
