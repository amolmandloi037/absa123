package com.absa.amol.saving.util.bankersnotes;

import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.utility.CommonUtil;

public class CreditCardTransactionConstant {

	public static final String BAD_REQUEST_CODE = "400";
	public static final String ERROR_CODE = "500";
	
	public static final String SUCCESS_MESSAGE = "Success"; 
	
	
	public static final long FALLBACK_TIMEOUT = 10000;

	public static final String FALLBACK_METHOD_FOR_TIMEOUT = "fallbackForTimeout";

	public static final String FAILURE_MSG = "Failure";
	public static final String TIMEOUT_CODE = "504";
	
	public static final String VALIDATE_REQUEST = "validateRequest";
	
	
	
	public static final String GET_TRANSACTION_HISTORY_RESPONSE = "retrievePostedTransactionDetails";
	public static final String EXCEPTION_OCCURED_FROM_SERVER =
		      "exception occured while invoking system service";
	

	
	public static final String CONT_POSTED_METHOD_NAME = "getPostedTransactionDetails";
	public static final String CONFIG_SOURCE_NAME = "FileSystemConfigSource";
	
	public static final String getCorrelationId(ApiRequestHeader requestHeader) {
		if (CommonUtil.isNotNull(requestHeader) && CommonUtil.isNotNull(requestHeader.getCorrelationId())) {
			return requestHeader.getCorrelationId();
		}
		return "";
	}
	
	public static String fillZeros(String accNumber) {
		return String.format("%19s", accNumber).replace(" ", "0");
	}
	
	public static String StringfillZerosForNumOfMonths(String numOfMonths) {
		return String.format("%2s", numOfMonths).replace(" ", "0");
	}
	
}
