package com.absa.amol.saving.service;

import javax.ws.rs.core.Response;

import com.absa.amol.saving.model.SavingAccountArrangementRequest;

public interface SavingsAccountUpdateService {
	
	public Response updateAccountArrangement(SavingAccountArrangementRequest request);

}
