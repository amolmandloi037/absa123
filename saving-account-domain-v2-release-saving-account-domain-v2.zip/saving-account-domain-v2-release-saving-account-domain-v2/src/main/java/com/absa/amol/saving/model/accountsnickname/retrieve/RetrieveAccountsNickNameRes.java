package com.absa.amol.saving.model.accountsnickname.retrieve;

import java.util.List;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(name = "RetrieveAccountsNickNameRes", description = "Domain Response Schema to retrieve account Nickname details")
public class RetrieveAccountsNickNameRes {

	List<CustomerAccount> customerAccountList;
	 
}
