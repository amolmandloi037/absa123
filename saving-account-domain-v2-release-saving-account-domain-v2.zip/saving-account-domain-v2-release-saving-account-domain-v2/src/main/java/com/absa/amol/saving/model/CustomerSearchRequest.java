package com.absa.amol.saving.model;

import javax.ws.rs.BeanParam;
import javax.ws.rs.QueryParam;
import com.absa.amol.util.model.ApiRequestHeader;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CustomerSearchRequest {

  @BeanParam
  ApiRequestHeader apiRequestHeader;

  @QueryParam("branchCode")
  private String branchCode;

  // ***** accountNumber ***** //
  @QueryParam("productInstanceReference")
  private String productInstanceReference;
}
