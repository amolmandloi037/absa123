package com.absa.amol.saving.service.unclearedfund;

import javax.ws.rs.core.Response;

import com.absa.amol.saving.model.unclearedfund.UnclearFundDetailsRequest;

public interface UnclearedFundService {

	Response retrieveUnclearedFund(UnclearFundDetailsRequest unclearFundDetailsRequest);
}
