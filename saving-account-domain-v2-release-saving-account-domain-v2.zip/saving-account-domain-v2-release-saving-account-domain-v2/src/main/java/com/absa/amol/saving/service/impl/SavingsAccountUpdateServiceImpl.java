package com.absa.amol.saving.service.impl;

import javax.inject.Inject;
import javax.ws.rs.core.Response;

import org.eclipse.microprofile.rest.client.inject.RestClient;

import com.absa.amol.saving.mapper.SavingsAccountUpdateRequestMapper;
import com.absa.amol.saving.model.AccountArrangementRequest;
import com.absa.amol.saving.model.ArrangementResponse;
import com.absa.amol.saving.model.SavingAccountArrangementRequest;
import com.absa.amol.saving.service.SavingsAccountUpdateService;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.saving.util.SavingsAccountUpdateClient;
import com.absa.amol.util.model.ResponseEntity;



public class SavingsAccountUpdateServiceImpl implements SavingsAccountUpdateService{
	
	@Inject
	@RestClient
	SavingsAccountUpdateClient updateClient;
	
	@Inject
	SavingsAccountUpdateRequestMapper requestMapper;
	
	public Response updateAccountArrangement(SavingAccountArrangementRequest domainRequest) {
		AccountArrangementRequest request = requestMapper.accountUpdateReqMapper(domainRequest);
		ResponseEntity<ArrangementResponse> responseEntity = updateClient.updateAccountArrangement(request.getApiRequestHeader(), request);
		if (responseEntity.getCode().equals(Constant.SUCCESS_CODE)) {
			return Response.ok(responseEntity).build();
		} else if(responseEntity.getCode().equals(Constant.BAD_REQUEST_CODE)) {
			 return Response.status(Response.Status.BAD_REQUEST).entity(responseEntity)
			          .type("application/json").build();
		} else {
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(responseEntity)
			          .type("application/json").build();
		}
	}

}
