package com.absa.amol.saving.service.impl;

import javax.inject.Inject;
import javax.ws.rs.core.Response;

import org.eclipse.microprofile.rest.client.inject.RestClient;

import com.absa.amol.saving.builder.AcctPendingEntriesClientBuilder;
import com.absa.amol.saving.mapper.AcctPendingEntriesBrainsMapper;
import com.absa.amol.saving.mapper.EarmarkRequestMapper;
import com.absa.amol.saving.model.acctearmarkpendingentries.AcctEarmarkPendingEntriesDomainRequest;
import com.absa.amol.saving.model.acctearmarkpendingentries.AcctEarmarkPendingEntriesListResponse;
import com.absa.amol.saving.model.sys.acctearmark.AcctEarmarkSystemAdapterRes;
import com.absa.amol.saving.model.sys.pendingentries.AcctPendingEntriesSystemList;
import com.absa.amol.saving.model.sys.pendingentries.AcctPendingEntriesSystemReq;
import com.absa.amol.saving.service.AccountEarmarkPendingEntriesService;
import com.absa.amol.saving.util.AccountEarmarkClient;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.exception.ApiException;
import com.absa.amol.util.exception.ApiResponseException;
import com.absa.amol.util.exception.SORSystemServiceUnavailableException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ResponseEntity;
import com.absa.amol.util.utility.CommonUtil;

public class AccountEarmarkPendingEntriesServiceImpl implements AccountEarmarkPendingEntriesService {

	@Inject @RestClient AccountEarmarkClient accountEarmarkclientBuilder;

	@Inject
	AcctPendingEntriesClientBuilder pendingEntriesClientBuilder;

	@Inject
	EarmarkRequestMapper earmarkRequestMapper;
	@Inject
	AcctPendingEntriesBrainsMapper pendingEntriesMapper;
	private static final Logger LOGGER = LoggerFactory.getLogger(AccountEarmarkPendingEntriesServiceImpl.class);

	@Override
	public Response getEarmarkPendingEntriesList(AcctEarmarkPendingEntriesDomainRequest acctEarmarkPendingEntriesDomainRequest) {
		String method = "getEarmarkPendingEntriesList";
		String uniqueRefId = null;
		Response response = null;
		ResponseEntity<AcctEarmarkSystemAdapterRes> acctEarmarkSystemAdapterRes = null;
		ResponseEntity<AcctEarmarkPendingEntriesListResponse> acctEarmarkListPendingEntriesResponse =null;
		try {
			uniqueRefId = acctEarmarkPendingEntriesDomainRequest.getApiRequestHeader().getConsumerUniqueReferenceId();
			LOGGER.info(method, uniqueRefId, "message", "**-- inside accountEarmarkImpl --**");
			if("E".equalsIgnoreCase(acctEarmarkPendingEntriesDomainRequest.getRequestFlag())) {
				acctEarmarkSystemAdapterRes = accountEarmarkclientBuilder.getEarmarklist(earmarkRequestMapper.mapRequest(acctEarmarkPendingEntriesDomainRequest));
				acctEarmarkListPendingEntriesResponse = earmarkRequestMapper.mapResponse(acctEarmarkSystemAdapterRes);

			}else if("P".equalsIgnoreCase(acctEarmarkPendingEntriesDomainRequest.getRequestFlag())) {
				AcctPendingEntriesSystemReq acctPendingEntriesSystemReq = pendingEntriesMapper.acctPendingEntrReqMapping(acctEarmarkPendingEntriesDomainRequest);
				ResponseEntity<AcctPendingEntriesSystemList> systemRespEntity = pendingEntriesClientBuilder.retrieveAccountPendingEntriesList(acctPendingEntriesSystemReq);
				acctEarmarkListPendingEntriesResponse = pendingEntriesMapper.acctPendingEntrResMapping(systemRespEntity);
			}
			if (CommonUtil.isNotNull(acctEarmarkListPendingEntriesResponse)) {
				response=Response.status(Constant.SUCCESS).entity(acctEarmarkListPendingEntriesResponse).build();
			}

		}
		catch (SORSystemServiceUnavailableException ex) {
			LOGGER.error(method, uniqueRefId, "Account Earmark System Adapter is unavailable",ex.getErrorMessage());
			LOGGER.debug(method, uniqueRefId, "Account Earmark System Adapter is unavailable- Debug", ex);
			throw new SORSystemServiceUnavailableException(Constant.DOWNSTREAM_UNAVAILABLE, ex.getErrorMessage());
		}
		catch (ApiException apiException) {
			LOGGER.error(method, uniqueRefId, "ApiException", apiException.getMessage());
			LOGGER.debug(method, uniqueRefId, "ApiException Occurred", apiException);
			throw apiException;
		} catch (Exception exception) {
			LOGGER.error(method, uniqueRefId, "Exception", exception.getMessage());
			LOGGER.debug(method, uniqueRefId, "Exception Occurred", exception);
			throw new ApiResponseException(Constant.INTERNAL_ERROR_CODE, Constant.INTERNAL_ERROR_MSG);
		}

		return response;
	}
}