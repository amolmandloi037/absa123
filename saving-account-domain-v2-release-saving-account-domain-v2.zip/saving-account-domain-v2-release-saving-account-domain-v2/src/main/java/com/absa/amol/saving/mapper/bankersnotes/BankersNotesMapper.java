package com.absa.amol.saving.mapper.bankersnotes;

import com.absa.amol.saving.model.bankersnotes.AccountNotes;
import com.absa.amol.saving.model.bankersnotes.AccountNotesSystemResponse;
import com.absa.amol.saving.model.bankersnotes.BankersNotesDomainRequest;
import com.absa.amol.saving.model.bankersnotes.BankersNotesSystemRequest;
import com.absa.amol.util.utility.StringUtil;

public class BankersNotesMapper {
	
	public BankersNotesSystemRequest mapBankersNotesRequestDomainToSystem( BankersNotesDomainRequest bankersNotesDomainRequest) {
		BankersNotesSystemRequest systemRequest = new BankersNotesSystemRequest();
		systemRequest.setApiRequestHeader(bankersNotesDomainRequest.getApiRequestHeader());
		systemRequest.setAccountNumber(bankersNotesDomainRequest.getSavingAccountNumber());
		if(StringUtil.isStringNotNullAndNotEmpty(bankersNotesDomainRequest.getBranchCode())) {
			systemRequest.setBranchCode(bankersNotesDomainRequest.getBranchCode());
		}
	
		return systemRequest;
	}
	
	public AccountNotes mapBrainsResToDomainRes(AccountNotesSystemResponse sysResponse ) {
		
		
		AccountNotes accountNotes = new AccountNotes();
		
		if(StringUtil.isStringNotNullAndNotEmpty(sysResponse.getSavingsAccountNumber()) ||StringUtil.isStringNotNullAndNotEmpty(sysResponse.getMemoType()) )
		{
			accountNotes.setLastMaintanenceDate(sysResponse.getLastMaintanenceDate());
			accountNotes.setMemoText(sysResponse.getMemoText());
			accountNotes.setMemoType(sysResponse.getMemoType());
			accountNotes.setSavingsAccountNumber(sysResponse.getSavingsAccountNumber());
			accountNotes.setSeverity(sysResponse.getSeverity());
		}
		else {
			String str =  String.join(" ",sysResponse.getNotesLine1() , sysResponse.getNotesLine2(), sysResponse.getNotesLine3() );
			
			if(StringUtil.isStringNullOrEmpty(str)) {
				str = "";
			}
			accountNotes.setMemoText(str);
		}
		
		return accountNotes;
		
	}
}
