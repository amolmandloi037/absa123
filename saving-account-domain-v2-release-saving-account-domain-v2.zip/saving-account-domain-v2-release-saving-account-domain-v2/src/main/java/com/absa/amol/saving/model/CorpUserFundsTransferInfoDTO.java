package com.absa.amol.saving.model;

import java.util.List;
import java.util.Map;

import javax.json.bind.annotation.JsonbNillable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonbNillable
public class CorpUserFundsTransferInfoDTO {

  private String entityBankCIF;
  private String customerNumber;
  private String fundsTransferType;
  private AccountDTO creditAccount;
  private AccountDTO debitAccount;
  private Double debitAmount;
  private Double creditAmount;
  private String customerFullName;
  private String transactionStatus;
  private String trxReferenceNumber;
  private String trxSequenceNumber;
  private String remarks;
  private String txnBeneficiaryName;
  private String authMobileIndicator;
  private String authLevel;
  private String initiatedBy;
  private String initiatedDateTime;
  private List<CorpUserAuthDetailsDTO> corpUserAuthDetailsList;
  private Map<String, Object> corpUserOtherTxnDetails;
}
