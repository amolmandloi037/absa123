package com.absa.amol.saving.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ArrangementResponse {


  private String accountStatus;
  private String advanceClassification;
  private String bicCode;
  private String referStream;
  private String marketSegment;
  private String accountMigration;
  private String atmIndicator;
  private String mailingAddress;
  private String acctModification;
  private String loanRestucturing;
  private String additionOfCallback;
  private String amendmentCreditDebit;
  private String stopChequeStatus;
  private String realignment;
  private String unclearedEffects;
  private String interestFieldAmendment;


  private boolean isAccountStatusUpdated;
  private boolean isAdvanceClassificationUpdated;
  private boolean isBicCodeUpdated;
  private boolean isReferStreamUpdated;
  private boolean isMarketSegmentUpdated;
  private boolean isAccountMigrated;
  private boolean isAtmIndicatorUpdated;
  private boolean isMailingAddressUpdated;
  private boolean isAdditionOfCallbackUpdated;
  private boolean isAccountModified;
  private boolean isLoanRestuctured;
  private boolean isStoppedChequeUpdated;
  private boolean isCreditDebitAmendment;
  private boolean isRealignmentUpdated;
  private boolean isUnclearedEffectUpdated;
  private boolean isInterestFieldAmendmentUpdated;

}
