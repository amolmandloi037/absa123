package com.absa.amol.saving.builder;

import javax.ws.rs.BeanParam;
import javax.ws.rs.POST;

import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import com.absa.amol.saving.model.sys.chequebook.ChequeBookReq;
import com.absa.amol.saving.model.sys.chequebook.ChequeBookRes;
import com.absa.amol.saving.util.ServerSideExceptionMapper;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.model.ResponseEntity;

@RegisterRestClient(configKey = "cheque.book.sys.url")
@RegisterProvider(value = ServerSideExceptionMapper.class)
public interface ChequeBookRequestClientBuilder {
	
	@POST
	ResponseEntity<ChequeBookRes> addChequeBookRequest(@RequestBody ChequeBookReq chequeBookEboxReq,@BeanParam ApiRequestHeader apiRequestHeader);

}
