package com.absa.amol.saving.model.bankersnotes;

import javax.validation.Valid;
import javax.ws.rs.BeanParam;
import javax.ws.rs.QueryParam;

import com.absa.amol.util.model.ApiRequestHeader;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor

public class BankersNotesSystemRequest {
	@Valid
	@BeanParam
	private ApiRequestHeader apiRequestHeader;

	
	@QueryParam("accountNumber")
	private String accountNumber;

	@QueryParam("branchCode") private String branchCode;

}
