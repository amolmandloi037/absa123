package com.absa.amol.saving.model.standinginstruction.singledetail;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(name = "StandingInstructionSingleDetailResponse", description = "Response Schema for Single Standing Instruction API")
public class StandingInstructionSingleDetailResponse 
{ 
  private PaymentScheduleSingleDetailResp paymentSchedule;
  
  private String accountNumber; //earlier Integer
  
  private Integer bankBranchLocRef; //ebox
  
  private String transferChannel;
  
  private PaymentTransactionSingleDetailResp paymentTransaction;
  
  private StandingOrderReferenceSingleDetailResp standingOrderReference;
  
  private String paymentType; //FCR //earlier PaymentType.siType
 
}
