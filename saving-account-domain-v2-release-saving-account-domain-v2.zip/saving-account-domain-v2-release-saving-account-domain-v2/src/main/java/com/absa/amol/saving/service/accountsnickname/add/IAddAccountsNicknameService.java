package com.absa.amol.saving.service.accountsnickname.add;

import com.absa.amol.saving.model.accountsnickname.add.AddAccountsNickNameReq;
import com.absa.amol.saving.model.accountsnickname.add.AddAccountsNickNameRes;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.model.ResponseEntity;

public interface IAddAccountsNicknameService {

	ResponseEntity<AddAccountsNickNameRes> addUpdateAccountNickname(ApiRequestHeader requestHeader, AddAccountsNickNameReq addAccountsNickNameReq);

}
