package com.absa.amol.saving.model.updtacctstatus;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BankBranch {

	@Schema(description = "Mandatory field", pattern = "Numeric", maxLength = 3, required = true)
	@NotNull(message = "branchNumber.notnullempty.error.message")
	@NotEmpty(message = "branchNumber.notnullempty.error.message")
	@Pattern(regexp="[0-9]{1,3}", message="branchNumber.regex.error.message")
	private String branchNumber;
	
	@Schema(description = "Optional field", pattern = "Numeric", maxLength = 3, required = false)
	@Pattern(regexp="[0-9]{1,3}?|", message="contactBranch.regex.error.message")
	private String contactBranch;
	
}
