package com.absa.amol.saving.util;

import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import javax.ws.rs.BeanParam;
import javax.ws.rs.GET;

import com.absa.amol.saving.model.standinginstruction.singledetail.StandingInstructionSingleDetailRequest;
import com.absa.amol.saving.model.standinginstruction.singledetail.StandingInstructionSingleDetailResponse;
import com.absa.amol.util.model.ResponseEntity;

@RegisterRestClient(configKey = "saving.account.singleStandingInstruction.url")
@RegisterProvider(value = ServerSideExceptionMapper.class)
public interface IStandingInstructionSingleDetailClientBuilder
{
	@GET
	public ResponseEntity<StandingInstructionSingleDetailResponse> getSingleStandingInstruction(@BeanParam StandingInstructionSingleDetailRequest singleSIReq);
}
