package com.absa.amol.saving.model;

import javax.json.bind.annotation.JsonbNillable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonbNillable
public class CorpUserAuthDetailsDTO {

	private String authorizedBy;
    private String authorizerName;
    private String authorizedDateTime;
    private String decision;
    private String remarks;
}
