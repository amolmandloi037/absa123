package com.absa.amol.saving.model.standinginstruction.mod;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentPurposeModReq {

	private String narrative;

	private String benAddNarrative;
	private String benNarrative;

	private String benRegionCode;
	private String remAddNarrative;
	private String remNarrative;

}
