package com.absa.amol.saving.model.unclearedfund;

import java.math.BigDecimal;
import java.util.List;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Schema(name = "UnclearFundDetailsResponse", description = "Response Schema for Unclear Fund Details")
public class UnclearFundDetailsResponse {

	private String accountNumber;
	private String branchCode;
	private String transferreferenceID;
	private String transferID;
	private BigDecimal currentBalance;
	private BigDecimal availableBalance;
	private BigDecimal currentEARBalance;
	private BigDecimal currentUnclearBalance;
	private BigDecimal debitLimit;
	private BigDecimal futureBalanceDay1Amt;
	private String futureBalanceDate1;
	private BigDecimal futureBalanceDay2Amt;
	private String futureBalanceDate2;
	private BigDecimal futureBalanceDay3Amt;
	private String futureBalanceDate3;
	@Schema(description = "Retrun List of uncleared fund details")
	private List<UnclearedFundDetails> unclearedFundDetails;

}
