package com.absa.amol.saving.service.chequebook;

import com.absa.amol.saving.model.chequebook.ChequeBookDomainReqWrapper;

public interface ICustContactHistoryService {

	public void addCustContactHistory(ChequeBookDomainReqWrapper chequeBookDomainReqWrapper);
}
