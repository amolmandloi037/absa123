package com.absa.amol.saving.model;

import java.math.BigDecimal;
import java.util.List;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
@Schema(name = "SavingAccountDetailsResponse",
    description = "Response Schema To Get Saving Account Details")
public class SavingAccountDetailsResponse {

  private String customerNumber;
  private String accountNumber;
  private String accountCurrency;
  private String accountTitle;
  private Integer productCode;
  private String productTypeCode;
  private String productName;
  private AccountStatus accountStatus;
  private BigDecimal availableBalance;
  private BigDecimal currentBalance;
  private String branchCode;
  private String branchName;
  private String branchShortName;
  private List<DateType> dateType;
  private List<InterestAccrualType> interestAccrualType;
  private List<IssuedInventoryPropertyType> issuedInventoryPropertyType;
  private String nomineeName;
  private String languageCode;
  private CustomerReference customerReference;
  private RestrictionOptionSetting restrictionOptionSetting;
  private Boolean staffFlag;
  private String nib;
  private TaxReference taxReference;
  private ArrangementOption arrangementOption;
  private String ibanAccountNumber;
  private Integer lineNumber;
  private String passbookLifecycleStatusCode;
  private BigDecimal totalUnclearFundAmount;
  private Double advanceAgainstUnclearedFunds;
  private Double totalCASAHoldAmount;
  private BigDecimal authorisedDebitAmount;
  private BigDecimal minimumRequiredBalanceAmount;
  private Double minimumRequiredTradingBalanceAmount;
  private BigDecimal netBalanceAmount;
  private BigDecimal netAvailableBalanceForWithdrawal;
  private BigDecimal confirmationAmount;
  // private BigDecimal currentBookBalanceAmount;
  private BigDecimal previousDayClosingBookBalance;
  private BigDecimal sweepinAmountOnLien;
  private BigDecimal periodicAverageBalanceAmount;
  private Double balanceAmountAsOfLastCreditCap;
  private Double balanceAmountAsOfLastDebitCap;
  private Double debitsMonthTillDateAmount;
  private Double debitsYearTillDateAmount;
  private Integer mtdDebitsCount;
  private Integer ytdDebitsCount;
  private Double ytdDebitsLastAmount;
  private Double creditsMonthTillDateAmount;
  private Integer mtdCreditsCount;
  private Integer ytdCreditsCount;
  private Double ytdCreditLastAmount;
  private String address1;
  private String address2;
  private String address3;

  private String marketSegment;
  private String marketSegmentDesc;
  private String referCode;
  private String propositionTypeCode;
}
