package com.absa.amol.saving.model.standinginstruction.add;

import java.math.BigDecimal;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentScheduleAddReq {

	private BigDecimal firstPaymentAmount;
	
	private BigDecimal lastPaymentAmount;
	
	@Schema(description = "Conditional mandatory.",format = "yyyy-MM-ddTHH:mm:ss.SSSZ", required = true)
	private String nextExecutionDate;
	
	
	private Integer dayOfTheMonth;
	
	@Schema(description = "Conditional mandatory.",format = "yyyy-MM-ddTHH:mm:ss.SSSZ", required = true)
	private String endDate;
	
	@Schema(description = "Conditional mandatory" ,required = true)
	private String frequency;
	
	private String lastRetryDate;
	
	@Schema(description = "Field is mandatory for all flows.",format = "yyyy-MM-ddTHH:mm:ss.SSSZ", required = true)
	private String startDate;
	
	@Schema(description = "Conditional mandatory" ,required = true)
	private Integer paymentDurationType;

}
