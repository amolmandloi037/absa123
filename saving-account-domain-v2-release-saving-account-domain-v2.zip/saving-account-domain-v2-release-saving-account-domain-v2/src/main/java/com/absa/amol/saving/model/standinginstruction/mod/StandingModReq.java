package com.absa.amol.saving.model.standinginstruction.mod;

import javax.validation.Valid;

import javax.ws.rs.BeanParam;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import com.absa.amol.util.model.ApiRequestHeader;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StandingModReq {

	@BeanParam
	@Schema(hidden = true)
	@Valid
	private ApiRequestHeader apiRequestHeader;

	private String accountNumber;

	private String accountSweepAmount;

	private String branchCode;

	@Valid
	private AccountSweepConfigModReq accountSweepConfig;

	private String accountSweepType;

	private Integer accountType;

	private Integer bankBranch;

	@Valid
	private PaymentScheduleModReq paymentSchedule;

	@Valid
	private PaymentTransactionModReq paymentTransaction;

	private String paymentType;

	@Valid
	private StandingOrderReferenceModReq standingOrderReference;

}
