package com.absa.amol.saving.model.orderdebitcard;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class IssuedDevicePropertyValue {
	
	@Schema(description = "Field is mandatory.", pattern = "Only numeric", maxLength = 16, required = true)
	@NotEmpty(message = "orderdebitcard.cardNumber.nullorempty.error.message")
	@NotNull(message = "orderdebitcard.cardNumber.nullorempty.error.message")
	@Size(max = 16, message = "orderdebitcard.cardNumber.length.error.message")
	@Pattern(regexp="[0-9]*", message="orderdebitcard.cardNumber.regex.error.message")
	private String cardNumber;
	
	@Schema(description = "Field is mandatory.", maxLength = 26, required = true)
	@NotEmpty(message = "orderdebitcard.embrossedName.nullorempty.error.message")
	@NotNull(message = "orderdebitcard.embrossedName.nullorempty.error.message")
	@Size(max = 26, message = "orderdebitcard.embrossedName.length.error.message")
	private String embrossedName;

}
