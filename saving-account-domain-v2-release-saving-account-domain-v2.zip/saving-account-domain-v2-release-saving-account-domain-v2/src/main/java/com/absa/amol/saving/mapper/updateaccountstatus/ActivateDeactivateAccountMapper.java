package com.absa.amol.saving.mapper.updateaccountstatus;

import com.absa.amol.saving.model.sys.actdctaccount.AccountStatusSystemReq;
import com.absa.amol.saving.model.sys.actdctaccount.AccountStatusSystemRes;
import com.absa.amol.saving.model.sys.actdctaccount.MessagesSys;
import com.absa.amol.saving.model.updateaccountstatus.UpdateAccountStatusDomainReq;
import com.absa.amol.saving.model.updateaccountstatus.UpdateAccountStatusDomainReqWrapper;
import com.absa.amol.saving.model.updateaccountstatus.UpdateAccountStatusDomainRes;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.model.ResponseEntity;
import com.absa.amol.util.utility.CommonUtil;
import com.absa.amol.util.utility.StringUtil;

public class ActivateDeactivateAccountMapper {

	public AccountStatusSystemReq  getActDctAccRequest(UpdateAccountStatusDomainReqWrapper domainReqWrapper) {
		
		AccountStatusSystemReq statusSystemReq = new AccountStatusSystemReq();
		if(CommonUtil.isNotNull(domainReqWrapper) && CommonUtil.isNotNull(domainReqWrapper.getUpdateAccountStatusDomainReq())) {
			UpdateAccountStatusDomainReq domainReq = domainReqWrapper.getUpdateAccountStatusDomainReq();
			statusSystemReq.setAccounStatusIndicator(domainReq.getAccountStatus());
			statusSystemReq.setAccountId(domainReq.getSavingAccountNumber());
			statusSystemReq.setAccountTitle(domainReq.getAccountTitle());
			statusSystemReq.setBranchCode(domainReq.getBranchCode());
			statusSystemReq.setVerification(domainReq.getVerification());
			if(CommonUtil.isNotNull(domainReq.getAccountDetails())) {
				statusSystemReq.setPremierMembershipCentreCode(domainReq.getAccountDetails().getPremierMembershipCentreCode());
				statusSystemReq.setPremierMembershipFeeIndicator(domainReq.getAccountDetails().getPremierMembershipFeeIndicator());
			}
			
		}
		
		return statusSystemReq;
	}
	
	
	public  ResponseEntity<UpdateAccountStatusDomainRes>  getResponseStatus(ResponseEntity<AccountStatusSystemRes> systemResponse, String consumerUniqueId) {
		AccountStatusSystemRes accountStatusSystemRes =null;
		String msg = null;
		String statusMsg=Constant.SUCCESS_MESSAGE;
		String statusCode = Constant.SUCCESS_CODE;
		StringBuilder sb = new StringBuilder();
		if(CommonUtil.isNotNull(systemResponse) && CommonUtil.isNotNull(systemResponse.getData())) {
			 accountStatusSystemRes=systemResponse.getData();
			 if(Constant.REPLY_CODE_0.equals(accountStatusSystemRes.getReplyCode())) {
					msg = Constant.DATA_UPDATED_SUCCESS;
				}else if(Constant.REPLY_CODE_40.equals(accountStatusSystemRes.getReplyCode())){
					if(StringUtil.isStringNotNullAndNotEmpty(accountStatusSystemRes.getStatusDesc())) {
						sb.append(accountStatusSystemRes.getStatusDesc());
					}
					else {
						sb=	getMessage(accountStatusSystemRes);
					} 
					msg = sb.toString();
				}else {
					statusMsg= Constant.FAILURE_MSG;
					statusCode = Constant.BAD_REQUEST_CODE;
					if(StringUtil.isStringNotNullAndNotEmpty(accountStatusSystemRes.getStatusDesc())) {
						sb.append(accountStatusSystemRes.getStatusDesc());
					}
					else {
						sb=	getMessage(accountStatusSystemRes);
					}
					msg = sb.toString();
				}
		}
		UpdateAccountStatusDomainRes domainRes = new UpdateAccountStatusDomainRes();
		domainRes.setReferenceNumber(consumerUniqueId);
		return  new ResponseEntity<>(statusCode,msg,statusMsg,domainRes);
		
	}
	
	private StringBuilder getMessage(AccountStatusSystemRes systemResponseData) {
		 StringBuilder sb = new StringBuilder();
		if(CommonUtil.isNotNull(systemResponseData) &&
				CommonUtil.isNotNull(systemResponseData.getExtendedReply()) &&
				CommonUtil.isNotNull(systemResponseData.getExtendedReply().getMessages()) &&
				!systemResponseData.getExtendedReply().getMessages().isEmpty())
			sb.append(!systemResponseData.getExtendedReply().getMessages().isEmpty() ?
					systemResponseData.getExtendedReply().getMessages()
					.stream().map(MessagesSys::getMessage):"");
		return sb;
	}
}
