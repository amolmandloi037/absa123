package com.absa.amol.saving.model.standinginstruction.singledetail;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FeeDetailsSingleDetailResp 
{
	private String feeType; //FCR //hardcoded as SUCCESS or FAILURE
	
	private BigDecimal serviceFeeCharge; //FCR
}
