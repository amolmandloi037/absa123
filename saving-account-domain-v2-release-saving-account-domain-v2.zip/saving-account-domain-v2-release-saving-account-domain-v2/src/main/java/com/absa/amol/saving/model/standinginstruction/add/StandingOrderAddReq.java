package com.absa.amol.saving.model.standinginstruction.add;

import javax.validation.Valid;
import javax.ws.rs.BeanParam;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import com.absa.amol.util.model.ApiRequestHeader;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
@Schema(name = "StandingOrderAddReq", description = "Request Schema For Add Standing Instruction Domain API")
public class StandingOrderAddReq {
	
	@BeanParam
	@Schema(hidden = true)
	@Valid
	private ApiRequestHeader apiRequestHeader;
	
	@Schema(description = "Field is mandatory. For EBOX maxlength=7 and FCR maxlength=16", pattern = "[0-9]*",required = true)
	private String accountNumber;
	
	private String accountSweepAmount;
	private AccountSweepConfigAddReq accountSweepConfig;
	private String accountSweepType;
	private Integer accountType;
	
	@Schema(description = "Conditional mandatory. For EBOX maxlength=3 and FCR maxlength=5", pattern = "[0-9]*")
	private Integer bankBranch;
	
	
	@Schema(description = "Field is mandatory for all flows.", pattern = "[0-9]*", minLength = 1, maxLength = 12,required = true)
	private String customerReference;
	
	@Valid
	private PaymentScheduleAddReq paymentSchedule;
	
	@Valid
	private PaymentTransactionAddReq paymentTransaction;
	private String paymentType;
	
	@Valid
	private StandingOrderReferenceAddReq standingOrderReference;
	private CustomerReferenceAddReq customerRef;
	
	@Schema(hidden = true)
	private String eboxSysCustId;

}
