package com.absa.amol.saving.model.checkstatus;


import javax.json.bind.annotation.JsonbNillable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonbNillable
public class ChequeStatusModel {
	private String accountId;
	private Double  chequeAmount;
	private String  chequeStatus;
	private String customerShortName;
}
