package com.absa.amol.saving.model.standinginstruction.mod;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StandingOrderReferenceModReq {

	private Boolean forceDebitAllowedFlag;

	private String priority;

	private Integer standingOrderNumber;

	private Integer retryCount;

	private String noOfPayments;
	private BigDecimal terminationAmount;

	private String executionDate;

	private boolean calendarFlag;

	private String serviceChargeApplicableFlag;
}
