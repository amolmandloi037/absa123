package com.absa.amol.saving.model.demanddraft;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Schema(name="DemandDraftDomainRes", description=" Domain Response Schema for requesting a Demand Draft by using given Customer Number or Account Number")
public class DemandDraftDomainRes {
	
	private PaymentTransaction paymentTransaction;
}
