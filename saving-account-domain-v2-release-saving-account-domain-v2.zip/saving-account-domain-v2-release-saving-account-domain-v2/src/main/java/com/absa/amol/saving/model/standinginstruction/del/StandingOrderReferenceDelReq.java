package com.absa.amol.saving.model.standinginstruction.del;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.ws.rs.QueryParam;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StandingOrderReferenceDelReq {
	
	@QueryParam("standingOrderNumber")
	@NotNull(message = "standing.order.number.null.empty.message")
	@NotEmpty(message = "standing.order.number.null.empty.message")
	@Pattern(regexp = "[0-9]{0,3}", message = "standing.order.number.pattern.message")
	@Min(value = 1, message = "standing.order.number.value.message")
	private String standingOrderNumber;

}
