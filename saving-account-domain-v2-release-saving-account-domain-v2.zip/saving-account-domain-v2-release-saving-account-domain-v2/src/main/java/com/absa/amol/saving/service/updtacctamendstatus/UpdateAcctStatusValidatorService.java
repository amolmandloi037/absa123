package com.absa.amol.saving.service.updtacctamendstatus;

import com.absa.amol.saving.model.updtacctstatus.UpdateAcctStatusReqWrapper;

public interface UpdateAcctStatusValidatorService {
	public void validateInputRequest(UpdateAcctStatusReqWrapper requestWrapper);
}
