package com.absa.amol.saving.model.standinginstruction.singledetail;

import java.math.BigDecimal;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentTransactionSingleDetailResp 
{
	private PaymentPurposeSingleDetailResp paymentPurpose; //paymentPurpose.remNarrative (ebox) //paymentPurpose.narrative (FCR)
	  
	 private List<FeeDetailsSingleDetailResp> feeDetails; //FCR
	
	 private BigDecimal amount; 
	  
	  private String currency; 
	  
	  private PayeeAccountReferenceSingleDetailResp payeeAccountRef; //bene_account-id
	  
	  private PayeeBankRefSingleDetailResp payeeBankRef; //earlier beneficiaryBankRef
	  
	  private PayeeRefSingleDetailResp payeeReference; //earlier beneficiaryDetails
}
