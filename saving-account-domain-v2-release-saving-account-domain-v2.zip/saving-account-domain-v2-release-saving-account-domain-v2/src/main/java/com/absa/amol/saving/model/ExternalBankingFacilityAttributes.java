package com.absa.amol.saving.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ExternalBankingFacilityAttributes {
  private boolean ATMFacilityFlag;
  private boolean internetBankingAccessFlag;
  private boolean pointOfSaleFacilityFlag;
  private boolean mobileFacilityFlag;
}
