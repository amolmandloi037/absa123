package com.absa.amol.saving.model.sys.updtacctdtls;


import javax.json.bind.annotation.JsonbProperty;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(name = "AccountOpenRes", description = "Response Schema for Account Open - EBOX")
public class AccountOpenRes {
	
	 @JsonbProperty(nillable = true)
	 private SystemResponseHeader responseHeader;
	 @JsonbProperty(nillable = true)
	 private Status status;

}
