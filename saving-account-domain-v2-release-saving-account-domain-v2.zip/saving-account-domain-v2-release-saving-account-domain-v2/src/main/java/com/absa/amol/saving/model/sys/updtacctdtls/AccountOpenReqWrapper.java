package com.absa.amol.saving.model.sys.updtacctdtls;

import com.absa.amol.util.model.ApiRequestHeader;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountOpenReqWrapper {
	
	private ApiRequestHeader apiRequestHeader;
	private AccountOpenReq accountOpenReq;

	private String channelId;

	private String password;

	private String userIdentifier;

	private String locationCode;
	private boolean targetOffshoreInd;

}
