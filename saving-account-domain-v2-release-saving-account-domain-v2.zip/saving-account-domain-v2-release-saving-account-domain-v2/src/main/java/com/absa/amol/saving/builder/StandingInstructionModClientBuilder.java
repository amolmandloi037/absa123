package com.absa.amol.saving.builder;

import javax.ws.rs.BeanParam;
import javax.ws.rs.PUT;

import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import com.absa.amol.saving.model.standinginstruction.mod.StandingModReq;
import com.absa.amol.saving.model.standinginstruction.mod.StandingModRes;
import com.absa.amol.saving.util.ServerSideExceptionMapper;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.model.ResponseEntity;

@RegisterRestClient(configKey = "standing.inst.mod.prcs.sor.url")
@RegisterProvider(value = ServerSideExceptionMapper.class)
public interface StandingInstructionModClientBuilder {

	@PUT
	ResponseEntity<StandingModRes> modifyStandingInstruction(@BeanParam ApiRequestHeader requestHeader,
			@RequestBody StandingModReq request);
}
