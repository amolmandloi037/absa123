package com.absa.amol.saving.mapper.updtacctdtls;

import java.util.ArrayList;
import java.util.List;

import com.absa.amol.saving.model.sys.updtacctdtls.AccountOpenReq;
import com.absa.amol.saving.model.sys.updtacctdtls.AccountOpenRes;
import com.absa.amol.saving.model.sys.updtacctdtls.AccountParameters;
import com.absa.amol.saving.model.sys.updtacctdtls.AcctAddress;
import com.absa.amol.saving.model.sys.updtacctdtls.MailAddress;
import com.absa.amol.saving.model.sys.updtacctdtls.PricingParametersSys;
import com.absa.amol.saving.model.updtacctdtls.AccountAddress;
import com.absa.amol.saving.model.updtacctdtls.AccountParameter;
import com.absa.amol.saving.model.updtacctdtls.CorrespondenceArrangement;
import com.absa.amol.saving.model.updtacctdtls.CustomerReference;
import com.absa.amol.saving.model.updtacctdtls.MailingAddress;
import com.absa.amol.saving.model.updtacctdtls.PricingPlan;
import com.absa.amol.saving.model.updtacctdtls.ProductAndServicePreference;
import com.absa.amol.saving.model.updtacctdtls.UpdateAcctDtlsReq;
import com.absa.amol.saving.model.updtacctdtls.UpdateAcctDtlsReqWrapper;
import com.absa.amol.saving.model.updtacctdtls.UpdateAcctDtlsRes;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.utility.CommonUtil;
import com.absa.amol.util.utility.StringUtil;

public class UpdateAcctDtlsReqMapper {

	private static final Logger LOGGER = LoggerFactory.getLogger(UpdateAcctDtlsReqMapper.class);

	public AccountOpenReq updateAcctDetailsReqMapping(UpdateAcctDtlsReqWrapper updateAcctDtlsReqWrapper) {

		final String METHOD_NAME = "updateAcctDetailsReqMapping";
		String consumerUniqRefId = updateAcctDtlsReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId();
		LOGGER.info(METHOD_NAME, consumerUniqRefId, "Going to map domain request to system adapter", "Inside Method");
		AccountOpenReq accountOpenReq = new AccountOpenReq();
		UpdateAcctDtlsReq updateAcctDtlsReq = updateAcctDtlsReqWrapper.getUpdateAcctDtlsReq();
		setAccountOpenReq(accountOpenReq, updateAcctDtlsReq);
		if (CommonUtil.isNotNull(updateAcctDtlsReq.getCorrespondenceArrangement())) {
			setAcctAddressInfo(accountOpenReq, updateAcctDtlsReq);

		}
		if (CommonUtil.isNotNull(updateAcctDtlsReq.getCustomerReference())) {
			CustomerReference customerReference = updateAcctDtlsReq.getCustomerReference();
			accountOpenReq.setPrimaryCustomerNumber(customerReference.getPrimaryCustomerReference());

		}
		setAcctParameter(accountOpenReq, updateAcctDtlsReq);
		setPricingParameters(accountOpenReq, updateAcctDtlsReq);
		return accountOpenReq;
	}

	public void setAcctAddressInfo(AccountOpenReq accountOpenReq, UpdateAcctDtlsReq updateAcctDtlsReq) {
		AcctAddress acctAddress = new AcctAddress();
		CorrespondenceArrangement correspondenceArrangement = updateAcctDtlsReq.getCorrespondenceArrangement();
		if (StringUtil.isStringNotNullAndNotEmpty(correspondenceArrangement.getContactNumber())) {
			acctAddress.setCustomerContactNumber(correspondenceArrangement.getContactNumber());
		}
		if (CommonUtil.isNotNull(updateAcctDtlsReq.getCorrespondenceArrangement().getAccountAddress())) {
			AccountAddress accountAddress = updateAcctDtlsReq.getCorrespondenceArrangement().getAccountAddress();
			if (StringUtil.isStringNotNullAndNotEmpty(accountAddress.getSerialNumber())) {
				acctAddress.setSerialNumber(accountAddress.getSerialNumber());
			}
			if (StringUtil.isStringNotNullAndNotEmpty(accountAddress.getCustomerId())) {
				acctAddress.setCustomerId(accountAddress.getCustomerId());
			}

			if (CommonUtil.isNotNull(updateAcctDtlsReq.getCorrespondenceArrangement().getAccountAddress()
					.getProductAndServicePreference())) {
				setAcctAddress(updateAcctDtlsReq, acctAddress);
			}
			if (CommonUtil.isNotNull(
					updateAcctDtlsReq.getCorrespondenceArrangement().getAccountAddress().getMailingAddress())) {
				setMailAddress(updateAcctDtlsReq, acctAddress);
			}

		}
		accountOpenReq.setAcctAddress(acctAddress);
	}

	public void setAccountOpenReq(AccountOpenReq accountOpenReq, UpdateAcctDtlsReq updateAcctDtlsReq) {
		accountOpenReq.setBranchCode(updateAcctDtlsReq.getBankBranch());
		accountOpenReq.setAccountId(updateAcctDtlsReq.getSavingAccountNumber() );
		accountOpenReq.setLocationCode(updateAcctDtlsReq.getLocationReference());
		accountOpenReq.setProductId(updateAcctDtlsReq.getAccountType());
		if (StringUtil.isStringNotNullAndNotEmpty(updateAcctDtlsReq.getAccountShortName())) {
			accountOpenReq.setAccountShortName(updateAcctDtlsReq.getAccountShortName());
		}
		if (StringUtil.isStringNotNullAndNotEmpty(updateAcctDtlsReq.getAccountLongName())) {
			accountOpenReq.setAccountLongName(updateAcctDtlsReq.getAccountLongName());
		}
		accountOpenReq.setCurrency(updateAcctDtlsReq.getAccountCurrency());
	}

	public void setPricingParameters(AccountOpenReq accountOpenReq, UpdateAcctDtlsReq updateAcctDtlsReq) {
		if (CommonUtil.isNotNull(updateAcctDtlsReq.getPricingParameters())
				&& CommonUtil.isNotNull(updateAcctDtlsReq.getPricingParameters().getAccountDetails()) && CommonUtil
				.isNotNull(updateAcctDtlsReq.getPricingParameters().getAccountDetails().getPricingPlan())) {
			PricingPlan pricingPlan = updateAcctDtlsReq.getPricingParameters().getAccountDetails().getPricingPlan();
			PricingParametersSys pricingParametersSys = new PricingParametersSys();
			pricingParametersSys.setPriceCode(pricingPlan.getPriceCode());
			pricingParametersSys.setPlDesc(pricingPlan.getPlDesc());
			pricingParametersSys.setPlName(pricingPlan.getPlName());
			pricingParametersSys.setPlFromDate(pricingPlan.getPlFromDate());
			pricingParametersSys.setPlEndDate(pricingPlan.getPlEndDate());
			accountOpenReq.setPricingParameters(pricingParametersSys);
		}
	}

	public void setAcctParameter(AccountOpenReq accountOpenReq, UpdateAcctDtlsReq updateAcctDtlsReq) {
		List<AccountParameters> accountParametersSysList = new ArrayList<>();
		if (CommonUtil.isNotNull(updateAcctDtlsReq.getAccountParameter())) {
			List<AccountParameter> accountParameterList = updateAcctDtlsReq.getAccountParameter();
			for (AccountParameter accountParameter : accountParameterList) {
				AccountParameters accountParametersSys = new AccountParameters();
				accountParametersSys.setParameterId(accountParameter.getParameterId());
				accountParametersSys.setParameterValue(accountParameter.getParameterValue());
				accountParametersSysList.add(accountParametersSys);
			}
			accountOpenReq.setAccountParameter(accountParametersSysList);
		}
	}

	public void setMailAddress(UpdateAcctDtlsReq updateAcctDtlsReq, AcctAddress acctAddress) {
		MailingAddress mailingAddress = updateAcctDtlsReq.getCorrespondenceArrangement().getAccountAddress()
				.getMailingAddress();
		MailAddress mailAddress = new MailAddress();
		if (StringUtil.isStringNotNullAndNotEmpty(mailingAddress.getAddressSequenceNumber())) {
			mailAddress.setAddressSequenceNumber(mailingAddress.getAddressSequenceNumber());
		}
		if (StringUtil.isStringNotNullAndNotEmpty(mailingAddress.getAddressLine1())) {
			mailAddress.setAddressLine1(mailingAddress.getAddressLine1());
		}
		if (StringUtil.isStringNotNullAndNotEmpty(mailingAddress.getAddressLine2())) {
			mailAddress.setAddressLine2(mailingAddress.getAddressLine2());
		}
		if (StringUtil.isStringNotNullAndNotEmpty(mailingAddress.getAddressLine3())) {
			mailAddress.setAddressLine3(mailingAddress.getAddressLine3());
		}
		if (StringUtil.isStringNotNullAndNotEmpty(mailingAddress.getAddressName())) {
			mailAddress.setAddressName(mailingAddress.getAddressName());
		}
		acctAddress.setMailAddress(mailAddress);
	}

	public void setAcctAddress(UpdateAcctDtlsReq updateAcctDtlsReq, AcctAddress acctAddress) {
		ProductAndServicePreference productAndServicePreference = updateAcctDtlsReq
				.getCorrespondenceArrangement().getAccountAddress().getProductAndServicePreference();
		if (StringUtil.isStringNotNullAndNotEmpty(productAndServicePreference.getNoOfStatementCopies())) {
			acctAddress.setStatementCopies(productAndServicePreference.getNoOfStatementCopies());
		}
		if (StringUtil
				.isStringNotNullAndNotEmpty(productAndServicePreference.getChequesRequiredIndicator())) {
			acctAddress
			.setChequesRequiredIndicator(productAndServicePreference.getChequesRequiredIndicator());
		}
		if (StringUtil
				.isStringNotNullAndNotEmpty(productAndServicePreference.getBranchStatementIndicator())) {
			acctAddress
			.setBranchStatementIndicator(productAndServicePreference.getBranchStatementIndicator());
		}
		if (StringUtil.isStringNotNullAndNotEmpty(
				productAndServicePreference.getFixedDepositAddressIndicator())) {
			acctAddress.setFixedDepositAddressIndicator(
					productAndServicePreference.getFixedDepositAddressIndicator());
		}
		if (StringUtil.isStringNotNullAndNotEmpty(
				productAndServicePreference.getMiniStatementAddressIndicator())) {
			acctAddress.setMiniStatementAddressIndicator(
					productAndServicePreference.getMiniStatementAddressIndicator());
		}
		if (StringUtil
				.isStringNotNullAndNotEmpty(productAndServicePreference.getStatementAddressIndicator())) {
			acctAddress.setStatementAddressIndicator(
					productAndServicePreference.getStatementAddressIndicator());
		}
	}

	public UpdateAcctDtlsRes updateAcctDetailsResMapping(AccountOpenRes accountOpenRes) {
		UpdateAcctDtlsRes updateAcctDtlsRes = new UpdateAcctDtlsRes();
		updateAcctDtlsRes.setReferenceNumber(accountOpenRes.getResponseHeader().getTransactionId());
		return updateAcctDtlsRes;
	}

}
