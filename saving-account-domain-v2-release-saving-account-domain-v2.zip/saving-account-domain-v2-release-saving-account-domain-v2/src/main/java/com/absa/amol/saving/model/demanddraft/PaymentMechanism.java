package com.absa.amol.saving.model.demanddraft;

import javax.validation.constraints.Size;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import com.absa.amol.saving.util.Constant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class PaymentMechanism {
	
	@Size(max=3,message=Constant.DELIVERY_LENGTH_LENGTH_ERROR_MESSAGE)
	@Schema(description = "Field is optional",  maxLength = 3)
	private String deliveryType;

}
