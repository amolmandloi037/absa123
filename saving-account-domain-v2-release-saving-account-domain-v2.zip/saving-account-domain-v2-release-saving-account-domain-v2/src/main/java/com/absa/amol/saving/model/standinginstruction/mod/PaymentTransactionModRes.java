package com.absa.amol.saving.model.standinginstruction.mod;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentTransactionModRes {

	private PaymentPurposeModRes paymentPurpose;
	private String date;
	private String feeType;
	private BigDecimal feeCharge; 

}
