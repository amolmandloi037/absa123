package com.absa.amol.saving.builder;

import javax.ws.rs.BeanParam;
import javax.ws.rs.POST;

import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import com.absa.amol.saving.model.sys.actdctaccount.AccountStatusSystemReq;
import com.absa.amol.saving.model.sys.actdctaccount.AccountStatusSystemRes;
import com.absa.amol.saving.util.ServerSideExceptionMapper;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.model.ResponseEntity;

@RegisterRestClient(configKey = "uas.activate.deactivate.status")
@RegisterProvider(value = ServerSideExceptionMapper.class)
public interface UpdateAccountActDctStatusClientBuilder {

	@POST
	ResponseEntity<AccountStatusSystemRes> updateAccountStatus(@BeanParam ApiRequestHeader apiRequestHeader,
			@RequestBody AccountStatusSystemReq accountStatusSystemReq);
	
}
