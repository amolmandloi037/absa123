package com.absa.amol.saving.model.standinginstruction.retrieve;

import java.util.List;

import javax.json.bind.annotation.JsonbProperty;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(name = "StandingInstructionsRetRes", description = "Response Schema for Retrieve Standing Instructions")
public class StandingInstructionsRetRes {
	@JsonbProperty(nillable = true) private List<StandingInstructionSummaryRetRes> standingInstructionSummary;
	@JsonbProperty(nillable = true) private String customerReference;
}