package com.absa.amol.saving.model.sys.updaccudf;

import java.util.List;

import javax.json.bind.annotation.JsonbProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ValidationErrors {
	@JsonbProperty(nillable= true)
	private List<ValidationErr> validationError;
}