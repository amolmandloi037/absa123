package com.absa.amol.saving.model;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.ws.rs.BeanParam;
import javax.ws.rs.QueryParam;
import com.absa.amol.util.model.ApiRequestHeader;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@ValidDateRange(message = "date.error.message")
@ValidAmounts(message = "validamount.error.message")
public class TransactionHistoryRequest {

  @Valid
  @BeanParam
  private ApiRequestHeader apiRequestHeader;

  @NotNull(message = "accountId.noempty.error.message")
  @NotEmpty(message = "accountId.noempty.error.message")
  @Pattern(regexp = "^[0-9]*", message = "accountId.digit.error.message")
  @Size(min = 1, max = 16, message = "accountId.length.error.message")
  @QueryParam("accountId")
  private String accountId;

  @Size(min = 0, max = 5, message = "branchCode.length.error.message")
  @Pattern(regexp = "(^$)|^[0-9]*", message = "branchCode.digit.error.message")
  @QueryParam("branchCode")
  private String branchCode;

  @QueryParam("startDate")
  @Pattern(regexp = "^[0-9]*", message = "date.digit.error.message")
  @Date(message = "startDate.invalid.error.message", format = "yyyyMMdd")
  private String startDate;

  @QueryParam("endDate")
  @Pattern(regexp = "^[0-9]*", message = "date.digit.error.message")
  @Date(message = "endDate.invalid.error.message", format = "yyyyMMdd")
  private String endDate;

  @Pattern(regexp = "(^$)|(^[C])|(^[D])", message = "credit.debit.error.message")
  @QueryParam("drCrInd")
  private String drCrInd;

  @Pattern(regexp = "(^$)|(^[-0-9]{1,15}(?:\\.[0-9]{1,7})?$)",
      message = "startamount.invalid.error.message")
  @QueryParam("amountStart")
  private String amountStart;

  @Pattern(regexp = "(^$)|(^[-0-9]{1,15}(?:\\.[0-9]{1,7})?$)",
      message = "endamount.invalid.error.message")
  @QueryParam("amountEnd")
  private String amountEnd;

  @Size(min = 0, max = 3, message = "pageNo.error.message")
  @Pattern(regexp = "(^$)|^((?!(0))[0-9]+)$", message = "pageNo.numeric.error.message")
  @QueryParam("pageNo")
  private String pageNo;

  @Size(min = 0, max = 5, message = "pageSize.error.message")
  @Pattern(regexp = "(^$)|^((?!(0))[0-9]+)$", message = "pageSize.numeric.error.message")
  @QueryParam("pageSize")
  private String pageSize;

  @Override
  public String toString() {
    return "TransactionHistoryRequest [requestHeader=" + apiRequestHeader + ", branchCode="
        + branchCode + ", startDate=" + startDate + ", endDate=" + endDate + ", drCrInd=" + drCrInd
        + ", amountStart=" + amountStart + ", amountEnd=" + amountEnd + ", pageNo=" + pageNo
        + ", pageSize=" + pageSize + "]";
  }

}

