package com.absa.amol.saving.model.sys.demanddraft;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class DemandDraftReq {

	private String customerNumber;

	private String transactionBranch;

	private String accountId;

	private String beneficiaryName;

	private String currencyCode;

	private BigDecimal monetaryValue;

	private String additionalInfo;

	private String payableAtCountry;

	private String collectionBranchName;

	private String collectionBranchId;

	private String dateRequired;

	private String deliveryType;

	private SystemAddress beneficiaryAddress;

	private String beneficiaryPhone;

	private String paymentRemarks;

	private Boolean isServiceChargeApplicable;

	private Integer transactionType;
}
