package com.absa.amol.saving.model.unclearedfund;

import java.math.BigDecimal;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class AccountUnclearedFundDetails {

	private List<UnclearedFundInfo> unclearedFundInfo;
	private Integer currentAccountNumber;
	private Integer branchCode;
	private BigDecimal currentActualBal;
	private BigDecimal currentAvailableBal;
	private BigDecimal currentEarmarkedBal;
	private BigDecimal currentUnclearedEffectsBal;
	private BigDecimal futureBalance1;
	private BigDecimal futureBalance2;
	private BigDecimal futureBalance3;
	private BigDecimal debitLimit;
	private String futureBalanceDate1;
	private String futureBalanceDate2;
	private String futureBalanceDate3;

}
