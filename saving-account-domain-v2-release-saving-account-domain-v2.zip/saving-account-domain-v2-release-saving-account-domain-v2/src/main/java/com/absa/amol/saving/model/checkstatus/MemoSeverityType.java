package com.absa.amol.saving.model.checkstatus;

public class MemoSeverityType {

}
