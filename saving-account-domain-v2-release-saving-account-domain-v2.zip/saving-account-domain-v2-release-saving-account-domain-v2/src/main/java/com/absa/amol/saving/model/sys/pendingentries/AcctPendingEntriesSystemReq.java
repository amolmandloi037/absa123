package com.absa.amol.saving.model.sys.pendingentries;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.ws.rs.BeanParam;
import javax.ws.rs.QueryParam;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import com.absa.amol.util.model.ApiRequestHeader;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Schema(name = "AccountPendingEntriesListRequest",
description = "Request Schema for account earmark list system adapter")
public class AcctPendingEntriesSystemReq {

	@Valid
	@BeanParam
	private ApiRequestHeader requestHeader;

	@QueryParam("branchNumber")
	@NotNull(message = "branchNumber.null.empty.message")
	@NotEmpty(message = "branchNumber.null.empty.message")
	@Pattern(regexp = "[0-9]{1,3}", message = "branchNumber.pattern.message")
	private String branchNumber;

	@QueryParam("accountNumber")
	@NotNull(message = "accountNumber.null.empty.message")
	@NotEmpty(message = "accountNumber.null.empty.message")
	@Pattern(regexp = "[0-9]{7}", message = "accountNumber.pattern.message")
	private String accountNumber;


}
