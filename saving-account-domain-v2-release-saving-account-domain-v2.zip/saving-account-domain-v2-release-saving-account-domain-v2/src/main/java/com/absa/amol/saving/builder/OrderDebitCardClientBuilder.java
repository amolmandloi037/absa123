package com.absa.amol.saving.builder;

import javax.ws.rs.BeanParam;
import javax.ws.rs.POST;

import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import com.absa.amol.saving.model.orderdebitcard.OrderDebitCardSystemRequest;
import com.absa.amol.saving.model.orderdebitcard.OrderDebitCardSystemResponse;
import com.absa.amol.saving.util.ServerSideExceptionMapper;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.model.ResponseEntity;

@RegisterRestClient(configKey = "order.debit.card.sys.url")
@RegisterProvider(value = ServerSideExceptionMapper.class)
public interface OrderDebitCardClientBuilder {

	@POST
	public ResponseEntity<OrderDebitCardSystemResponse> orderDebitCard(@BeanParam ApiRequestHeader apiRequestHeader, @RequestBody OrderDebitCardSystemRequest orderDebitCardSystemRequest);

}