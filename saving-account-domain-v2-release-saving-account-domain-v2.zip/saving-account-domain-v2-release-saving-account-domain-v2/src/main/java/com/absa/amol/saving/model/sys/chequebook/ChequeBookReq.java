package com.absa.amol.saving.model.sys.chequebook;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ChequeBookReq {

	private String customerNumber;
	
	private Integer transactionBranch;
	
	private String accountId;
	
	private Integer noOfLeaves;
	
	private String transactionType;
	
	private String collectionBranchName;
	

}
