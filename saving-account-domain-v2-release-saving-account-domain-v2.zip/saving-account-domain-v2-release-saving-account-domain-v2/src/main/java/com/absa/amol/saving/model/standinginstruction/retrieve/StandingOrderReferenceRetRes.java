package com.absa.amol.saving.model.standinginstruction.retrieve;

import javax.json.bind.annotation.JsonbProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StandingOrderReferenceRetRes {
	@JsonbProperty(nillable = true) private Integer standingOrderNumber;
	@JsonbProperty(nillable = true) private Integer priority;
	@JsonbProperty(nillable = true) private String terminationMethod;
	@JsonbProperty(nillable = true) private String eofPeriodInd;
	@JsonbProperty(nillable = true) private String noOfPayments;
	@JsonbProperty(nillable = true) private String terminationAmount;
	@JsonbProperty(nillable = true) private String numberToDate;
	@JsonbProperty(nillable = true) private String amountToDate;
	@JsonbProperty(nillable = true) private String customerTransferInd;
	@JsonbProperty(nillable = true) private String simPaymentInd;
	@JsonbProperty(nillable = true) private String missedPaymentsCount;
}