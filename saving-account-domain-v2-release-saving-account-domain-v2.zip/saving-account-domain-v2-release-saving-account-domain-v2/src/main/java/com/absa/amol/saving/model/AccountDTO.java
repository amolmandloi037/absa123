package com.absa.amol.saving.model;

import javax.json.bind.annotation.JsonbNillable;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonbNillable
public class AccountDTO {

    protected String accountNumber;
    protected String acctType;
    protected String accountCurrency;
    protected String accountType;
    protected Boolean ibanAccount;
    protected Boolean residentAccount;
    protected String authLevel;
    protected String branchCode;
}
