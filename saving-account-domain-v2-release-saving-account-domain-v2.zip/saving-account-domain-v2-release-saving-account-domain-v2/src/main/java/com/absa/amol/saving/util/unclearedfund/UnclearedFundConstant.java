package com.absa.amol.saving.util.unclearedfund;

public class UnclearedFundConstant {
	private UnclearedFundConstant() {
	}

	public static final String FALLBACK_TIMEOUT = "com.absa.amol.saving.controller.SavingAccountDomainController/retrieveUnclearedFund/Timeout/value";
	public static final String FALLBACK_METHOD_FOR_TIMEOUT = "fallbackTimeoutForUnclearedFund";
	public static final String TIMEOUT_CODE = "504";
	public static final String SERIVCE_UN_CODE = "503";
	public static final String SERVICE_UN_MSG = "Service Unavailable";
	public static final String FAILURE_MSG = "Failure";
	public static final int SUCCESS = 200;
	public static final String SUCCESS_MSG = "Success";
	public static final String SUCCESS_CODE = "200";
	public static final String EXCEPTION_OCCURED_FROM_SERVER = "exception occured while invoking system service";
	public static final String GET_UNCLEAR_FUND_DETAILS = "retrieveUnclearedFund";
	public static final String RESPONSE_SUCCESS_MESSAGE = "Records retrieved successfully";

	public static final String UNCLEARFUND_AMOUNT = "UnclearFund Amount";
	public static final String EARMARK_AMOUNT = "EarMark Amount";
	public static final String UNCLEAR_DATE = "Unclear date";
	public static final String EARMARK_CLEAR_DATE = "EarMark Clear date";
	public static final String EARMARK_DATE = "EarMark date";
	public static final String REQ_DATE = "yyyyMMdd";
	public static final String RES_DATE = "yyyy-MM-dd";

	public static final long REPLY_CODE_40 = 40;
	public static final long REPLY_CODE_SUCCESS = 0;
	public static final String BAD_REQUEST_CODE = "400";
	public static final String STATUS_CODE_1 = "-1";
	public static final String STATUS_CODE_2 = "-2";
	public static final String STATUS_CODE_3 = "-3";
	public static final String STATUS_CODE_4 = "-4";
}
