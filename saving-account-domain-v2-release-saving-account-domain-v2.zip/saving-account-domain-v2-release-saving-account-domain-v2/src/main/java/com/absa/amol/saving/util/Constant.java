package com.absa.amol.saving.util;

import static com.absa.amol.util.utility.CommonUtil.isNotNull;

import java.math.BigDecimal;

import com.absa.amol.util.model.ApiRequestHeader;

public final class Constant {

  private Constant() {

  }

  public static final String SUCCESS_CODE = "200";

  public static final String BAD_REQUEST_CODE = "400";

  public static final int SUCCESS = 200;

  public static final String SUCCESS_MSG = "SUCCESS";

  public static final String ERROR_MSG = "ERROR";

  public static final String PRODUCT_PROCESSOR_HEADER = "ProductProcessorID";

  public static final String GET_SAVING_ACCOUNT_DETAILS = "getSavingAccountDetails";

  public static final String GET_SAVING_ACCOUNT_RESPONSE = "getSavingAcctResponse";

  public static final String EXCEPTION_OCCURED = "Exception Occured";

  public static final String IO_EXCEPTION = "IO exception occurred!";

  public static final String FILE_NOT_FOUND_EXCEPTION = "File not found!";

  public static final String GET_ACCOUNT_NAME = "getAccountName";

  public static final String NO_RESP_FROM_DOWNSTREAM_SERVICE =
      "No response from downstream service";

  public static final String CONFIG_SOURCE_NAME = "FileSystemConfigSource";

  public static final String INVALID_HEADER = "Invalid header.";

  public static final String INVALID_COUNTRY_CODE_AND_BUSINESSID =
      "Invalid Country Code or Business Id..";

  public static final String VALIDATE_REQUEST = "validateRequest";

  public static final String BAD_CODE_REQUEST = "404";
  public static final String BAD_REQUEST_MSG = "Customer Number not found.";

  public static final String INTERNAL_ERROR_CODE = "500";
  public static final String INTERNAL_ERROR_MSG = "Internal Server Error.";

  public static final String SUCCESS_RESPONSE_MESSAGE = "Get Customer Details";
  public static final String NAME = "OK";

  public static final String SUMMERY = "Get Saving Account details by Customer Number";
  public static final String DESC = "Get Saving account details";

  public static final String TITLE = "Saving Account Detail Service openAPI";
  public static final String CONTACT_NAME = "Amol";
  public static final String LICENSE_NAME = "Amol";
  public static final String CONTACT_EMAIL = "abc@absa.africa";
  public static final String VERSION = "1.0.0";

  public static final String TIMEOUT_CODE = "504";
  public static final long FALLBACK_TIMEOUT = 40000;
  public static final String FALLBACK_TIMEOUT_KEY_AM =
      "com.absa.amol.saving.controller.SavingAccountDomainController/getSavingAccountDetails/Timeout/value";
  public static final String FALLBACK_TIMEOUT_KEY_TH =
      "com.absa.amol.saving.controller.SavingAccountDomainController/getTransactionHistoryDetails/Timeout/value";
  public static final String FALLBACK_METHOD_FOR_TIMEOUT = "fallbackForTimeout";
  public static final String FAILURE_MSG = "Failure";

  public static final String GET_TRANSACTION_HISTORY_RESPONSE = "getTransactionHistoryResponse";
  public static final String EXCEPTION_OCCURED_FROM_SERVER =
      "exception occured while invoking system service";

  public static final String RESP_SCHEMA_NAME = "RetrieveCorpUserFundsTransferDetailsResponse";
  public static final String RESP_SCHEMA_DESC =
      "Response Schema for Corp User Funds Transfer Details System MCE Adapter";
  public static final String REQ_SCHEMA_NAME = "FundsTransferDetailsRequest";
  public static final String REQ_SCHEMA_DESC =
      "Request Schema For Corporate User Funds Transfer Details System MCE Adapter";
  public static final String LIST_REQ_SCHEMA_NAME = "FundsTransferDetailsListRequest";
  public static final String LIST_REQ_SCHEMA_DESC =
      "Request Schema For Corporate User Funds Transfer List System MCE Adapter";

  public static final String GET_TRANSACTION_HISTORY_LIST =
      "getRetrieveCorpUserFundsTransferServiceList";

  public static final String GET_TRANSACTION_HISTORY_DETAILS =
      "getRetrieveCorpUserFundsTransferServiceDetails";

  public static final String AMOUNT_REGEX = "(^$)|(^[-0-9]{1,15}(?:\\.[0-9]{1,7})?$)";

  public static final Long REPLY_CODE_0 = 0L;

  public static final Long REPLY_CODE_30 = 30L;

  public static final Long REPLY_CODE_40 = 40L;

  public static final Long REPLY_CODE_80 = 80L;

  public static BigDecimal ZERO_BALANCE = BigDecimal.valueOf(0.0);

  public static final String NO_RECORD_FOUND = "No Record Found";

  public static final String LOG_BUSINESS_MSG =
      "Got Business Failure Response from FCR retrieveCustomerInformation system. Reply Code receieved ";

  public static final String getConsumerUniqueReferenceId(ApiRequestHeader requestHeader) {
    if (isNotNull(requestHeader) && isNotNull(requestHeader.getConsumerUniqueReferenceId())) {
      return requestHeader.getConsumerUniqueReferenceId();
    }
    return "";
  }

  /** constants added for ADD SI starts **/
  public static final String EXECUTED = "executed";
  public static final String ADD_STANDING_INSTRUCTION = "addStandingInstruction";
  public static final String ADD_STANDING_INSTRUCTION_URL =
      "saving.account.addStandingInstruction.url";
  public static final String FALLBACK_TIMEOUT_FOR_ADD_STANDING_INSTRUCTION =
      "fallbackTimeoutForAddStandingInstruction";
  public static final String EMPTY = "";
  public static final String FALLBACK_METHOD_AFTER_WAITING_15_MILLISECONDS =
      "Fallback method after waiting 15 milliseconds!";

  /** constants added for ADD SI ends **/

  // for retrieveStandingInstructions
  public static final String FIVE_O_THREE = "503";
  public static final String FALLBACK_RET_SI = "fallbackForRetrieveStandingInstructions";
  public static final String BACKEND_UN_AVAILABLE = "Downstream Unavailable";
  public static final String BAD_REQ = "Bad Request";
  public static final String DATA_RECEIVED = "Data Received";
  public static final String SEPARATOR = ", ";
  public static final String RET_SI_TIMEOUT =
      "com.absa.amol.saving.controller.SavingAccountDomainController/retrieveStandingInstructions/Timeout/value";

  public static final String FALLBACK_METHOD_FOR_ACCOUNT_UPDATE = "fallbackForAccountUpdate";

  /** Constants added for Delete SI starts **/

  public static final String EXCEPTION = "Exception";
  public static final String API_EXCEPTION = "ApiException";
  public static final String BLANK = "";
  public static final String COLON = ":";
  public static final String WAITING_TIME = "waiting time in ms :";
  public static final String SOR_DOWN_MSG = "Service down in downstream SOR";
  public static final int TIMEOUT_INT = 504;
  public static final String GATEWAY_TIMEOUT = "Gateway Timeout";
  public static final String DATA_RECIEVED = "Data Recieved";
  public static final String FALLBACK_METHOD_DEL = "delFallbackTimeout";
  public static final String MAINTAINENCE_TYPE = "d";
  public static final String FEE_TYPE = "FAILURE";
  public static final String DATE_TIME_PATTERN = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
  public static final String SI_TIMEOUT_DEL =
      "com.absa.amol.saving.controller.SavingAccountDomainController/deleteSI/Timeout/value";
  public static final String DEL_STANDING_INSTRUCTION = "delStandingInstruction";

  /** Constants added for Delete SI ends **/

  /** Constant for Modify starts */

  public static final String YYYYMMDD = "yyyyMMdd";
  public static final String FALLBACK_METHOD_MOD = "modFallbackTimeout";
  public static final String SI_TIMEOUT_MOD =
      "com.absa.amol.saving.controller.SavingAccountDomainController/modifySI/Timeout/value";
  public static final String MOD_STANDING_INSTRUCTION = "modStandingInstruction";

  /** Constant for Modify starts */


  /** Constants added for Single SI starts **/

  public static final String SINGLE_SI = "singleStandingInstruction";
  public static final String FALLBACK_RET_SINGLE_SI = "fallbackForSingleStandingInstructions";
  public static final String FIVE_O_THREE_MSG = "System Adapter Service unavailable";
  /** Constants added for Single SI starts **/


  /** Constant for AddChequeBookRequest starts */
  public static final String CUSTOMER_REFERENCE_PATTERN_ERROR_MESSAGE =
      "customerReference.pattern.error.message";
  public static final String CUSTOMER_REFERENCE_LENGTH_ERROR_MESSAGE =
      "customerReference.length.error.message";
  public static final String CUSTOMER_REFERENCE_NOTNULLEMPTY_ERROR_MESSAGE =
      "customerReference.notnullempty.error.message";
  public static final String CHEQUE_BOOK_LEAF_SIZE_LENGTH_ERROR_MESSAGE =
      "chequeBookleafSize.length.error.message";
  public static final String CHEQUE_BOOK_LEAF_SIZE_NOTNULLEMPTY_ERROR_MESSAGE =
      "chequeBookleafSize.notnullempty.error.message";
  public static final String ISSUED_DEVICE_DESCRIPTION_NULLOR_EMPTY_ERROR_MESSAGE =
      "issued.device.description.nullorEmpty.error.message";
  public static final String PRODUCT_INST_REFERENCE_NOTNULLEMPTY_ERROR_MESSAGE =
      "productInstanceReference.notnullempty.error.message";
  public static final String PRODUCT_INST_REFERENCE_PATTERN_ERROR_MESSAGE =
      "productInstanceReference.pattern.error.message";
  public static final String BRANCH_ID_REGX = "^[0-9]*";
  public static final String REQUEST_SCHEMA_FOR_ADD_CHEQUE_BOOK =
      "Request Schema for Add Cheque EBOX";
  public static final String ADD_CHEQUE_BOOK_REQUEST_SCHEMA = "Add ChequeBook Request";
  public static final String VALIDATE_INPUT_REQUEST = "validateInputRequest";
  public static final String CUSTOMVALIDATED_BEANS = "customvalidatedBeans";
  public static final String ZERO_STRING = "0";
  public static final String ADD_CHEQUE_BOOK_REQUEST = "addChequeBookRequestService";
  public static final String EBOX_SUCCESS_STATUS_CODE = "00000";
  public static final String FALLBACK_METHOD_FOR_CHEQUE_BOOK = "fallbackForAddChequeBookReq";
  public static final String CONTACT_LIST = "contactHistoryList";
  public static final String ADD_CUST_CONTACT_HISTORY = "addCustContactHistory";
  public static final String CHEQUE_BOOK_TIMEOUT =
      "com.absa.amol.current.controller.SavingAccountDomainController/addChequeBookRequest/Timeout/value";
  public static final String DATA_ADDED_SUCCESS = "Data Added successfully";
  public static final String INVOKE_MCE = "invokeMce";
  public static final String SUCCESS_MESSAGE = "Success";
  /** Constant for AddChequeBookRequest ends */


  /** Constant for demandDraftRequest starts */

  public static final String DEMAND_DRAFT_SERVICE = "demandDraftRequestService";
  public static final String DEMAND_DRAFT_TIMEOUT =
      "com.absa.amol.saving.controller.SavingAccountDomainController/demandDraftRequest/Timeout/value";
  public static final String FALLBACK_METHOD_FOR_DEMAND_DRAFT = "fallbackFordemandDraftRequest";
  public static final String BANK_BRANCH_REFERENCE_NOTNULLEMPTY_ERROR_MESSAGE =
      "bankBranchReference.notnullempty.error.message";
  public static final String BANK_BRANCH_REFERENCE_LENGTH_ERROR_MESSAGE =
      "bankBranchReference.length.error.message";
  public static final String BANK_BRANCH_REFERENCE_PATTERN_ERROR_MESSAGE =
      "bankBranchReference.pattern.error.message";
  public static final String SAVINGS_ACCOUNT_NUMBER_NOTNULLEMPTY_ERROR_MESSAGE =
      "savingsAccountNumber.notnullempty.error.message";
  public static final String SAVINGS_ACCOUNT_NUMBER_PATTERN_ERROR_MESSAGE =
      "savingsAccountNumber.pattern.error.message";
  public static final String SAVINGS_ACCOUNT_NUMBER_LENGTH_ERROR_MESSAGE =
      "savingsAccountNumber.length.error.message";
  public static final String DD_CUSTOMER_REFERENCE_PATTERN_ERROR_MESSAGE =
      "dd.customerReference.pattern.error.message";
  public static final String DD_CUSTOMER_REFERENCE_LENGTH_ERROR_MESSAGE =
      "dd.customerReference.length.error.message";
  public static final String CURRENCY_CODE_PATTERN_ERROR_MESSAGE =
      "currencycode.pattern.error.message";
  public static final String CURRENCY_CODE_LENGTH_ERROR_MESSAGE =
      "currencycode.length.error.message";
  public static final String CURRENCY_CODE_NOTNULLEMPTY_ERROR_MESSAGE =
      "currencycode.notnullempty.error.message";
  public static final String AMOUNT_LENGTH_ERROR_MESSAGE = "amount.length.error.message";
  public static final String DATE_PATTERN_ERROR_MESSAGE = "date.pattern.error.message";
  public static final String ONLY_CHARACTERS_REGEX = "^[a-zA-Z ]+$";
  public static final String ONLY_SPACE_CHARACTERS_REGEX = "^[a-zA-Z ]*$";
  public static final String ONLY_SPACE_ALPHANUMERIC_REGEX = "^[a-zA-Z0-9 ]*$";
  public static final String DELIVERY_LENGTH_LENGTH_ERROR_MESSAGE =
      "deliveryType.length.error.message";
  public static final String ADDITIONAL_INFO_LENGTH_ERROR_MESSAGE =
      "additionalinfo.length.error.message";
  public static final String ADDITIONAL_INFO_PATTERN_ERROR_MESSAGE =
      "additionalinfo.pattern.error.message";
  public static final String PAYMENT_REMARKS_LENGTH_ERROR_MESSAGE =
      "paymentRemarks.length.error.message";
  public static final String PAYMENT_REMARKS_PATTERN_ERROR_MESSAGE =
      "paymentRemarks.pattern.error.message";
  public static final String BENEFICIARY_NAME_NOTNULLEMPTY_ERROR_MESSAGE =
      "beneficiaryname.notnullempty.error.message";
  public static final String BENEFICIARY_NAME_LENGTH_ERROR_MESSAGE =
      "beneficiaryname.length.error.message";
  public static final String BENEFICIARY_NAME_PATTERN_ERROR_MESSAGE =
      "beneficiaryname.pattern.error.message";
  public static final String PHONE_NUMBER_LENGTH_ERROR_MESSAGE = "phoneNumber.length.error.message";
  public static final String PHONE_NUMBER_PATTERN_ERROR_MESSAGE =
      "phoneNumber.pattern.error.message";
  public static final String CITY_NAME_LENGTH_ERROR_MESSAGE = "cityName.length.error.message";
  public static final String CITY_NAME_PATTERN_ERROR_MESSAGE = "cityName.pattern.error.message";
  public static final String COUNTRY_NAME_LENGTH_ERROR_MESSAGE = "countryName.length.error.message";
  public static final String COUNTRY_NAME_PATTERN_ERROR_MESSAGE =
      "countryName.pattern.error.message";
  public static final String ADDRESS_LINE1_LENGTH_ERROR_MESSAGE =
      "addressline1.length.error.message";
  public static final String ADDRESS_LINE1_PATTERN_ERROR_MESSAGE =
      "addressline1.pattern.error.message";
  public static final String ADDRESS_LINE2_LENGTH_ERROR_MESSAGE =
      "addressline2.length.error.message";
  public static final String ADDRESS_LINE2_PATTERN_ERROR_MESSAGE =
      "addressline2.pattern.error.message";
  public static final String ADDRESS_LINE3_LENGTH_ERROR_MESSAGE =
      "addressline3.length.error.message";
  public static final String ADDRESS_LINE3_PATTERN_ERROR_MESSAGE =
      "addressline3.pattern.error.message";
  public static final String STATE_LENGTH_ERROR_MESSAGE = "state.length.error.message";
  public static final String STATE_PATTERN_ERROR_MESSAGE = "state.pattern.error.message";
  public static final String ZIP_CODE_LENGTH_ERROR_MESSAGE = "zipCode.length.error.message";
  public static final String ZIP_CODE_PATTERN_ERROR_MESSAGE = "zipCode.pattern.error.message";
  public static final String COUNTRY_CODE_LENGTH_ERROR_MESSAGE = "countryCode.length.error.message";
  public static final String COUNTRY_CODE_PATTERN_ERROR_MESSAGE =
      "countryCode.pattern.error.message";
  public static final String COLLECTION_BRANCH_ID_LENGTH_ERROR_MESSAGE =
      "collection.branchid.length.error.message";
  public static final String COLLECTION_BRANCH_ID_PATTERN_ERROR_MESSAGE =
      "collection.branchid.pattern.error.message";
  public static final String COLLECTION_BRANCH_NAME_LENGTH_ERROR_MESSAGE =
      "collection.branchname.length.error.message";
  public static final String COLLECTION_BRANCH_NAME_PATTERN_ERROR_MESSAGE =
      "collection.branchname.pattern.error.message";
  /** Constant for demandDraftRequest ends */
  /** Constant for RetrieveNickName starts */
  public static final String RETRIEVE_NICK_NAME = "retrieveNickName";
  public static final String FALLBACK_METHOD_FOR_RETRIEVE_NICK_NAME = "fallbackForRetrieveNickName";
  public static final String RETRIEVE_NICK_NAME_TIMEOUT =
      "com.absa.amol.saving.controller.SavingAccountDomainController/retrieveNickName/Timeout/value";
  public static final String TIME_OUT_AFTER_MS = "Timeout after ms";
  public static final String CUSTOMER_REFERENCE_ALL_ZEROES_ERROR_MSG =
      "retrievecustnickname.customerReference.allzeroes.error.message";

  /** Constant for AddAcountsNickname starts */
  public static final Integer TIMEOUT_CODE_INT = 504;
  public static final String M_ADD_ACCOUNTS_NICKNAME_FALLBACK =
      "fallbackForAddUpdateAccountNickname";
  public static final String M_ADD_UPDATE_ACCOUNTS_NICKNAME = "addUpdateAccountNickname";
  public static final String ACCOUNTS_NICKNAME_TIMEOUT =
      "com.absa.amol.saving.controller.SavingAccountDomainController/addUpdateAccountNickname/Timeout/value";
  public static final String M_ADD_UPDATE_ACCOUNTS_NICKNAME_REQ_MAPPING =
      "getAddAccountsNicknameReqMapping";
  public static final String ADD_ACC_NICKNAE_CUSTOMER_REFERENCE_ALL_ZEROES_ERROR_MSG =
      "addcustnickname.customerReference.allzeroes.error.message";
  public static final String ACCOUNT_NUMBER_ALL_ZEROES_ERROR_MSG =
      "addcustnickname.accountNumber.allzeroes.error.message";
  public static final String BANK_BRANCH_ALL_ZEROES_ERROR_MSG =
      "addcustnickname.bankBranchCode.allzeroes.error.message";
  public static final String API_EXCEPTION_OCCURRED = "ApiException occurred";
  public static final String EXCEPTION_OCCURRED = "Exception occurred";
  public static final String SERVICE_UNAVAILABLE = "System Adapter Service is unavailable.";
  public static final String TIMEOUT_AFTER = "Timeout after ";
  public static final String ADD_ACCT_NICKNAME_SUCCESS_MSG = "Account NickName added/updated";
  public static final String ACCOUNTS_NICKNAME = "Account Nickname";

  /** Constant for Order Paper Statement starts */
  public static final String ORDER_PAPER_STMT_FALLBACK = "fallbackForOrderPaperStatement";
  public static final String ORDER_PAPER_STMT_TIMEOUT =
      "com.absa.amol.saving.controller.SavingAccountDomainController/getOrderPaperStatement/Timeout/value";
  public static final String GET_ORDER_PAPER_STMT = "getOrderPaperStatement";
  public static final String CALL_ADD_CONTACT_HIST = "Call Add Contact History";
  /** Constant for Order Paper Statement end */

  /**
   * bankers notes start
   */
  public static final String BANKERS_NOTES_FALLBACK_METHOD = "fallbackForBankersNotesTimeout";
  public static final String BANKERS_NOTES_TIMEOUT =
	      "com.absa.amol.saving.controller.SavingAccountDomainController/getBankersNotesDetails/Timeout/value";
  
  public static final String SAVING_ACCOUNT_NUMBER_ALL_ZEROES_ERROR_MSG =
	      "bankers.notes.savingAccountNumber.allzeroes.error.message";
  
  public static final String SAVING_BANK_BRANCH_ALL_ZEROES_ERROR_MSG=
		  "bankers.notes.branchCode.allzeroes.error.message";
  
  public static final String BANKERS_METHOD_NAME= "getBankersNotesDetails";
 
  
  /**
   * bankers notes end
   */
  
  /**
   * check status start
   */
  public static final String ISSUED_DEVICE_ALL_ZEROES_ERROR_MSG="check.status.issued.device.allzeros.error.message";
  public static final String CHECK_STATUS_FALLBACK_METHOD="fallbackForCheckStatus";
  public static final String CHECK_STATUS_METHOD_NAME = "getCheckStatus";
  public static final String CHECK_STATUS_TIMEOUT =
	      "com.absa.amol.saving.controller.SavingAccountDomainController/getCheckStatus/Timeout/value";
  
  /**
   * check status end
   */
  public static final String EARMARK_FALLBAK = "fallbackForEarmarkPendingEntries";
  public static final String EARMARK_TIMEOUT =
      "com.absa.amol.saving.controller.SavingAccountDomainController/getEarmarkPendingEntriesList/Timeout/value";
  public static final String GET_EARMARK_PENINDENTRIES = "getEarmarkPendingEntriesList";
  public static final String DOWNSTREAM_UNAVAILABLE = "503";

  public static final String SAVINGS_ACCOUNT_FULFILLMENT = "Savings Account Fulfillment";
  public static final String SAVINGS_ACCOUNT_ARRANGEMENT = "Savings Account Arrangement";
  public static final String APPL_JSON = "application/json";

  public static final String TH_ACTION_CODE_LIST = "LIST";
  
  public static final String SUCCESS_NO_DATA = "SuccessNoData";
  
//CreateCasaAccount
public static final String FALLBACK_METHOD_FOR_CREATE_CASA_ACCOUNT = "fallbackForCreateCasaAccount";

public static final String PURCHASE_MV_SIGNIN_SYS_URL = "purchaseMvSignInSys";
public static final String PURCHASE_MV_SYS_URL = "moneyVoucherPurchaseSys";
public static final String FALLBACK_METHOD_FOR_PURCHASE_MV = "fallbackForPurchaseMoneyVoucher";
public static final String TIME_OUT_PURCHASE_MV = "com.absa.amol.saving.controller.SavingAccountDomainController/purchaseMoneyVoucher/Timeout/value";

public static final String FALLBACK_METHOD_FOR_UPDATE_ACCT_DTLS="fallbackForUpdateAcctDetails";
public static final String TIME_OUT_UPDATE_ACCT_DTLS = "com.absa.amol.saving.controller.SavingAccountDomainController/updateAcctDetails/Timeout/value";
public static final String DATA_UPDATED="Data Updated Successfully";
public static final String INSIDE_CONTROLLER = "Inside Controller";

//Amend Customer Account

public static final String FALLBACK_METHOD_FOR_ACCOUNT_STATUS_UPDATE = "fallbackForAccountStatusUpdate";
public static final String TIME_OUT_ACCOUNT_STATUS_UPDATE = "com.absa.amol.saving.controller.SavingAccountDomainController/amendCustomerAccount/Timeout/value";
public static final String ACCOUNT_MANAGEMENT_STATUS_SYS_URL = "accountManagementStatusSys";

public static final String STANDING_INSTRUCTION = "Standing Instruction";


//UpdateAccountStatus

public static final String FALLBACK_METHOD_FOR_UPDATE_ACCOUNT_STATUS = "fallbackForUpdateAccountStatus";
public static final String TIME_OUT_UPD_ACCOUNT_STATUS = "com.absa.amol.saving.controller.SavingAccountDomainController/getUpdatedAccountStatus/Timeout/value";
public static final String DATA_UPDATED_SUCCESS = "Data Updated Successfully";

//Order Debit Card
public static final String FALLBACK_METHOD_FOR_ORDER_DEBIT_CARD = "fallbackForOrderDebitCard";
public static final String M_ORDER_DEBIT_CARD = "orderDebitCard";
public static final String TIME_OUT_ORDER_DEBIT_CARD = "com.absa.amol.saving.controller.SavingAccountDomainController/orderDebitCard/Timeout/value";

}
