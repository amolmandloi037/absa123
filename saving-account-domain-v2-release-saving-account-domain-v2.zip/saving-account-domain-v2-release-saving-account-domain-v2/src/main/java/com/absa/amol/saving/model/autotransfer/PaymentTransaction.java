package com.absa.amol.saving.model.autotransfer;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class PaymentTransaction {

	private String payeeBankReference;
	private String payeeAccountReference;
	private String amount;
}
