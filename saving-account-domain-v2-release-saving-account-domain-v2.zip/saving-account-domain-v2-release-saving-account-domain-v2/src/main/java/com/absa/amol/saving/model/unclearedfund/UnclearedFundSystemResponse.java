package com.absa.amol.saving.model.unclearedfund;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class UnclearedFundSystemResponse {

	private AccountUnclearedFundDetails accountUnclearedFundDetails;
	private Status status;

}
