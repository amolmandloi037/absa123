package com.absa.amol.saving.model.standinginstruction.del;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StandingOrderReferenceDelRes {

	private Integer standingOrderNumber;

}
