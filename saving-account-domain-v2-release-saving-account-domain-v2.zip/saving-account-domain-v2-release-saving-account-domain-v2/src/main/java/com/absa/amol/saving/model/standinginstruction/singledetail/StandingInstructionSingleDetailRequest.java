package com.absa.amol.saving.model.standinginstruction.singledetail;

import javax.ws.rs.BeanParam;
import javax.ws.rs.QueryParam;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import com.absa.amol.util.model.ApiRequestHeader;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(name = "StandingInstructionSingleDetailRequest", description = "Request Schema for Single Standing Instruction API")
public class StandingInstructionSingleDetailRequest
{
	@BeanParam
	ApiRequestHeader apiRequestHeader;
	
	@Schema(description = "Field is mandatory.", pattern = "Only numeric", maxLength = 12, required = true)
	@QueryParam("customerReference")
	private String customerReference;
	
	
	@Schema(description = "Field is mandatory.", pattern = "Only numeric", maxLength = 7, required = true)
	@QueryParam("accountNumber")
	private String accountNumber; 
	
	
	@Schema(description = "Field is mandatory.", pattern = "Only numeric", maxLength = 3, required = true)
	@QueryParam("bankBranch")
	private String bankBranch; 						

	
	@BeanParam
	private StandingOrderReferenceSingleDetailReq standingOrder; 
}
