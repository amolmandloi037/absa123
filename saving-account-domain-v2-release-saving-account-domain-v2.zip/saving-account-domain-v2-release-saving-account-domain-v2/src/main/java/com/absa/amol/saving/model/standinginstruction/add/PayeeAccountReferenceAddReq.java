package com.absa.amol.saving.model.standinginstruction.add;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PayeeAccountReferenceAddReq {
	private String beneficiaryAccountTypes;
	
	@Schema(description = "Field is conditional mandatory. For EBOX and FCR maxlength=16", pattern = "[0-9]*",required = true)
	private String accountNumber;
}
