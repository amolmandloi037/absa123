package com.absa.amol.saving.model.orderdebitcard;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(name = "OrderDebitCardDomainReq", description = "Request Schema for Order Debit Card API")
public class OrderDebitCardDomainReq {
	
	@Schema(description = "Field is optional.", pattern = "Only numeric", maxLength = 20)
	@Size(max = 20, message = "orderdebitcard.customerReference.length.error.message")
	@Pattern(regexp="[0-9]*", message="orderdebitcard.customerReference.regex.error.message")
	private String customerReference;
	
	@Valid
	@NotNull(message = "orderdebitcard.issuedDevicePropertyValue.null.error.message")
	private IssuedDevicePropertyValue issuedDevicePropertyValue;
	
	@Valid
	@NotNull(message = "orderdebitcard.locationReference.null.error.message")
	private LocationReference locationReference;
	
	@Valid
	@NotNull(message = "orderdebitcard.productInstanceReference.null.error.message")
	private ProductInstanceReference productInstanceReference;

}
