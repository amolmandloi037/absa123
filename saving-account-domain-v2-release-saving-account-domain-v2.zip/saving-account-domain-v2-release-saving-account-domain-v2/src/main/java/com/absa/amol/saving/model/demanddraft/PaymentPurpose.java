package com.absa.amol.saving.model.demanddraft;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import com.absa.amol.saving.util.Constant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class PaymentPurpose {

	@Size( max = 200, message = Constant.ADDITIONAL_INFO_LENGTH_ERROR_MESSAGE)
	@Pattern(regexp = Constant.ONLY_SPACE_CHARACTERS_REGEX, message = Constant.ADDITIONAL_INFO_PATTERN_ERROR_MESSAGE)
	@Schema(description = "Field is optional", pattern = "only characters and space", maxLength = 200)
	private String additionalInfo;
	
	@Size( max = 40, message = Constant.PAYMENT_REMARKS_LENGTH_ERROR_MESSAGE)
	@Pattern(regexp = Constant.ONLY_SPACE_CHARACTERS_REGEX, message = Constant.PAYMENT_REMARKS_PATTERN_ERROR_MESSAGE)
	@Schema(description = "Field is optional", pattern = "only characters and space", maxLength = 40)
	private String paymentRemarks;
	
	private String externalReferenceNumber;
}
