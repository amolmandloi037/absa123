package com.absa.amol.saving;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;
import org.eclipse.microprofile.openapi.annotations.OpenAPIDefinition;
import org.eclipse.microprofile.openapi.annotations.info.Info;

@OpenAPIDefinition(info = @Info(title = "Saving Account Domain API", version = "2.0.0"))
@ApplicationPath("v2/")
public class SavingAccountDomainRestApplication extends Application {
}
