package com.absa.amol.saving.model.unclearedfund;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class UnclearedFundInfo {
	/**
	 *  "currentUnclearedEffectsBal": value is not zero(0.00)
	 * EBOX system response  unclearFunds, valueDate,unclClearDays
	 *  
	 *   "currentEarmarkedBal": value is not zero(0.00)
	 *   
	 * EBOX system response  earDate,earClearDate,earIndicator,earAmount,earNarrative
	 * 
	 * if both(currentUnclearedEffectsBal,currentEarmarkedBal) will be zero the empty list will populate.
	 * 
	 * FCR system response unclearAmount,unclearDate
	 */
	private BigDecimal unclearAmount;
	private String unclearDate;
	private String earDate;
	private String earClearDate;
	private String earIndicator;
	private BigDecimal earAmount;
	private String earNarrative;
	private Integer unclClearDays;

}
