package com.absa.amol.saving.model.unclearedfund;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.ws.rs.BeanParam;
import javax.ws.rs.QueryParam;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import com.absa.amol.util.model.ApiRequestHeader;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Schema(name = "UnclearFundDetailsRequest", description = "POJO that represents Unclear Fund Details request")
public class UnclearFundDetailsRequest {

	@Valid
	@BeanParam
	private ApiRequestHeader apiRequestHeader;

	@NotNull(message = "accountNumber.nullOrEmpty.message")
	@NotEmpty(message = "accountNumber.nullOrEmpty.message")
	@Pattern(regexp = "[0-9]{1,16}", message = "accountNumber.pattern.message")
	@Schema(description = "Field is mandatory for all flow",maxLength = 16,required = true)
	@QueryParam(value = "accountNumber")
	private String accountNumber; 
 
	@Size(max = 3, message = "branchCode.size.error.message")
	@Pattern(regexp = "^$|[0-9]+", message = "currentbranchCode.pattern.message")
	@Schema(description = "Field is optional",maxLength = 3)
	@QueryParam(value = "branchCode")
	private String branchCode;  
}
