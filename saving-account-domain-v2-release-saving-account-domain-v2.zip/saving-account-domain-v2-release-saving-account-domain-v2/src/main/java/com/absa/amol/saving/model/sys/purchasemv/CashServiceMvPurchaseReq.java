package com.absa.amol.saving.model.sys.purchasemv;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(name = "CashServiceMvPurchaseReq", description = "Request Schema for money voucher purchase")
public class CashServiceMvPurchaseReq {
	private String creatorMobile;
	private String operationId;
	private String creatorAccount;
	private String recipientMobile;
	private String voucherValue;
	private String voucherValueCurrency;
	private String voucherPinblock;
	private String voucherPin;

}
