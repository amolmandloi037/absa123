package com.absa.amol.saving.service.updateaccountstatus;

import com.absa.amol.saving.model.updateaccountstatus.UpdateAccountStatusDomainReqWrapper;
import com.absa.amol.saving.model.updateaccountstatus.UpdateAccountStatusDomainRes;
import com.absa.amol.util.model.ResponseEntity;

public interface UpdateAccountStatusService {

	public ResponseEntity<UpdateAccountStatusDomainRes> getUpdateAccStsResponse(UpdateAccountStatusDomainReqWrapper domainReqWrapper);
}
