package com.absa.amol.saving.util;

import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import com.absa.amol.saving.model.AccountArrangementRequest;
import com.absa.amol.saving.model.ArrangementResponse;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.model.ResponseEntity;

@RegisterRestClient(configKey = "updateAccount")
@RegisterProvider(ServerSideExceptionMapper.class)
public interface SavingsAccountUpdateClient {

  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  public ResponseEntity<ArrangementResponse> updateAccountArrangement(
		  @BeanParam ApiRequestHeader apiRequestHeader, @RequestBody AccountArrangementRequest request);
}