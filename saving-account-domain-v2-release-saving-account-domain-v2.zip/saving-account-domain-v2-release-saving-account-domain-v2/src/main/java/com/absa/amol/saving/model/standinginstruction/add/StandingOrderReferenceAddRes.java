package com.absa.amol.saving.model.standinginstruction.add;

import javax.json.bind.annotation.JsonbProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StandingOrderReferenceAddRes {

	@JsonbProperty(nillable = true)
	private Integer standingOrderNumber;

}
