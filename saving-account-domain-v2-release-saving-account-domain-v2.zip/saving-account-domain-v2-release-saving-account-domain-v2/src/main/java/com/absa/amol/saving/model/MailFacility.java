package com.absa.amol.saving.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class MailFacility {
  private boolean additionalAddressFlag;
  private boolean holdMailFlag;
  private String mailFacilityMailControl;
}
