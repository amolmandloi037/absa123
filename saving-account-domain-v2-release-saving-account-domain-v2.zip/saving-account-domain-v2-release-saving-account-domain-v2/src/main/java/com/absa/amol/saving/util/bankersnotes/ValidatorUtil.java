package com.absa.amol.saving.util.bankersnotes;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.eclipse.microprofile.config.Config;

import com.absa.amol.saving.model.bankersnotes.BankersNotesDomainRequest;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.exception.ApiRequestException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.utility.CommonUtil;
import com.absa.amol.util.utility.StringUtil;


@ApplicationScoped
public class ValidatorUtil {

	public static final String AMOUNT_REGEX = "(^$)|(^[-0-9]{1,12}(?:\\.[0-9]{1,2})?$)";
	@Inject
	private Validator validator;

	@Inject
	Config config;

	private static final Logger LOGGER = LoggerFactory.getLogger(ValidatorUtil.class);

	public <T>void validateInputRequest(T request,ApiRequestHeader apiRequestHeader,Class<?> ...groups) {
		Set<String> errorSet = validatedAnnotedBeans(apiRequestHeader,groups);
		errorSet.addAll(validatedAnnotedBeans(request,groups));
		if (!errorSet.isEmpty()) {
			String errorMessage = String.join(",", errorSet);
			//LOGGER.error("validateInputRequest", apiRequestHeader.getCorrelationId(), "Validation failed:", errorMessage);
			throw new ApiRequestException(CreditCardTransactionConstant.BAD_REQUEST_CODE, errorMessage);
		}
	}

	public Set<String> customValidatedAnnotedBeans(Object obj) {
		Set<ConstraintViolation<Object>> violations = validator.validate(obj);
		return violations.stream().map(constraint -> {
			String customErroMsg = getPropertyValue(constraint.getMessageTemplate());
			return StringUtil.isStringNullOrEmpty(customErroMsg) ? constraint.getMessage()
					: customErroMsg;
		}).collect(Collectors.toSet());
	}

	public <T>void validateInputRequest(T request,Class<?> ...groups) {
		Set<String> errorSet = validatedAnnotedBeans(groups);
		errorSet.addAll(validatedAnnotedBeans(request,groups));
		errorSet.addAll(customvalidatedBeans((BankersNotesDomainRequest) request));
		if (!errorSet.isEmpty()) {
			String errorMessage = String.join(",", errorSet);
			LOGGER.error("validateInputRequest", "", "Validation failed:", errorMessage);
			throw new ApiRequestException(CreditCardTransactionConstant.BAD_REQUEST_CODE, errorMessage);
		}
	}

	private Set<String> customvalidatedBeans(BankersNotesDomainRequest req) {

		LOGGER.info(Constant.CUSTOMVALIDATED_BEANS, Constant.EMPTY,Constant.EMPTY, Constant.EMPTY);
		Set<String> customValErrSet = new HashSet<>();
			
			if (CommonUtil.isNotNull(req)) {
				if(StringUtil.isStringNotNullAndNotEmpty(req.getSavingAccountNumber()) && 
						req.getSavingAccountNumber().split(Constant.ZERO_STRING, -1).length-1 == req.getSavingAccountNumber().length()) {
					customValErrSet.add(getPropertyValue(Constant.SAVING_ACCOUNT_NUMBER_ALL_ZEROES_ERROR_MSG));
				}
				if(StringUtil.isStringNotNullAndNotEmpty(req.getBranchCode()) 
						&&  req.getBranchCode().split(Constant.ZERO_STRING, -1).length-1 == req.getBranchCode().length()){
					customValErrSet.add(getPropertyValue(Constant.SAVING_BANK_BRANCH_ALL_ZEROES_ERROR_MSG));
				}
			}
		
		return customValErrSet;
	}

	private <T>Set<String> validatedAnnotedBeans(T request,Class<?>... groups) {
		Set<ConstraintViolation<Object>> violations = validator.validate(request,groups);
		return violations.stream().map(constraint -> {
			String customErroMsg = getPropertyValue(constraint.getMessageTemplate());
			return StringUtil.isStringNullOrEmpty(customErroMsg) ? constraint.getMessage()
					: customErroMsg;
		}).collect(Collectors.toSet());
	}

	private String getPropertyValue(String confkey) {
		try {
			return config.getValue(confkey, String.class);
		} catch (Exception e) {
			LOGGER.error("getPropertyValue", "", "Exception while reading property for the key ::" + confkey, e.getMessage());
		}
		return "";
	}

}
