package com.absa.amol.saving.model.orderpaperstmt;

import javax.ws.rs.BeanParam;
import javax.ws.rs.QueryParam;
import com.absa.amol.util.model.ApiRequestHeader;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class OrderPaperStmtSystemRequest {
  @BeanParam
  private ApiRequestHeader apiRequestHeader;

  @QueryParam("customerNumber")
  private String customerNumber;

  @QueryParam("accountId")
  private String accountId;

  @QueryParam("branchCode")
  private String branchCode;

  @QueryParam("fromDate")
  private String fromDate;

  @QueryParam("toDate")
  private String toDate;

  public OrderPaperStmtSystemRequest(OrderPaperStmtDomainRequest domainReq) {
    super();
    this.apiRequestHeader = domainReq.getApiRequestHeader();
    this.customerNumber = domainReq.getCustomerNumber();
    this.accountId = domainReq.getAccountId();
    this.branchCode = domainReq.getBranchCode();
    this.fromDate = domainReq.getFromDate();
    this.toDate = domainReq.getToDate();
  }
}
