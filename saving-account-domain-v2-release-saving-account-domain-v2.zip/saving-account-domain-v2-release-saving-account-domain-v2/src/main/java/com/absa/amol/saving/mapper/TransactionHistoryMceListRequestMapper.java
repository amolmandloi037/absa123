package com.absa.amol.saving.mapper;

import com.absa.amol.saving.model.CorpuserFTListRequest;
import com.absa.amol.saving.model.TransactionHistoryDomainRequest;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.utility.StringUtil;

public class TransactionHistoryMceListRequestMapper {
  private static final Logger LOGGER =
      LoggerFactory.getLogger(TransactionHistoryMceListRequestMapper.class);

  public CorpuserFTListRequest fundsTransferListReqMapper(ApiRequestHeader apiRequestHeader,
      TransactionHistoryDomainRequest request) {
    LOGGER.info("SavingAccountDomainMceRequestMapper",
        Constant.getConsumerUniqueReferenceId(apiRequestHeader),
        "start of  Mce request mapper Method", "");

    CorpuserFTListRequest corpuserFTListRequest = new CorpuserFTListRequest();

    corpuserFTListRequest.setApiRequestHeader(apiRequestHeader);
    corpuserFTListRequest.setUserID(request.getUserId());
    corpuserFTListRequest.setAccountNumber(request.getSavingsAccountNumber());
    corpuserFTListRequest.setTransactionSearchTypeCode(request.getTransactionSearchTypeCode());
    if (StringUtil.isStringNotNullAndNotEmpty(request.getNumberOfRecordsPerPage())) {
      corpuserFTListRequest.setNumberOfRecordsPerPage(request.getNumberOfRecordsPerPage());
    } else {
      corpuserFTListRequest.setNumberOfRecordsPerPage("40");
    }
    if (StringUtil.isStringNotNullAndNotEmpty(request.getNumberOfRecordsPerPage())) {
      corpuserFTListRequest.setPageNumber(request.getPageNumber());
    } else {
      corpuserFTListRequest.setPageNumber("1");
    }

    LOGGER.info("TransactionHistoryMceListRequestMapper",
        Constant.getConsumerUniqueReferenceId(apiRequestHeader), "MCE request mapper Method",
        corpuserFTListRequest.toString());
    return corpuserFTListRequest;
  }

}
