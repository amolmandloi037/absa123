package com.absa.amol.saving.model.standinginstruction.retrieve;

import javax.json.bind.annotation.JsonbProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StandingInstructionSummaryRetRes {
	@JsonbProperty(nillable = true) private String accountNumber;
	@JsonbProperty(nillable = true) private String paymentType;
	@JsonbProperty(nillable = true) private String bankBranch;
	@JsonbProperty(nillable = true) private String accountCurrency;
	@JsonbProperty(nillable = true) private String originatorName;
	@JsonbProperty(nillable = true) private StandingOrderReferenceRetRes standingOrderReference;
	@JsonbProperty(nillable = true) private PaymentTransactionRetRes paymentTransaction;
	@JsonbProperty(nillable = true) private PaymentScheduleRetRes paymentSchedule;
}