package com.absa.amol.saving.model.sys.accountsnickname.retrieve;

import java.util.Date;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Schema(name = "CustAcctNicknameMceResponse", description = "Customer details Schema of the system adapter")
public class RetrieveAccountsNickNameSystemRes
{
	private String accountNumber;
	
	private String accountNickName;
	
	private Integer branchCode;
	
	private String creditCardFlag;
	
	private String createdby;
	
	private Date createDateTime; 
	
	private String lastMaintainedByUserID;
	
	private Date lastMaintainedDateTime; 

}
