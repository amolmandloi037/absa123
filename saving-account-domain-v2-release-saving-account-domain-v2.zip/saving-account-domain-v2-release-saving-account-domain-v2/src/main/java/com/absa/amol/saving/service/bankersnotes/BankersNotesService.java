package com.absa.amol.saving.service.bankersnotes;

import com.absa.amol.saving.model.bankersnotes.AccountNotes;
import com.absa.amol.saving.model.bankersnotes.BankersNotesDomainRequest;
import com.absa.amol.util.model.ResponseEntity;

public interface BankersNotesService {
	public ResponseEntity<AccountNotes>  retrieveBankersNotesDetails(BankersNotesDomainRequest bankersNotesDomainRequest);
}
