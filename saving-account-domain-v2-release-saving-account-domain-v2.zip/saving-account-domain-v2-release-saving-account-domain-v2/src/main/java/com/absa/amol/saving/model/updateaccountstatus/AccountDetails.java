package com.absa.amol.saving.model.updateaccountstatus;

import javax.validation.constraints.Pattern;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class AccountDetails {

	@Schema(description = "Conditional mandatory")
	private String premierMembershipCentreCode;
	@Schema(description = "Conditional mandatory")
	@Pattern(regexp = "[YN]", message = "premierMembershipFeeIndicator.pattern.message")
	private String premierMembershipFeeIndicator;
}
