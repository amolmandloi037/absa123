package com.absa.amol.saving.model.accountsnickname.add;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(name = "AddAccountsNickNameReq", description = "Request Schema for Add Account NickName API")
public class AddAccountsNickNameReq {
	
	@Schema(description = "Field is mandatory.", pattern = "Only numeric", maxLength = 12, required = true)
	@NotEmpty(message = "addcustnickname.customerReference.nullorempty.error.message")
	@NotNull(message = "addcustnickname.customerReference.nullorempty.error.message")
	@Size(max = 12, message = "addcustnickname.customerReference.length.error.message")
	@Pattern(regexp="[0-9]*", message="addcustnickname.customerReference.regex.error.message")
	private String customerReference;
	
	@Schema(description = "Field is mandatory.", pattern = "Only numeric", maxLength = 7, required = true)
	@NotNull(message = "addcustnickname.bankBranchCode.nullorempty.error.message")
	@Min(value = 1, message = "addcustnickname.bankBranchCode.size.error.message")
	@Max(value = 9999999, message = "addcustnickname.bankBranchCode.size.error.message")
    private Integer bankBranchCode;
	
	@Schema(description = "Field is mandatory.", pattern = "Only numeric", minLength = 1, maxLength = 22, required = true)
	@NotEmpty(message = "addcustnickname.accountNumber.nullorempty.error.message")
	@NotNull(message = "addcustnickname.accountNumber.nullorempty.error.message")
	@Pattern(regexp = "^[0-9]*", message = "addcustnickname.accountNumber.pattern.error.message")
	@Size(min=1, max = 22, message = "addcustnickname.accountNumber.size.error.message")
    private String accountNumber;
    
	@Schema(description = "Field is mandatory.", maxLength = 100, required = true)
	@NotEmpty(message = "addcustnickname.accountNickName.nullorempty.error.message")
    @NotNull(message = "addcustnickname.accountNickName.nullorempty.error.message")
    @Size(max = 100, message = "addcustnickname.accountNickName.size.error.message")
    private String accountNickName;

}
