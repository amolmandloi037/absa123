package com.absa.amol.saving.model.standinginstruction.add;

import java.math.BigDecimal;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StandingOrderReferenceAddReq {

	private Boolean forceDebitAllowedFlag;
	private String priority;
	private Integer standingOrderNumber;
	private Integer retryCount;
	private String noOfPayments;
	private BigDecimal terminationAmount;
	private String executionDate;
	
	@Schema(description = "Field is mandatory for all flows.", required = true)
	private String calendarFlag;

}
