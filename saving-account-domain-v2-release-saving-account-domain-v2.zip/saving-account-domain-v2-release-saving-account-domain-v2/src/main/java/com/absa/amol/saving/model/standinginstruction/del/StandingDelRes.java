package com.absa.amol.saving.model.standinginstruction.del;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(name = "Delete Standing Instruction Response", description = "Response Schema for Delete Standing Instruction")
public class StandingDelRes {

	private PaymentTransactionDelRes paymentTransaction;
	private StandingOrderReferenceDelRes standingOrderReference;
}
