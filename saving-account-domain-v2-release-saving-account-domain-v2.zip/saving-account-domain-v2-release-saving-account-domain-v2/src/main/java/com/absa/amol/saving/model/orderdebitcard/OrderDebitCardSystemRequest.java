package com.absa.amol.saving.model.orderdebitcard;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.ws.rs.BeanParam;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import com.absa.amol.util.model.ApiRequestHeader;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class OrderDebitCardSystemRequest {

	@Valid
	@BeanParam
	@Schema(hidden = true)
	private ApiRequestHeader apiRequestHeader;

	@NotNull(message = "cardNumber.noempty.error.message")
	@NotEmpty(message = "cardNumber.noempty.error.message")
	private String cardNumber; 

	@NotNull(message = "cardBranch.noempty.error.message")
	@NotEmpty(message = "cardBranch.noempty.error.message")
	private String cardBranch;

	@NotNull(message = "embossedName.noempty.error.message")
	@NotEmpty(message = "embossedName.noempty.error.message")
	private String embossedName;

	@NotNull(message = "postalAddress.noempty.error.message")
	private PostalAddressSystemRequest postalAddress;

	@NotNull(message = "accountNumber.noempty.error.message")
	@NotEmpty(message = "accountNumber.noempty.error.message")
	private String accountNumber; 

	@NotNull(message = "productCode.noempty.error.message")
	@NotEmpty(message = "productCode.noempty.error.message")
	private String productCode;

	@NotNull(message = "customerNumber.noempty.error.message")
	@NotEmpty(message = "customerNumber.noempty.error.message")
	private String customerNumber;

	@Schema(hidden = true)
	private String configuredChannelId;

}
