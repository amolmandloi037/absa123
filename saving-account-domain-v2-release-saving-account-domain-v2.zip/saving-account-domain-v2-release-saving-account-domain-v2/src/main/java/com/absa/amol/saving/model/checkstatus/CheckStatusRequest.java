package com.absa.amol.saving.model.checkstatus;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.ws.rs.BeanParam;
import javax.ws.rs.QueryParam;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import com.absa.amol.util.model.ApiRequestHeader;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Schema(name = "CheckStatusRequest",
description = "Request Schema For CheckS tatus")
public class CheckStatusRequest {

	@Valid
	@BeanParam
	private ApiRequestHeader apiRequestHeader;

	@Schema(description = "Field is mandatory for all flows.", pattern = "Only numeric",
		      minLength = 1, maxLength = 16, required = true)
	@NotNull(message = "check.status.savingsAccountNumber.noempty.error.message")
	@NotEmpty(message = "check.status.savingsAccountNumber.noempty.error.message")
	@Pattern(regexp = "^[0-9]*", message = "check.status.savingsAccountNumber.digit.error.message")
	@Size(min = 1, max = 16, message = "check.status.savingsAccountNumber.length.error.message")
	@QueryParam("savingsAccountNumber")
	private String savingsAccountNumber;
	
	
	@Schema(description = "Field is mandatory for all flows.", pattern = "Only numeric",
		      minLength = 1, maxLength = 16, required = true)
	@NotNull(message = "issuedDevicePropertyValue.noempty.error.message")
	@NotEmpty(message = "issuedDevicePropertyValue.noempty.error.message")
	@Pattern(regexp = "^[0-9]*", message = "issuedDevicePropertyValue.digit.error.message")
	@Size(min = 1, max = 16, message = "issuedDevicePropertyValue.length.error.message")
	@QueryParam("issuedDevicePropertyValue")
	private String issuedDevicePropertyValue;
}
