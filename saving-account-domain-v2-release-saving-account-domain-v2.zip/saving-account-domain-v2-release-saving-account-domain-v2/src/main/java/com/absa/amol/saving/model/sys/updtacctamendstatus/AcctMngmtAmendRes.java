package com.absa.amol.saving.model.sys.updtacctamendstatus;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AcctMngmtAmendRes {

	private ResponseStatusAmend responseStatusAmend;
	
}
