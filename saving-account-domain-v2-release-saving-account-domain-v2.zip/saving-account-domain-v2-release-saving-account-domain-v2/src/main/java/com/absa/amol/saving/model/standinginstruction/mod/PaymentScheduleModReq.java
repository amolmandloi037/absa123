package com.absa.amol.saving.model.standinginstruction.mod;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentScheduleModReq {

	private BigDecimal firstPaymentAmount;

	private BigDecimal lastPaymentAmount;

	private String nextExecutionDate;

	private Integer dayOfTheMonth;

	private String endDate;

	private String frequency;

	private String lastRetryDate;

	private String startDate;

	private Integer paymentDurationType;

}
