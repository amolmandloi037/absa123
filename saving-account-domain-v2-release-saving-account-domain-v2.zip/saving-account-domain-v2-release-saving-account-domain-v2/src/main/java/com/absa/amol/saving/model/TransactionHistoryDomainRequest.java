package com.absa.amol.saving.model;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.ws.rs.BeanParam;
import javax.ws.rs.QueryParam;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import com.absa.amol.util.model.ApiRequestHeader;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Schema(name = "TransactionHistoryRequest",
    description = "POJO that represents Transaction History details")
@ValidDateRange(message = "invalid.daterange.error.message")
@ValidAmounts(message = "invalid.amountrange.error.message")
public class TransactionHistoryDomainRequest {
  @BeanParam
  @Valid
  private ApiRequestHeader apiRequestHeader;

  @QueryParam("actionCode")
  private String actionCode;

  @Pattern(regexp = "^[0-9]*", message = "accountNumber.th.pattern.message")
  @Size(max = 16, message = "accountNumber.th.size.error.message")
  @QueryParam("accountNumber")
  private String savingsAccountNumber;


  @Size(max = 3, message = "branchCode.th.size.error.message")
  @QueryParam("branchCode")
  private String branchCode;


  @Date(message = "startDate.invalid.error.message", format = "yyyyMMdd")
  @Pattern(regexp = "^[0-9]*", message = "startDate.pattern.error.message")
  @QueryParam("startDate")
  private String startDate;


  @Date(message = "endDate.invalid.error.message", format = "yyyyMMdd")
  @Pattern(regexp = "^[0-9]*", message = "endDate.pattern.error.message")
  @QueryParam("endDate")
  private String endDate;

  @Pattern(regexp = "(^$)|(^[-0-9]{1,15}(?:\\.[0-9]{1,7})?$)",
      message = "amountStart.pattern.error.message")
  @QueryParam("amountStart")
  private String amountStart;

  @Pattern(regexp = "(^$)|(^[-0-9]{1,15}(?:\\.[0-9]{1,7})?$)",
      message = "amountEnd.pattern.error.message")
  @QueryParam("amountEnd")
  private String amountEnd;


  @Size(max = 30, message = "transactionRefNumber.size.error.message")
  @QueryParam("transactionRefNumber")
  private String transactionRefNumber;

  @QueryParam("filterCriteria")
  private String filterCriteria;

  @Size(max = 40, message = "userId.size.error.message")
  @QueryParam("userId")
  private String userId;

  @Size(max = 30, message = "transactionSearchTypeCode.size.error.message")
  @QueryParam("transactionSearchTypeCode")
  private String transactionSearchTypeCode;

  @QueryParam("numberOfRecordsPerPage")
  private String numberOfRecordsPerPage;

  @QueryParam("pageNumber")
  private String pageNumber;

  // @QueryParam("pageSize")
  // private String pageSize;

  @QueryParam("debitCreditIndicator")
  private String debitCreditIndicator;



}
