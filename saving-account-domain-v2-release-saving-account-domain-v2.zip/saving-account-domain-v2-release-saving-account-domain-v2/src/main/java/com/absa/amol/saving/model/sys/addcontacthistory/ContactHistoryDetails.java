package com.absa.amol.saving.model.sys.addcontacthistory;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ContactHistoryDetails {
	
	private String customerId;

	private String activityId;

	private String activityName;

	private String dataOne;

	private String dataTwo;

}
