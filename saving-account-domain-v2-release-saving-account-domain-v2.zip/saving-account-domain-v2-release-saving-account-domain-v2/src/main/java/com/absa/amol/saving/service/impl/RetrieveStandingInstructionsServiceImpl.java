package com.absa.amol.saving.service.impl;

import javax.inject.Inject;

import org.eclipse.microprofile.rest.client.inject.RestClient;

import com.absa.amol.saving.model.standinginstruction.retrieve.StandingInstructionsRetReq;
import com.absa.amol.saving.model.standinginstruction.retrieve.StandingInstructionsRetRes;
import com.absa.amol.saving.service.RetrieveStandingInstructionsService;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.saving.util.RetrieveStandingInstructionsClientBuilder;
import com.absa.amol.util.exception.ApiException;
import com.absa.amol.util.exception.ApiResponseException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ResponseEntity;

public class RetrieveStandingInstructionsServiceImpl implements RetrieveStandingInstructionsService {

	@Inject @RestClient RetrieveStandingInstructionsClientBuilder clientBuilder;
	private static final Logger LOGGER = LoggerFactory.getLogger(RetrieveStandingInstructionsServiceImpl.class);

	@Override
	public ResponseEntity<StandingInstructionsRetRes> retrieveStandingInstructions(StandingInstructionsRetReq standingInstructionsRetReq) {
		String method = "retrieveStandingInstructions";
		String uniqueRefId = null;
		try {
			uniqueRefId = standingInstructionsRetReq.getApiRequestHeader().getConsumerUniqueReferenceId();
			LOGGER.info(method, uniqueRefId, "message", "**-- inside retrieveStandingInstructions --**");
			return clientBuilder.retrieveStandingInstructions(standingInstructionsRetReq);
		} catch (ApiException apiException) {
			LOGGER.error(method, uniqueRefId, "ApiException", apiException.getMessage());
			LOGGER.debug(method, uniqueRefId, "ApiException Occurred", apiException);
			throw apiException;
		} catch (Exception exception) {
			LOGGER.error(method, uniqueRefId, "Exception", exception.getMessage());
			LOGGER.debug(method, uniqueRefId, "Exception Occurred", exception);
			throw new ApiResponseException(Constant.INTERNAL_ERROR_CODE, Constant.INTERNAL_ERROR_MSG);
		}
	}
}