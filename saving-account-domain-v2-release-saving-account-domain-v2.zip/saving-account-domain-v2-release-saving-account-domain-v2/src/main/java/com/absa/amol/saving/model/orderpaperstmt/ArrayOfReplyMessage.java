package com.absa.amol.saving.model.orderpaperstmt;

import java.util.List;
import javax.json.bind.annotation.JsonbNillable;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonbNillable
public class ArrayOfReplyMessage {
  private List<SystemReplyMessage> item;
}
