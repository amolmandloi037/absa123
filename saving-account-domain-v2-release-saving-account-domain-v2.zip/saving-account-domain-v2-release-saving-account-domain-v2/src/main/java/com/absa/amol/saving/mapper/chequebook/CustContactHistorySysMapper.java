package com.absa.amol.saving.mapper.chequebook;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.eclipse.microprofile.config.Config;

import com.absa.amol.saving.model.chequebook.ChequeBookDomainReqWrapper;
import com.absa.amol.saving.model.sys.addcontacthistory.AddContactHistoryRequest;
import com.absa.amol.saving.model.sys.addcontacthistory.ContactHistoryDetails;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;

public class CustContactHistorySysMapper {
	private static final Logger LOGGER = LoggerFactory.getLogger(CustContactHistorySysMapper.class);
	
	@Inject
	Config config;
	
	public AddContactHistoryRequest addContactHistorySysReqMapping(ChequeBookDomainReqWrapper chequeBookDomainReqWrapper) {
		LOGGER.info("addContactHistorySysReqMapping",
				chequeBookDomainReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(),
				Constant.EMPTY, " executed");
		
		AddContactHistoryRequest addContactHistoryRequest = new AddContactHistoryRequest();
		ContactHistoryDetails contactHistoryDetails = new ContactHistoryDetails();
		List<ContactHistoryDetails> contactHistoryDetailsList = new ArrayList<>();
		contactHistoryDetails.setActivityId(config.getValue("cheque.book.contacthist.activityId", String.class));
		contactHistoryDetails.setActivityName(config.getValue("cheque.book.contacthist.activityName", String.class));
		contactHistoryDetails.setCustomerId(chequeBookDomainReqWrapper.getChequeBookDomainReq().getCustomerReference());
		contactHistoryDetails.setDataOne(null);
		contactHistoryDetails.setDataTwo(null);
		contactHistoryDetailsList.add(contactHistoryDetails);
		addContactHistoryRequest.setContactHistoryDetails(contactHistoryDetailsList);
		
		return addContactHistoryRequest;
	}

}
