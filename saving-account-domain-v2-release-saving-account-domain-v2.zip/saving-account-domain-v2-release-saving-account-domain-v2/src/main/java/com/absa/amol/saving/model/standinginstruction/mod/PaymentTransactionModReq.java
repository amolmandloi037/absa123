package com.absa.amol.saving.model.standinginstruction.mod;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentTransactionModReq {

	private BigDecimal amount;

	private String currency;

	private PayeeAccountReferenceModReq payeeAccountReference;
	private PayeeBankReferenceModReq payeeBankReference;
	private PayeeReferenceModReq payeeReference;
	private PaymentPurposeModReq paymentPurpose;

}
