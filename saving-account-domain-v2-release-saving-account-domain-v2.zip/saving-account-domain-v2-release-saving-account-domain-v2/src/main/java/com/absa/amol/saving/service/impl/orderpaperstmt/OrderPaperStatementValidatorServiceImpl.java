package com.absa.amol.saving.service.impl.orderpaperstmt;

import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import org.eclipse.microprofile.config.Config;
import com.absa.amol.saving.model.orderpaperstmt.OrderPaperStmtDomainRequest;
import com.absa.amol.saving.service.orderpaperstmt.OrderPaperStatementValidatorService;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.exception.ApiRequestException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.utility.StringUtil;

public class OrderPaperStatementValidatorServiceImpl
    implements OrderPaperStatementValidatorService {

  private static final Logger logger =
      LoggerFactory.getLogger(OrderPaperStatementValidatorServiceImpl.class);

  @Inject
  private Validator validator;

  @Inject
  Config config;

  @Override
  public void validateOrderPaperStmtRequest(OrderPaperStmtDomainRequest req) {
    final String method_name = "validateOrderPaperStmtRequest";
    ApiRequestHeader header = req.getApiRequestHeader();
    logger.info(method_name, getConsumerUniqRefId(header), "Validating the request", "");
    Set<String> errorList = validatedAnnotedBeans(req);
    if (!errorList.isEmpty()) {
      String errorMessage = String.join(",", errorList);
      ApiRequestException exception =
          new ApiRequestException(Constant.BAD_REQUEST_CODE, errorMessage);
      logger.error(method_name, getConsumerUniqRefId(header), "Validation failed:",
          exception.getErrorMessage());
      throw exception;
    }
    logger.info(method_name, getConsumerUniqRefId(header), "No validation errors found", "");
  }

  private Set<String> validatedAnnotedBeans(Object req) {
    Set<ConstraintViolation<Object>> violations = validator.validate(req);
    return violations.stream().map(constraint -> {
      String customErroMsg = getPropertyValue(constraint.getMessageTemplate());
      return StringUtil.isStringNullOrEmpty(customErroMsg) ? constraint.getMessage()
          : customErroMsg;
    }).collect(Collectors.toSet());
  }

  private String getPropertyValue(String confKey) {
    try {
      return config.getValue(confKey, String.class);
    } catch (Exception e) {
      logger.error("getPropertyValue", "",
          "Exception while reading property for the key ::" + confKey, e.getMessage());
      return confKey;
    }
  }

  private String getConsumerUniqRefId(ApiRequestHeader header) {
    if (!Objects.isNull(header) && !Objects.isNull(header.getConsumerUniqueReferenceId())) {
      return header.getConsumerUniqueReferenceId();
    }
    return "";
  }
}
