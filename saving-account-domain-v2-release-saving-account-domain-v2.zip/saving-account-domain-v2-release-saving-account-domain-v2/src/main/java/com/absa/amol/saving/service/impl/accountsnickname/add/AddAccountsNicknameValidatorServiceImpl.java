package com.absa.amol.saving.service.impl.accountsnickname.add;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.eclipse.microprofile.config.Config;

import com.absa.amol.saving.model.accountsnickname.add.AddAccountsNickNameReq;
import com.absa.amol.saving.service.accountsnickname.add.IAccountsNicknameValidatorService;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.exception.ApiRequestException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.utility.CommonUtil;
import com.absa.amol.util.utility.StringUtil;

@ApplicationScoped
public class AddAccountsNicknameValidatorServiceImpl implements IAccountsNicknameValidatorService{

	@Inject
	private Validator validator;

	@SuppressWarnings("cdi-ambiguous-dependency")
	@Inject
	Config config;

	private static final Logger LOGGER = LoggerFactory.getLogger(AddAccountsNicknameValidatorServiceImpl.class);

	public <T>void validateInputRequest(T request,ApiRequestHeader apiRequestHeader) {
		Set<String> errSet = validatedAnnotedBeans(apiRequestHeader);
		errSet.addAll(validatedAnnotedBeans(request));
		errSet.addAll(customvalidatedBeans((AddAccountsNickNameReq) request));
		if (!errSet.isEmpty()) {
			String errorMsg = String.join(",", errSet);
			LOGGER.error("validateInputRequest", apiRequestHeader.getConsumerUniqueReferenceId(), "Validation failed:", errorMsg);
			throw new ApiRequestException(Constant.BAD_REQUEST_CODE, errorMsg);
		}
	}

	private <T>Set<String> validatedAnnotedBeans(T request) {
		Set<ConstraintViolation<Object>> violations = validator.validate(request);
		return violations.stream().map(constraint -> {
			String customErroMsg = getPropertyValue(constraint.getMessageTemplate());
			return StringUtil.isStringNullOrEmpty(customErroMsg) ? constraint.getMessage() : customErroMsg;
		}).collect(Collectors.toSet());
	}
	
	private Set<String> customvalidatedBeans(AddAccountsNickNameReq addAccountsNickNameReq) {

		LOGGER.info(Constant.CUSTOMVALIDATED_BEANS, Constant.BLANK,Constant.BLANK, Constant.BLANK);
		Set<String> customValErrSet = new HashSet<>();
			if (StringUtil.isStringNotNullAndNotEmpty(addAccountsNickNameReq.getCustomerReference()) && 
					addAccountsNickNameReq.getCustomerReference().split(Constant.ZERO_STRING, -1).length-1 == addAccountsNickNameReq.getCustomerReference().length()) {
				customValErrSet.add(getPropertyValue(Constant.CUSTOMER_REFERENCE_ALL_ZEROES_ERROR_MSG));
			}
			if (CommonUtil.isNotNull(addAccountsNickNameReq)) {
				if(StringUtil.isStringNotNullAndNotEmpty(addAccountsNickNameReq.getAccountNumber()) && 
						addAccountsNickNameReq.getAccountNumber().split(Constant.ZERO_STRING, -1).length-1 == addAccountsNickNameReq.getAccountNumber().length()) {
					customValErrSet.add(getPropertyValue(Constant.ACCOUNT_NUMBER_ALL_ZEROES_ERROR_MSG));
				}
				if(null!=addAccountsNickNameReq.getBankBranchCode() && addAccountsNickNameReq.getBankBranchCode()==0) {
					customValErrSet.add(getPropertyValue(Constant.BANK_BRANCH_ALL_ZEROES_ERROR_MSG));
				}
			}
		
		return customValErrSet;
	}

	private String getPropertyValue(String confkey) {
		String msg=null;
		try {
			msg =  config.getValue(confkey, String.class);
		} catch (Exception e) {
			LOGGER.error("getPropertyValue", "", "Exception while reading property for the key ::" + confkey, e.getMessage());
		}
		return msg;
	}

}
