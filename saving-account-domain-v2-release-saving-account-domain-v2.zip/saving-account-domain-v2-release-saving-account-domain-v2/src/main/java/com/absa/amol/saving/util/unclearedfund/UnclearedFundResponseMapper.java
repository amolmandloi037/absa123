package com.absa.amol.saving.util.unclearedfund;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import com.absa.amol.saving.model.unclearedfund.UnclearFundDetailsRequest;
import com.absa.amol.saving.model.unclearedfund.UnclearFundDetailsResponse;
import com.absa.amol.saving.model.unclearedfund.UnclearedFundDetails;
import com.absa.amol.saving.model.unclearedfund.UnclearedFundInfo;
import com.absa.amol.saving.model.unclearedfund.UnclearedFundSystemResponse;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;

public class UnclearedFundResponseMapper {

	private static final Logger LOGGER = LoggerFactory.getLogger(UnclearedFundResponseMapper.class);

	private UnclearedFundResponseMapper() {
	}

	public static UnclearFundDetailsResponse mapUnclearedFundResponse(UnclearedFundSystemResponse data,
			UnclearFundDetailsRequest unclearFundDetailsRequest) {
		LOGGER.info("mapUnclearedFundResponse",
				unclearFundDetailsRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
				"Map Response for Domain", "");
		UnclearFundDetailsResponse unclearFundDetailsResponse = new UnclearFundDetailsResponse();
		List<UnclearedFundDetails> unclearedFundDetailsList = new ArrayList<>();

		if (!data.getAccountUnclearedFundDetails().getUnclearedFundInfo().isEmpty()) {
			for (UnclearedFundInfo unclearedFundInfo : data.getAccountUnclearedFundDetails().getUnclearedFundInfo()) {
				UnclearedFundDetails unclearedFundDetails = new UnclearedFundDetails();
				unclearedFundDetails.setUnclearAmount(unclearedFundInfo.getUnclearAmount());
				unclearedFundDetails.setUnclearDate(convertDate(UnclearedFundConstant.REQ_DATE,
						UnclearedFundConstant.RES_DATE, unclearedFundInfo.getUnclearDate()));
				unclearedFundDetails.setUnclearClearingDays(unclearedFundInfo.getUnclClearDays());
				unclearedFundDetails.setEarDate(convertDate(UnclearedFundConstant.REQ_DATE,
						UnclearedFundConstant.RES_DATE, unclearedFundInfo.getEarDate()));
				unclearedFundDetails.setEARClearDate(convertDate(UnclearedFundConstant.REQ_DATE,
						UnclearedFundConstant.RES_DATE, unclearedFundInfo.getEarClearDate()));
				unclearedFundDetails.setEARNarration(unclearedFundInfo.getEarNarrative());
				unclearedFundDetails.setEARDebitCreditIndicator(unclearedFundInfo.getEarIndicator());
				unclearedFundDetails.setEarAmount(unclearedFundInfo.getEarAmount());
				unclearedFundDetailsList.add(unclearedFundDetails);
			}
		} 

		unclearFundDetailsResponse.setAccountNumber(unclearFundDetailsRequest.getAccountNumber());
		unclearFundDetailsResponse.setBranchCode(unclearFundDetailsRequest.getBranchCode());
		unclearFundDetailsResponse
				.setTransferreferenceID(unclearFundDetailsRequest.getApiRequestHeader().getConsumerUniqueReferenceId());
		if (data.getStatus() != null && data.getStatus().getExternalReferenceNo() != null) {
			unclearFundDetailsResponse.setTransferID(data.getStatus().getExternalReferenceNo());
		} else {
			unclearFundDetailsResponse
					.setTransferID(unclearFundDetailsRequest.getApiRequestHeader().getConsumerUniqueReferenceId());
		}
		unclearFundDetailsResponse.setCurrentBalance(data.getAccountUnclearedFundDetails().getCurrentActualBal());
		unclearFundDetailsResponse.setAvailableBalance(data.getAccountUnclearedFundDetails().getCurrentAvailableBal());
		unclearFundDetailsResponse.setCurrentEARBalance(data.getAccountUnclearedFundDetails().getCurrentEarmarkedBal());
		unclearFundDetailsResponse
				.setCurrentUnclearBalance(data.getAccountUnclearedFundDetails().getCurrentUnclearedEffectsBal());
		unclearFundDetailsResponse.setDebitLimit(data.getAccountUnclearedFundDetails().getDebitLimit());
		unclearFundDetailsResponse.setFutureBalanceDay1Amt(data.getAccountUnclearedFundDetails().getFutureBalance1());
		unclearFundDetailsResponse.setFutureBalanceDate1(convertDate(UnclearedFundConstant.REQ_DATE,
				UnclearedFundConstant.RES_DATE, data.getAccountUnclearedFundDetails().getFutureBalanceDate1()));
		unclearFundDetailsResponse.setFutureBalanceDay2Amt(data.getAccountUnclearedFundDetails().getFutureBalance2());
		unclearFundDetailsResponse.setFutureBalanceDate2(convertDate(UnclearedFundConstant.REQ_DATE,
				UnclearedFundConstant.RES_DATE, data.getAccountUnclearedFundDetails().getFutureBalanceDate2()));
		unclearFundDetailsResponse.setFutureBalanceDay3Amt(data.getAccountUnclearedFundDetails().getFutureBalance3());
		unclearFundDetailsResponse.setFutureBalanceDate3(convertDate(UnclearedFundConstant.REQ_DATE,
				UnclearedFundConstant.RES_DATE, data.getAccountUnclearedFundDetails().getFutureBalanceDate3()));
		unclearFundDetailsResponse.setUnclearedFundDetails(unclearedFundDetailsList);
		return unclearFundDetailsResponse;
	}

	public static String convertDate(String inputFormat, String outputFormat, String dateStr) {
		if (dateStr != null) {
			try {
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern(inputFormat);
				LocalDate outDateStr = LocalDate.parse(dateStr, formatter);
				return DateTimeFormatter.ofPattern(outputFormat).format(outDateStr);
			} catch (Exception e) {
				LOGGER.error("convertDate", "", "Error in Date format conversion", dateStr);
			}
		}
		return null;
	}
}
