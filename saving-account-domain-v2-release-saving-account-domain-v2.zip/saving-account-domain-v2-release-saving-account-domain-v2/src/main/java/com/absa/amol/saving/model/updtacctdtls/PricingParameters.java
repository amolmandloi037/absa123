package com.absa.amol.saving.model.updtacctdtls;


import javax.validation.Valid;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PricingParameters {
	
	@Valid
	private AccountDetails accountDetails;

}
