package com.absa.amol.saving.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class TaxReference {
  private boolean tdsFlag;
  private Integer taxCode1;
  private Integer taxCode2;
  private Double tdsExemptionLimitAmount2;
  private Double tdsExemptionLimitAmount1;
}
