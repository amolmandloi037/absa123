package com.absa.amol.saving.service.impl.unclearedfund;

import java.util.stream.Collectors;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.Response;

import org.eclipse.microprofile.rest.client.inject.RestClient;

import com.absa.amol.saving.model.unclearedfund.Message;
import com.absa.amol.saving.model.unclearedfund.UnclearFundDetailsRequest;
import com.absa.amol.saving.model.unclearedfund.UnclearFundDetailsResponse;
import com.absa.amol.saving.model.unclearedfund.UnclearedFundSystemResponse;
import com.absa.amol.saving.service.unclearedfund.UnclearedFundService;
import com.absa.amol.saving.util.unclearedfund.UnclearedFundClient;
import com.absa.amol.saving.util.unclearedfund.UnclearedFundConstant;
import com.absa.amol.saving.util.unclearedfund.UnclearedFundResponseMapper;
import com.absa.amol.util.exception.ApiException;
import com.absa.amol.util.exception.ApiResponseException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ResponseEntity;
import com.absa.amol.util.utility.CommonUtil;
import com.absa.amol.util.utility.StringUtil;

@ApplicationScoped
public class UnclearedFundServiceImpl implements UnclearedFundService {

	private static final Logger LOGGER = LoggerFactory.getLogger(UnclearedFundServiceImpl.class);

	@Inject
	@RestClient
	UnclearedFundClient unclearedFundClient;

	@Override
	public Response retrieveUnclearedFund(UnclearFundDetailsRequest unclearFundDetailsRequest) {

		LOGGER.info(UnclearedFundConstant.GET_UNCLEAR_FUND_DETAILS,
				unclearFundDetailsRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
				"inside Service : invoking system service client", "");
		try {
			Response response = unclearedFundClient.getUnclearedFundDetailsResponse(unclearFundDetailsRequest);
			ResponseEntity<UnclearFundDetailsResponse> casaEntity = null;
			ResponseEntity<UnclearedFundSystemResponse> entitySummar = response
					.readEntity(new GenericType<ResponseEntity<UnclearedFundSystemResponse>>() {
					});
			if (CommonUtil.isNotNull(entitySummar) && CommonUtil.isNotNull(entitySummar.getData())) {
				casaEntity = retrieveFCRResponse(entitySummar.getData(), unclearFundDetailsRequest);

			} else {
				LOGGER.info(UnclearedFundConstant.GET_UNCLEAR_FUND_DETAILS, "", "data field is empty or null", "");
				casaEntity = new ResponseEntity<>(entitySummar.getCode(), entitySummar.getMessage(),
						entitySummar.getStatus(), null);
			}

			return Response.status(Integer.parseInt(casaEntity.getCode())).entity(casaEntity).build();
		} catch (ApiException exception) {
			LOGGER.error(UnclearedFundConstant.GET_UNCLEAR_FUND_DETAILS,
					unclearFundDetailsRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
					UnclearedFundConstant.EXCEPTION_OCCURED_FROM_SERVER, exception.getErrorMessage());
			LOGGER.debug(UnclearedFundConstant.GET_UNCLEAR_FUND_DETAILS,
					unclearFundDetailsRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
					UnclearedFundConstant.EXCEPTION_OCCURED_FROM_SERVER, exception);
			throw exception;
		} catch (Exception exception) {
			LOGGER.error(UnclearedFundConstant.GET_UNCLEAR_FUND_DETAILS,
					unclearFundDetailsRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
					UnclearedFundConstant.EXCEPTION_OCCURED_FROM_SERVER, exception.getMessage());
			LOGGER.debug(UnclearedFundConstant.GET_UNCLEAR_FUND_DETAILS,
					unclearFundDetailsRequest.getApiRequestHeader().getConsumerUniqueReferenceId(),
					UnclearedFundConstant.EXCEPTION_OCCURED_FROM_SERVER, exception);
			throw new ApiResponseException("500", "Internal  Server Error");
		}
	}

	private ResponseEntity<UnclearFundDetailsResponse> retrieveFCRResponse(UnclearedFundSystemResponse data,
			UnclearFundDetailsRequest unclearFundDetailsRequest) {
		ResponseEntity<UnclearFundDetailsResponse> unclearFundDetailsResponseEntity = null;
		UnclearFundDetailsResponse unclearFundDetailsResponse = UnclearedFundResponseMapper
				.mapUnclearedFundResponse(data, unclearFundDetailsRequest);
		String msg = getConcatmessage(data);
		if (data.getStatus() != null && data.getStatus().getReplyCode() != UnclearedFundConstant.REPLY_CODE_SUCCESS) {
			if (data.getStatus().getReplyCode() == UnclearedFundConstant.REPLY_CODE_40) {
				unclearFundDetailsResponseEntity = new ResponseEntity<>(UnclearedFundConstant.SUCCESS_CODE, msg,
						UnclearedFundConstant.SUCCESS_MSG, unclearFundDetailsResponse);
			} else {
				unclearFundDetailsResponseEntity = new ResponseEntity<>(UnclearedFundConstant.BAD_REQUEST_CODE, msg,
						UnclearedFundConstant.FAILURE_MSG, unclearFundDetailsResponse);
			}
		} else if (data.getStatus() != null
				&& (data.getStatus().getStatusCode().equalsIgnoreCase(UnclearedFundConstant.STATUS_CODE_1)
						|| data.getStatus().getStatusCode().equalsIgnoreCase(UnclearedFundConstant.STATUS_CODE_2)
						|| data.getStatus().getStatusCode().equalsIgnoreCase(UnclearedFundConstant.STATUS_CODE_3))) {
			unclearFundDetailsResponseEntity = new ResponseEntity<>(UnclearedFundConstant.SUCCESS_CODE,
					data.getStatus().getStatusDesc(), UnclearedFundConstant.SUCCESS_MSG, null);
		} else if (data.getStatus() != null
				&& data.getStatus().getStatusCode().equalsIgnoreCase(UnclearedFundConstant.STATUS_CODE_4)) {
			unclearFundDetailsResponseEntity = new ResponseEntity<>(UnclearedFundConstant.SERIVCE_UN_CODE,
					data.getStatus().getStatusDesc(), UnclearedFundConstant.SERVICE_UN_MSG, null);
		}

		else {
			unclearFundDetailsResponseEntity = new ResponseEntity<>(UnclearedFundConstant.SUCCESS_CODE,
					UnclearedFundConstant.RESPONSE_SUCCESS_MESSAGE, UnclearedFundConstant.SUCCESS_MSG,
					unclearFundDetailsResponse);
		}
		return unclearFundDetailsResponseEntity;
	}

	private String getConcatmessage(UnclearedFundSystemResponse data) {
		String msg = null;
		if (null != data.getStatus() && StringUtil.isStringNotNullAndNotEmpty(data.getStatus().getReplyText())) {
			msg = data.getStatus().getReplyText();
		} else if (null != data.getStatus() && StringUtil.isStringNullOrEmpty(data.getStatus().getReplyText())&&null != data.getStatus().getExtendedReply()
				&& null != data.getStatus().getExtendedReply().getMessages()) {
		
				msg = !data.getStatus().getExtendedReply().getMessages().getItem().isEmpty()
						? data.getStatus().getExtendedReply().getMessages().getItem().stream().map(Message::getMsg)
								.collect(Collectors.joining(", "))
						: "";
		}
		return msg;
	}
}
