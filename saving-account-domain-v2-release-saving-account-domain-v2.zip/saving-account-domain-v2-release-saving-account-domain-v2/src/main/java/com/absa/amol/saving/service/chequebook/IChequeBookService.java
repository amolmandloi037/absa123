package com.absa.amol.saving.service.chequebook;

import com.absa.amol.saving.model.chequebook.ChequeBookDomainReqWrapper;
import com.absa.amol.saving.model.chequebook.ChequeBookDomainRes;
import com.absa.amol.util.model.ResponseEntity;

public interface IChequeBookService {

	public ResponseEntity<ChequeBookDomainRes> addrequestChequeBook(ChequeBookDomainReqWrapper chequeBookDomainReqWrapper);
}
