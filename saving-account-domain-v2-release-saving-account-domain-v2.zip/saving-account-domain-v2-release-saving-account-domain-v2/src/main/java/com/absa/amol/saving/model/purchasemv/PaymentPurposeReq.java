package com.absa.amol.saving.model.purchasemv;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class PaymentPurposeReq {

	@NotNull(message = "senderMobileNumber.notnullempty.error.message")
	@NotEmpty(message = "senderMobileNumber.notnullempty.error.message")
	@Pattern(regexp="[0-9]{5,10}", message="senderMobileNumber.regex.error.message")
	private String senderMobileNumber;
	
	@NotNull(message = "recipientMobileNumber.notnullempty.error.message")
	@NotEmpty(message = "recipientMobileNumber.notnullempty.error.message")
	@Pattern(regexp="[0-9+]{10,15}", message="recipientMobileNumber.regex.error.message")
	private String recipientMobileNumber;
	
	@NotNull(message = "voucherPinBlock.notnullempty.error.message")
	@NotEmpty(message = "voucherPinBlock.notnullempty.error.message")
	@Pattern(regexp="[a-zA-Z0-9]{1,20}", message="voucherPinblock.regex.error.message")
	private String voucherPinBlock;
	
	@Pattern(regexp="[0-9]{1,6}?|", message="voucherPin.regex.error.message")
	private String voucherPin;
	
}
