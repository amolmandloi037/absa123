package com.absa.amol.saving.service.impl.accountsnickname.retrieve;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.eclipse.microprofile.config.Config;

import com.absa.amol.saving.model.accountsnickname.retrieve.RetrieveAccountsNickNameReq;
import com.absa.amol.saving.service.accountsnickname.RetrieveNickNameValidatorService;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.exception.ApiRequestException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.utility.StringUtil;

public class RetrieveNickNameValidatorServiceImpl implements RetrieveNickNameValidatorService {

		
		
		@Inject
		Config config;

		@Inject
		private Validator validator;

		private static final Logger LOGGER = LoggerFactory.getLogger(RetrieveNickNameValidatorServiceImpl.class);

		@Override
		public void validateRequest(RetrieveAccountsNickNameReq retrieveAccountsNickNameReq) {
			Set<String> errorlist = validatedAnnotationBeans(retrieveAccountsNickNameReq);
			errorlist.addAll(customvalidatedBeans(retrieveAccountsNickNameReq));
			if (!errorlist.isEmpty()) {
				String errorMessage = String.join(",", errorlist);
				throw new ApiRequestException(Constant.BAD_REQUEST_CODE, errorMessage);

			}

		}

		private Set<String> validatedAnnotationBeans(RetrieveAccountsNickNameReq retrieveAccountsNickNameReq) {
			Set<ConstraintViolation<RetrieveAccountsNickNameReq>> violations = validator.validate(retrieveAccountsNickNameReq);
			return violations.stream().map(constraint -> {
				String customErroMsg = getPropertyValue(constraint.getMessageTemplate());
				return StringUtil.isStringNullOrEmpty(customErroMsg) ? constraint.getMessage() : customErroMsg;
			}).collect(Collectors.toSet());
		}
		
		
		private Set<String> customvalidatedBeans(RetrieveAccountsNickNameReq retrieveAccountsNickNameReq) {

			LOGGER.info(Constant.CUSTOMVALIDATED_BEANS, Constant.BLANK,Constant.BLANK, Constant.BLANK);
			Set<String> customValErrSet = new HashSet<>();
				if (StringUtil.isStringNotNullAndNotEmpty(retrieveAccountsNickNameReq.getCustomerReference()) && 
						retrieveAccountsNickNameReq.getCustomerReference().split(Constant.ZERO_STRING, -1).length-1 == retrieveAccountsNickNameReq.getCustomerReference().length()) {
					customValErrSet.add(getPropertyValue(Constant.CUSTOMER_REFERENCE_ALL_ZEROES_ERROR_MSG));
				}
			return customValErrSet;
		}

		private String getPropertyValue(String confKey) {
			try {
				return config.getValue(confKey, String.class);
			} catch (Exception e) {
				LOGGER.error("getPropertyValue", Constant.BLANK,
						"Exception while reading property for the key ::" + confKey, e.getMessage());
			}
			return "";
		}

	}
