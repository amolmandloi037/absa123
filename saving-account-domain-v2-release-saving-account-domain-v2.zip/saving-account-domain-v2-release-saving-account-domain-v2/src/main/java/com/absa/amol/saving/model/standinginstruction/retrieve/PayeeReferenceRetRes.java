package com.absa.amol.saving.model.standinginstruction.retrieve;

import javax.json.bind.annotation.JsonbProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PayeeReferenceRetRes {
	@JsonbProperty(nillable = true) private String beneficiaryName;
}