package com.absa.amol.saving.model;


import java.util.Objects;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;



public class AmountValidator


    implements ConstraintValidator<ValidAmounts, TransactionHistoryDomainRequest> {


  @Override


  public boolean isValid(TransactionHistoryDomainRequest request, ConstraintValidatorContext context) {


    if (Objects.isNull(request.getAmountStart()) && Objects.isNull(request.getAmountEnd())) {


      return true;


    }


    if ((Objects.nonNull(request.getAmountStart()) && Objects.nonNull(request.getAmountEnd()))


        && (validateNumber(request.getAmountStart()) && validateNumber(request.getAmountEnd()))


        && (Double.parseDouble(request.getAmountStart()) > Double


            .parseDouble(request.getAmountEnd()))) {


      return false;


    }


    if (Objects.isNull(request.getAmountStart()) || Objects.isNull(request.getAmountEnd())) {


      return false;


    }


    return true;


  }


  public boolean validateNumber(String amount) {


    return amount.matches("^[-0-9]*.?[0-9]+$");


  }


}


