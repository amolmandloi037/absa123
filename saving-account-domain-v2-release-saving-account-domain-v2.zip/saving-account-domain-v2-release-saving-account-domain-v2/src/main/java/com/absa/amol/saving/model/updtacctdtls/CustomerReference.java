package com.absa.amol.saving.model.updtacctdtls;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CustomerReference {
	
	@Min(value = 100000000 , message = "primaryCustomerReference.length.error.message")
	@Max(value = 999999999, message = "primaryCustomerReference.length.error.message")
	@NotNull( message="primaryCustomerReference.null.empty.message")
	@NotEmpty( message="primaryCustomerReference.null.empty.message")
	@Schema(description = "Mandatory field", pattern = "Numeric", maxLength = 9)
	private String primaryCustomerReference;

}
