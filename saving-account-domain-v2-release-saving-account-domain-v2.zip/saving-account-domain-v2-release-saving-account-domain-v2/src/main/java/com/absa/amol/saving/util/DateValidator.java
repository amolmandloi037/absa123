package com.absa.amol.saving.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class DateValidator implements ConstraintValidator<Date, String> {

  private String format = "yyyyMMdd";

  @Override
  public void initialize(Date date) {
    format = date.format();
  }

  @Override
  public boolean isValid(String inputDate, ConstraintValidatorContext context) {

    if (inputDate == null) {
      return true;
    }

    if (inputDate.isEmpty()) {
      return true;
    }

    try {
      DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
      LocalDate.parse(inputDate, formatter);
    } catch (Exception exception) {
      return false;
    }

    return true;
  }

}
