package com.absa.amol.saving.model.purchasemv;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Schema(name = "PurchaseMvReq", description = "Request schema for purchase money voucher")
public class PurchaseMvReq {
	
	@Valid
	private PaymentTransactionReq paymentTransaction;
	@Valid
	private PaymentTransactionAmount paymentTransactionAmount;
	
	@NotNull(message = "savingsAccountNumber.notnullempty.error.message")
	@NotEmpty(message = "savingsAccountNumber.notnullempty.error.message")
	@Pattern(regexp="[0-9]{1,19}", message="savingsAccountNumber.regex.error.message")
	private String savingsAccountNumber;
	
	
}
