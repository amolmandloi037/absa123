package com.absa.amol.saving.model.sys.updtacctamendstatus;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResponseStatusAmend {

	private Integer statusCode;

	private String statusDesc;

}
