package com.absa.amol.saving.model.standinginstruction.singledetail;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentScheduleSingleDetailResp 
{
	private String nextExecutionDate; //yyyyMMdd //earlier date
	
	private String frequency;
	
	private String startDate; //yyyyMMdd //earlier date
	
	private String endDate; //yyyyMMdd //earlier date
	
	private Boolean executionDate;  //fcr
}
