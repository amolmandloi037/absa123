package com.absa.amol.saving.service;

import com.absa.amol.saving.model.standinginstruction.singledetail.StandingInstructionSingleDetailRequest;
import com.absa.amol.saving.model.standinginstruction.singledetail.StandingInstructionSingleDetailResponse;
import com.absa.amol.util.model.ResponseEntity;

public interface IStandingInstructionSingleDetailService{

	ResponseEntity<StandingInstructionSingleDetailResponse> singleStandingInstruction(StandingInstructionSingleDetailRequest singleSIReq);

}
