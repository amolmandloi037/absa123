package com.absa.amol.saving.model.createcasaaccount;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ResponseWrapper {
  private String code;
  private String message;
  private String status;
  private CreateCasaAccountResponse createNewAcctResponse;
  private Exception exception;
}
