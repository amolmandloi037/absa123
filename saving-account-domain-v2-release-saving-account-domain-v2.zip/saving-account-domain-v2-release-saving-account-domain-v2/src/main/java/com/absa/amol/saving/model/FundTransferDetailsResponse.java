package com.absa.amol.saving.model;

import java.util.List;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import com.absa.amol.saving.util.Constant;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(name = Constant.RESP_SCHEMA_NAME, description = Constant.RESP_SCHEMA_DESC)
public class FundTransferDetailsResponse {

  private List<CorpUserFundsTransferInfoDTO> corpUserFundsTransferInfoList;
  private Integer totalCount;
  private String serviceResponseCode;
  private String errorMessage;
}
