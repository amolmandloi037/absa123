package com.absa.amol.saving.model.bankersnotes;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.ws.rs.BeanParam;
import javax.ws.rs.QueryParam;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import com.absa.amol.util.model.ApiRequestHeader;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor

@Schema(name = "BankersNotesDomainRequest",
description = "Request Schema For Bankers Notes")
public class BankersNotesDomainRequest {
	@Valid
	@BeanParam
	private ApiRequestHeader apiRequestHeader;

	
	@Schema(description = "Field is mandatory for all flows.", pattern = "Only numeric",
		      minLength = 1, maxLength = 16, required = true)
	@NotNull(message = "savingAccountNumber.noempty.error.message")
	@NotEmpty(message = "savingAccountNumber.noempty.error.message")
	@Pattern(regexp = "^[0-9]*", message = "savingAccountNumber.digit.error.message")
	@Size(min = 1, max = 16, message = "savingAccountNumber.length.error.message")
	@QueryParam("savingAccountNumber")
	private String savingAccountNumber;



	@Schema(description = "Field is conditional mandatory for Ebox/Brains flow.", maxLength = 5)
	@Size(min = 0, max = 5, message = "branchCode.length.error.message")
	@Pattern(regexp = "(^$)|^[0-9]*", message = "branchCode.digit.error.message")
	@QueryParam("branchCode") 
	private String branchCode;

}
