package com.absa.amol.saving.service.impl.unclearedfund;

import java.util.Set;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.eclipse.microprofile.config.Config;

import com.absa.amol.saving.model.unclearedfund.UnclearFundDetailsRequest;
import com.absa.amol.saving.service.unclearedfund.UnclearedfundReqValidator;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.exception.ApiRequestException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.utility.StringUtil;

public class UnclearedfundReqValidatorImpl implements UnclearedfundReqValidator {
	@Inject
	private Validator validator;

	@Inject
	Config config;

	private static final Logger LOGGER = LoggerFactory.getLogger(UnclearedfundReqValidatorImpl.class);

	@Override
	public void validateRetrieveUnclearedFund(UnclearFundDetailsRequest unclearFundDetailsRequest) {
		LOGGER.info(Constant.VALIDATE_REQUEST, "", "Validating the request",
				unclearFundDetailsRequest.getApiRequestHeader().getCorrelationId());
		Set<String> errorList = validatedAnnotedBeans(unclearFundDetailsRequest);
		if (!errorList.isEmpty()) {
			String errorMessage = String.join(",", errorList);
			ApiRequestException exception = new ApiRequestException(Constant.BAD_REQUEST_CODE, errorMessage);
			LOGGER.error(Constant.VALIDATE_REQUEST, "", "Validation failed:", exception.getErrorMessage());
			throw exception;
		}
		LOGGER.info(Constant.VALIDATE_REQUEST, "", "No validation errors found",
				unclearFundDetailsRequest.getApiRequestHeader().getCorrelationId());
	}

	private Set<String> validatedAnnotedBeans(UnclearFundDetailsRequest accountRequest) {
		Set<ConstraintViolation<UnclearFundDetailsRequest>> violations = validator.validate(accountRequest);
		return violations.stream().map(constraint -> {
			String customErroMsg = getPropertyValue(constraint.getMessageTemplate());
			return StringUtil.isStringNullOrEmpty(customErroMsg) ? constraint.getMessage() : customErroMsg;
		}).collect(Collectors.toSet());
	}

	private String getPropertyValue(String confKey) {
		try {
			return config.getValue(confKey, String.class);
		} catch (Exception e) {
			LOGGER.error("getPropertyValue", "", "Exception while reading property for the key ::" + confKey,
					e.getMessage());
		}
		return "";
	}
}
