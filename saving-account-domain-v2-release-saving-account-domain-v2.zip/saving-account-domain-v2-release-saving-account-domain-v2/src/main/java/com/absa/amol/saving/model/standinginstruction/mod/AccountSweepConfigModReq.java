package com.absa.amol.saving.model.standinginstruction.mod;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountSweepConfigModReq {

	private String compoundingFreq;

	private Boolean sweepInProviderFlag;

	private Integer productCode;

	private Integer termDays;

	private Integer termMonths;

	private Float accountVariance;

}
