package com.absa.amol.saving.service;

import com.absa.amol.saving.model.standinginstruction.add.StandingOrderAddReq;
import com.absa.amol.saving.model.standinginstruction.add.StandingOrderAddRes;
import com.absa.amol.util.model.ResponseEntity;

public interface AddStandingInstructionService {

	ResponseEntity<StandingOrderAddRes> addStandingInstruc(StandingOrderAddReq standingOrderAddReq);

}
