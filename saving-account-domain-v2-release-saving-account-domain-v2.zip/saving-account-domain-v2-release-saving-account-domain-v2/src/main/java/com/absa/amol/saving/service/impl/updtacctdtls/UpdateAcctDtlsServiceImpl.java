package com.absa.amol.saving.service.impl.updtacctdtls;

import javax.inject.Inject;

import com.absa.amol.saving.builder.UpdateAcctDtlsClientBuilder;
import com.absa.amol.saving.mapper.updtacctdtls.UpdateAcctDtlsReqMapper;
import com.absa.amol.saving.model.sys.updtacctdtls.AccountOpenReq;
import com.absa.amol.saving.model.sys.updtacctdtls.AccountOpenRes;
import com.absa.amol.saving.model.updtacctdtls.UpdateAcctDtlsReqWrapper;
import com.absa.amol.saving.model.updtacctdtls.UpdateAcctDtlsRes;
import com.absa.amol.saving.service.updtacctdtls.UpdateAcctDtlsService;
import com.absa.amol.saving.service.updtacctdtls.UpdateAcctDtlsValidatorService;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.exception.ApiException;
import com.absa.amol.util.exception.ApiRequestException;
import com.absa.amol.util.exception.ApiResponseException;
import com.absa.amol.util.exception.SORSystemServiceUnavailableException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ResponseEntity;

public class UpdateAcctDtlsServiceImpl implements UpdateAcctDtlsService {

	private static final Logger LOGGER = LoggerFactory.getLogger(UpdateAcctDtlsServiceImpl.class);

	@Inject
	UpdateAcctDtlsReqMapper updateAcctDtlsReqMapper;

	@Inject
	UpdateAcctDtlsClientBuilder updateAcctDtlsClientBuilder;
	
	@Inject
	UpdateAcctDtlsValidatorService updateAcctDtlsValidatorService;

	@Override
	public ResponseEntity<UpdateAcctDtlsRes> updateAcctDetails(UpdateAcctDtlsReqWrapper updateAcctDtlsReqWrapper) {

		final String METHOD_NAME = "updateAcctDetails";
		String consumerUniqRefId = updateAcctDtlsReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId();
		LOGGER.info(METHOD_NAME, consumerUniqRefId, "Inside service impl", Constant.BLANK);
		ResponseEntity<UpdateAcctDtlsRes> updateAcctDtlsResEntity=null;
		try {
			updateAcctDtlsValidatorService.validateInputRequest(updateAcctDtlsReqWrapper);
			AccountOpenReq accountOpenReq=updateAcctDtlsReqMapper.updateAcctDetailsReqMapping(updateAcctDtlsReqWrapper);
			ResponseEntity<AccountOpenRes> sysEntity=updateAcctDtlsClientBuilder
					.updateAcctDetails(updateAcctDtlsReqWrapper.getApiRequestHeader(), accountOpenReq);
			AccountOpenRes accountOpenRes=sysEntity.getData();
			UpdateAcctDtlsRes updateAcctDtlsRes=updateAcctDtlsReqMapper.updateAcctDetailsResMapping(accountOpenRes);
				updateAcctDtlsResEntity = new ResponseEntity<>(sysEntity.getCode(),Constant.DATA_UPDATED,Constant.SUCCESS_MSG,updateAcctDtlsRes);
				
		} catch (SORSystemServiceUnavailableException ex) {
			LOGGER.error(METHOD_NAME, consumerUniqRefId, "System adapter is unavailable",ex.getErrorMessage());
			LOGGER.debug(METHOD_NAME, consumerUniqRefId, "System adapter is unavailable - Debug", ex);
			throw new SORSystemServiceUnavailableException(Constant.FIVE_O_THREE, ex.getErrorMessage());
		} catch (ApiRequestException ex) {
			LOGGER.error(METHOD_NAME, consumerUniqRefId, "ApiRequestException occured", ex.getErrorMessage());
			LOGGER.debug(METHOD_NAME, consumerUniqRefId, "ApiRequestException occured", ex);
			throw new ApiRequestException(ex.getErrorCode(), ex.getErrorMessage());
		} catch (ApiException ex) {
			LOGGER.error(METHOD_NAME, consumerUniqRefId, "ApiException occured", ex.getMessage());
			LOGGER.debug(METHOD_NAME, consumerUniqRefId, "ApiException occured", ex);
			throw new ApiResponseException(ex.getErrorCode(), ex.getErrorMessage());
		} catch (Exception ex) {
			LOGGER.error(METHOD_NAME, consumerUniqRefId, "Exception occured", ex.getMessage());
			LOGGER.debug(METHOD_NAME, consumerUniqRefId, "Exception occured-Debug", ex);
			throw new ApiResponseException(Constant.INTERNAL_ERROR_CODE, Constant.INTERNAL_ERROR_MSG);
		}

		return updateAcctDtlsResEntity;
	}

}
