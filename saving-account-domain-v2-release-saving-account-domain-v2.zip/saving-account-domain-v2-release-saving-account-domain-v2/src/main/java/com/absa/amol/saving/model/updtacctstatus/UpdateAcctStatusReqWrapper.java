package com.absa.amol.saving.model.updtacctstatus;

import javax.validation.Valid;

import com.absa.amol.util.model.ApiRequestHeader;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class UpdateAcctStatusReqWrapper {
	
	@Valid
	private ApiRequestHeader apiRequestHeader;
	@Valid
	private UpdateAcctStatusReq updateAcctStatusReq;
	private String operationId;
	
}
