package com.absa.amol.saving.model.createcasaaccount;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CustomerReference {
	
	@Size(min = 1, max = 40, message = "customerReference.customerName.length.error.message")
	private String customerName;

	// 3
	@NotNull(message = "customerReference.associationType.nullOrEmpty.error.message")
	@NotEmpty(message = "customerReference.associationType.nullOrEmpty.error.message")
	//@Size(min = 3, max = 3, message = "customerReference.associationType.length.error.message")
	private String associationType;

	@NotNull(message = "customerReference.customerReference.nullOrEmpty.error.message")
	@NotEmpty(message = "customerReference.customerReference.nullOrEmpty.error.message")
	@Size(min = 1, max = 10, message = "customerReference.customerReference.length.error.message")
	private String customerReference;// customerId

}
