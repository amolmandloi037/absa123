package com.absa.amol.saving.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class BasicInformation {
  private String checker;
  private String fieldReferenceNumber;
  private String maintenanceCode;
  private String maintenanceStatus;
  private String maintenanceTicket;
  private String maker;
  private CustomDate modificationDate;
  private Integer version;
  private String accountStatus;
  private boolean blocked;
  private String casaAccountStatus;
  private boolean employeeAccount;
  private String internationalBankAccountNumber;
  private boolean isMinor;
  private String minorStatus;
  private String officerName;
  private String openingDate;
  private String passbookStatus;
  private Integer reasonForBlocking;
  private boolean restrictedAccount;
  private boolean serviceChargeWaived;
  private String taxExemptLevel;
  private Long taxableCustomerCode;
  private String taxableCustomerShortName;
}
