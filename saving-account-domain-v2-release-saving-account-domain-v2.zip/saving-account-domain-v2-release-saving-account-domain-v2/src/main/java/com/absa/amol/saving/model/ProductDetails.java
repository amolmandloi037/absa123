package com.absa.amol.saving.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductDetails {

  private String productServiceType;
  private String productServiceId;

}
