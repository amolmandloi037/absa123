package com.absa.amol.saving.model.sys.acctearmark;

import java.util.ArrayList;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AcctEarmarkSystemAdapterRes {
	private String code;
	private String message;
	private String status;
	private ArrayList<AccountEarmark> earmarkingList;
}
