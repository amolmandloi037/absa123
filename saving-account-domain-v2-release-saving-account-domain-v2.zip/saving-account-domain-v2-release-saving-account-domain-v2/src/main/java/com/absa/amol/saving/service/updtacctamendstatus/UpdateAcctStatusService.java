package com.absa.amol.saving.service.updtacctamendstatus;

import com.absa.amol.saving.model.updtacctstatus.UpdateAcctStatusReqWrapper;
import com.absa.amol.saving.model.updtacctstatus.UpdateAcctStatusRes;
import com.absa.amol.util.model.ResponseEntity;

public interface UpdateAcctStatusService {
	public ResponseEntity<UpdateAcctStatusRes> amendCustomerAccount(UpdateAcctStatusReqWrapper requestWrapper);
}
