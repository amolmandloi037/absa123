package com.absa.amol.saving.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CustomerReferenceDTO {

  private String designationCode;
  private String customerIdentification;


}
