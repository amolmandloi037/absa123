package com.absa.amol.saving.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class PositionLimitValue {
  private Float debitLimitReductionAmount;
  private Double drBalanceEffective;
  private Double crBalanceEffective;
  private Integer amountToClear;
}
