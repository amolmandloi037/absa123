package com.absa.amol.saving.model.orderdebitcard;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class LocationReference {
	
	@Schema(description = "Field is mandatory.", pattern = "Only numeric", maxLength = 4, required = true)
	@NotEmpty(message = "orderdebitcard.cardBranch.nullorempty.error.message")
	@NotNull(message = "orderdebitcard.cardBranch.nullorempty.error.message")
	@Size(max = 4, message = "orderdebitcard.cardBranch.length.error.message")
	@Pattern(regexp="[0-9]*", message="orderdebitcard.cardBranch.regex.error.message")
	private String cardBranch;
	
	@Schema(description = "Field is mandatory.", maxLength = 50, required = true)
	@NotEmpty(message = "orderdebitcard.postalAddressLine1.nullorempty.error.message")
	@NotNull(message = "orderdebitcard.postalAddressLine1.nullorempty.error.message")
	@Size(max = 50, message = "orderdebitcard.postalAddressLine1.length.error.message")
	private String postalAddressLine1;
	
	@Schema(description = "Field is mandatory.", maxLength = 50, required = true)
	@NotEmpty(message = "orderdebitcard.postalAddressLine2.nullorempty.error.message")
	@NotNull(message = "orderdebitcard.postalAddressLine2.nullorempty.error.message")
	@Size(max = 50, message = "orderdebitcard.postalAddressLine2.length.error.message")
	private String postalAddressLine2;
	
	@Schema(description = "Field is mandatory.", maxLength = 50, required = true)
	@NotEmpty(message = "orderdebitcard.postalAddressLine3.nullorempty.error.message")
	@NotNull(message = "orderdebitcard.postalAddressLine3.nullorempty.error.message")
	@Size(max = 50, message = "orderdebitcard.postalAddressLine3.length.error.message")
	private String postalAddressLine3;
	
	@Schema(description = "Field is mandatory.", maxLength = 50, required = true)
	@NotEmpty(message = "orderdebitcard.postalAddressLine4.nullorempty.error.message")
	@NotNull(message = "orderdebitcard.postalAddressLine4.nullorempty.error.message")
	@Size(max = 50, message = "orderdebitcard.postalAddressLine4.length.error.message")
	private String postalAddressLine4;

}
