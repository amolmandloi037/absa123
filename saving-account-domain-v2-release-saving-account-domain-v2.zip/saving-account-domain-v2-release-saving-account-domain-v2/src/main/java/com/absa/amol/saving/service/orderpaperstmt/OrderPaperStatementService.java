package com.absa.amol.saving.service.orderpaperstmt;

import javax.ws.rs.core.Response;

import com.absa.amol.saving.model.orderpaperstmt.OrderPaperStmtDomainRequest;

public interface OrderPaperStatementService {
  public Response getOrderPaperStatement(OrderPaperStmtDomainRequest req);
}
