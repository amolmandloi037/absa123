package com.absa.amol.saving.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ChequeBookFacility {
  private Integer numberOfChequeWithdrawals;
  private Integer chequeReorderThresholdNumber;
  private String lastIssuedCheckNumber;
}
