package com.absa.amol.saving.model.sys.updtacctdtls;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MailAddress {
	
	    private String addressSequenceNumber;
	    private String addressName;
	    private String addressLine1;
	    private String addressLine2;
	    private String addressLine3;

}
