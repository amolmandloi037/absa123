package com.absa.amol.saving.model;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.ws.rs.BeanParam;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import com.absa.amol.util.model.ApiRequestHeader;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AccountArrangementRequest {

  @BeanParam
  @Schema(hidden = true)
  @Valid
  private ApiRequestHeader apiRequestHeader;

  @NotNull(message = "bankBranch cannot be null or empty")
  @Digits(fraction = 0, integer = 2, message = "bankBranch cannot be more than 2 digits")
  private Integer bankBranch;
  @NotNull(message = "productInstanceReference cannot be null or empty")
  @Digits(fraction = 0, integer = 7,
      message = "productInstanceReference cannot be more than 7 digits")
  private Integer productInstanceReference;
  @NotNull(message = "accountType cannot be null or empty")
  @Digits(fraction = 0, integer = 2, message = "accountType cannot be more than 2 digits")
  private Integer accountType;
  @Pattern(regexp = "[0-9]{1}",
      message = "Only numbers are allowed in accountStatus and the length should be 1")
  private String accountStatus;
  @Pattern(regexp = "^[0-9]*$", message = "Only numbers are allowed in accountClassification")
  private String accountClassification;
  @Pattern(regexp = "^[0-9]*$", message = "Only numbers are allowed in bicCode")
  private String bicCode;
  @Pattern(regexp = "^[0-9]*$", message = "Only numbers are allowed in marketSegment")
  private String marketSegment;
  @Pattern(regexp = "^[0-9]*$", message = "Only numbers are allowed in referStream")
  private String referStream;
  @NotNull(message = "accountCurrency cannot be null or empty")
  @Digits(fraction = 0, integer = 2, message = "accountCurrency cannot be more than 2 digits")
  private Integer accountCurrency;
  @NotNull(message = "terminalNumber cannot be null or empty")
  @NotEmpty(message = "terminalNumber cannot be null or empty")
  @Pattern(regexp = "^[0-9]*$", message = "Only numbers are allowed in terminalNumber")
  @Digits(fraction = 0, integer = 9, message = "Enter a valid value for terminalNumber")
  private String terminalNumber;
  @NotNull(message = "sequenceNumber cannot be null or empty")
  @NotEmpty(message = "sequenceNumber cannot be null or empty")
  @Pattern(regexp = "^[0-9]*$", message = "Only numbers are allowed in sequenceNumber")
  @Digits(fraction = 0, integer = 9, message = "Enter a valid value for sequenceNumber")
  private String sequenceNumber;
  @Pattern(regexp = "^[nNyY]", message = "Only n, N, y and Y are valid values for atmIndicator")
  private String atmIndicator;

  // private ProductAndServicePreference productAndServicePreference;
  private MailingAddress mailingAddress;

  // Added for Addition of callback person
  private AccountNotes accountNotes;
  private String hostname;
  private String userid;
  @Pattern(regexp = "^[UD]", message = "Only U and D are valid values for notesActionCode")
  private String notesActionCode;

  private AccountStoppedCheque accountStoppedCheque;

  @Pattern(regexp = "^[UD]", message = "Only U and D are valid values for stoppedChequeActionCode")
  private String stoppedChequeActionCode;

  // new................
  private String accountModificationIndicator;
  private String shortName;//
  private String customerIdentification;//

  private String longName;//
  private String designationCode;//
  private Integer kycInd;//
  private String kycDate;//
  private Float interestSinceDormant;// workplace banking code
  private String locationCode;// account location code
  private String salesLocation;//
  private String gscaDrCode;//
  private String crediatorClassification;

  // amendment of cancellation of debit
  private String debitLimitExpiry;
  private Float creditLimit;
  private Float drLimitReductionAmt;
  private String frequencyInd;
  private String frequencyData;
  private Float effectiveDebitLimit;
  private boolean amendmtCnclOfDebit;

  // Auto-Transfer
  // Auto-Transfer
  private String serialNumber;
  com.absa.amol.saving.model.autotransfer.PaymentTransaction paymentTransaction; // counter party
                                                                                 // branch,account,
                                                                                 // amount
  com.absa.amol.saving.model.autotransfer.PaymentSchedule paymentSchedule;// frquency,frequencydata,nextdue
                                                                          // date
  com.absa.amol.saving.model.autotransfer.PaymentTransactionType paymentTransactionType;// transfertype
  private String positionLimitType;
  private String transfersOutAllowed;
  private String transfersInAllowed;

  @Pattern(regexp = "^[AUD]",
      message = "Only A, U and D are valid values for autoTransferActionCode")
  private String autoTransferActionCode;

  // Realignment
  private Integer debitInterestContra;
  private Integer creditInterestContra;

  // unclear effects
  private String unclearedEffectType;
  private Integer systemDayNumber;
  private Integer amountToClear;

  // InterestRate Amendments
  private Integer debitRateIndicator1;
  private Float debitRate1;
  private Integer debitRateIndicator2;
  private Float debitRate2;
  private Double drBalanceEffective;
  private Integer creditRateIndicator1;
  private Float creditRate1;
  private Integer creditRateIndicator2;
  private Float creditRate2;
  private Double crBalanceEffective;
  private boolean interestRateIndicator;

}
