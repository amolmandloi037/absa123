package com.absa.amol.saving.model.standinginstruction.retrieve;

import javax.json.bind.annotation.JsonbProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentPurposeRetRes {
	@JsonbProperty(nillable = true) private String narrative;
	@JsonbProperty(nillable = true) private String benNarrative;
	@JsonbProperty(nillable = true) private String benRegionCode;
	@JsonbProperty(nillable = true) private String benAddNarrative;
	@JsonbProperty(nillable = true) private String remAddNarrative;
	@JsonbProperty(nillable = true) private String subTransactionCode;
	@JsonbProperty(nillable = true) private String remNarrative;
}