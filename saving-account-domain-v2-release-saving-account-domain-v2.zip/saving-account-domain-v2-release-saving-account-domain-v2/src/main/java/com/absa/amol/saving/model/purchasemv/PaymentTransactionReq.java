package com.absa.amol.saving.model.purchasemv;

import javax.validation.Valid;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class PaymentTransactionReq {

	@Valid
	private PaymentPurposeReq paymentPurpose;
}
