package com.absa.amol.saving.model.accountsnickname.retrieve;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.ws.rs.BeanParam;
import javax.ws.rs.QueryParam;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import com.absa.amol.util.model.ApiRequestHeader;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(name = "RetrieveAccountsNickNameReq", description = "Domain Request Schema to retrieve account Nickname details")
public class RetrieveAccountsNickNameReq 
{	
	@Valid
	@BeanParam
	private ApiRequestHeader apiRequestheader;
	
	@NotEmpty(message = "retrievecustnickname.customerReference.nullorempty.error.message")
	@NotNull(message = "retrievecustnickname.customerReference.nullorempty.error.message")
	@Size(max = 12, message = "retrievecustnickname.customerReference.length.error.message")
	@Pattern(regexp="[0-9]*", message="retrievecustnickname.customerReference.regex.error.message")
	@QueryParam(value = "customerReference")
	@Schema(description = "Field is mandatory", pattern = "Only numeric", maxLength = 12, required = true)
	private String customerReference;
	
}
