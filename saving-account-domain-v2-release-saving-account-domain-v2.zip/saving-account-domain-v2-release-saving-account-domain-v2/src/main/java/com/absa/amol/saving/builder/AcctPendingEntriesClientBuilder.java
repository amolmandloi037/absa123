package com.absa.amol.saving.builder;

import javax.ws.rs.BeanParam;
import javax.ws.rs.GET;

import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import com.absa.amol.saving.model.sys.pendingentries.AcctPendingEntriesSystemList;
import com.absa.amol.saving.model.sys.pendingentries.AcctPendingEntriesSystemReq;
import com.absa.amol.saving.util.ServerSideExceptionMapper;
import com.absa.amol.util.model.ResponseEntity;

@RegisterRestClient(configKey = "pendingentrise.retrieve.sys.url")
@RegisterProvider(value = ServerSideExceptionMapper.class)
public interface AcctPendingEntriesClientBuilder {

	@GET
	ResponseEntity<AcctPendingEntriesSystemList> retrieveAccountPendingEntriesList(@BeanParam AcctPendingEntriesSystemReq acctPendingEntriesSystemReq) ;

}
