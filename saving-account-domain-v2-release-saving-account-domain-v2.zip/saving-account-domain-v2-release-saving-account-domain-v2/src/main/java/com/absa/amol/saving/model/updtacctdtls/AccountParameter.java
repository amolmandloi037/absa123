package com.absa.amol.saving.model.updtacctdtls;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountParameter {
	
	@NotNull( message="parameterId.null.empty.message")
	@NotEmpty( message="parameterId.null.empty.message")
	@Schema(description = "Mandatory field", pattern = "Numeric",minLength=1, maxLength = 3,required=true )
	private String parameterId;
	
	@Size( min=1,max=6, message="parameterValue.size.message")
	@NotNull( message="parameterValue.null.empty.message")
	@NotEmpty( message="parameterValue.null.empty.message")
	@Schema(description = "Mandatory field", pattern = "AlphaNumeric",minLength=1, maxLength = 6,required=true )
	private String parameterValue;

}
