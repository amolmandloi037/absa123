package com.absa.amol.saving.model.updtacctdtls;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountAddress {
	
	@Pattern(regexp = "[0-9]{1,10}", message = "serialNumber.pattern.message")
	@Schema(description = "Optional field", pattern = "Numeric", minLength=1 ,maxLength = 10 )
	private String serialNumber;
	
	@Min(value = 100000000 , message = "customerId.length.error.message")
	@Max(value = 999999999, message = "customerId.length.error.message")
	@Schema(description = "Optional field", pattern = "Numeric",minLength=9, maxLength = 9 )
	private String customerId;
	
	@Valid
	private MailingAddress mailingAddress;
	@Valid
	private ProductAndServicePreference productAndServicePreference;
	

}
