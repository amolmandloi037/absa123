package com.absa.amol.saving.model;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Schema(name = "IdPKDetails", description = "POJO that represents IdPKDetails details")
public class IdPKDetails {
  private String idPkName;
  private String idPkValue;
  private String idPkOrder;

}
