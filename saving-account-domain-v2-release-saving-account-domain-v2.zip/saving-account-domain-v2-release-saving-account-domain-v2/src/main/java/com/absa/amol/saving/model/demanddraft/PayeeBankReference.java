package com.absa.amol.saving.model.demanddraft;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import com.absa.amol.saving.util.Constant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class PayeeBankReference {
	
	@Size( max = 40, message = Constant.COUNTRY_CODE_LENGTH_ERROR_MESSAGE)
	@Pattern(regexp = Constant.ONLY_SPACE_CHARACTERS_REGEX, message = Constant.COUNTRY_CODE_PATTERN_ERROR_MESSAGE)
	@Schema(description = "Field is optional", pattern = "only characters and space", maxLength = 40)
	private String countryCode;
	
	@Size( max = 15, message = Constant.COLLECTION_BRANCH_NAME_LENGTH_ERROR_MESSAGE)
	@Pattern(regexp = Constant.ONLY_SPACE_CHARACTERS_REGEX, message = Constant.COLLECTION_BRANCH_NAME_PATTERN_ERROR_MESSAGE)
	@Schema(description = "Field is optional", pattern = "only characters and space", maxLength = 15)
	private String collectionBranchName;
	
	@Size( max =3, message = Constant.COLLECTION_BRANCH_ID_LENGTH_ERROR_MESSAGE)
	@Pattern(regexp = Constant.BRANCH_ID_REGX, message = Constant.COLLECTION_BRANCH_ID_PATTERN_ERROR_MESSAGE)
	@Schema(description = "Field is optional", pattern = "only numeric", maxLength = 3)
	private String collectionBranchId;

}
