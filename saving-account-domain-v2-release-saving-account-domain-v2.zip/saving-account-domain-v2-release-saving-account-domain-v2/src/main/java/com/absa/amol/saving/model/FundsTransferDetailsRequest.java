package com.absa.amol.saving.model;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.ws.rs.BeanParam;
import javax.ws.rs.QueryParam;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.model.ApiRequestHeader;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(name = Constant.REQ_SCHEMA_NAME, description = Constant.REQ_SCHEMA_DESC)
public class FundsTransferDetailsRequest {

  @BeanParam
  @Schema(hidden = true)
  @Valid
  private ApiRequestHeader apiRequestHeader;

  @NotNull(message = "trxReferenceNumber.notnullempty.error.message")
  @NotEmpty(message = "trxReferenceNumber.notnullempty.error.message")
  @Size(min = 4, max = 30, message = "trxReferenceNumber.length.error.message")
  @QueryParam("trxReferenceNumber")
  private String trxReferenceNumber;

  @QueryParam("lockRequired")
  private String lockRequired;
}
