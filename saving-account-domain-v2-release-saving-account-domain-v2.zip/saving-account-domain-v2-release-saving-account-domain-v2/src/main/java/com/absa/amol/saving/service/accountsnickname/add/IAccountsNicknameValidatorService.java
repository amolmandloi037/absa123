package com.absa.amol.saving.service.accountsnickname.add;

import com.absa.amol.util.model.ApiRequestHeader;

public interface IAccountsNicknameValidatorService {

	public <T>void validateInputRequest(T request,ApiRequestHeader apiRequestHeader);
}
