package com.absa.amol.saving.model.updtacctstatus;

import javax.validation.constraints.Pattern;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountDetails {

	@Schema(description = "Optional field", pattern = "True/False", maxLength = 1)
	@Pattern(regexp="^([Tt][Rr][Uu][Ee]|[Ff][Aa][Ll][Ss][Ee])${1}?|", message="primaryAccountIndicator.regex.error.message")
	private	String primaryAccountIndicator;
	
	@Schema(description = "Optional field", pattern = "True/False", maxLength = 1)
	@Pattern(regexp="^([Tt][Rr][Uu][Ee]|[Ff][Aa][Ll][Ss][Ee])${1}?|", message="cashbackAccountIndicator.regex.error.message")
	private String cashbackAccountNumber;
	
}
