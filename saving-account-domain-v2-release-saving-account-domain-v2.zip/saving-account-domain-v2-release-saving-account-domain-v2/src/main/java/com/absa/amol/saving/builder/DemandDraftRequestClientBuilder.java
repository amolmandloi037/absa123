package com.absa.amol.saving.builder;

import javax.ws.rs.BeanParam;
import javax.ws.rs.POST;

import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import com.absa.amol.saving.model.sys.demanddraft.DemandDraftReq;
import com.absa.amol.saving.model.sys.demanddraft.DemandDraftRes;
import com.absa.amol.saving.util.ServerSideExceptionMapper;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.model.ResponseEntity;

@RegisterRestClient(configKey = "demand.draft.system.url")
@RegisterProvider(value = ServerSideExceptionMapper.class)
public interface DemandDraftRequestClientBuilder {

	@POST
	ResponseEntity<DemandDraftRes> demandDraftSystemRequest(@RequestBody DemandDraftReq DemandDraftReq,@BeanParam ApiRequestHeader apiRequestHeader);
}
