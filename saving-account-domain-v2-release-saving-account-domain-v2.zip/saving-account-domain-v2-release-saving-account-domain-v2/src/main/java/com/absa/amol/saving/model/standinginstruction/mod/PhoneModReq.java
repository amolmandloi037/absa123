package com.absa.amol.saving.model.standinginstruction.mod;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PhoneModReq {

	private String extension;

	private String isdCode;

	private String number;

	private String stdCode;

}
