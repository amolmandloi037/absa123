package com.absa.amol.saving.model.standinginstruction.add;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PhoneAddReq {
	private String extension;
	private String isdCode;
	private String number;
	private String stdCode;

}
