package com.absa.amol.saving.service.chequebook;

import com.absa.amol.util.model.ApiRequestHeader;

public interface IChequeBookValidatorService {

	public <T>void validateInputRequest(T request,ApiRequestHeader apiRequestHeader);
}
