package com.absa.amol.saving.model.purchasemv;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class PaymentPurposeRes {

	private String voucherId;
}
