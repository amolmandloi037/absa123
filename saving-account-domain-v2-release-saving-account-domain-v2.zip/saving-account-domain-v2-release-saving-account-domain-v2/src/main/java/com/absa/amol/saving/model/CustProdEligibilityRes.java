package com.absa.amol.saving.model;

import java.util.ArrayList;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CustProdEligibilityRes {
  private ArrayList<ProductDetails> productServiceDetails;
}
