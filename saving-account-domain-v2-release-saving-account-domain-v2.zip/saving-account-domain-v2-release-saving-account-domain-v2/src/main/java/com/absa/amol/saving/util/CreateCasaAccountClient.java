package com.absa.amol.saving.util;

import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import com.absa.amol.saving.model.createcasaaccount.CreateCasaAccountRequest;
import com.absa.amol.saving.model.createcasaaccount.CreateCasaAccountResponse;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.model.ResponseEntity;

@RegisterRestClient(configKey = "create.casa.account.system.url")
@RegisterProvider(ServerSideExceptionMapper.class)
public interface CreateCasaAccountClient {
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  public ResponseEntity<CreateCasaAccountResponse> createCasaAccount(@BeanParam ApiRequestHeader header, @RequestBody CreateCasaAccountRequest req);
}
