package com.absa.amol.saving.service.impl;

import java.util.Set;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import com.absa.amol.saving.model.orderdebitcard.OrderDebitCardDomainReq;
import com.absa.amol.saving.service.IOrderDebitCardValidatorService;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.saving.util.SavingAccountDomainUtil;
import com.absa.amol.util.exception.ApiRequestException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.utility.StringUtil;

public class OrderDebitCardValidatorServiceImpl implements IOrderDebitCardValidatorService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(OrderDebitCardValidatorServiceImpl.class);
	
	@Inject SavingAccountDomainUtil util;
	
	@Inject
	private Validator validator;

	@Override
	public void validateOrderDebitCardReq(ApiRequestHeader apiRequestHeader,OrderDebitCardDomainReq orderDebitCardDomainReq) {
		Set<String> errSet = validatedAnnotedBeans(apiRequestHeader);
		errSet.addAll(validatedAnnotedBeans(orderDebitCardDomainReq));
		if (!errSet.isEmpty()) {
			String errorMsg = String.join(",", errSet);
			LOGGER.error("validateOrderDebitCardReq", apiRequestHeader.getConsumerUniqueReferenceId(), "Validation failed:", errorMsg);
			throw new ApiRequestException(Constant.BAD_REQUEST_CODE, errorMsg);
		}
		
	}
	
	private <T>Set<String> validatedAnnotedBeans(T request) {
		Set<ConstraintViolation<Object>> violations = validator.validate(request);
		return violations.stream().map(constraint -> {
			String customErroMsg = util.getPropertyValue(constraint.getMessageTemplate());
			return StringUtil.isStringNullOrEmpty(customErroMsg) ? constraint.getMessage() : customErroMsg;
		}).collect(Collectors.toSet());
	}
	
	

}
