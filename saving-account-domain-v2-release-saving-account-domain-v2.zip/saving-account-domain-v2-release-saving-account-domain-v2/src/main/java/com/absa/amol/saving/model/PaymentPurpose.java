package com.absa.amol.saving.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString

public class PaymentPurpose {
  private String transactionReferenceNumber;
  private String statementTxnDesc1;
  private String statementTxnDesc2;
  private String statementTxnDesc3;
  private String statementTxnDesc4;
  private String checkNumber;
  private String transactionSequenceNumber;

}
