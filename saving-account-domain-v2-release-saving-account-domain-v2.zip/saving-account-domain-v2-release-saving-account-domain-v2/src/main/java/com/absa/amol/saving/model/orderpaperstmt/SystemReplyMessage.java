package com.absa.amol.saving.model.orderpaperstmt;

import javax.json.bind.annotation.JsonbNillable;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonbNillable
public class SystemReplyMessage {
  private String code;
  private String message;
}
