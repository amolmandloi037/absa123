package com.absa.amol.saving.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class CASAValue {
  private Double totalCASAHoldAmount;
  private Double interestAccruedInCurrentFinancialYear;
}
