package com.absa.amol.saving.model.orderdebitcard;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PostalAddressSystemRequest {

	@NotNull(message = "addressLine1.noempty.error.message")
	@NotEmpty(message = "addressLine1.noempty.error.message")
	private String addressLine1; 

	@NotNull(message = "addressLine2.noempty.error.message")
	@NotEmpty(message = "addressLine2.noempty.error.message")
	private String addressLine2; 

	@NotNull(message = "addressLine3.noempty.error.message")
	@NotEmpty(message = "addressLine3.noempty.error.message")
	private String addressLine3;

	@NotNull(message = "addressLine4.noempty.error.message")
	@NotEmpty(message = "addressLine4.noempty.error.message")
	private String addressLine4;
}
