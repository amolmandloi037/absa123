package com.absa.amol.saving.model.standinginstruction.retrieve;

import javax.json.bind.annotation.JsonbProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PayeeBankReferenceRetRes {
	@JsonbProperty(nillable = true) private String beneficiaryBranchCode;
	@JsonbProperty(nillable = true) private String beneficiaryBankName;
	@JsonbProperty(nillable = true) private String beneficiaryBranchName;
	@JsonbProperty(nillable = true) private String beneficiaryBankCode;
}