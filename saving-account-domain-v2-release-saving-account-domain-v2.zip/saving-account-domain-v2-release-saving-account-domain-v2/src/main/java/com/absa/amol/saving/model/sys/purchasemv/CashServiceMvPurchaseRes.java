package com.absa.amol.saving.model.sys.purchasemv;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(name = "CashServiceMvPurchaseRes", description = "Response Schema for money voucher purchase")
public class CashServiceMvPurchaseRes {
	private String voucherId;
}
