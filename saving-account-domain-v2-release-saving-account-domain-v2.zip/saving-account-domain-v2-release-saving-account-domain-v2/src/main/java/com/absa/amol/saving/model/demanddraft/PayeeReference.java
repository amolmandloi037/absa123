package com.absa.amol.saving.model.demanddraft;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import com.absa.amol.saving.util.Constant;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class PayeeReference {
	
	@Pattern(regexp = Constant.ONLY_SPACE_CHARACTERS_REGEX, message = Constant.BENEFICIARY_NAME_PATTERN_ERROR_MESSAGE)
	@Size(min = 1, max = 55, message = Constant.BENEFICIARY_NAME_LENGTH_ERROR_MESSAGE)
	@NotNull(message = Constant.BENEFICIARY_NAME_NOTNULLEMPTY_ERROR_MESSAGE)
	@NotEmpty(message = Constant.BENEFICIARY_NAME_NOTNULLEMPTY_ERROR_MESSAGE)
	@Schema(description = "Field is mandatory", pattern = "only characters and space",minLength = 1, maxLength = 55, required = true)
	private String beneficiaryName;
	
	@Size( max = 15, message = Constant.PHONE_NUMBER_LENGTH_ERROR_MESSAGE)
	@Pattern(regexp = Constant.BRANCH_ID_REGX, message = Constant.PHONE_NUMBER_PATTERN_ERROR_MESSAGE)
	@Schema(description = "Field is optional", pattern = "only numeric", maxLength = 15)
	private String phoneNumber;
	
	@Valid
	private Address address;

}
