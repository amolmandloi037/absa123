package com.absa.amol.saving.model;

import java.math.BigDecimal;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class AccountBalance {

  protected BigDecimal totalUnclearFundAmount;
  protected BigDecimal accountAvailableBalance;
  protected BigDecimal currentBookBalanceAmount; // accountCurrentBalance
  protected BigDecimal authorisedDebitAmount;
  protected BigDecimal minimumRequiredBalanceAmount;
  protected BigDecimal netBalanceAmount; // netAvailableBalanceForWithdrawal
  protected BigDecimal confirmationAmount;
  protected BigDecimal previousDayClosingBookBalance;
  protected BigDecimal sweepinAmountOnLien;
  protected BigDecimal periodicAverageBalanceAmount;
}
