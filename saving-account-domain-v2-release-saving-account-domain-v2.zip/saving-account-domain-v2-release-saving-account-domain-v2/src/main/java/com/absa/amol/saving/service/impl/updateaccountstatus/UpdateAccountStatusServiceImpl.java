package com.absa.amol.saving.service.impl.updateaccountstatus;

import javax.inject.Inject;

import org.eclipse.microprofile.config.Config;
import org.eclipse.microprofile.rest.client.inject.RestClient;

import com.absa.amol.saving.builder.UpdateAccountActDctStatusClientBuilder;
import com.absa.amol.saving.builder.UpdateAccountUdfStatusClientBuilder;
import com.absa.amol.saving.mapper.updateaccountstatus.ActivateDeactivateAccountMapper;
import com.absa.amol.saving.mapper.updateaccountstatus.UpdateAccountUdfMapper;
import com.absa.amol.saving.model.sys.actdctaccount.AccountStatusSystemReq;
import com.absa.amol.saving.model.sys.actdctaccount.AccountStatusSystemRes;
import com.absa.amol.saving.model.sys.updaccudf.AccountUdfUpdateRes;
import com.absa.amol.saving.model.updateaccountstatus.UpdateAccountStatusDomainReqWrapper;
import com.absa.amol.saving.model.updateaccountstatus.UpdateAccountStatusDomainRes;
import com.absa.amol.saving.service.updateaccountstatus.UpdateAccountStatusService;
import com.absa.amol.saving.service.updateaccountstatus.UpdateAccountStatusValidationService;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.exception.ApiException;
import com.absa.amol.util.exception.ApiResponseException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ResponseEntity;
import com.absa.amol.util.utility.CommonUtil;

public class UpdateAccountStatusServiceImpl implements UpdateAccountStatusService {

	@Inject
	@RestClient
	UpdateAccountActDctStatusClientBuilder actDctStatusClientBuilder;
	
	@Inject
	@RestClient
	UpdateAccountUdfStatusClientBuilder udfStatusClientBuilder;
	
	@Inject
	UpdateAccountStatusValidationService validationService;
	
	@Inject
	ActivateDeactivateAccountMapper activateDeactivateAccountMapper;
	
	@Inject
	UpdateAccountUdfMapper updateAccountUdfMapper;

	@Inject
	Config config;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(UpdateAccountStatusServiceImpl.class);
	
	@Override
	public ResponseEntity<UpdateAccountStatusDomainRes> getUpdateAccStsResponse(UpdateAccountStatusDomainReqWrapper domainReqWrapper) {
		final String METHOD_NAME = "getUpdateAccStsResponse";
		ResponseEntity<UpdateAccountStatusDomainRes> domainResponse = null;
		String consumerUniqueId = null;
		try {
			if(CommonUtil.isNotNull(domainReqWrapper) && CommonUtil.isNotNull(domainReqWrapper.getApiRequestHeader())) {
				consumerUniqueId= domainReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId();
			}
			validationService.validateInputRequest(domainReqWrapper.getUpdateAccountStatusDomainReq(), domainReqWrapper.getApiRequestHeader());
			AccountStatusSystemReq accountStatusSystemReq =	 activateDeactivateAccountMapper.getActDctAccRequest(domainReqWrapper);
			ResponseEntity<AccountStatusSystemRes> actDctStatusResponse= actDctStatusClientBuilder.updateAccountStatus
					(domainReqWrapper.getApiRequestHeader(), accountStatusSystemReq);
			domainResponse = activateDeactivateAccountMapper.getResponseStatus(actDctStatusResponse,consumerUniqueId);
		if("Success".equalsIgnoreCase(domainResponse.getStatus()) && ("Y").equalsIgnoreCase(config.getValue("UDFUpdateIndicator", String.class))) {
				ResponseEntity<AccountUdfUpdateRes> udfResponseEntity =	udfStatusClientBuilder.accountUpdateUdf(domainReqWrapper.getApiRequestHeader(), 
						updateAccountUdfMapper.getActDctAccRequest(domainReqWrapper));
				domainResponse = updateAccountUdfMapper.setActDctAccResponse(udfResponseEntity, consumerUniqueId);
			}
			
		} catch (ApiException exception) {
			LOGGER.error(METHOD_NAME,
					domainReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(),
					Constant.API_EXCEPTION, exception.getErrorMessage());
			LOGGER.debug(METHOD_NAME,
					domainReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(),
					Constant.API_EXCEPTION, exception);
			throw exception;
		} catch (Exception exception) {
			LOGGER.error(METHOD_NAME,
					domainReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(),
					Constant.EXCEPTION, exception.getMessage());
			LOGGER.debug(METHOD_NAME,
					domainReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId(),
					Constant.EXCEPTION, exception);
			throw new ApiResponseException("500", "Internal  Server Error");
		}
		
		return domainResponse;
	}

}
