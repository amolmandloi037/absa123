package com.absa.amol.saving.service.updateaccountstatus;

import com.absa.amol.util.model.ApiRequestHeader;

public interface UpdateAccountStatusValidationService {

	public <T> void validateInputRequest(T request, ApiRequestHeader apiRequestHeader);
}
