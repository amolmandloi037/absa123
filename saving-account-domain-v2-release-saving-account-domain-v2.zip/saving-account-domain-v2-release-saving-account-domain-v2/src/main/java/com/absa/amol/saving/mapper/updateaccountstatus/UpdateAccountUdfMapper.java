package com.absa.amol.saving.mapper.updateaccountstatus;

import com.absa.amol.saving.model.sys.updaccudf.AccountUdfUpdateReq;
import com.absa.amol.saving.model.sys.updaccudf.AccountUdfUpdateRes;
import com.absa.amol.saving.model.sys.updaccudf.ReplyMessages;
import com.absa.amol.saving.model.updateaccountstatus.UpdateAccountStatusDomainReqWrapper;
import com.absa.amol.saving.model.updateaccountstatus.UpdateAccountStatusDomainRes;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.model.ResponseEntity;
import com.absa.amol.util.utility.CommonUtil;
import com.absa.amol.util.utility.StringUtil;

public class UpdateAccountUdfMapper {
	public AccountUdfUpdateReq  getActDctAccRequest(UpdateAccountStatusDomainReqWrapper domainReqWrapper) {
		AccountUdfUpdateReq accountUdfUpdateReq = new AccountUdfUpdateReq(); 
		if(CommonUtil.isNotNull(domainReqWrapper) && CommonUtil.isNotNull(domainReqWrapper.getUpdateAccountStatusDomainReq())) {
			accountUdfUpdateReq.setAccountId(domainReqWrapper.getUpdateAccountStatusDomainReq().getSavingAccountNumber());
			if(CommonUtil.isNotNull(domainReqWrapper.getUpdateAccountStatusDomainReq().getUdfDetails())&&
					"NUIT".equalsIgnoreCase(domainReqWrapper.getUpdateAccountStatusDomainReq().getUdfDetails().getUdfType())) {
				accountUdfUpdateReq.setNuitNo(domainReqWrapper.getUpdateAccountStatusDomainReq().getUdfDetails().getUdfCode());
			}
		}
		
		return accountUdfUpdateReq;
	}
	
	public ResponseEntity<UpdateAccountStatusDomainRes> setActDctAccResponse(ResponseEntity<AccountUdfUpdateRes> systemResponse, String consumerUniqueId){
		AccountUdfUpdateRes accountUdfUpdateRes=null;
		String msg = null;
		String statusMsg=Constant.SUCCESS_MESSAGE;
		String statusCode = Constant.SUCCESS_CODE;
		StringBuilder sb = new StringBuilder();
		if(CommonUtil.isNotNull(systemResponse) && CommonUtil.isNotNull(systemResponse.getData())) {
			 accountUdfUpdateRes=systemResponse.getData();
			 if(accountUdfUpdateRes.getReplyCode().equals(Constant.REPLY_CODE_0)) {
					msg = Constant.DATA_UPDATED_SUCCESS;
				}else if(accountUdfUpdateRes.getReplyCode().equals(Constant.REPLY_CODE_40)){
					if(StringUtil.isStringNotNullAndNotEmpty(accountUdfUpdateRes.getStatusDesc())) {
						sb.append(accountUdfUpdateRes.getStatusDesc());
					}
					else {
						sb=	getMessage(accountUdfUpdateRes);
					} 
					msg = sb.toString();
				}else {
					statusMsg= Constant.FAILURE_MSG;
					statusCode = Constant.BAD_REQUEST_CODE;
					if(StringUtil.isStringNotNullAndNotEmpty(accountUdfUpdateRes.getStatusDesc())) {
						sb.append(accountUdfUpdateRes.getStatusDesc());
					}
					else {
						sb=	getMessage(accountUdfUpdateRes);
					}
					msg = sb.toString();
				}
		}
		UpdateAccountStatusDomainRes domainRes = new UpdateAccountStatusDomainRes();
		domainRes.setReferenceNumber(consumerUniqueId);
		return  new ResponseEntity<>(statusCode,msg,statusMsg,domainRes);
		
	}

private StringBuilder getMessage(AccountUdfUpdateRes accountUdfUpdateRes) {
	 StringBuilder sb = new StringBuilder();
	if(CommonUtil.isNotNull(accountUdfUpdateRes) &&
			CommonUtil.isNotNull(accountUdfUpdateRes.getExtendedReply()) &&
			CommonUtil.isNotNull(accountUdfUpdateRes.getExtendedReply().getMessages()) &&
			CommonUtil.isNotNull(accountUdfUpdateRes.getExtendedReply().getMessages().getItems()))
		sb.append(!accountUdfUpdateRes.getExtendedReply().getMessages().getItems().isEmpty() ?
				accountUdfUpdateRes.getExtendedReply().getMessages().getItems()
				.stream().map(ReplyMessages::getMessage):"");
	return sb;
}

}
