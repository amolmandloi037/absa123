package com.absa.amol.saving.model.sys.purchasemv;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CashServiceMvSignInRes {
	
	String serviceResCode;
	String serviceResDesc;

}
