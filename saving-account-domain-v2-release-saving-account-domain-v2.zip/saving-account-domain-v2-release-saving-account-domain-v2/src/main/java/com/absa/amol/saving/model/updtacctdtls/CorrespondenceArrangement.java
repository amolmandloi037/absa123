package com.absa.amol.saving.model.updtacctdtls;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CorrespondenceArrangement {
	
	@Valid
	private AccountAddress accountAddress;
	
	
	@Pattern(regexp = "[0-9]{1,3}", message = "contactNumber.pattern.message")
	@Schema(description = "Optional field", pattern = "Numeric",minLength=1, maxLength = 3 )
	private String contactNumber;

}
