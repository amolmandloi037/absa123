package com.absa.amol.saving.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class CASAInterestCapitalization {
  private CustomDate lastDebitCapitalisationDate;
  private CustomDate lastCreditCapitalisationDate;
  private double balanceAmountAsOfLastCreditCap;
  private double balanceAmountAsOfLastDebitCap;
  private String creditInterestCapitalisationBasisCode;
  private String creditInterestCapitalizationFrequency;
  private String debitInterestCapitalisationBasisCode;
  private String debitInterestCapitalisationFrequencyCode;
  private CustomDate nextCreditInterestCapitalisationDate;
  private CustomDate nextDebitInterestCapitalisationDate;

}
