package com.absa.amol.saving.model.createcasaaccount;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;
import javax.ws.rs.BeanParam;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import com.absa.amol.util.model.ApiRequestHeader;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CreateCasaAccountRequest {
	@BeanParam
	@Valid
	private ApiRequestHeader apiRequestHeader;

	@Valid
	private BankBranch bankBranch;
	 
	@Size(max = 60, message = "customerCommentary.size.error.message")
	private String customerCommentary;
	@Valid
	private ProductInstanceReference productInstanceReference;
	@Valid
	private AccountStatus accountStatus;
	@Valid
	private AccountType accountType;
	@Valid
	private List<CustomerReference> customerReferences;

	
	@Size(min = 1, max = 40, message = "createCasaAccountRequest.title.length.error.message")
	private String title;
	@Valid
	private List<ArrangementOption> arrangementOption;
	
	@Digits(integer = 7, fraction = 0, message = "startAccountNumberRange.digits.error.message")
	private Integer startAccountNumberRange;

	@Digits(integer = 7, fraction = 0, message = "endAccountNumberRange.digits.error.message")
	private Integer endAccountNumberRange;
	  
	@Valid
	private List<MisInfo> misInfo;

	@Schema(hidden = true)
	private String ConfiguredChannelId;
}
