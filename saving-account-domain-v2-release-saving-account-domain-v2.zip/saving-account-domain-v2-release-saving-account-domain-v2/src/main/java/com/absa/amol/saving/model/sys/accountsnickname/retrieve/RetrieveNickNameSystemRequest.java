package com.absa.amol.saving.model.sys.accountsnickname.retrieve;

import javax.ws.rs.BeanParam;
import javax.ws.rs.QueryParam;

import com.absa.amol.util.model.ApiRequestHeader;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RetrieveNickNameSystemRequest {
    
	@BeanParam
	private ApiRequestHeader apiRequestheader;
	
	@QueryParam(value="scvId")
	private String scvId;
}
