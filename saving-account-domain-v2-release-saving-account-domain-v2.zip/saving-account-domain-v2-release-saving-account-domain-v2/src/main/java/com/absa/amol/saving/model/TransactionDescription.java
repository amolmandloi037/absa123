package com.absa.amol.saving.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class TransactionDescription {
	private String remarks;
	private String authorisedBy;
	private String authorisedDateTime;
	private String decision;
	private String authorizerName;

}
