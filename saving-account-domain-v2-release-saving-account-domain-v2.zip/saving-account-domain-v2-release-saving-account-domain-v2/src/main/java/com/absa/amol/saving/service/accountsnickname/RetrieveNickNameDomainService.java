package com.absa.amol.saving.service.accountsnickname;

import com.absa.amol.saving.model.accountsnickname.retrieve.RetrieveAccountsNickNameReq;
import com.absa.amol.saving.model.accountsnickname.retrieve.RetrieveAccountsNickNameRes;
import com.absa.amol.util.model.ResponseEntity;

public interface RetrieveNickNameDomainService {
	
	ResponseEntity<RetrieveAccountsNickNameRes> retrieveNickNameDomain(RetrieveAccountsNickNameReq retrieveAccountsNickNameReq);
}
