package com.absa.amol.saving.service.demandraft;

import com.absa.amol.util.model.ApiRequestHeader;

public interface IDemandDraftValidatorService {
	public <T> void validateInputRequest(T request, ApiRequestHeader apiRequestHeader);

}
