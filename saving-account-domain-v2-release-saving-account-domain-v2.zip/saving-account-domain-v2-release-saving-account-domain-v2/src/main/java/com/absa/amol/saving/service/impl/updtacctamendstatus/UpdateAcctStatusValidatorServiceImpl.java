package com.absa.amol.saving.service.impl.updtacctamendstatus;

import java.util.HashSet;
import java.util.Set;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import com.absa.amol.saving.util.Constant;
import com.absa.amol.saving.util.SavingAccountDomainUtil;
import com.absa.amol.saving.model.updtacctstatus.UpdateAcctStatusReqWrapper;
import com.absa.amol.saving.service.updtacctamendstatus.UpdateAcctStatusValidatorService;
import com.absa.amol.util.exception.ApiRequestException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;

@ApplicationScoped
public class UpdateAcctStatusValidatorServiceImpl implements UpdateAcctStatusValidatorService {

	@Inject
	private Validator validator;

	@Inject
	SavingAccountDomainUtil util;


	private static final Logger LOGGER = LoggerFactory.getLogger(UpdateAcctStatusValidatorServiceImpl.class);

	@Override
	public void validateInputRequest(UpdateAcctStatusReqWrapper requestWrapper) {
		final String METHOD_NAME = "validateInputRequest";
		String consumerUniqRefId = requestWrapper.getApiRequestHeader().getConsumerUniqueReferenceId();
		LOGGER.info(METHOD_NAME, consumerUniqRefId, "Validating the request","");
		Set<String> errorSet = new HashSet<>();
		Set<String> annoBeansValErrSet = validatedAnnotedBeans(requestWrapper);
		errorSet.addAll(annoBeansValErrSet);
		if (!errorSet.isEmpty()) {
			String errorMessage = String.join(",", errorSet);
			LOGGER.error(METHOD_NAME, consumerUniqRefId, "Validation failed:", errorMessage);
			throw new ApiRequestException(Constant.BAD_REQUEST_CODE, errorMessage);
		}
		LOGGER.info(METHOD_NAME, consumerUniqRefId, "Successfully validated the request","Good to go ahead");
	}

	private Set<String> validatedAnnotedBeans(UpdateAcctStatusReqWrapper requestWrapper) {
		Set<String> annoBeansValErrSet = new HashSet<>();
		Set<ConstraintViolation<Object>> violations = validator.validate(requestWrapper);
		for (ConstraintViolation<Object> error : violations) {
			String customErroMsg = util.getPropertyValue(error.getMessageTemplate());
			annoBeansValErrSet.add(customErroMsg);
		}
		return annoBeansValErrSet;
	}

}
