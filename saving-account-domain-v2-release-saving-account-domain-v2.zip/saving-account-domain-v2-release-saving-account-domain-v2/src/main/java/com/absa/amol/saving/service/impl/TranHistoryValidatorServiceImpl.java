package com.absa.amol.saving.service.impl;

import java.util.Set;
import java.util.stream.Collectors;
import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import org.eclipse.microprofile.config.Config;
import com.absa.amol.saving.model.TransactionHistoryDomainRequest;
import com.absa.amol.saving.service.TranHistoryValidatorService;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.exception.ApiRequestException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.utility.StringUtil;

public class TranHistoryValidatorServiceImpl implements TranHistoryValidatorService {
  @Inject
  private Validator validator;

  @Inject
  Config config;

  private static final Logger logger =
      LoggerFactory.getLogger(TranHistoryValidatorServiceImpl.class);

  @Override
  public void validateCasaRequest(TransactionHistoryDomainRequest accountRequest) {

    logger.info(Constant.VALIDATE_REQUEST, "", "Validating the request", "");
    Set<String> errorList = validatedAnnotedBeans(accountRequest);
    customValidation(accountRequest, errorList);
    if (!errorList.isEmpty()) {
      String errorMessage = String.join(",", errorList);
      ApiRequestException exception =
          new ApiRequestException(Constant.BAD_REQUEST_CODE, errorMessage);
      logger.error(Constant.VALIDATE_REQUEST, "", "Validation failed:",
          exception.getErrorMessage());
      throw exception;
    }
    logger.info(Constant.VALIDATE_REQUEST, "", "No validation errors found", "");
  }

  private Set<String> validatedAnnotedBeans(TransactionHistoryDomainRequest accountRequest) {
    Set<ConstraintViolation<TransactionHistoryDomainRequest>> violations =
        validator.validate(accountRequest);
    return violations.stream().map(constraint -> {
      String customErroMsg = getPropertyValue(constraint.getMessageTemplate());
      return StringUtil.isStringNullOrEmpty(customErroMsg) ? constraint.getMessage()
          : customErroMsg;
    }).collect(Collectors.toSet());
  }

  private Set<String> customValidation(TransactionHistoryDomainRequest request,
      Set<String> errors) {
    if (StringUtil.isStringNullOrEmpty(request.getActionCode())
        || Constant.TH_ACTION_CODE_LIST.equals(request.getActionCode())) {
      if (StringUtil.isStringNullOrEmpty(request.getSavingsAccountNumber())) {
        String customErroMsg = getPropertyValue("accountNumber.th.nullOrEmpty.error.message");
        errors.add(customErroMsg);
      }
    }
    return errors;
  }


  private String getPropertyValue(String confKey) {
    try {
      return config.getValue(confKey, String.class);
    } catch (Exception e) {
      logger.error("getPropertyValue", "",
          "Exception while reading property for the key ::" + confKey, e.getMessage());
    }
    return "";
  }

}
