package com.absa.amol.saving.service.impl;

import javax.inject.Inject;

import org.eclipse.microprofile.rest.client.inject.RestClient;

import com.absa.amol.saving.model.standinginstruction.singledetail.StandingInstructionSingleDetailRequest;
import com.absa.amol.saving.model.standinginstruction.singledetail.StandingInstructionSingleDetailResponse;
import com.absa.amol.saving.service.IStandingInstructionSingleDetailService;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.saving.util.IStandingInstructionSingleDetailClientBuilder;
import com.absa.amol.util.exception.ApiException;
import com.absa.amol.util.exception.ApiRequestException;
import com.absa.amol.util.exception.ApiResponseException;
import com.absa.amol.util.exception.SORSystemServiceUnavailableException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ResponseEntity;

public class StandingInstructionSingleDetailServiceImpl implements IStandingInstructionSingleDetailService
{
	private static final Logger LOGGER = LoggerFactory.getLogger(StandingInstructionSingleDetailServiceImpl.class);
	
	@SuppressWarnings("cdi-ambiguous-dependency")
	@Inject
	@RestClient
	IStandingInstructionSingleDetailClientBuilder clientBuilder;
	
	@Override
	public ResponseEntity<StandingInstructionSingleDetailResponse> singleStandingInstruction(
			StandingInstructionSingleDetailRequest singleSIReq) {
		try {
			LOGGER.info(Constant.SINGLE_SI + ":Service", Constant.EMPTY ,singleSIReq.getApiRequestHeader().getConsumerUniqueReferenceId(), Constant.EMPTY);
			return clientBuilder.getSingleStandingInstruction(singleSIReq);
		} catch (ApiRequestException apiRequestException) {
			LOGGER.error(Constant.SINGLE_SI, singleSIReq.getApiRequestHeader().getConsumerUniqueReferenceId(), "ApiRequestException", apiRequestException.getMessage());
			LOGGER.debug(Constant.SINGLE_SI, singleSIReq.getApiRequestHeader().getConsumerUniqueReferenceId(), "ApiRequestException Occurred", apiRequestException);
			throw apiRequestException;
		} catch (SORSystemServiceUnavailableException unavailableex) {
			LOGGER.error(Constant.SINGLE_SI, singleSIReq.getApiRequestHeader().getConsumerUniqueReferenceId() , "Inside SORSystemServiceUnavailableException", unavailableex.getErrorMessage());
			LOGGER.debug(Constant.SINGLE_SI, singleSIReq.getApiRequestHeader().getConsumerUniqueReferenceId() , "Inside SORSystemServiceUnavailableException Debug", unavailableex);
			throw new SORSystemServiceUnavailableException(unavailableex.getErrorCode(), unavailableex.getErrorMessage());
		}catch (ApiException apiException) {
			LOGGER.error(Constant.SINGLE_SI, singleSIReq.getApiRequestHeader().getConsumerUniqueReferenceId(), "ApiException", apiException.getMessage());
			LOGGER.debug(Constant.SINGLE_SI, singleSIReq.getApiRequestHeader().getConsumerUniqueReferenceId(), "ApiException Occurred", apiException);
			throw apiException;
		} catch (Exception exception) {
			LOGGER.error(Constant.SINGLE_SI, singleSIReq.getApiRequestHeader().getConsumerUniqueReferenceId(), "Exception", exception.getMessage());
			LOGGER.debug(Constant.SINGLE_SI, singleSIReq.getApiRequestHeader().getConsumerUniqueReferenceId(), "Exception Occurred", exception);
			throw new ApiResponseException(Constant.INTERNAL_ERROR_CODE, Constant.INTERNAL_ERROR_MSG);
		}
		
	}

}
