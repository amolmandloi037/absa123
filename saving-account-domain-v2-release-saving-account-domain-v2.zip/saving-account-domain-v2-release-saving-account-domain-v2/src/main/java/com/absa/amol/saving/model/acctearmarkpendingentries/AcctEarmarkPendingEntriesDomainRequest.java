package com.absa.amol.saving.model.acctearmarkpendingentries;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import javax.ws.rs.BeanParam;
import javax.ws.rs.QueryParam;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import com.absa.amol.util.model.ApiRequestHeader;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Schema(name = "AcctEarmarkPendingEntriesDomainRequest", description = "Request Schema for Account Earmark Pending Entries Domain")
public class AcctEarmarkPendingEntriesDomainRequest {

	@Valid
	@BeanParam
	private ApiRequestHeader apiRequestHeader;

	@Schema(description = "Field is mandatory for all flows.", pattern = "[0-9]*", 
			maxLength = 7, required = true)
	@NotNull(message = "earmark.accountNumber.notempty.error.message")
	@NotEmpty(message = "earmark.accountNumber.notempty.error.message")
	@Size(max = 7, message = "earmark.accountNumber.length.error.message")
	@Pattern(regexp = "(^$)|^[0-9]*", message = "earmark.accountNumber.digit.error.message")
	@QueryParam("accountNumber")
	private String accountNumber;

	@Schema(description = "Field is mandatory for all flows.", pattern = "[0-9]*", minLength = 1,
			maxLength = 16, required = true)
	@NotNull(message = "earmark.bankBranchReference.notempty.error.message")
	@NotEmpty(message = "earmark.bankBranchReference.notempty.error.message")
	@Pattern(regexp = "^[0-9]*", message = "earmark.bankBranchReference.digit.error.message")
	@Size(min = 1, max = 3, message = "earmark.bankBranchReference.length.error.message")
	@QueryParam("bankBranchReference")
	private String bankBranchReference;
	
	@Schema(description = "Field is mandatory for all flows.", pattern = "[0-9]*", minLength = 1,
			maxLength = 16, required = true)
	@NotNull(message = "earmark.requestFlag.notempty.error.message")
	@NotEmpty(message = "earmark.requestFlag.notempty.error.message")
	@Pattern(regexp = "[EP]", message = "earmark.requestFlag.pattern.message")
	@QueryParam("requestFlag")
	private String requestFlag;
	
}