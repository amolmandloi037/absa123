package com.absa.amol.saving.model;

import java.math.BigDecimal;
import java.util.List;
import javax.json.bind.annotation.JsonbNillable;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@JsonbNillable
@ToString
public class TransactionHistoryResponse {
  private String accountNumber;
  private BigDecimal chequePurchaseLimit;
  private BigDecimal closingBalance;
  private String cpLimitExpiryDate;
  private String endDate;
  private boolean hasMoreResults;
  private BigDecimal lastStatementBalance;
  private String lastStatementDate;
  private BigDecimal netBalance;
  private long numberOfRecords;
  private BigDecimal openingBalance;
  private String startDate;
  private BigDecimal utilizedChequePurchaseLimit;
  // private AccountCommonInformation accountCommonInformation;
  // private AccountPurchaseLine purchaseLine;
  private FcrTransactionStatus status;

  private String accountName;
  private String accountTypeDesc;
  private String currencyCode;
  private String currencyDesc;
  private String branchName;
  private String curAvailBal;
  private String earBalance;
  private String effectiveDebitLimit;
  private String unclearedAmount;
  private String branchId;
  private String openingActualBal;
  private List<Transaction> transactions;
}
