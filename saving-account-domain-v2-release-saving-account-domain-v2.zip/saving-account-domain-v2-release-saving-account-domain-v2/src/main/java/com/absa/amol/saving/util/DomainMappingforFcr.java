package com.absa.amol.saving.util;


import java.util.ArrayList;
import java.util.List;
import com.absa.amol.saving.model.AccountBalance;
import com.absa.amol.saving.model.AccountCommonInformation;
import com.absa.amol.saving.model.AccountStatus;
import com.absa.amol.saving.model.ArrangementOption;
import com.absa.amol.saving.model.CASAControlAttribute;
import com.absa.amol.saving.model.CASAInterestCapitalization;
import com.absa.amol.saving.model.CASAValue;
import com.absa.amol.saving.model.CurrentAndSavingsAccount;
import com.absa.amol.saving.model.CustomerReference;
import com.absa.amol.saving.model.DateType;
import com.absa.amol.saving.model.ExternalBankingFacilityAttributes;
import com.absa.amol.saving.model.InterestAccrualType;
import com.absa.amol.saving.model.IssuedInventoryPropertyType;
import com.absa.amol.saving.model.RestrictionOptionSetting;
import com.absa.amol.saving.model.SavingAccountDetailsRequest;
import com.absa.amol.saving.model.SavingAccountDetailsResponse;
import com.absa.amol.saving.model.SavingAccountSummaryResp;
import com.absa.amol.saving.model.TaxReference;
import com.absa.amol.saving.model.UnclearedFundsAdvanceFacility;
import com.absa.amol.util.exception.ApiRequestException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.utility.AmolDateUtils;
import com.absa.amol.util.utility.CommonUtil;

public class DomainMappingforFcr {

 
private static final Logger logger = LoggerFactory.getLogger(DomainMappingforFcr.class);

  public SavingAccountDetailsResponse getDomainMappingofAccDetailsFromFcr(SavingAccountSummaryResp summaryResp,
      SavingAccountDetailsRequest casaRequest) {
	   final String METHOD_NAME = "getDomainMappingofAccDetailsFromFcr";
    String inDateFormat = "yyyyMMdd";
    String outDateFormat = "yyyy-MM-dd";

    logger.info(METHOD_NAME,
        casaRequest.getApiRequestHeader().getConsumerUniqueReferenceId(), "Domain Mapping for FCR Started", "");
    try {
      SavingAccountDetailsResponse casaResp = new SavingAccountDetailsResponse();
      AccountCommonInformation comInfo = summaryResp.getAccount().getAccountCommonInformation();
      AccountBalance acctBal = summaryResp.getAccount().getAccountBalance();
      CurrentAndSavingsAccount casaAcct = summaryResp.getAccount().getCurrentAndSavingsAccount();
      UnclearedFundsAdvanceFacility unclFund = summaryResp.getAccount().getUnclearedFundsAdvanceFacility();
      CASAValue casaVal = summaryResp.getAccount().getCASAValue();
      CASAControlAttribute casaCtrlAttr = summaryResp.getAccount().getCASAControlAttribute();
      ExternalBankingFacilityAttributes extrnlBankFac =
          summaryResp.getAccount().getExternalBankingFacilityAttributes();

      CASAInterestCapitalization casaIntCap = summaryResp.getAccount().getCASAInterestCapitalization();

      List<DateType> dateTypeList = new ArrayList<>();

      casaResp.setAccountNumber(comInfo.getAccountNumber());
      casaResp.setAccountTitle(comInfo.getAccountTitle());
      casaResp.setAccountCurrency(comInfo.getCurrencyShortName());
      casaResp.setCustomerNumber(comInfo.getCustomerNumber().toString());
      CustomerReference custRef = new CustomerReference();
      custRef.setFullName(comInfo.getFullName());
      casaResp.setCustomerReference(custRef);
      casaResp.setProductCode(comInfo.getProductCode());
      casaResp.setProductName(comInfo.getProductName());

      AccountStatus accStat = new AccountStatus();
      accStat.setAccountLifecycleStatusCode(comInfo.getAccountLifecycleStatusCode());
      accStat.setMinorAccountStatusCode(casaAcct.getMinorAccountStatusCode());
      accStat.setAccrualStatusCode(casaAcct.getAccountAccrualStatusCode());
      casaResp.setAccountStatus(accStat);

      casaResp.setAvailableBalance(acctBal.getAccountAvailableBalance());
      casaResp.setCurrentBalance(acctBal.getCurrentBookBalanceAmount());
      casaResp.setBranchCode(comInfo.getBranchCode().toString());
      casaResp.setBranchName(comInfo.getBranchName());
      casaResp.setBranchShortName(comInfo.getBranchShortName());

      DateType dateType = null;;

      if (CommonUtil.isNotNull(comInfo.getAccountOpeningDate())
          && CommonUtil.isNotNull(comInfo.getAccountOpeningDate().getYearMonthDate())) {
        dateType = new DateType("AccountOpeningDate", AmolDateUtils.dateConversion(inDateFormat, outDateFormat,
            comInfo.getAccountOpeningDate().getYearMonthDate().toString()));
        dateTypeList.add(dateType);
      }

      casaResp.setLanguageCode(comInfo.getLanguageCode());
      casaResp.setNomineeName(casaAcct.getNomineeName());

      RestrictionOptionSetting restSett = new RestrictionOptionSetting();
      restSett.setRestrictedAccountFlag(comInfo.isRestrictedAccountFlag());
      casaResp.setRestrictionOptionSetting(restSett);

      casaResp.setStaffFlag(comInfo.isStaffFlag());
      ArrangementOption arrangeOpt = new ArrangementOption();
      arrangeOpt.setHoldMailFlag(summaryResp.getAccount().getMailFacility().getMailFacilityMailControl());
      arrangeOpt.setJointAccountFlag(summaryResp.getAccount().getCASAControlAttribute().isJointAccountFlag());
      casaResp.setNib(casaAcct.getNib());

      TaxReference taxReference = new TaxReference();
      taxReference.setTdsFlag(casaAcct.isTdsFlag());
      taxReference.setTaxCode1(casaAcct.getTaxCode1());
      taxReference.setTaxCode2(casaAcct.getTaxCode2());
      taxReference.setTdsExemptionLimitAmount1(casaAcct.getTdsExemptionLimitAmount1());
      taxReference.setTdsExemptionLimitAmount2(casaAcct.getTdsExemptionLimitAmount1());
      casaResp.setTaxReference(taxReference);

      arrangeOpt
          .setMailAddressControlFlag(summaryResp.getAccount().getMailFacility().getMailFacilityMailControl());
      arrangeOpt.setNumberOfStatementCopies(
          summaryResp.getAccount().getStatementFacility().getNumberOfStatementCopies());

      arrangeOpt.setGenerateRateChangeIntimationFlag(casaAcct.isGenerateRateChangeIntimationFlag());
      arrangeOpt.setLeadDaysIntimation(casaAcct.getLeadDaysIntimation());
      casaResp.setIbanAccountNumber(
          summaryResp.getAccount().getBasicInformation().getInternationalBankAccountNumber());
      casaResp.setLineNumber(casaAcct.getPassbookLineNo());
      arrangeOpt.setNumberOfPastDueChecks(casaAcct.getNumberOfPastDueChecks());
      arrangeOpt.setNumberOfCheckWithdrawals(
          summaryResp.getAccount().getChequeBookFacility().getNumberOfChequeWithdrawals());
      casaResp.setPassbookLifecycleStatusCode(casaAcct.getPassbookLifecycleStatusCode());
      arrangeOpt.setCheckReorderThresholdNumber(
          summaryResp.getAccount().getChequeBookFacility().getChequeReorderThresholdNumber());
      arrangeOpt.setDeferredStmtGenerationDayOfMonth(
          summaryResp.getAccount().getStatementFacility().getDeferredStmtGenerationDayOfMonth());

      if (CommonUtil.isNotNull(summaryResp.getAccount())
          && CommonUtil.isNotNull(summaryResp.getAccount().getStatementPeriodBeginDate())) {
        if (CommonUtil.isNotNull(summaryResp.getAccount().getStatementPeriodBeginDate().getYearMonthDate())) {
          dateType =
              new DateType("StatementPeriodStartDate", AmolDateUtils.dateConversion(inDateFormat, outDateFormat,
                  summaryResp.getAccount().getStatementPeriodBeginDate().getYearMonthDate().toString()));
          dateTypeList.add(dateType);
        }

        if (CommonUtil.isNotNull(summaryResp.getAccount().getStatementPeriodEndDate().getYearMonthDate())) {
          dateType = new DateType("StatementPeriodEndDate", AmolDateUtils.dateConversion(inDateFormat,
              outDateFormat, summaryResp.getAccount().getStatementPeriodEndDate().getYearMonthDate().toString()));
          dateTypeList.add(dateType);
        }
      }

      casaResp.setTotalUnclearFundAmount(acctBal.getTotalUnclearFundAmount());
      casaResp.setAdvanceAgainstUnclearedFunds(unclFund.getAdvanceAgainstUnclearedFunds());
      casaResp.setTotalCASAHoldAmount(casaVal.getTotalCASAHoldAmount());
      casaResp.setAuthorisedDebitAmount(acctBal.getAuthorisedDebitAmount());
      casaResp.setMinimumRequiredBalanceAmount(acctBal.getMinimumRequiredBalanceAmount());
      casaResp.setMinimumRequiredTradingBalanceAmount(casaAcct.getMinimumRequiredTradingBalanceAmount());
      casaResp.setNetBalanceAmount(acctBal.getNetBalanceAmount());
      casaResp.setNetAvailableBalanceForWithdrawal(acctBal.getNetBalanceAmount());
      casaResp.setConfirmationAmount(acctBal.getConfirmationAmount());
      // casaResp.setCurrentBookBalanceAmount(acctBal.getCurrentBookBalanceAmount());
      casaResp.setPreviousDayClosingBookBalance(acctBal.getPreviousDayClosingBookBalance());
      casaResp.setSweepinAmountOnLien(acctBal.getSweepinAmountOnLien());
      casaResp.setPeriodicAverageBalanceAmount(acctBal.getPeriodicAverageBalanceAmount());

      arrangeOpt.setAdditionalAddressFlag(summaryResp.getAccount().getMailFacility().isAdditionalAddressFlag());
      arrangeOpt.setAdHocStatementFlag(casaCtrlAttr.isAdHocStatementFlag());
      arrangeOpt.setAtmFacilityFlag(extrnlBankFac.isATMFacilityFlag()); //
      arrangeOpt.setGroupBonusInteresFlag(casaCtrlAttr.getIsGroupBonusInterestApplicable());
      arrangeOpt.setInternetBankingAccessFlag(extrnlBankFac.isInternetBankingAccessFlag());
      arrangeOpt.setInwardDirectDebitAuthorizationFlag(casaCtrlAttr.isInwardDirectDebitAuthorizationFlag());
      arrangeOpt.setMobileFacilityFlag(extrnlBankFac.isMobileFacilityFlag());
      arrangeOpt.setPointOfSaleFacilityFlag(extrnlBankFac.isPointOfSaleFacilityFlag());
      arrangeOpt.setStandingInstructionFlag(casaCtrlAttr.isStandingInstructionFlag());
      arrangeOpt.setSweepoutInstructionFlag(casaCtrlAttr.isSweepoutInstructionFlag());

      if (casaIntCap != null) {

        if (CommonUtil.isNotNull(casaIntCap.getLastCreditCapitalisationDate())
            && CommonUtil.isNotNull(casaIntCap.getLastCreditCapitalisationDate().getYearMonthDate())) {
          dateType = new DateType("LastCreditCapitalisationDate", AmolDateUtils.dateConversion(inDateFormat,
              outDateFormat, casaIntCap.getLastCreditCapitalisationDate().getYearMonthDate().toString()));
          dateTypeList.add(dateType);
        }
        if (CommonUtil.isNotNull(casaIntCap.getLastDebitCapitalisationDate())
            && CommonUtil.isNotNull(casaIntCap.getLastDebitCapitalisationDate().getYearMonthDate())) {
          dateType = new DateType("LastDebitCapitalisationDate", AmolDateUtils.dateConversion(inDateFormat,
              outDateFormat, casaIntCap.getLastDebitCapitalisationDate().getYearMonthDate().toString()));
          dateTypeList.add(dateType);
        }

        casaResp.setBalanceAmountAsOfLastCreditCap(casaIntCap.getBalanceAmountAsOfLastCreditCap());

        casaResp.setBalanceAmountAsOfLastDebitCap(casaIntCap.getBalanceAmountAsOfLastDebitCap());

        if (CommonUtil.isNotNull(casaIntCap.getNextCreditInterestCapitalisationDate())
            && CommonUtil.isNotNull(casaIntCap.getNextCreditInterestCapitalisationDate().getYearMonthDate())) {
          dateType = new DateType("NextCreditInterestCapitalisationDate",
              AmolDateUtils.dateConversion(inDateFormat, outDateFormat,
                  casaIntCap.getNextCreditInterestCapitalisationDate().getYearMonthDate().toString()));
          dateTypeList.add(dateType);
        }

        if (CommonUtil.isNotNull(casaIntCap.getNextDebitInterestCapitalisationDate())
            && CommonUtil.isNotNull(casaIntCap.getNextDebitInterestCapitalisationDate().getYearMonthDate())) {
          dateType = new DateType("NextDebitInterestCapitalisationDate", AmolDateUtils.dateConversion(inDateFormat,
              outDateFormat, casaIntCap.getNextDebitInterestCapitalisationDate().getYearMonthDate().toString()));
          dateTypeList.add(dateType);
        }

        arrangeOpt.setCreditInterestCapitalisationBasisCode(casaIntCap.getCreditInterestCapitalisationBasisCode());

        arrangeOpt.setCreditInterestCapitalizationFrequency(casaIntCap.getCreditInterestCapitalizationFrequency());

        arrangeOpt.setDebitInterestCapitalisationBasisCode(casaIntCap.getDebitInterestCapitalisationBasisCode());

        arrangeOpt
            .setDebitInterestCapitalisationFrequencyCode(casaIntCap.getDebitInterestCapitalisationFrequencyCode());
      }

      List<InterestAccrualType> intereAccrList = new ArrayList<>();
      InterestAccrualType interestAccrualType =
          new InterestAccrualType("CreditInterestAccruedAmount", casaAcct.getCreditInterestAccruedAmount());
      intereAccrList.add(interestAccrualType);

      interestAccrualType =
          new InterestAccrualType("DebitInterestAccruedAmount", casaAcct.getDebitInterestAccruedAmount());
      intereAccrList.add(interestAccrualType);

      interestAccrualType =
          new InterestAccrualType("AdjustedCreditInterestAccrued", casaAcct.getAdjustedCreditInterestAccrued());
      intereAccrList.add(interestAccrualType);

      interestAccrualType =
          new InterestAccrualType("AdjustedDebitInterestAccrued", casaAcct.getAdjustedDebitInterestAccrued());
      intereAccrList.add(interestAccrualType);

      interestAccrualType = new InterestAccrualType("ProjectedTaxOnAccruedInterestAmount",
          casaAcct.getProjectedTaxOnAccruedInterestAmount());
      intereAccrList.add(interestAccrualType);

      interestAccrualType = new InterestAccrualType("InterestAccruedInCurrentFinancialYear",
          casaVal.getInterestAccruedInCurrentFinancialYear());
      intereAccrList.add(interestAccrualType);
      casaResp.setInterestAccrualType(intereAccrList);

      arrangeOpt
          .setOverdraftLimitAmount(summaryResp.getAccount().getOverdraftFacility().getOverdraftLimitAmount());
      arrangeOpt.setInterestWaiverFlag(casaCtrlAttr.isInterestWaiverFlag());

      List<IssuedInventoryPropertyType> issuedInventoryPropList = new ArrayList<>();
      IssuedInventoryPropertyType issuedInventoryPropertyType = new IssuedInventoryPropertyType();
      issuedInventoryPropertyType.setType("LastIssuedCheckNumber");
      issuedInventoryPropertyType
          .setValue(summaryResp.getAccount().getChequeBookFacility().getLastIssuedCheckNumber());
      issuedInventoryPropList.add(issuedInventoryPropertyType);
      casaResp.setIssuedInventoryPropertyType(issuedInventoryPropList);

      casaResp.setDebitsMonthTillDateAmount(casaAcct.getDebitsMonthTillDateAmount());

      if (CommonUtil.isNotNull(casaAcct) && CommonUtil.isNotNull(casaAcct.getDebitsLastDate())
          && CommonUtil.isNotNull(casaAcct.getDebitsLastDate().getYearMonthDate())) {
        dateType = new DateType("DebitsLastDate", AmolDateUtils.dateConversion(inDateFormat, outDateFormat,
            casaAcct.getDebitsLastDate().getYearMonthDate().toString()));
        dateTypeList.add(dateType);
      }

      casaResp.setDebitsYearTillDateAmount(casaAcct.getDebitsYearTillDateAmount());
      casaResp.setMtdDebitsCount(casaAcct.getMTDDebitsCount());
      casaResp.setYtdDebitsCount(casaAcct.getYTDDebitsCount());
      casaResp.setYtdDebitsLastAmount(casaAcct.getYTDDebitsLastAmount());
      casaResp.setCreditsMonthTillDateAmount(casaAcct.getCreditsMonthTillDateAmount());
      casaResp.setMtdCreditsCount(casaAcct.getMTDCreditsCount());
      casaResp.setYtdCreditsCount(casaAcct.getYTDCreditsCount());

      if (CommonUtil.isNotNull(casaAcct) && CommonUtil.isNotNull(casaAcct.getCreditLastDate())
          && CommonUtil.isNotNull(casaAcct.getCreditLastDate().getYearMonthDate())) {
        dateType = new DateType("CreditLastDate", AmolDateUtils.dateConversion(inDateFormat, outDateFormat,
            casaAcct.getCreditLastDate().getYearMonthDate().toString()));
        dateTypeList.add(dateType);
      }
      casaResp.setYtdCreditLastAmount(casaAcct.getYTDCreditLastAmount());
      casaResp.setArrangementOption(arrangeOpt);
      casaResp.setDateType(dateTypeList);

      return casaResp;

    } catch (Exception exception) {
      logger.error(METHOD_NAME,
          casaRequest.getApiRequestHeader().getConsumerUniqueReferenceId(), "Exception in request mapping",
          exception.getMessage());
      logger.error(METHOD_NAME,
          casaRequest.getApiRequestHeader().getConsumerUniqueReferenceId(), "Exception in request mapping",
          exception);
      throw new ApiRequestException(Constant.BAD_REQUEST_CODE, exception.getMessage());
    }
  }
}
