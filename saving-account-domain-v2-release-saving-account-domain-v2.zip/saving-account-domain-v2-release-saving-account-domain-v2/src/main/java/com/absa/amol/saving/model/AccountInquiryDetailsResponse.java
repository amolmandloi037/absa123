package com.absa.amol.saving.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class AccountInquiryDetailsResponse {

  private String customerNumber;
  private String proposition;
  private String displayName;
  private String companyName;
  private String businessType;
  private String companyRegistrationNumber;
  private String dateBusinessEstablished;
  private String natureOfBusiness;
  private String gcisClientId;
  private String icaCaseId;
  private String title;
  private String firstName;
  private String familyName;
  private String idCardNumber;
  private String passportNumber;
  private String customerRelationshipNote;
  private String relationshipEstablished;
  private String marketSegment;
  private String referCode;
  private String marketingOptOut;
  private String vatNumber;
  private String vatClassification;
  private String customerStatus;
  private String dateOfStatus;
  private String referDesc;
  private String primaryAccount;
  private String primaryContact;
  private String chargePackage;
  private String ratePackage;
  private String ddUnpayExcess;
  private String creditRating;
  private String creditRatingReference;
  private String creditRatingRate;
  private String driverLicenseDetails;
  private String incomeTaxNumber;
  private String gender;
  private String kycStatus;
  private String turnover;
  private String internetBankInd;
  private String pepInd;
  private String tradingName;
  private String natureOfBusinessCode;
  private String geoOperStatus;
  private String solicitationChannel;
  private String volumesExceeded;
  private String entityType;
  private String complexStructure;
  private Integer currentCount;
  private Integer savingsCount;
  private Integer termDepCount;
  private Integer investmentCount;
  private Integer securedCount;
  private Integer securedCreditFinanceCount;
  private Integer unsecuredCount;
  private Integer tradeOrInsuranceCount;
  private String riskScore;
  private String riskLevel;
  private String cashExceedLimit;
  private String prohibitedAccount;
  private String isAddedToKamls;
  private String preferredMethodOfContact;
}
