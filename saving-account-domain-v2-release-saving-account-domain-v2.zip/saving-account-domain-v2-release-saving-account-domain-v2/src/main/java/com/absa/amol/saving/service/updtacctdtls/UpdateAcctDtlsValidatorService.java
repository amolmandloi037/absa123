package com.absa.amol.saving.service.updtacctdtls;

import com.absa.amol.saving.model.updtacctdtls.UpdateAcctDtlsReqWrapper;

public interface UpdateAcctDtlsValidatorService {
	public void validateInputRequest(UpdateAcctDtlsReqWrapper updateAcctDtlsReqWrapper);

}
