package com.absa.amol.saving.model.updtacctstatus;

import java.util.List;

import javax.validation.Valid;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UpdateAcctStatusReq {

	@Valid
	private ProductInstanceReference productInstanceReference;
	
	@Valid
	private BankBranch bankBranch;
	
	@Valid
	private List<AccountCustomerUpdate> accountCustomerUpdates;
	
}
