package com.absa.amol.saving.model.sys.updtacctamendstatus;

import java.util.List;

import javax.json.bind.annotation.JsonbProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AcctMngmtAmendReq {
	
	private String branchCode;
	
	private String accountId;
	
	@JsonbProperty(value = "accountCustomerUpdate")
	private List<AccountCustomerUpdateAmend> accountCustomerUpdateAmend;	
	
}
