package com.absa.amol.saving.builder;

import javax.ws.rs.BeanParam;
import javax.ws.rs.POST;

import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import com.absa.amol.saving.model.sys.updtacctdtls.AccountOpenReq;
import com.absa.amol.saving.model.sys.updtacctdtls.AccountOpenRes;
import com.absa.amol.saving.util.ServerSideExceptionMapper;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.model.ResponseEntity;

@RegisterRestClient(configKey = "account.update.dtls.sys.url")
@RegisterProvider(value = ServerSideExceptionMapper.class)
public interface UpdateAcctDtlsClientBuilder {

	@POST
	ResponseEntity<AccountOpenRes> updateAcctDetails(@BeanParam ApiRequestHeader apiRequestHeader,
			@RequestBody AccountOpenReq accountOpenReq);

}
