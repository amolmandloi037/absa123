package com.absa.amol.saving.model.sys.demanddraft;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Status {

	private String statusCode;
	private String statusDesc;
	private SystemExtendedReply extendedReply;
	private String externalReferenceNo;
	private String inputOverridenWarnings;
	private Boolean isOverriden;
	private Boolean isServiceChargeApplied;
	private String memo;
	private Long replyCode;
	private String replyText;
	private Long spReturnValue;
	private String transactionDateTimeText;
	private String userReferenceNumber;
	private ArrayOfValidationError validationErrors;

}
