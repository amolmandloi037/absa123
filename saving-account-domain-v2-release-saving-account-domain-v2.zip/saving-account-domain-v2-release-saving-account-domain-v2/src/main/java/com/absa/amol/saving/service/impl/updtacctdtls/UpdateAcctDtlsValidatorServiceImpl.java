package com.absa.amol.saving.service.impl.updtacctdtls;

import java.util.HashSet;
import java.util.Set;

import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import com.absa.amol.saving.model.updtacctdtls.UpdateAcctDtlsReqWrapper;
import com.absa.amol.saving.service.updtacctdtls.UpdateAcctDtlsValidatorService;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.saving.util.SavingAccountDomainUtil;
import com.absa.amol.util.exception.ApiRequestException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.utility.CommonUtil;
import com.absa.amol.util.utility.StringUtil;

public class UpdateAcctDtlsValidatorServiceImpl implements UpdateAcctDtlsValidatorService {
	
	@Inject
	private Validator validator;

	@Inject
	SavingAccountDomainUtil util;


	private static final Logger LOGGER = LoggerFactory.getLogger(UpdateAcctDtlsValidatorServiceImpl.class);
	
	@Override
	public void validateInputRequest(UpdateAcctDtlsReqWrapper updateAcctDtlsReqWrapper) {
		final String METHOD_NAME = "validateInputRequest";
		String consumerUniqRefId = updateAcctDtlsReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId();
		LOGGER.info(METHOD_NAME, consumerUniqRefId, "Validating the request","");
		Set<String> errorSet = new HashSet<>();
		Set<String> annoBeansValErrSet = validatedAnnotedBeans(updateAcctDtlsReqWrapper);
		Set<String> customValErrSet = customvalidatedBeans(updateAcctDtlsReqWrapper);
		errorSet.addAll(annoBeansValErrSet);
		errorSet.addAll(customValErrSet);
		if (!errorSet.isEmpty()) {
			String errorMessage = String.join(",", errorSet);
			LOGGER.error(METHOD_NAME, consumerUniqRefId, "Validation failed:", errorMessage);
			throw new ApiRequestException(Constant.BAD_REQUEST_CODE, errorMessage);
		}
		LOGGER.info(METHOD_NAME, consumerUniqRefId, "Successfully validated the request","Good to go ahead");
	}

	private Set<String> validatedAnnotedBeans(UpdateAcctDtlsReqWrapper updateAcctDtlsReqWrapper) {
		Set<String> annoBeansValErrSet = new HashSet<>();
		Set<ConstraintViolation<Object>> violations = validator.validate(updateAcctDtlsReqWrapper);
		for (ConstraintViolation<Object> error : violations) {
			String customErroMsg = util.getPropertyValue(error.getMessageTemplate());
			annoBeansValErrSet.add(customErroMsg);
		}
		return annoBeansValErrSet;
	}
	
	private Set<String> customvalidatedBeans(UpdateAcctDtlsReqWrapper updateAcctDtlsReqWrapper) {

		String consumerUniqRefId = updateAcctDtlsReqWrapper.getApiRequestHeader().getConsumerUniqueReferenceId();
		LOGGER.info("customvalidatedBeans", consumerUniqRefId, "Validating the request","");
		Set<String> customValErrSet = new HashSet<>();
		if(CommonUtil.isNotNull(updateAcctDtlsReqWrapper.getUpdateAcctDtlsReq()) 
			 && StringUtil.isStringNotNullAndNotEmpty(updateAcctDtlsReqWrapper.getUpdateAcctDtlsReq().getSavingAccountNumber())
			 && (updateAcctDtlsReqWrapper.getUpdateAcctDtlsReq().getSavingAccountNumber().split("0", 
					 -1).length-1 ==updateAcctDtlsReqWrapper.getUpdateAcctDtlsReq().getSavingAccountNumber().length())) {
			customValErrSet.add(util.getPropertyValue("savingAccountNumber.regex.error.message"));
		}
		return customValErrSet;
	}
		
}

