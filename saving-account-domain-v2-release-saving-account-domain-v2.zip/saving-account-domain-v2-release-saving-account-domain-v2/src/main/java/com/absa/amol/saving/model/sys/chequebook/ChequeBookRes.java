package com.absa.amol.saving.model.sys.chequebook;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ChequeBookRes {
	
	Status status;
	

}
