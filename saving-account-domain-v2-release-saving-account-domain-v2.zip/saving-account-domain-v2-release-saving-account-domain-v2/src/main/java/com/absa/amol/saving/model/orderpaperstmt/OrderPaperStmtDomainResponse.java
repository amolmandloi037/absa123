package com.absa.amol.saving.model.orderpaperstmt;

import org.eclipse.microprofile.openapi.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(name = "OrderPaperStmtDomainResponse",
    description = "Response Schema For Order Paper Statement")
public class OrderPaperStmtDomainResponse {
  private String transactionReferenceNumber;
}
