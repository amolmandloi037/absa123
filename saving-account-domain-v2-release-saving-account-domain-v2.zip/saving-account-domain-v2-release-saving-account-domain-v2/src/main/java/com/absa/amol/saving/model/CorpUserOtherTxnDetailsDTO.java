package com.absa.amol.saving.model;

import javax.json.bind.annotation.JsonbNillable;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonbNillable
public class CorpUserOtherTxnDetailsDTO {
	
    private String fieldKey;
    private String fieldValue;
    private String fieldOrder;
}
