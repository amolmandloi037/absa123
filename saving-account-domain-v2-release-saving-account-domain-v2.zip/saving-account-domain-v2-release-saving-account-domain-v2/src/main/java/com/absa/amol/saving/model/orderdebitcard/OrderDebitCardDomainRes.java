package com.absa.amol.saving.model.orderdebitcard;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Schema(name = "OrderDebitCardDomainRes", description = "Response Schema for Order Debit Card API")
public class OrderDebitCardDomainRes {
	
	private String referenceNumber;

}
