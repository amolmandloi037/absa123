package com.absa.amol.saving.model.standinginstruction.singledetail;

import javax.ws.rs.QueryParam;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StandingOrderReferenceSingleDetailReq 
{
	
	@Schema(description = "Field is mandatory.", pattern = "Only numeric", maxLength = 6, required = true)
	@QueryParam("standingOrderNumber")
	private String standingOrderNumber;
										 
}
