package com.absa.amol.saving.model.updtacctdtls;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UpdateAcctDtlsReq {
	
	@Pattern(regexp = "[0-9]{1,3}", message = "bankBranch.pattern.message")
	@NotNull( message="bankBranch.null.empty.message")
	@NotEmpty( message="bankBranch.null.empty.message")
	@Schema(description = "Mandatory field", pattern = "Numeric", maxLength = 3, required = true )
	private String bankBranch;
	
	@Pattern(regexp = "[0-9]{1,7}", message = "savingAccountNumber.pattern.message")
	@NotNull( message="savingAccountNumber.null.empty.message")
	@NotEmpty( message="savingAccountNumber.null.empty.message")
	@Schema(description = "Mandatory field", pattern = "Numeric", maxLength = 7, required = true )
	private String savingAccountNumber;
	
	@Pattern(regexp = "[0-9]{1,3}", message = "locationReference.pattern.message")
	@NotNull( message="locationReference.null.empty.message")
	@NotEmpty( message="locationReference.null.empty.message")
	@Schema(description = "Mandatory field", pattern = "Numeric", maxLength = 3, required = true )
	private String locationReference;
	
	@Pattern(regexp = "[0-9]{1,10}", message = "accountType.pattern.message")
	@NotNull( message="accountType.null.empty.message")
	@NotEmpty( message="accountType.null.empty.message")
	@Schema(description = "Mandatory field", pattern = "Numeric", maxLength = 10, required = true )
	private String accountType;
	
	@Size(min=1, max=25, message="accountShortName.size.error.message")
	@Schema(description = "Optional field", pattern = "AlphaNumeric", maxLength = 25 )
	private String accountShortName;
	
	@Size(min=1, max=35, message="accountLongName.size.error.message")
	@Schema(description = "Optional field", pattern = "AlphaNumeric", maxLength = 35 )
	private String accountLongName;
	
	@Pattern(regexp = "[a-zA-Z]{3,3}", message = "accountCurrency.pattern.message")
	@NotNull( message="accountCurrency.null.empty.message")
	@NotEmpty( message="accountCurrency.null.empty.message")
	@Schema(description = "Mandatory field", pattern = "Alphabetic", maxLength = 3, required = true )
	private String accountCurrency;
	
	@Pattern(regexp = "[012345]{0,1}?|", message = "accountStatus.pattern.message")
	@Schema(description = "Optional field", pattern = "Numeric", maxLength = 1 )
	private String accountStatus;
	
	@Valid
	private CustomerReference customerReference;
	
	@Valid
	private CorrespondenceArrangement correspondenceArrangement;
	@Valid
	private List<AccountParameter> accountParameter;
	@Valid
	private PricingParameters pricingParameters;


}
