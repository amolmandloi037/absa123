package com.absa.amol.saving.model;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.ws.rs.BeanParam;
import javax.ws.rs.QueryParam;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.model.ApiRequestHeader;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Schema(name = Constant.LIST_REQ_SCHEMA_NAME, description = Constant.LIST_REQ_SCHEMA_DESC)
@ToString
public class CorpuserFTListRequest {

  @BeanParam
  @Schema(hidden = true)
  @Valid
  private ApiRequestHeader apiRequestHeader;


  @QueryParam("userID")
  private String userID;

  @NotNull(message = "accountNumber.notnullempty.error.message")
  @NotEmpty(message = "accountNumber.notnullempty.error.message")
  @QueryParam("accountNumber")
  private String accountNumber;

  @NotNull(message = "transactionSearchTypeCode.notnullempty.error.message")
  @NotEmpty(message = "transactionSearchTypeCode.notnullempty.error.message")
  @QueryParam("transactionSearchTypeCode")
  private String transactionSearchTypeCode;

  // @Pattern(regexp = "[0-9]+", message = "numberOfRecordsPerPage.regex.error.message")
  @QueryParam("numberOfRecordsPerPage")
  private String numberOfRecordsPerPage;

  @QueryParam("pageNumber")
  // @Pattern(regexp = "[0-9]+", message = "pageNumber.regex.error.message")
  private String pageNumber;
}
