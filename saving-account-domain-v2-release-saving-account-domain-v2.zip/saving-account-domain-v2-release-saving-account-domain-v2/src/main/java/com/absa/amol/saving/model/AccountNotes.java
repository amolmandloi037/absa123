package com.absa.amol.saving.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AccountNotes {
	
	private String note1;
	private String note2;
	private String note3;
	

}
