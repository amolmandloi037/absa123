package com.absa.amol.saving.model.standinginstruction.retrieve;

import javax.validation.Valid;
import javax.ws.rs.BeanParam;
import javax.ws.rs.QueryParam;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

import com.absa.amol.util.model.ApiRequestHeader;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Schema(name = "StandingInstructionsRetReq", description = "Domain API Request Schema for Retrieve Standing Instructions")
public class StandingInstructionsRetReq {

	@Valid
    @BeanParam
    @Schema(hidden = true)
    private ApiRequestHeader apiRequestHeader;

    @QueryParam("customerReference")
    @Schema(description = "Mandatory filed for all flows. Represents customerId of System Adapter.", pattern = "[0-9]*", minLength = 1, maxLength = 12, required = true)
    private String customerReference;

    @QueryParam("accountNumber")
    @Schema(description = "Optional filed. maxlength = 7 For EBOX, maxlength = 16 for FCR", pattern = "[0-9]*")
    private String accountNumber;

    @QueryParam("bankBranch")
    @Schema(description = "Optional filed. Represents branchCode of System Adapter. maxlength = 3 For EBOX, maxlength = 5 for FCR", pattern = "[0-9]*")
    private String bankBranch;

    @QueryParam("standingOrderNumber")
    @Schema(description = "Optional filed for all flows. maxlength = 3", pattern = "[0-9]*")
    private String standingOrderNumber;
}