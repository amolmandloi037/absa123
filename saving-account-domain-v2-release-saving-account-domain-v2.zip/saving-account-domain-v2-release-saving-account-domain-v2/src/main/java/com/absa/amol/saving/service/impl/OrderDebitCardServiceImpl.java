package com.absa.amol.saving.service.impl;

import javax.inject.Inject;

import org.eclipse.microprofile.rest.client.inject.RestClient;

import com.absa.amol.saving.builder.OrderDebitCardClientBuilder;
import com.absa.amol.saving.model.orderdebitcard.OrderDebitCardDomainReq;
import com.absa.amol.saving.model.orderdebitcard.OrderDebitCardDomainRes;
import com.absa.amol.saving.model.orderdebitcard.OrderDebitCardSystemRequest;
import com.absa.amol.saving.model.orderdebitcard.OrderDebitCardSystemResponse;
import com.absa.amol.saving.model.orderdebitcard.PostalAddressSystemRequest;
import com.absa.amol.saving.service.IOrderDebitCardService;
import com.absa.amol.saving.service.IOrderDebitCardValidatorService;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.exception.ApiException;
import com.absa.amol.util.exception.ApiResponseException;
import com.absa.amol.util.logging.Logger;
import com.absa.amol.util.logging.LoggerFactory;
import com.absa.amol.util.model.ApiRequestHeader;
import com.absa.amol.util.model.ResponseEntity;

public class OrderDebitCardServiceImpl implements IOrderDebitCardService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(OrderDebitCardServiceImpl.class);
	
	@Inject
	@RestClient
	private OrderDebitCardClientBuilder clientBuilder;
	
	@Inject
	private IOrderDebitCardValidatorService validatorService;

	@Override
	public ResponseEntity<OrderDebitCardDomainRes> orderDebitCard(ApiRequestHeader apiRequestHeader,OrderDebitCardDomainReq orderDebitCardDomainReq) {
		LOGGER.info(Constant.M_ORDER_DEBIT_CARD, apiRequestHeader.getConsumerUniqueReferenceId(), Constant.BLANK, Constant.BLANK);
		ResponseEntity<OrderDebitCardDomainRes> domainResEntity = null;
		try 
		{
			validatorService.validateOrderDebitCardReq(apiRequestHeader, orderDebitCardDomainReq);
			OrderDebitCardSystemRequest orderDebitCardSystemRequest = mapSystemReq(apiRequestHeader,orderDebitCardDomainReq);
			ResponseEntity<OrderDebitCardSystemResponse> sysResEntity = clientBuilder.orderDebitCard(apiRequestHeader,orderDebitCardSystemRequest);
			
			if(null!=sysResEntity && Constant.SUCCESS_CODE.equals(sysResEntity.getCode())) {
					OrderDebitCardDomainRes orderDebitCardDomainRes = new OrderDebitCardDomainRes();
					orderDebitCardDomainRes.setReferenceNumber(apiRequestHeader.getConsumerUniqueReferenceId());
					domainResEntity = new ResponseEntity<>(sysResEntity.getCode(), sysResEntity.getMessage(), sysResEntity.getStatus(), orderDebitCardDomainRes);
			}
		}
		catch (ApiException exception) 
		{
			LOGGER.error(Constant.M_ORDER_DEBIT_CARD, apiRequestHeader.getConsumerUniqueReferenceId(), Constant.API_EXCEPTION_OCCURRED, exception.getErrorMessage());
			LOGGER.debug(Constant.M_ORDER_DEBIT_CARD, apiRequestHeader.getConsumerUniqueReferenceId(), Constant.API_EXCEPTION_OCCURRED, exception);
			throw exception;
		} 
		catch (Exception exception) 
		{
			LOGGER.error(Constant.M_ORDER_DEBIT_CARD, apiRequestHeader.getConsumerUniqueReferenceId(), Constant.EXCEPTION_OCCURRED, exception.getMessage());
			LOGGER.debug(Constant.M_ORDER_DEBIT_CARD, apiRequestHeader.getConsumerUniqueReferenceId(), Constant.EXCEPTION_OCCURRED, exception);
			throw new ApiResponseException(Constant.INTERNAL_ERROR_CODE, Constant.INTERNAL_ERROR_MSG);
		}
		return domainResEntity;
	}

	private OrderDebitCardSystemRequest mapSystemReq(ApiRequestHeader apiRequestHeader, OrderDebitCardDomainReq orderDebitCardDomainReq) {
		OrderDebitCardSystemRequest sysReq = new OrderDebitCardSystemRequest();
		PostalAddressSystemRequest addressSystemRequest = new PostalAddressSystemRequest();
		addressSystemRequest.setAddressLine1(orderDebitCardDomainReq.getLocationReference().getPostalAddressLine1());
		addressSystemRequest.setAddressLine2(orderDebitCardDomainReq.getLocationReference().getPostalAddressLine2());
		addressSystemRequest.setAddressLine3(orderDebitCardDomainReq.getLocationReference().getPostalAddressLine3());
		addressSystemRequest.setAddressLine4(orderDebitCardDomainReq.getLocationReference().getPostalAddressLine4());
		
		sysReq.setAccountNumber(orderDebitCardDomainReq.getProductInstanceReference().getAccountNumber());
		sysReq.setApiRequestHeader(apiRequestHeader);
		sysReq.setCardBranch(orderDebitCardDomainReq.getLocationReference().getCardBranch());
		sysReq.setCardNumber(orderDebitCardDomainReq.getIssuedDevicePropertyValue().getCardNumber());
		sysReq.setCustomerNumber(orderDebitCardDomainReq.getCustomerReference());
		sysReq.setEmbossedName(orderDebitCardDomainReq.getIssuedDevicePropertyValue().getEmbrossedName());
		sysReq.setPostalAddress(addressSystemRequest);
		sysReq.setProductCode(orderDebitCardDomainReq.getProductInstanceReference().getProductCode());
		return sysReq;
	}

}
