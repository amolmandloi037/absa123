package com.absa.amol.saving.builder;

import javax.ws.rs.BeanParam;
import javax.ws.rs.DELETE;

import org.eclipse.microprofile.rest.client.annotation.RegisterProvider;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

import com.absa.amol.saving.model.standinginstruction.del.StandingDelReq;
import com.absa.amol.saving.model.standinginstruction.del.StandingDelRes;
import com.absa.amol.saving.util.ServerSideExceptionMapper;
import com.absa.amol.util.model.ResponseEntity;

@RegisterRestClient(configKey = "standing.inst.del.prcs.sor.url")
@RegisterProvider(value = ServerSideExceptionMapper.class)
public interface StandingInstructionDelClientBuilder {

		@DELETE
		ResponseEntity<StandingDelRes> deleteStandingInstructionDetails(@BeanParam StandingDelReq request);
}
