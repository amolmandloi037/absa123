package com.absa.amol.saving.mapper.chequebook;

import com.absa.amol.saving.model.chequebook.ChequeBookDomainReq;
import com.absa.amol.saving.model.chequebook.ChequeBookDomainReqWrapper;
import com.absa.amol.saving.model.chequebook.ChequeBookDomainRes;
import com.absa.amol.saving.model.chequebook.IssuedDeviceOptionSetting;
import com.absa.amol.saving.model.sys.chequebook.ChequeBookReq;
import com.absa.amol.saving.model.sys.chequebook.ChequeBookRes;
import com.absa.amol.saving.model.sys.chequebook.Message;
import com.absa.amol.saving.util.Constant;
import com.absa.amol.util.exception.ApiRequestException;
import com.absa.amol.util.model.ResponseEntity;
import com.absa.amol.util.utility.CommonUtil;
import com.absa.amol.util.utility.StringUtil;

public class ChequeBookRequestMapper {

	public ChequeBookReq chequeBookReqmapping(ChequeBookDomainReqWrapper reqWrapper) {

		ChequeBookDomainReq chequeBookDomainReq = reqWrapper.getChequeBookDomainReq();
		ChequeBookReq chequeBookReq= new ChequeBookReq();
		chequeBookReq.setAccountId(chequeBookDomainReq.getProductInstanceReference());
		chequeBookReq.setCustomerNumber(chequeBookDomainReq.getCustomerReference());
		if(CommonUtil.isNotNull(chequeBookDomainReq.getBankBranch())) {
			chequeBookReq.setTransactionBranch(chequeBookDomainReq.getBankBranch().getHomeBranch());
			chequeBookReq.setCollectionBranchName(chequeBookDomainReq.getBankBranch().getCollectionBranch());
		}
		chequeBookReq.setNoOfLeaves(chequeBookDomainReq.getIssuedDeviceDescription().getChequeBookleafSize());
		chequeBookReq.setTransactionType(Constant.ZERO_STRING);
		return chequeBookReq;

	}

	public ResponseEntity<ChequeBookDomainRes> chequeBookResmapping(ResponseEntity<ChequeBookRes> chequeBookRespEntity){

		ResponseEntity<ChequeBookDomainRes> respEntity = null;
		ChequeBookDomainRes chequeBookDomainRes= new ChequeBookDomainRes();
		ChequeBookRes chequeBookRes = null;
		if(CommonUtil.isNotNull(chequeBookRespEntity)) {
			chequeBookRes =chequeBookRespEntity.getData();
			if(CommonUtil.isNotNull(chequeBookRes) && CommonUtil.isNotNull(chequeBookRes.getStatus())) {
				if(StringUtil.isStringNotNullAndNotEmpty(chequeBookRes.getStatus().getStatusCode())
						&& StringUtil.isStringNotNullAndNotEmpty(chequeBookRes.getStatus().getStatusDesc())) {
					if(Constant.EBOX_SUCCESS_STATUS_CODE.equals(chequeBookRes.getStatus().getStatusCode())) {
						chequeBookDomainRes.setIssuedDeviceTransactionDate(chequeBookRes.getStatus().getTransactionDateTimeText());
						chequeBookDomainRes.setIssuedDeviceTransactionReferenceNumber(chequeBookRes.getStatus().getExternalReferenceNo());
						respEntity = new ResponseEntity<>(Constant.SUCCESS_CODE,Constant.DATA_ADDED_SUCCESS,
								Constant.SUCCESS_MESSAGE,chequeBookDomainRes);
					}else {
						throw new ApiRequestException(Constant.BAD_REQUEST_CODE, chequeBookRes.getStatus().getStatusDesc());
					}
				} else {
					respEntity=mapFcrResponse(chequeBookRes);
				}
			}else {
				respEntity = new ResponseEntity<>(Constant.SUCCESS_CODE,"NO_DATA_FOUND",Constant.SUCCESS_MESSAGE,null);
			}
		}

		return respEntity;
	}

	private  ResponseEntity<ChequeBookDomainRes> mapFcrResponse(ChequeBookRes chequeBookRes){
		String msg = null;
		String statusMsg=Constant.SUCCESS_MESSAGE;
		String statusCode = Constant.SUCCESS_CODE;
		StringBuilder sb = new StringBuilder();
		if(chequeBookRes.getStatus().getReplyCode().equals(Constant.REPLY_CODE_0)) {
			msg = Constant.DATA_ADDED_SUCCESS;
		}else if(chequeBookRes.getStatus().getReplyCode().equals(Constant.REPLY_CODE_40)){
			if(null!=chequeBookRes.getStatus() && null!=chequeBookRes.getStatus().getReplyText() && 
					!chequeBookRes.getStatus().getReplyText().trim().isEmpty()) {
				sb.append(chequeBookRes.getStatus().getReplyText());
			}
			else {
				sb=	getMessage(chequeBookRes);
			} 
			msg = sb.toString();
		}else {
			statusMsg= Constant.FAILURE_MSG;
			statusCode = Constant.BAD_REQUEST_CODE;
			if(null!=chequeBookRes.getStatus() && null!=chequeBookRes.getStatus().getReplyText() && ! chequeBookRes.getStatus().getReplyText().trim().isEmpty()) {
				sb.append(chequeBookRes.getStatus().getReplyText());
			}
			else {
				sb=	getMessage(chequeBookRes);
			} 
			msg = sb.toString();	

		}
		ChequeBookDomainRes chequeBookDomainRes= new ChequeBookDomainRes();
		chequeBookDomainRes.setIssuedDeviceTransactionDate(chequeBookRes.getStatus().getTransactionDateTimeText());
		chequeBookDomainRes.setIssuedDeviceTransactionReferenceNumber(chequeBookRes.getStatus().getExternalReferenceNo());
		IssuedDeviceOptionSetting issuedDeviceOptionSetting = new IssuedDeviceOptionSetting();
		issuedDeviceOptionSetting.setIsServiceChargeApplied(chequeBookRes.getStatus().getIsServiceChargeApplied());
		chequeBookDomainRes.setIssuedDeviceOptionSetting(issuedDeviceOptionSetting);
		return  new ResponseEntity<>(statusCode,msg,statusMsg,chequeBookDomainRes);
		
	}

	private StringBuilder getMessage(ChequeBookRes chequeBookRes) {
		 StringBuilder sb = new StringBuilder();
		if(CommonUtil.isNotNull(chequeBookRes.getStatus()) &&
				CommonUtil.isNotNull(chequeBookRes.getStatus().getExtendedReply()) &&
				CommonUtil.isNotNull(chequeBookRes.getStatus().getExtendedReply().getMessages()) &&
				CommonUtil.isNotNull(chequeBookRes.getStatus().getExtendedReply().getMessages().getItem()))
			sb.append(!chequeBookRes.getStatus().getExtendedReply().getMessages().getItem().isEmpty() ?
					chequeBookRes.getStatus().getExtendedReply().getMessages().getItem()
					.stream().map(Message::getMsg):"");
		return sb;
	}

}
