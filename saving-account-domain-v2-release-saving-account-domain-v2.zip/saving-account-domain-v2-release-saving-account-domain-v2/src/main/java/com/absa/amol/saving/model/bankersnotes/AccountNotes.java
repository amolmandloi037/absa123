package com.absa.amol.saving.model.bankersnotes;
import org.eclipse.microprofile.openapi.annotations.media.Schema;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Schema(name = "Bankers notes response",
description = "Response Schema For Bankers notes")
public class AccountNotes {
	private String memoType;
	private String memoText;
	private String lastMaintanenceDate;
	private String severity;
	private String savingsAccountNumber;

}