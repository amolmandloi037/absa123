package com.absa.amol.saving.model.sys.actdctaccount;

import javax.json.bind.annotation.JsonbProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ValidationErrorsSys {
	
	@JsonbProperty(nillable= true)
	private String applicableAttributes;
	@JsonbProperty(nillable= true)
    private String attributeName;
    @JsonbProperty(nillable= true)
    private String attributeValue;
    @JsonbProperty(nillable= true)
    private String errorCode;
    @JsonbProperty(nillable= true)
    private String errorMessage;
    @JsonbProperty(nillable= true)
    private String methodName;
    @JsonbProperty(nillable= true)
    private String objectName;

}
